import React, { createContext, useState, useEffect } from "react";
import api from "../api";

export const AuthContext = createContext();

function parseJwt(token) {
  try {
    const base64Url = token.split(".")[1];
    if (!base64Url) return null;
    // base64url -> base64
    const base64 = base64Url.replace(/-/g, "+").replace(/_/g, "/");
    const jsonPayload = decodeURIComponent(
      atob(base64)
        .split("")
        .map(function (c) {
          return "%" + ("00" + c.charCodeAt(0).toString(16)).slice(-2);
        })
        .join("")
    );
    return JSON.parse(jsonPayload);
  } catch (e) {
    console.warn("Failed to parse JWT", e);
    return null;
  }
}

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // try to fetch /me if token exists; fallback to guest decode if /me fails
  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) {
      setLoading(false);
      return;
    }

    // Attempt to fetch /me for real users
    api
      .get("/api/users/me")
      .then((res) => {
        setUser(res.data);
      })
      .catch((err) => {
        // If /me fails (network or 401), attempt to decode token for guest
        console.warn("Could not fetch /me", err?.response?.status);

        const decoded = parseJwt(token);
        if (decoded) {
          // Common JWT field names: sub (subject), email, role, roles
          const role = (decoded.role || decoded.roles || decoded.authority || decoded.authorities || "").toString().toLowerCase();
          if (role === "guest" || role === "g" || (decoded.guest === true)) {
            // create lightweight guest user and continue
            const guestUser = {
              email: decoded.sub || decoded.email || `guest@${Date.now()}.local`,
              displayName: decoded.displayName || decoded.name || "Guest",
              role: "GUEST",
              guest: true,
            };
            setUser(guestUser);
            return;
          }
        }

        // If not a guest token, remove token and clear user
        localStorage.removeItem("token");
        setUser(null);
      })
      .finally(() => setLoading(false));
  }, []);

  const login = ({ token }) => {
    if (token) {
      localStorage.setItem("token", token);
      // try fetch /me (same logic as above)
      return api
        .get("/api/users/me")
        .then((r) => {
          setUser(r.data);
          return r.data;
        })
        .catch((err) => {
          const decoded = parseJwt(token);
          if (decoded) {
            const role = (decoded.role || decoded.roles || "").toString().toLowerCase();
            if (role === "guest" || decoded.guest === true) {
              const guestUser = {
                email: decoded.sub || decoded.email || `guest@${Date.now()}.local`,
                displayName: decoded.displayName || decoded.name || "Guest",
                role: "GUEST",
                guest: true,
              };
              setUser(guestUser);
              return guestUser;
            }
          }
          localStorage.removeItem("token");
          return Promise.reject(err);
        });
    }
    return Promise.reject(new Error("No token provided"));
  };

  const logout = () => {
    localStorage.removeItem("token");
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, setUser, login, logout, loading }}>
      {children}
    </AuthContext.Provider>
  );
}
