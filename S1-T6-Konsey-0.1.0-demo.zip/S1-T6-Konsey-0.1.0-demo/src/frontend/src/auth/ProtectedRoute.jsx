import React, { useContext } from "react";
import { Navigate } from "react-router-dom";
import { AuthContext } from "../auth/AuthProvider";


export default function ProtectedRoute({ roles, children }) {
  const { user, loading } = useContext(AuthContext);

  if (loading) {
    return <div>Loading...</div>; // or a spinner
  }

  // If not logged in, redirect to login
  if (!user) {
    return <Navigate to="/login" replace />;
  }

  // Check role
  const role = user.role?.toLowerCase() || "guest";
  if (!roles.includes(role) && !roles.includes("all")) {
    return <Navigate to="/dashboard" replace />;
  }

  return children;
}
