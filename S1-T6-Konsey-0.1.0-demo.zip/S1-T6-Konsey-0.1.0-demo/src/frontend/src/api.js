// central axios instance
import axios from "axios";

//const baseURL = process.env.REACT_APP_API_URL?.replace(/\/$/, "") || "http://auth-service:8080";

const baseURL = "http://localhost:80";

const api = axios.create({
  baseURL,
  /* headers: {
    "Content-Type": "application/json",
  }, */
});

// attach token if present
api.interceptors.request.use((config) => {
  const token = localStorage.getItem("token");
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export default api;

