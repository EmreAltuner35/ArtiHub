import React, { useState } from "react";
import api from "../api";

/**
 * ForumAttachmentPicker - Attachment picker for forum posts supporting both files and artifacts
 * 
 * Props:
 * - selectedArtifacts: Array of { artifactId, title, type: 'artifact' }
 * - selectedFiles: Array of { file: File, preview: string, type: 'file' }
 * - onArtifactsChange: (artifacts) => void
 * - onFilesChange: (files) => void
 * - showArtifactLink: boolean - Whether to show the "Link Artifact" button (for admin/researcher only)
 */
export default function ForumAttachmentPicker({
    selectedArtifacts = [],
    selectedFiles = [],
    onArtifactsChange,
    onFilesChange,
    showArtifactLink = false
}) {
    const [showPicker, setShowPicker] = useState(false);

    // Picker state
    const [folders, setFolders] = useState([]);
    const [selectedFolderId, setSelectedFolderId] = useState(null);
    const [artifacts, setArtifacts] = useState([]);
    const [loadingFolders, setLoadingFolders] = useState(false);
    const [loadingArtifacts, setLoadingArtifacts] = useState(false);
    const [folderPage, setFolderPage] = useState(0);
    const [folderTotalPages, setFolderTotalPages] = useState(1);
    const [artifactPage, setArtifactPage] = useState(0);
    const [artifactTotalPages, setArtifactTotalPages] = useState(1);

    const PAGE_SIZE = 6;
    const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB

    const fetchFolders = async (page = 0) => {
        setLoadingFolders(true);
        try {
            const res = await api.get("/api/artifacts/folders", {
                params: { page, size: PAGE_SIZE },
            });
            const data = res.data || {};
            setFolders(Array.isArray(data.content) ? data.content : []);
            setFolderPage(data.page ?? page);
            setFolderTotalPages(data.totalPages ?? 1);
        } catch (err) {
            console.error("Failed to load folders", err);
        } finally {
            setLoadingFolders(false);
        }
    };

    const fetchArtifacts = async (folderId, page = 0) => {
        setLoadingArtifacts(true);
        try {
            const res = await api.get("/api/artifacts", {
                params: { folderId, page, size: PAGE_SIZE },
            });
            const data = res.data || {};
            setArtifacts(Array.isArray(data.content) ? data.content : []);
            setArtifactPage(data.page ?? page);
            setArtifactTotalPages(data.totalPages ?? 1);
        } catch (err) {
            console.error("Failed to load artifacts", err);
        } finally {
            setLoadingArtifacts(false);
        }
    };

    const openPicker = () => {
        setShowPicker(true);
        setSelectedFolderId(null);
        fetchFolders(0);
        fetchArtifacts(null, 0);
    };

    const handleSelectFolder = (folderId) => {
        if (selectedFolderId === folderId) {
            setSelectedFolderId(null);
            setArtifactPage(0);
            fetchArtifacts(null, 0);
        } else {
            setSelectedFolderId(folderId);
            setArtifactPage(0);
            fetchArtifacts(folderId, 0);
        }
    };

    const addArtifact = (artifact) => {
        const exists = selectedArtifacts.some(a => a.artifactId === artifact.id);
        if (exists) {
            alert("This artifact is already added.");
            return;
        }
        onArtifactsChange([...selectedArtifacts, {
            artifactId: artifact.id,
            title: artifact.title || "Artifact",
            type: 'artifact'
        }]);
    };

    const removeArtifact = (artifactId) => {
        onArtifactsChange(selectedArtifacts.filter(a => a.artifactId !== artifactId));
    };

    // File upload handlers
    const handleFileUpload = (event) => {
        const files = Array.from(event.target.files);
        const validFiles = [];

        files.forEach(file => {
            if (file.size > MAX_FILE_SIZE) {
                alert(`File "${file.name}" is too large. Maximum size is 10MB.`);
                return;
            }

            // Check if file already exists
            const exists = selectedFiles.some(f => f.file.name === file.name && f.file.size === file.size);
            if (exists) {
                alert(`File "${file.name}" is already added.`);
                return;
            }

            // Create preview for images
            const isImage = file.type.startsWith('image/');
            const preview = isImage ? URL.createObjectURL(file) : null;

            validFiles.push({
                file,
                preview,
                type: 'file',
                name: file.name,
                size: file.size,
                contentType: file.type
            });
        });

        if (validFiles.length > 0) {
            onFilesChange([...selectedFiles, ...validFiles]);
        }

        event.target.value = "";
    };

    const removeFile = (index) => {
        const fileToRemove = selectedFiles[index];
        // Revoke object URL to prevent memory leaks
        if (fileToRemove.preview) {
            URL.revokeObjectURL(fileToRemove.preview);
        }
        onFilesChange(selectedFiles.filter((_, i) => i !== index));
    };

    const formatFileSize = (bytes) => {
        if (bytes < 1024) return bytes + ' B';
        if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
        return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
    };

    const hasAttachments = selectedArtifacts.length > 0 || selectedFiles.length > 0;

    return (
        <div style={{ marginTop: '12px' }}>
            {/* Attachments Display */}
            {hasAttachments && (
                <div style={{ marginBottom: '12px' }}>
                    <div style={{ fontSize: '13px', color: '#9ca3af', marginBottom: '8px' }}>
                        Attachments:
                    </div>
                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                        {/* Uploaded Files */}
                        {selectedFiles.map((fileItem, index) => (
                            <div
                                key={`file-${index}`}
                                style={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '6px',
                                    padding: '4px 10px',
                                    backgroundColor: '#4b5563',
                                    borderRadius: '6px',
                                    fontSize: '13px',
                                    color: '#e5e7eb'
                                }}
                            >
                                {fileItem.preview ? (
                                    <img
                                        src={fileItem.preview}
                                        alt=""
                                        style={{ width: 20, height: 20, objectFit: 'cover', borderRadius: 3 }}
                                    />
                                ) : (
                                    <span>📄</span>
                                )}
                                <span title={fileItem.name}>
                                    {fileItem.name.length > 20 ? fileItem.name.slice(0, 17) + '...' : fileItem.name}
                                </span>
                                <span style={{ fontSize: '11px', color: '#9ca3af' }}>
                                    ({formatFileSize(fileItem.size)})
                                </span>
                                <button
                                    type="button"
                                    onClick={() => removeFile(index)}
                                    style={{
                                        background: 'none',
                                        border: 'none',
                                        color: '#ef4444',
                                        cursor: 'pointer',
                                        padding: '0 2px',
                                        fontSize: '16px'
                                    }}
                                >
                                    ×
                                </button>
                            </div>
                        ))}

                        {/* Linked Artifacts */}
                        {selectedArtifacts.map((art) => (
                            <div
                                key={art.artifactId}
                                style={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '6px',
                                    padding: '4px 10px',
                                    backgroundColor: '#374151',
                                    borderRadius: '6px',
                                    fontSize: '13px',
                                    color: '#e5e7eb'
                                }}
                            >
                                <span>🔗 {art.title}</span>
                                <button
                                    type="button"
                                    onClick={() => removeArtifact(art.artifactId)}
                                    style={{
                                        background: 'none',
                                        border: 'none',
                                        color: '#ef4444',
                                        cursor: 'pointer',
                                        padding: '0 2px',
                                        fontSize: '16px'
                                    }}
                                >
                                    ×
                                </button>
                            </div>
                        ))}
                    </div>
                </div>
            )}

            {/* Action Buttons */}
            <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
                {/* File Upload Button */}
                <label
                    style={{
                        display: 'inline-flex',
                        alignItems: 'center',
                        gap: '6px',
                        padding: '6px 12px',
                        backgroundColor: '#8b5cf6',
                        color: 'white',
                        borderRadius: '6px',
                        cursor: 'pointer',
                        fontSize: '13px',
                        fontWeight: 500
                    }}
                >
                    📎 Upload File
                    <input
                        type="file"
                        multiple
                        onChange={handleFileUpload}
                        style={{ display: 'none' }}
                        accept="image/*,.pdf,.doc,.docx,.txt,.zip,.rar"
                    />
                </label>

                {/* Link Artifact Button - Only for Admin/Researcher */}
                {showArtifactLink && (
                    <button
                        type="button"
                        onClick={openPicker}
                        style={{
                            display: 'inline-flex',
                            alignItems: 'center',
                            gap: '6px',
                            padding: '6px 12px',
                            backgroundColor: '#06b6d4',
                            color: 'white',
                            border: 'none',
                            borderRadius: '6px',
                            cursor: 'pointer',
                            fontSize: '13px',
                            fontWeight: 500
                        }}
                    >
                        🔗 Link Artifact
                    </button>
                )}
            </div>

            {/* Artifact Picker Modal */}
            {showPicker && (
                <div
                    style={{
                        position: 'fixed',
                        top: 0,
                        left: 0,
                        right: 0,
                        bottom: 0,
                        background: 'rgba(0,0,0,0.7)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        zIndex: 1100
                    }}
                    onClick={() => setShowPicker(false)}
                >
                    <div
                        style={{
                            background: '#1f2937',
                            borderRadius: '12px',
                            padding: '24px',
                            width: '90%',
                            maxWidth: '700px',
                            maxHeight: '70vh',
                            overflow: 'auto'
                        }}
                        onClick={(e) => e.stopPropagation()}
                    >
                        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '16px' }}>
                            <h3 style={{ margin: 0, color: '#f3f4f6' }}>Link an Artifact</h3>
                            <button
                                type="button"
                                onClick={() => setShowPicker(false)}
                                style={{
                                    background: 'none',
                                    border: 'none',
                                    color: '#9ca3af',
                                    fontSize: '24px',
                                    cursor: 'pointer'
                                }}
                            >
                                ×
                            </button>
                        </div>

                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
                            {/* Folders */}
                            <div>
                                <div style={{ fontSize: '13px', fontWeight: 600, marginBottom: '8px', color: '#d1d5db' }}>
                                    Folders ({folderPage + 1}/{folderTotalPages})
                                </div>
                                <div style={{
                                    background: '#374151',
                                    borderRadius: '8px',
                                    padding: '8px',
                                    minHeight: '200px',
                                    maxHeight: '280px',
                                    overflow: 'auto'
                                }}>
                                    {loadingFolders && <div style={{ color: '#9ca3af' }}>Loading...</div>}
                                    {!loadingFolders && folders.length === 0 && (
                                        <div style={{ color: '#9ca3af' }}>No folders.</div>
                                    )}
                                    {!loadingFolders && folders.map((folder) => (
                                        <button
                                            key={folder.id}
                                            type="button"
                                            onClick={() => handleSelectFolder(folder.id)}
                                            style={{
                                                display: 'block',
                                                width: '100%',
                                                padding: '8px 12px',
                                                marginBottom: '4px',
                                                background: selectedFolderId === folder.id ? 'rgba(6,182,212,0.2)' : 'transparent',
                                                border: 'none',
                                                borderRadius: '6px',
                                                textAlign: 'left',
                                                color: '#e5e7eb',
                                                cursor: 'pointer'
                                            }}
                                        >
                                            📁 {folder.name || "(unnamed)"}
                                        </button>
                                    ))}
                                </div>
                                <div style={{ display: 'flex', gap: '8px', marginTop: '8px' }}>
                                    <button
                                        type="button"
                                        onClick={() => fetchFolders(folderPage - 1)}
                                        disabled={folderPage === 0 || loadingFolders}
                                        style={{
                                            padding: '4px 10px',
                                            background: '#4b5563',
                                            color: 'white',
                                            border: 'none',
                                            borderRadius: '4px',
                                            cursor: folderPage === 0 ? 'not-allowed' : 'pointer',
                                            opacity: folderPage === 0 ? 0.5 : 1
                                        }}
                                    >
                                        Prev
                                    </button>
                                    <button
                                        type="button"
                                        onClick={() => fetchFolders(folderPage + 1)}
                                        disabled={folderPage + 1 >= folderTotalPages || loadingFolders}
                                        style={{
                                            padding: '4px 10px',
                                            background: '#4b5563',
                                            color: 'white',
                                            border: 'none',
                                            borderRadius: '4px',
                                            cursor: folderPage + 1 >= folderTotalPages ? 'not-allowed' : 'pointer',
                                            opacity: folderPage + 1 >= folderTotalPages ? 0.5 : 1
                                        }}
                                    >
                                        Next
                                    </button>
                                </div>
                            </div>

                            {/* Artifacts */}
                            <div>
                                <div style={{ fontSize: '13px', fontWeight: 600, marginBottom: '8px', color: '#d1d5db' }}>
                                    {selectedFolderId ? "Artifacts in Folder" : "Root Artifacts"} ({artifactPage + 1}/{artifactTotalPages})
                                </div>
                                <div style={{
                                    background: '#374151',
                                    borderRadius: '8px',
                                    padding: '8px',
                                    minHeight: '200px',
                                    maxHeight: '280px',
                                    overflow: 'auto'
                                }}>
                                    {loadingArtifacts && <div style={{ color: '#9ca3af' }}>Loading...</div>}
                                    {!loadingArtifacts && artifacts.length === 0 && (
                                        <div style={{ color: '#9ca3af' }}>
                                            {selectedFolderId ? "No artifacts in folder." : "Select a folder."}
                                        </div>
                                    )}
                                    {!loadingArtifacts && artifacts.map((artifact) => (
                                        <button
                                            key={artifact.id}
                                            type="button"
                                            onClick={() => addArtifact(artifact)}
                                            style={{
                                                display: 'flex',
                                                alignItems: 'center',
                                                gap: '8px',
                                                width: '100%',
                                                padding: '8px 12px',
                                                marginBottom: '4px',
                                                background: 'transparent',
                                                border: 'none',
                                                borderRadius: '6px',
                                                textAlign: 'left',
                                                color: '#e5e7eb',
                                                cursor: 'pointer'
                                            }}
                                            onMouseEnter={(e) => e.currentTarget.style.background = 'rgba(6,182,212,0.1)'}
                                            onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}
                                        >
                                            <span style={{ fontSize: '18px' }}>📄</span>
                                            <span style={{ flex: 1, overflow: 'hidden', textOverflow: 'ellipsis' }}>
                                                {artifact.title || artifact.id}
                                            </span>
                                        </button>
                                    ))}
                                </div>
                                <div style={{ display: 'flex', gap: '8px', marginTop: '8px' }}>
                                    <button
                                        type="button"
                                        onClick={() => fetchArtifacts(selectedFolderId, artifactPage - 1)}
                                        disabled={artifactPage === 0 || loadingArtifacts}
                                        style={{
                                            padding: '4px 10px',
                                            background: '#4b5563',
                                            color: 'white',
                                            border: 'none',
                                            borderRadius: '4px',
                                            cursor: artifactPage === 0 ? 'not-allowed' : 'pointer',
                                            opacity: artifactPage === 0 ? 0.5 : 1
                                        }}
                                    >
                                        Prev
                                    </button>
                                    <button
                                        type="button"
                                        onClick={() => fetchArtifacts(selectedFolderId, artifactPage + 1)}
                                        disabled={artifactPage + 1 >= artifactTotalPages || loadingArtifacts}
                                        style={{
                                            padding: '4px 10px',
                                            background: '#4b5563',
                                            color: 'white',
                                            border: 'none',
                                            borderRadius: '4px',
                                            cursor: artifactPage + 1 >= artifactTotalPages ? 'not-allowed' : 'pointer',
                                            opacity: artifactPage + 1 >= artifactTotalPages ? 0.5 : 1
                                        }}
                                    >
                                        Next
                                    </button>
                                </div>
                            </div>
                        </div>

                        <div style={{ marginTop: '16px', textAlign: 'right' }}>
                            <button
                                type="button"
                                onClick={() => setShowPicker(false)}
                                className="btn"
                            >
                                Done
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}
