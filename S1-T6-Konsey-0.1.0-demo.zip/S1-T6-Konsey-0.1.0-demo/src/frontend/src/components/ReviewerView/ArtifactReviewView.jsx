// ArtifactReviewView.js (READ-ONLY REVIEW VERSION)

import React, { useRef, useEffect } from 'react';
import Editor from '@monaco-editor/react';
import { getMonacoDecorations } from '../comparison/utils';
import ImageArtifactReviewView from './ImageArtifactReviewView';

const ArtifactReviewView = ({
    artifact,
    annotations = [],
    editorInstances,
}) => {
    const decorationIdsRef = useRef([]);

    // -------------------- Apply decorations safely --------------------
    const applyDecorations = (editor) => {
        if (!editor) return;
        if (!Array.isArray(annotations)) return;
        if (!artifact?.content) return;

        const decorations = getMonacoDecorations(
            artifact.content,
            annotations,
            artifact.id
        );

        decorationIdsRef.current = editor.deltaDecorations(
            decorationIdsRef.current,
            decorations
        );
    };

    // -------------------- Re-apply on annotation updates --------------------
    useEffect(() => {
        const editor = editorInstances.current?.[artifact.id];
        applyDecorations(editor);
    }, [annotations, artifact.id]);

    // -------------------- Monaco mount (NO interaction hooks) --------------------
    const handleEditorDidMount = (editor, monacoInstance) => {
        if (!editor) return;

        editorInstances.current[artifact.id] = editor;
        editorInstances.current[`monaco-${artifact.id}`] = monacoInstance;

        editor.updateOptions({
            readOnly: true,
            contextmenu: false,
            selectionClipboard: false,
            quickSuggestions: false,
            occurrencesHighlight: false,
        });

        applyDecorations(editor);
    };

    // -------------------- Image artifacts (read-only overlay) --------------------
    if (artifact.type === 'image' || artifact.type?.startsWith?.('image/')) {
        return (
            <ImageArtifactReviewView
                artifact={artifact}
                annotations={annotations}
                readOnly={true}
            />
        );
    }

    // -------------------- Text / Code artifacts --------------------
    return (
        <div
            style={{
                position: 'relative',
                border: '1px solid var(--glass)',
                borderRadius: 8,
                overflow: 'hidden',
                background: 'var(--card)',
            }}
        >
            <h3
                style={{
                    color: 'var(--accent)',
                    padding: 10,
                    margin: 0,
                    borderBottom: '1px solid var(--glass)',
                    background: 'var(--card)',
                    fontSize: 16,
                }}
            >
                Artifact: {artifact.title}
            </h3>

            <div style={{ height: '50vh' }}>
                <Editor
                    height="100%"
                    language={artifact.language || artifact.type || 'plaintext'}
                    theme="vs-dark"
                    value={artifact.content || ''}
                    onMount={handleEditorDidMount}
                    options={{ readOnly:true, minimap:{enabled:true}, scrollBeyondLastLine:false, selectionClipboard:false }}
                />
            </div>
        </div>
    );
};

export default ArtifactReviewView;
