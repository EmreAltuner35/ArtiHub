// ImageArtifactReviewView.js (READ-ONLY REVIEW MODE)

import React, { useRef, useEffect, useState } from "react";

const ImageArtifactReviewView = ({
  artifact,
  annotations = []
}) => {
  const containerRef = useRef(null);
  const imgRef = useRef(null);

  const [naturalSize, setNaturalSize] = useState({ width: 0, height: 0 });
  const [displayBoxes, setDisplayBoxes] = useState([]);
  const [resizeTrigger, setResizeTrigger] = useState(0);

  // ---------------- Load natural image size ----------------
  useEffect(() => {
    const img = imgRef.current;
    if (!img) return;

    const onLoad = () => {
      setNaturalSize({
        width: img.naturalWidth || 0,
        height: img.naturalHeight || 0
      });
    };

    if (img.complete) onLoad();
    else img.addEventListener("load", onLoad);

    return () => {
      try { img.removeEventListener("load", onLoad); } catch {}
    };
  }, [artifact.url]);

  // ---------------- Resize observer ----------------
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    let timeout = null;
    const handleResize = () => {
      clearTimeout(timeout);
      timeout = setTimeout(() => {
        setResizeTrigger(v => v + 1);
      }, 100);
    };

    if (typeof ResizeObserver !== "undefined") {
      const observer = new ResizeObserver(handleResize);
      observer.observe(container);
      return () => {
        observer.disconnect();
        clearTimeout(timeout);
      };
    } else {
      window.addEventListener("resize", handleResize);
      return () => {
        window.removeEventListener("resize", handleResize);
        clearTimeout(timeout);
      };
    }
  }, [artifact.id]);

  // ---------------- Natural → Display coords ----------------
  const naturalToPxBox = (nat) => {
    const img = imgRef.current;
    if (!img || !naturalSize.width || !naturalSize.height) return null;

    const rect = img.getBoundingClientRect();
    const sx = rect.width / naturalSize.width;
    const sy = rect.height / naturalSize.height;

    return {
      x: Math.round(nat.x * sx),
      y: Math.round(nat.y * sy),
      width: Math.round(nat.width * sx),
      height: Math.round(nat.height * sy)
    };
  };

  // ---------------- Build display boxes ----------------
  useEffect(() => {
    if (!naturalSize.width || !naturalSize.height) {
      setDisplayBoxes([]);
      return;
    }

    const boxes = (annotations || [])
      .filter(a =>
        a &&
        a.artifactId === artifact.id &&
        a.x != null &&
        a.y != null &&
        a.width != null &&
        a.height != null
      )
      .map(a => {
        const px = naturalToPxBox(a);
        if (!px) return null;

        return {
          ...px,
          id: a.id,
          isHighlighted: !!a.isHighlighted || !!a.highlighted,
          text: a.annotationText || ""
        };
      })
      .filter(Boolean);

    setDisplayBoxes(boxes);
  }, [annotations, naturalSize, resizeTrigger, artifact.id]);

  // ---------------- Render ----------------
  return (
    <div
      style={{
        position: "relative",
        border: "1px solid var(--glass)",
        borderRadius: 8,
        overflow: "hidden",
        background: "var(--card)"
      }}
    >
      <h3 style={{ color: "var(--accent)", padding: 10, margin: 0 }}>
        Artifact: {artifact.title}
      </h3>

      <div
        ref={containerRef}
        style={{
          position: "relative",
          width: "100%",
          userSelect: "none"
        }}
      >
        <img
          ref={imgRef}
          src={artifact.url}
          alt={artifact.title}
          style={{
            display: "block",
            width: "100%",
            height: "auto",
            maxWidth: "100%"
          }}
          draggable={false}
        />

        {/* Existing annotation boxes */}
        {displayBoxes.map(b => (
          <div
            key={b.id}
            title={b.text}
            style={{
              position: "absolute",
              left: b.x,
              top: b.y,
              width: b.width,
              height: b.height,
              border: b.isHighlighted
                ? "2px solid rgba(0,200,120,0.95)"
                : "2px dashed rgba(0,200,120,0.95)",
              background: b.isHighlighted
                ? "rgba(0,200,120,0.12)"
                : "transparent",
              borderRadius: 4,
              boxSizing: "border-box",
              pointerEvents: "none",
              zIndex: 20
            }}
          />
        ))}
      </div>
    </div>
  );
};

export default ImageArtifactReviewView;
