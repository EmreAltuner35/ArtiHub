import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import api from "../../api";
import Navbar from "../Navbar";

const FinalizeParticipantReview = () => {
    const { studyId, participantId } = useParams();
    const navigate = useNavigate();

    const [reviews, setReviews] = useState([]);
    const [finalComment, setFinalComment] = useState("");
    const [loading, setLoading] = useState(true);
    const [submitting, setSubmitting] = useState(false);

    useEffect(() => {
        const loadReviews = async () => {
            setLoading(true);
            try {
                const res = await api.get(
                    `/api/studies/review/${studyId}/participant/${participantId}/decisions`
                );
                setReviews(res.data || []);
            } catch (err) {
                console.error("Failed to load review decisions", err);
            } finally {
                setLoading(false);
            }
        };
        loadReviews();
    }, [studyId, participantId]);

    const handleFinalize = async () => {
        setSubmitting(true);
        try {
            await api.post(`/api/studies/review/submit-final`, {
                comment: finalComment,
                studyId,
                participantId
            });
            navigate(`/study/${studyId}/list`);
        } catch (err) {
            console.error("Failed to finalize review", err);
            alert("Failed to finalize review");
        } finally {
            setSubmitting(false);
        }
    };

    if (loading) {
        return (
            <>
                <Navbar />
                <div style={{ padding: 32, textAlign: "center", color: "#fff" }}>
                    Loading review summary…
                </div>
            </>
        );
    }

    return (
        <>
            <Navbar />
            <div
                style={{
                    padding: 32,
                    maxWidth: 960,
                    margin: "0 auto",
                    display: "flex",
                    flexDirection: "column",
                    gap: 24,
                    color: "#fff",
                }}
            >
                {/* Back Button */}
                <button
                    onClick={() => navigate(-1)}
                    style={{
                        background: "#6ee7b7",
                        border: "none",
                        color: "#000",
                        cursor: "pointer",
                        fontSize: 14,
                        fontWeight: 500,
                        alignSelf: "flex-start",
                        padding: "8px 16px",
                        borderRadius: 8,
                        transition: "0.2s",
                    }}
                >
                    ← Back to submissions
                </button>

                <h1 style={{ fontSize: 28, fontWeight: 700 }}>Finalize Participant Review</h1>

                {/* ---------- Review Summary ---------- */}
                <section
                    style={{
                        padding: 20,
                        borderRadius: 12,
                        border: "1px solid var(--glass)",
                        background: "var(--card)",
                        boxShadow: "0 2px 8px rgba(0,0,0,0.5)",
                    }}
                >
                    <h2 style={{ fontSize: 20, marginBottom: 16 }}>Reviewed Submissions</h2>
                    {reviews.length === 0 ? (
                        <p style={{ color: "#aaa" }}>
                            No submissions have been reviewed yet.
                        </p>
                    ) : (
                        <table style={{ width: "100%", borderCollapse: "collapse", color: "#fff" }}>
                            <thead>
                                <tr style={{ textAlign: "left", borderBottom: "1px solid var(--glass)" }}>
                                    <th style={{ padding: "8px 12px" }}>Task</th>
                                    <th style={{ padding: "8px 12px" }}>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                {reviews.map((r) => (
                                    <tr key={r.reviewDecisionId} style={{ borderBottom: "1px solid var(--glass)" }}>
                                        <td style={{ padding: "8px 12px" }}>{r.taskTitle || "Task"}</td>
                                        <td
                                            style={{
                                                padding: "8px 12px",
                                                color: r.reviewStatus === "APPROVED" ? "#22c55e" : "#ef4444",
                                                fontWeight: 600,
                                            }}
                                        >
                                            {r.reviewStatus}
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    )}
                </section>

                {/* ---------- Final Comment ---------- */}
                <section
                    style={{
                        display: "flex",
                        flexDirection: "column",
                        gap: 8,
                    }}
                >
                    <h2 style={{ fontSize: 20 }}>Final Reviewer Comment</h2>
                    <textarea
                        value={finalComment}
                        onChange={(e) => setFinalComment(e.target.value)}
                        placeholder="Overall feedback for this participant..."
                        style={{
                            width: "100%",
                            height: 120,
                            padding: 12,
                            borderRadius: 8,
                            border: "1px solid var(--glass)",
                            background: "#1f1f1f",
                            color: "#fff",
                            fontSize: 14,
                            resize: "vertical",
                        }}
                    />
                </section>

                {/* ---------- Actions ---------- */}
                <div
                    style={{
                        display: "flex",
                        justifyContent: "flex-end",
                        gap: 12,
                    }}
                >
                    <button
                        onClick={() => navigate(-1)}
                        style={{
                            padding: "10px 20px",
                            borderRadius: 8,
                            border: "1px solid #6ee7b7",
                            background: "transparent",
                            color: "#6ee7b7",
                            fontWeight: 600,
                            cursor: "pointer",
                        }}
                    >
                        Cancel
                    </button>

                    <button
                        onClick={handleFinalize}
                        disabled={submitting}
                        style={{
                            padding: "10px 20px",
                            borderRadius: 8,
                            border: "none",
                            background: "#6ee7b7",
                            color: "#000",
                            fontWeight: 700,
                            cursor: submitting ? "not-allowed" : "pointer",
                        }}
                    >
                        {submitting ? "Submitting…" : "Finalize Review"}
                    </button>
                </div>
            </div>
        </>
    );
};

export default FinalizeParticipantReview;
