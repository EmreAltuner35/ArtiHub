import React, { useState, useEffect, useRef } from 'react';
import ArtifactReviewView from './ArtifactReviewView';
import ArtifactEditorInput from '../comparison/ArtifactEditorInput';
import MonacoViewer from './MonacoViewer';
import api from '../../api';
import { determineMonacoLanguage } from '../comparison/utils';
import { useParams } from "react-router-dom";

// Read-only Five Star Rating
const ReadOnlyFiveStar = ({ value }) => {
    const stars = Array.from({ length: 5 }, (_, i) => i + 1);
    return (
        <div style={{ display: 'flex', gap: 4, alignItems: 'center' }}>
            {stars.map(star => (
                <span
                    key={star}
                    style={{ color: star <= value ? 'gold' : 'var(--muted)', fontSize: 20 }}
                >
                    ★
                </span>
            ))}
            <span style={{ fontSize: 13, color: 'var(--muted)', marginLeft: 8 }}>
                ({value} / 5)
            </span>
        </div>
    );
};

const ParticipantReviewCard = ({ taskId, participantData, onSubmitReview }) => {
    const { studyId } = useParams();
    const editorInstances = useRef({});
    const { participantId, artifactIds, existingReviewStatus, answers } = participantData;

    const [currentStatus, setCurrentStatus] = useState(null);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [loadedArtifacts, setLoadedArtifacts] = useState([]);
    const [isArtifactLoading, setIsArtifactLoading] = useState(true);
    const [expandedArtifacts, setExpandedArtifacts] = useState({});

    useEffect(() => {
        setCurrentStatus(existingReviewStatus || null);
    }, [existingReviewStatus]);

    // Load artifacts for ARTIFACT_EDIT submissions & previews
    useEffect(() => {
        if (!artifactIds?.length) {
            setIsArtifactLoading(false);
            return;
        }

        let cancelled = false;
        const createdUrls = []; // <-- FIX: Array to track URLs for cleanup

        const loadArtifacts = async () => {
            setIsArtifactLoading(true);

            try {
                const results = await Promise.all(
                    artifactIds.map(async (artifactId) => {
                        const metaRes = await api.get(`/api/artifacts/${artifactId}`);
                        const meta = metaRes.data || {};

                        const fileRes = await api.get(
                            `/api/artifacts/${artifactId}/file?download=0`,
                            { responseType: 'blob' }
                        );
                        const blob = fileRes.data;

                        const annRes = await api.get(
                            `/api/studies/annotations/${taskId}/${artifactId}/${participantId}`
                        );
                        const annotations = (annRes.data || []).map(a => ({ ...a, isHighlighted: a.highlighted }));

                        const isImage = meta.type === 'image' || meta.type?.startsWith?.('image');
                        if (isImage) {
                            const url = URL.createObjectURL(blob);
                            createdUrls.push(url); // <-- FIX: Store URL
                            return { ...meta, id: artifactId, type: 'image', url, annotations };
                        }

                        let content = '';
                        try { content = await blob.text(); } catch {}
                        return { ...meta, id: artifactId, content, language: determineMonacoLanguage(meta), annotations };
                    })
                );

                if (!cancelled) setLoadedArtifacts(results);
            } catch (err) {
                console.error('Failed loading artifacts', err);
            } finally {
                if (!cancelled) setIsArtifactLoading(false);
            }
        };

        loadArtifacts();
        
        return () => { 
            cancelled = true; 
            createdUrls.forEach(url => URL.revokeObjectURL(url)); // <-- FIX: Revoke URLs on unmount/re-run
        };
    }, [artifactIds, participantId, studyId, taskId]); // Added taskId to dependency array for completeness

    const toggleArtifactExpand = (artifactId) => {
        setExpandedArtifacts(prev => ({ ...prev, [artifactId]: !prev[artifactId] }));
    };

    const handleSubmit = async (status) => {
        setIsSubmitting(true);
        try {
            await onSubmitReview(participantId, status);
            setCurrentStatus(status);
        } finally {
            setIsSubmitting(false);
        }
    };

    if (isArtifactLoading) return <p style={{ padding: 24, color: 'var(--muted)' }}>Loading artifacts…</p>;

    const decisionBtn = (type, active) => ({
        flex: 1,
        padding: '10px 18px',
        borderRadius: 8,
        border: 'none',
        fontWeight: 700,
        cursor: isSubmitting ? 'not-allowed' : 'pointer',
        background: type === 'APPROVED' ? active ? '#10B981' : 'rgba(16,185,129,0.25)' : active ? '#EF4444' : 'rgba(239,68,68,0.25)',
        color: active ? '#fff' : 'var(--text)',
        opacity: isSubmitting ? 0.6 : 1,
        transition: 'all 0.15s ease',
    });

    return (
        <div style={{ marginTop: 20 }}>
            {/* Existing Review */}
            {currentStatus && (
                <div style={{ background: 'var(--glass-dark)', borderLeft: '4px solid var(--accent)', padding: 10, borderRadius: 6, marginBottom: 14 }}>
                    <strong>Existing Review:</strong>{' '}
                    <span style={{ fontWeight: 700, color: currentStatus === 'APPROVED' ? '#10B981' : '#EF4444' }}>
                        {currentStatus}
                    </span>
                </div>
            )}

            {/* Artifacts preview (Moved up) */}
            <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap', marginTop: 20 }}>
                {loadedArtifacts.map(artifact => (
                    <div key={artifact.id} style={{ flex: '1 1 48%' }}>
                        <ArtifactReviewView
                            artifact={artifact}
                            annotations={artifact.annotations}
                            editorInstances={editorInstances}
                        />
                    </div>
                ))}
            </div>

            {/* Participant Answers (Moved down) */}
            <div style={{ display: 'grid', gap: 16, marginTop: 20 }}>
                {answers?.map((resp, idx) => {
                    if (resp.itemName === 'ARTIFACT_EDIT_SUBMISSION') {
                        const artifact = loadedArtifacts.find(a => a.id === resp.artifactId);
                        
                        // Use the responseText (the submission) or fall back to base content if responseText is empty/null
                        const contentToDisplay = resp.responseText || artifact?.content || '';

                        return (
                            <div key={idx} style={{ border: '1px solid var(--glass)', borderRadius: 8, marginBottom: 8, background: 'var(--card)' }}>
                                <div
                                    onClick={() => toggleArtifactExpand(resp.artifactId)}
                                    style={{ padding: 10, cursor: 'pointer', background: 'rgba(255,255,255,0.05)', display: 'flex', justifyContent: 'space-between', alignItems: 'center', userSelect: 'none' }}
                                >
                                    <strong>{resp.groupName}</strong>
                                    <span style={{ fontSize: 12, color: 'var(--muted)' }}>
                                        {expandedArtifacts[resp.artifactId] ? 'Minimize ▲' : 'Click to Open ▼'}
                                    </span>
                                </div>
                                <div style={{ display: expandedArtifacts[resp.artifactId] ? 'block' : 'none', padding: 10 }}>
                                    <MonacoViewer
                                        value={contentToDisplay} // Pass pre-loaded content directly
                                        meta={artifact || {}} // Pass metadata for language detection
                                    />
                                </div>
                            </div>
                        );
                    }

                    if (resp.score != null) {
                        return (
                            <div key={idx}>
                                <strong>{resp.groupName} - {resp.itemName}</strong>
                                <ReadOnlyFiveStar value={resp.score} />
                            </div>
                        );
                    }

                    return (
                        <div key={idx}>
                            <strong>{resp.groupName}</strong>
                            <p style={{ margin: 0, color: 'var(--muted)' }}>{resp.itemName}</p>
                        </div>
                    );
                })}
            </div>

            {/* Review Decision */}
            <div style={{ background: 'var(--card)', border: '1px solid var(--glass)', padding: 16, borderRadius: 10, marginTop: 24 }}>
                <h2 style={{ marginBottom: 12 }}>Review Decision</h2>
                <div style={{ display: 'flex', gap: 12 }}>
                    <button
                        onClick={() => handleSubmit('APPROVED')}
                        disabled={isSubmitting}
                        style={decisionBtn('APPROVED', currentStatus === 'APPROVED')}
                    >
                        {currentStatus === 'APPROVED' ? 'Approved' : 'Approve'}
                    </button>

                    <button
                        onClick={() => handleSubmit('DENIED')}
                        disabled={isSubmitting}
                        style={decisionBtn('DENIED', currentStatus === 'DENIED')}
                    >
                        {currentStatus === 'DENIED' ? 'Denied' : 'Deny'}
                    </button>
                </div>
            </div>
        </div>
    );
};

export default ParticipantReviewCard;