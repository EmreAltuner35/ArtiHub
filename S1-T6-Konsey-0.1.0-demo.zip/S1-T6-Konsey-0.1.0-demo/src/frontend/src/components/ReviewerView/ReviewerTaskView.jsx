import React, { useEffect, useState, useCallback } from 'react';
import api from "../../api";
import { useParams, useNavigate } from 'react-router-dom';
import ParticipantReviewCard from './ParticipantReviewCard';
import Navbar from '../Navbar';

const ReviewerTaskView = () => {
    const { studyId, participantId } = useParams();
    const navigate = useNavigate();

    const [reviewDtos, setReviewDtos] = useState([]);
    const [loading, setLoading] = useState(true);
    const [currentIndex, setCurrentIndex] = useState(0);

    const fetchParticipantReviews = useCallback(async () => {
        setLoading(true);
        try {
            const res = await api.get(
                `/api/studies/review/${studyId}/details/${participantId}`
            );
            setReviewDtos(res.data || []);
            setCurrentIndex(0);
        } catch (err) {
            console.error("Failed to load participant review details", err);
        } finally {
            setLoading(false);
        }
    }, [studyId, participantId]);

    useEffect(() => {
        fetchParticipantReviews();
    }, [fetchParticipantReviews]);

    const currentReviewDto = reviewDtos[currentIndex]; // <-- This can be undefined initially or if array is empty

    const handleReviewSubmit = async (participantId, status) => {
        // Need a check here to ensure currentReviewDto is defined before accessing taskId
        if (!currentReviewDto) {
            console.error("Cannot submit review: current task data is missing.");
            return;
        }

        await api.post(`/api/studies/review/submit`, {
            studyId,
            taskId: currentReviewDto.taskId,
            participantId,
            reviewStatus: status,
        });

        setReviewDtos(prev =>
            prev.map((dto, idx) =>
                idx === currentIndex
                    ? { ...dto, existingReviewStatus: status }
                    : dto
            )
        );

        if (currentIndex < reviewDtos.length - 1) {
            setCurrentIndex(i => i + 1);
        }
    };

    if (loading) {
        return (
            <>
                <Navbar />
                <p style={{ padding: 24 }}>Loading participant submissions…</p>
            </>
        );
    }
    
    // RENDER FIX: Check if there are any reviews available after loading
    if (!currentReviewDto) {
        return (
            <>
                <Navbar />
                <p style={{ padding: 24, color: 'var(--muted)' }}>
                    No tasks or submissions found for this participant.
                </p>
                <div style={{ padding: 24 }}>
                    <button
                        onClick={() => navigate(`/study/${studyId}/list`)}
                        style={{ padding: '10px 18px', borderRadius: 8, border: '1px solid var(--glass)', background: 'var(--accent)', color: '#000', fontWeight: 700, cursor: 'pointer' }}
                    >
                        ← Back to Task List
                    </button>
                </div>
            </>
        );
    }

    const pageBtn = (active) => ({
        padding: '6px 14px',
        borderRadius: 6,
        border: '1px solid var(--glass)',
        background: active ? 'var(--accent)' : 'var(--card)',
        color: active ? '#000' : 'var(--text)',
        fontWeight: active ? 700 : 500,
        cursor: 'pointer',
        minWidth: 36,
    });

    return (
        <>
            <Navbar />

            <div style={{ padding: 24 }}>
                <button
                    onClick={() => navigate(`/study/${studyId}/list`)}
                    style={{
                        padding: '10px 18px',
                        borderRadius: 8,
                        border: '1px solid var(--glass)',
                        background: 'var(--accent)',
                        color: '#000',
                        fontWeight: 700,
                        cursor: 'pointer',
                        marginBottom: 16,
                        transition: 'all 0.15s ease',
                    }}
                    onMouseEnter={e => e.currentTarget.style.background = '#6ee7b7'}
                    onMouseLeave={e => e.currentTarget.style.background = 'var(--accent)'}
                >
                    ← Back to Task List
                </button>

                <h1 style={{ marginBottom: 16 }}>
                    Reviewing Participant Submissions
                </h1>

                {/* The conditional check is now done above, so we can safely render here */}
                <ParticipantReviewCard
                    key={currentReviewDto.taskId}
                    taskId={currentReviewDto.taskId}
                    participantData={currentReviewDto}
                    onSubmitReview={handleReviewSubmit}
                />

                {/* Pagination */}
                <div
                    style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        marginTop: 30,
                        flexWrap: 'wrap',
                        gap: 16,
                    }}
                >
                    <div style={{ display: 'flex', gap: 8 }}>
                        {reviewDtos.map((_, index) => (
                            <button
                                key={index}
                                onClick={() => setCurrentIndex(index)}
                                style={pageBtn(index === currentIndex)}
                            >
                                {index + 1}
                            </button>
                        ))}
                    </div>

                    <button
                        disabled={currentIndex !== reviewDtos.length - 1}
                        onClick={() =>
                            navigate(
                                `/study/${studyId}/participant/${participantId}/review/finalize`
                            )
                        }
                        style={{
                            padding: '10px 20px',
                            borderRadius: 10,
                            border: 'none',
                            fontWeight: 700,
                            background:
                                currentIndex === reviewDtos.length - 1
                                    ? 'var(--accent)'
                                    : 'var(--glass)',
                            color:
                                currentIndex === reviewDtos.length - 1
                                    ? '#000'
                                    : 'var(--muted)',
                            cursor:
                                currentIndex === reviewDtos.length - 1
                                    ? 'pointer'
                                    : 'not-allowed',
                        }}
                    >
                        Finalize Review →
                    </button>
                </div>
            </div>
        </>
    );
};

export default ReviewerTaskView;