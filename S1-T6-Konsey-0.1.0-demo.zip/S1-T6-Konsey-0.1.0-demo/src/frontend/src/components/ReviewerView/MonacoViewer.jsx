import React from 'react';
import Editor from '@monaco-editor/react';
import { determineMonacoLanguage } from '../comparison/utils';

const MonacoViewer = ({ value, meta, height = "300px" }) => {
    const language = meta ? determineMonacoLanguage(meta) : "plaintext";

    return (
        <div style={{ border: "1px solid var(--glass)", borderRadius: 8, overflow: "hidden" }}>
            <div style={{
                background: "#0f172a",
                padding: "6px 12px",
                borderBottom: "1px solid var(--glass)",
                display: "flex",
                justifyContent: "space-between",
                fontSize: 12,
                color: "var(--muted)"
            }}>
                <span>Viewer: {language}</span>
            </div>
            
            <Editor
                height={height}
                language={language}
                theme="vs-dark"
                value={value ?? ""}
                options={{
                    readOnly: true, // Always read-only
                    minimap: { enabled: false },
                    scrollBeyondLastLine: false,
                    fontSize: 13,
                    padding: { top: 10 }
                }}
            />
        </div>
    );
};

export default MonacoViewer;