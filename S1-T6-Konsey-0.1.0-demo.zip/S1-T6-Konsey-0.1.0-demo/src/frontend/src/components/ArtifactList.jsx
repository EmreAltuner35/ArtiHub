import React from "react";
import { useNavigate } from "react-router-dom";

/**
 * Props:
 * - artifacts: Array<ArtifactDto>
 * - page: number (0-based)
 * - totalPages: number
 * - totalElements: number
 * - pageSize: number
 * - onPageChange: (nextPage: number) => void
 * - isLoading?: boolean
 * - error?: string
 */
export default function ArtifactList({
  artifacts,
  page,
  totalPages,
  totalElements,
  pageSize,
  onPageChange,
  isLoading = false,
  error = "",
  onDeleteArtifact,
}) {
  const navigate = useNavigate();

  const pageNumbers = getCompactPages(page, totalPages);

  const start = totalElements === 0 ? 0 : page * pageSize + 1;
  const end =
    totalElements === 0
      ? 0
      : Math.min(page * pageSize + artifacts.length, totalElements);

  if (error) return <div className="error">{error}</div>;
  if (!artifacts || artifacts.length === 0)
    return <div className="muted">No artifacts found.</div>;

  return (
    <>
      <div className="artifact-list-grid">
        {artifacts.map((artifact) => (
          <div key={artifact.id} className="artifact-card">
            <div className="artifact-card-header">
              <h3 className="artifact-card-title">{artifact.title}</h3>
              {artifact.isAIGenerated && (
                <span className="artifact-card-ai-badge">AI</span>
              )}
              {onDeleteArtifact && (
                <button
                  type="button"
                  title="Delete artifact"
                  onClick={() => onDeleteArtifact(artifact.id)}
                  className="icon-btn icon-btn--danger"
                >
                  X
                </button>
              )}
            </div>

            <p className="artifact-card-meta">
              Type:{" "}
              <span className="artifact-card-meta-value">
                {artifact.type}
              </span>
            </p>

            {artifact.tags && artifact.tags.length > 0 && (
              <div className="artifact-card-tags">
                {artifact.tags.map((tag, i) => (
                  <span key={i} className="artifact-tag-chip">
                    #{tag}
                  </span>
                ))}
              </div>
            )}

            <button
              onClick={() => navigate(`/artifacts/${artifact.id}`)}
              className="btn btn-sm artifact-card-view-btn"
            >
              View
            </button>
          </div>
        ))}
      </div>

      {totalPages > 1 && (
        <div className="pagination">
          <PageBtn
            label="<<"
            disabled={page === 0}
            onClick={() => onPageChange(0)}
          />
          <PageBtn
            label="<"
            disabled={page === 0}
            onClick={() => onPageChange(page - 1)}
          />

          {pageNumbers.map((p, idx) => {
            const prev = idx > 0 ? pageNumbers[idx - 1] : null;
            const showDots = prev !== null && p - prev > 1;
            return (
              <React.Fragment key={p}>
                {showDots && <Ellipsis />}
                <PageBtn
                  label={(p + 1).toString()}
                  active={p === page}
                  onClick={() => onPageChange(p)}
                />
              </React.Fragment>
            );
          })}

          <PageBtn
            label=">"
            disabled={page >= totalPages - 1}
            onClick={() => onPageChange(page + 1)}
          />
          <PageBtn
            label=">>"
            disabled={page >= totalPages - 1}
            onClick={() => onPageChange(totalPages - 1)}
          />
        </div>
      )}

      <div className="pagination-summary">
        <span>
          Page {page + 1} of {Math.max(totalPages, 1)} • Showing {start}-{end} of{" "}
          {totalElements}
        </span>
      </div>
    </>
  );
}

/** compact numbered pages with ellipses */
function getCompactPages(current, total) {
  const maxCount = 7;
  if (!total || total <= 0) return [];
  if (total <= maxCount) return Array.from({ length: total }, (_, i) => i);

  const set = new Set([
    0,
    total - 1,
    current,
    current - 1,
    current + 1,
    current - 2,
    current + 2,
  ]);
  [...set].forEach((v) => {
    if (v < 0 || v > total - 1) set.delete(v);
  });

  while (set.size < maxCount) {
    const arr = Array.from(set).sort((a, b) => a - b);
    const leftGap = arr[0] - 1;
    const rightGap = total - 1 - arr[arr.length - 1] - 1;
    if (leftGap > rightGap && arr[0] - 1 >= 0) {
      set.add(arr[0] - 1);
    } else if (arr[arr.length - 1] + 1 <= total - 1) {
      set.add(arr[arr.length - 1] + 1);
    } else break;
  }

  return Array.from(set).sort((a, b) => a - b);
}

function PageBtn({ label, onClick, disabled = false, active = false }) {
  const classNames = ["pagination-btn"];
  if (active) classNames.push("pagination-btn--active");

  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={classNames.join(" ")}
    >
      {label}
    </button>
  );
}

function Ellipsis() {
  return <span className="pagination-ellipsis">…</span>;
}
