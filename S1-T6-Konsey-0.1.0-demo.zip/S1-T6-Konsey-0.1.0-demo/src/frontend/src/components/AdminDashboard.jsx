import React, { useState } from "react";
import ManageArtifacts from "../pages/AdminPanel/ManageArtifacts";
import ManageUsers from "../pages/AdminPanel/ManageUsers";
import ManageRoleApplications from "../pages/AdminPanel/ManageRoleApplications";

export default function AdminDashboard() {
  const [tab, setTab] = useState("artifacts");

  return (
    <div>
      {/* Tabs */}
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          gap: "12px",
          marginBottom: "24px",
        }}
      >
        <button
          className="btn small"
          style={{
            background:
              tab === "artifacts" ? "var(--accent)" : "var(--glass)",
            color: tab === "artifacts" ? "#032027" : "var(--text)",
          }}
          onClick={() => setTab("artifacts")}
        >
          Manage Artifacts
        </button>

        <button
          className="btn small"
          style={{
            background: tab === "users" ? "var(--accent)" : "var(--glass)",
            color: tab === "users" ? "#032027" : "var(--text)",
          }}
          onClick={() => setTab("users")}
        >
          Manage Users
        </button>

        <button
          className="btn small"
          style={{
            background: tab === "roles" ? "var(--accent)" : "var(--glass)",
            color: tab === "roles" ? "#032027" : "var(--text)",
          }}
          onClick={() => setTab("roles")}
        >
          Role Applications
        </button>
      </div>

      {/* Content */}
      <div
        style={{
          background: "var(--card)",
          borderRadius: "12px",
          padding: "20px",
          width: "100%",
        }}
      >
        {tab === "artifacts" && <ManageArtifacts />}
        {tab === "users" && <ManageUsers />}
        {tab === "roles" && <ManageRoleApplications />}
      </div>
    </div>
  );
}
