import React, { useEffect, useState } from "react";

export default function RoleApplicationStatusModal({ application, open, onClose }) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  if (!open) return null;

  const formatDateTime = (value) => {
    if (!value) return "-";
    const d = new Date(value);
    if (Number.isNaN(d.getTime())) return value;
    return d.toLocaleString();
  };

  const statusPillStyle = (status) => {
    const base = {
      display: "inline-flex",
      alignItems: "center",
      padding: "2px 10px",
      borderRadius: "999px",
      fontSize: "12px",
      fontWeight: 600,
    };

    switch (status) {
      case "APPROVED":
        return {
          ...base,
          background: "rgba(110, 231, 183, 0.12)",
          border: "1px solid rgba(110, 231, 183, 0.7)",
          color: "var(--accent)",
        };
      case "REJECTED":
        return {
          ...base,
          background: "rgba(255, 107, 107, 0.12)",
          border: "1px solid rgba(255, 107, 107, 0.7)",
          color: "var(--danger)",
        };
      case "PENDING":
      default:
        return {
          ...base,
          background: "rgba(148, 163, 184, 0.18)",
          border: "1px solid rgba(148, 163, 184, 0.8)",
          color: "var(--muted)",
        };
    }
  };

  const renderBody = () => {
    if (loading) {
      return (
        <p className="muted" style={{ marginTop: 8 }}>
          Loading your application…
        </p>
      );
    }

    if (error) {
      return <div className="error">{error}</div>;
    }

    if (!application) {
      return (
        <p className="muted" style={{ marginTop: 8 }}>
          No application data found.
        </p>
      );
    }

    const {
      requestedRole,
      status,
      motivation,
      reviewerComment,
      reviewer,
      createdAt,
      updatedAt,
    } = application;

    return (
      <>
        {/* Role + status row */}
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            gap: 12,
            alignItems: "center",
            marginTop: 6,
          }}
        >
          <div>
            <div className="modal-label">Requested role</div>
            <div style={{ fontWeight: 600, fontSize: 14 }}>
              {requestedRole}
            </div>
          </div>
          <div style={{ textAlign: "right" }}>
            <div className="modal-label">Status</div>
            <span style={statusPillStyle(status)}>
              {status === "PENDING" && "Pending review"}
              {status === "APPROVED" && "Approved"}
              {status === "REJECTED" && "Rejected"}
            </span>
          </div>
        </div>

        {/* Motivation + reviewer comment */}
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "1.1fr 1.3fr",
            gap: 12,
            marginTop: 12,
          }}
        >
          <div>
            <div className="modal-label">Your motivation</div>
            <div className="modal-surface">
              {motivation && motivation.trim().length > 0
                ? motivation
                : "No motivation text provided."}
            </div>
          </div>

          <div>
            <div className="modal-label">Reviewer&apos;s comment</div>
            <div className="modal-surface">
              {reviewerComment && reviewerComment.trim().length > 0
                ? reviewerComment
                : status === "PENDING"
                ? "Your application is still being reviewed."
                : "No reviewer comment provided."}
            </div>
          </div>
        </div>

        {/* Reviewer info */}
        <div style={{ marginTop: 12 }}>
          <div className="modal-label">Reviewer</div>
          <div style={{ fontSize: 13 }}>
            {reviewer ? (
              <>
                {reviewer.displayName && (
                  <div style={{ fontWeight: 500 }}>
                    {reviewer.displayName}
                  </div>
                )}
                {reviewer.email && (
                  <div style={{ fontSize: 12, color: "var(--muted)" }}>
                    {reviewer.email}
                  </div>
                )}
              </>
            ) : (
              <div style={{ color: "var(--muted)" }}>Not assigned yet.</div>
            )}
          </div>
        </div>

        {/* Dates */}
        <div className="modal-meta">
          <div>
            <div>Created at</div>
            <div>{formatDateTime(createdAt)}</div>
          </div>
          <div style={{ textAlign: "right" }}>
            <div>Last updated</div>
            <div>{formatDateTime(updatedAt)}</div>
          </div>
        </div>
      </>
    );
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-card" onClick={(e) => e.stopPropagation()}>
        <div className="topbar" style={{ marginBottom: 6 }}>
          <div>
            <div
              style={{
                fontSize: 11,
                color: "var(--muted)",
                textTransform: "uppercase",
                letterSpacing: "0.08em",
              }}
            >
              Role application
            </div>
            <h2 className="modal-title">Your current status</h2>
          </div>

          <button
            type="button"
            onClick={onClose}
            style={{
              border: "none",
              background: "transparent",
              color: "var(--muted)",
              cursor: "pointer",
              fontSize: 20,
              lineHeight: 1,
              padding: "2px 4px",
            }}
            aria-label="Close"
          >
            ×
          </button>
        </div>

        {renderBody()}
      </div>
    </div>
  );
}
