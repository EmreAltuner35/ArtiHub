import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../api";

const isEditable = (status) => status !== "ACTIVE";

function formatDate(dateString) {
  if (!dateString) return "-";
  return new Date(dateString).toLocaleDateString("tr-TR");
}

export default function StudyItem({ study, onStudyDeleted = () => {} }) {
  const navigate = useNavigate();
  const [deleting, setDeleting] = useState(false);

  const editable = isEditable(study.status);
  const statusClass =
    study.status === "ACTIVE" ? "study-status-pill--active" : "study-status-pill--draft";

  const handleDelete = async () => {
    if (deleting) return;

    try {
      setDeleting(true);
      await api.delete(`/api/studies/${study.studyId}`);
      onStudyDeleted(); // call once, only on success
    } catch (error) {
      console.error("Error while deleting study:", error);
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="study-card">
      <div className="study-card-header">
        <div className="study-card-header-left">
          <h3 className="study-card-title">{study.title}</h3>
        </div>

        <span className={`study-status-pill ${statusClass}`}>{study.status}</span>
      </div>

      <p className="study-card-desc">{study.description || "No description"}</p>

      <div className="study-card-meta">
        <span>
          <strong>Starts:</strong> {formatDate(study.startDate)}
        </span>
        <span>
          <strong>Ends:</strong> {formatDate(study.endDate)}
        </span>
      </div>

      <div className="study-card-actions">
        {editable ? (
          <>
            <button
              className="btn btn-sm"
              onClick={() => navigate(`/study/${study.studyId}/tasks`)}
            >
              Manage Study
            </button>

            <button
              className="btn btn-danger btn-sm"
              onClick={handleDelete}
              disabled={deleting}
            >
              {deleting ? "Deleting…" : "Delete Study"}
            </button>
          </>
        ) : (
          <button
            className="btn btn-sm"
            onClick={() => navigate(`/study/${study.studyId}/viewstudy`)}
          >
            View Study
          </button>
        )}
      </div>
    </div>
  );
}
