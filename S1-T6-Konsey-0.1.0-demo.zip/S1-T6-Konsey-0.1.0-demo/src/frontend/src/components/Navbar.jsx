import React, { useContext } from "react";
import { Link, useLocation } from "react-router-dom";
import { AuthContext } from "../auth/AuthProvider";
import UserSearch from "../components/UserSearch";

export default function Navbar() {
  const { user } = useContext(AuthContext);
  const role = user?.role?.toLowerCase() || "guest";
  const location = useLocation();

  const baseLinks = {
    researcher: [
      { path: "/dashboard", label: "Dashboard" },
      { path: "/analytics", label: "Analytics" },
      { path: "/studies", label: "Studies" },
      { path: "/forums", label: "Forums" },
      { path: "/artifacts", label: "Artifacts" },
      { path: "/quizzes", label: "Quizzes" },
      { path: "/account", label: "Account" },
    ],
    participant: [
      { path: "/dashboard", label: "Dashboard" },
      { path: "/assignments", label: "Assignments" },
      { path: "/forums", label: "Forums" },
      { path: "/account", label: "Account" },
    ],
    reviewer: [
      { path: "/dashboard", label: "Dashboard" },
      { path: "/forums", label: "Forums" },
      { path: "/account", label: "Account" },
    ],
    admin: [
      { path: "/dashboard", label: "Dashboard" },
      { path: "/analytics", label: "Analytics" },
      { path: "/forums", label: "Forums" },
      { path: "/account", label: "Account" },
    ],
    guest: [{ path: "/dashboard", label: "Dashboard" }, { path: "/forums", label: "Forums" }],
  };

  const links = baseLinks[role] || baseLinks.guest;

  return (
    <nav
      style={{
        background: "rgba(255,255,255,0.03)",
        borderBottom: "1px solid rgba(255,255,255,0.05)",
        backdropFilter: "blur(6px)",
        padding: "10px 22px",
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        position: "sticky",
        top: 0,
        zIndex: 10,
      }}
    >
      <div style={{ fontWeight: 700, color: "var(--accent)", fontSize: 20 }}>
        ArtiHub
      </div>

      <div style={{ display: "flex", gap: "18px", alignItems: "center" }}>
        {links.map((link) => (
          <Link
            key={link.path}
            to={link.path}
            style={{
              textDecoration: "none",
              color:
                location.pathname === link.path
                  ? "var(--accent)"
                  : "var(--text)",
              fontWeight: location.pathname === link.path ? 600 : 400,
              fontSize: 14,
              transition: "color 0.2s",
            }}
          >
            {link.label}
          </Link>
        ))}

        {/* User search bar */}
        <UserSearch />
      </div>
    </nav>
  );
}
