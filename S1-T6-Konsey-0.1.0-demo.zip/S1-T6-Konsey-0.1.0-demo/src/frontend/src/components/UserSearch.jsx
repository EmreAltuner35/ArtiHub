import React, { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import api from "../api";

export default function UserSearch() {
  const [keyword, setKeyword] = useState("");
  const [results, setResults] = useState([]);
  const [page, setPage] = useState(0);
  const [totalPages, setTotalPages] = useState(0);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const containerRef = useRef(null);

  // Close dropdown if clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (containerRef.current && !containerRef.current.contains(event.target)) {
        setResults([]);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  useEffect(() => {
    if (!keyword) {
      setResults([]);
      return;
    }

    const delayDebounce = setTimeout(() => {
      fetchUsers(keyword, page);
    }, 300);

    return () => clearTimeout(delayDebounce);
  }, [keyword, page]);

  const fetchUsers = async (search, pageNum) => {
    setLoading(true);
    try {
      const { data } = await api.get("/api/users/search", {
        params: { keyword: search, page: pageNum, size: 5 },
      });
      setResults(data.results || data.content || []);
      setTotalPages(data.totalPages || 0);
    } catch (err) {
      console.error("User search error:", err);
      setResults([]);
      setTotalPages(0);
    } finally {
      setLoading(false);
    }
  };

  const handleUserClick = (id) => {
    setKeyword("");
    setResults([]);
    navigate(`/users/${id}`);
  };

  return (
    <div ref={containerRef} style={{ position: "relative" }}>
      <input
        type="text"
        placeholder="Search users..."
        value={keyword}
        onChange={(e) => {
          setKeyword(e.target.value);
          setPage(0);
        }}
        style={{
          padding: "8px 12px",
          borderRadius: 8,
          border: "1px solid rgba(255,255,255,0.03)",
          background: "var(--glass)",
          color: "var(--text)",
          outline: "none",
          fontSize: 14,
          minWidth: 200,
        }}
      />

      {keyword && results.length > 0 && (
        <div
          style={{
            position: "absolute",
            top: "36px",
            left: 0,
            background: "var(--card)",
            border: "1px solid rgba(255,255,255,0.04)",
            borderRadius: 8,
            width: "100%",
            maxHeight: 220,
            overflowY: "auto",
            boxShadow: "0 8px 30px rgba(2,6,23,0.6)",
            zIndex: 20,
          }}
        >
          {results.map((user) => (
            <div
              key={user.id}
              style={{
                padding: "8px 12px",
                borderBottom: "1px solid rgba(255,255,255,0.03)",
                cursor: "pointer",
                color: "var(--text)",
              }}
              onClick={() => handleUserClick(user.id)}
              onMouseEnter={(e) => (e.currentTarget.style.background = "rgba(255,255,255,0.05)")}
              onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
            >
              {user.displayName} <span style={{ color: "var(--muted)", fontSize: 12 }}>({user.email})</span>
            </div>
          ))}

          {totalPages > 1 && (
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                padding: "6px 12px",
                fontSize: 12,
                color: "var(--muted)",
              }}
            >
              <button
                disabled={page === 0}
                onClick={() => setPage(page - 1)}
                className="btn small"
                style={{ background: "var(--glass)" }}
              >
                Prev
              </button>
              <span>
                Page {page + 1} / {totalPages}
              </span>
              <button
                disabled={page + 1 >= totalPages}
                onClick={() => setPage(page + 1)}
                className="btn small"
                style={{ background: "var(--glass)" }}
              >
                Next
              </button>
            </div>
          )}
        </div>
      )}

      {keyword && results.length === 0 && !loading && (
        <div
          style={{
            position: "absolute",
            top: "36px",
            left: 0,
            background: "var(--card)",
            border: "1px solid rgba(255,255,255,0.04)",
            borderRadius: 8,
            width: "100%",
            padding: "8px 12px",
            zIndex: 20,
            color: "var(--muted)",
          }}
        >
          No results
        </div>
      )}
    </div>
  );
}
