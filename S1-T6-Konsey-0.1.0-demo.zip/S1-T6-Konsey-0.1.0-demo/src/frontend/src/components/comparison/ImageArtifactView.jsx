import React, { useRef, useState, useEffect } from "react";

/**
 * Props:
 * - artifact: { id, title, url }
 * - annotations: [{ id, artifactId, x, y, width, height, isHighlighted, annotationText }]
 * - setSelectionPopup
 * - setSelectedArtifact
 * - setHighlightRange (expects natural coords: { x,y,width,height })
 */
const ImageArtifactView = ({
  artifact,
  annotations = [],
  setSelectionPopup,
  setSelectedArtifact,
  setHighlightRange
}) => {
  const containerRef = useRef(null);
  const imgRef = useRef(null);

  const [isDrawing, setIsDrawing] = useState(false);
  const [startPx, setStartPx] = useState(null);
  const [boxPx, setBoxPx] = useState(null);
  const [naturalSize, setNaturalSize] = useState({ width: 0, height: 0 });

  // NEW: State to trigger re-render and recalculation on resize
  const [resizeTrigger, setResizeTrigger] = useState(0); 

  // Derived display boxes (px) computed from natural coords in annotations.
  const [displayBoxes, setDisplayBoxes] = useState([]);

  // --- 1. Load Natural Size ---
  useEffect(() => {
    const img = imgRef.current;
    if (!img) return;

    const onLoad = () => {
      setNaturalSize({ width: img.naturalWidth || 0, height: img.naturalHeight || 0 });
    };

    if (img.complete) onLoad();
    else img.addEventListener("load", onLoad);

    return () => {
      try { img.removeEventListener("load", onLoad); } catch (e) { /* ignore */ }
    };
  }, [artifact.url]);

  // --- 2. Resize Observer ---
  // Forces recalculation of display boxes whenever the container size changes.
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    // Throttle the update slightly using a delay
    let timeout = null;
    const handleResize = () => {
        clearTimeout(timeout);
        timeout = setTimeout(() => {
            setResizeTrigger(prev => prev + 1);
        }, 100); // Debounce by 100ms
    };

    if (typeof ResizeObserver !== 'undefined') {
        // Use ResizeObserver for efficient monitoring of the element's size
        const observer = new ResizeObserver(handleResize);
        observer.observe(container);
        return () => {
            observer.disconnect();
            clearTimeout(timeout);
        };
    } else {
        // Fallback to window resize (less efficient but works)
        window.addEventListener('resize', handleResize);
        return () => {
            window.removeEventListener('resize', handleResize);
            clearTimeout(timeout);
        };
    }
  }, [artifact.id]); // Re-run when artifact changes

  // --- 3. Coordinate Conversion Helpers ---

  // Helper: convert natural -> px (display)
  const naturalToPxBox = (nat) => {
    const img = imgRef.current;
    if (!img || !naturalSize.width || !naturalSize.height) return null;
    
    // Get the current displayed dimensions of the image.
    // We use the image element's clientRect as it reflects the scaled size.
    const dispRect = img.getBoundingClientRect(); 
    
    const sx = dispRect.width / naturalSize.width;
    const sy = dispRect.height / naturalSize.height;

    // parse numbers defensively
    const nx = Number(nat.x);
    const ny = Number(nat.y);
    const nw = Number(nat.width);
    const nh = Number(nat.height);
    if (!Number.isFinite(nx) || !Number.isFinite(ny) || !Number.isFinite(nw) || !Number.isFinite(nh)) return null;

    return {
      x: Math.round(nx * sx),
      y: Math.round(ny * sy),
      width: Math.round(nw * sx),
      height: Math.round(nh * sy)
    };
  };

  // Convert px-based user selection -> natural, used on mouseUp
  const pxBoxToNatural = (pxBox) => {
    const img = imgRef.current;
    if (!img || !naturalSize.width || !naturalSize.height) return null;
    const dispRect = img.getBoundingClientRect();
    const sx = naturalSize.width / dispRect.width;
    const sy = naturalSize.height / dispRect.height;

    return {
      x: Math.round(pxBox.x * sx),
      y: Math.round(pxBox.y * sy),
      width: Math.round(pxBox.width * sx),
      height: Math.round(pxBox.height * sy)
    };
  };

  // --- 4. Annotation Display Calculation ---
  // Whenever annotations, natural size, OR resizeTrigger changes, recompute displayBoxes
  useEffect(() => {
    if (!imgRef.current) return;

    // If natural size not available yet, skip — it will be recomputed after onLoad
    if (!naturalSize.width || !naturalSize.height) {
      setDisplayBoxes([]); // ensure empty until image ready
      return;
    }

    const boxes = (annotations || [])
      .filter(a => a && a.artifactId === artifact.id && a.x != null && a.y != null && a.width != null && a.height != null)
      .map(a => {
        const nat = { x: a.x, y: a.y, width: a.width, height: a.height };
        const px = naturalToPxBox(nat);
        
        // Use either 'highlighted' or 'isHighlighted' from props for flexibility
        const isHighlighted = !!a.highlighted || !!a.isHighlighted;
        
        return px ? { 
            ...px, 
            id: a.id, 
            isHighlighted: isHighlighted,
            text: a.annotationText || a.comment || "" 
        } : null;
      })
      .filter(Boolean);

    setDisplayBoxes(boxes);
  }, [annotations, naturalSize, artifact.id, resizeTrigger]); // <-- FIXED: Added resizeTrigger

  // --- 5. Mouse Handlers ---
  const onMouseDown = (e) => {
    if (e.button !== 0) return;
    const containerRect = containerRef.current.getBoundingClientRect();
    const x = e.clientX - containerRect.left;
    const y = e.clientY - containerRect.top;
    setIsDrawing(true);
    setStartPx({ x, y });
    setBoxPx({ x, y, width: 0, height: 0 });
  };

  const onMouseMove = (e) => {
    if (!isDrawing || !startPx) return;
    const containerRect = containerRef.current.getBoundingClientRect();
    const x = e.clientX - containerRect.left;
    const y = e.clientY - containerRect.top;
    const left = Math.min(startPx.x, x);
    const top = Math.min(startPx.y, y);
    const width = Math.abs(x - startPx.x);
    const height = Math.abs(y - startPx.y);
    setBoxPx({ x: left, y: top, width, height });
  };

  const onMouseUp = (e) => {
    if (!isDrawing || !boxPx) {
      setIsDrawing(false);
      setStartPx(null);
      setBoxPx(null);
      return;
    }

    setIsDrawing(false);

    if (boxPx.width < 6 || boxPx.height < 6) {
      setStartPx(null);
      setBoxPx(null);
      return;
    }

    const naturalBox = pxBoxToNatural(boxPx);
    if (!naturalBox) {
      setStartPx(null);
      setBoxPx(null);
      return;
    }

    // notify parent with NATURAL coords
    setSelectedArtifact(artifact);
    setHighlightRange(naturalBox);

    // compute popup position near selection (page coords)
    const containerRect = containerRef.current.getBoundingClientRect();
    const popupX = containerRect.left + boxPx.x + window.scrollX;
    const popupY = containerRect.top + boxPx.y + window.scrollY - 44;

    setSelectionPopup({ x: popupX, y: popupY });

    // Note: We intentionally don't clear boxPx here, allowing the parent (App.js) 
    // to clear it after save/cancel, or we could set a new state for the temporary box.
    // For now, let's clear the live box immediately since the parent handles saving.
    setBoxPx(null); 
  };

  // --- 6. Component Render ---
  return (
    <div style={{ position: "relative", border: "1px solid var(--glass)", borderRadius: 8, overflow: "hidden", background: "var(--card)" }}>
      <h3 style={{ color: "var(--accent)", padding: 10, margin: 0 }}>{artifact.title}</h3>

      <div
        ref={containerRef}
        style={{ position: "relative", display: "inline-block", width: "100%", maxWidth: "100%", cursor: "crosshair", userSelect: "none" }}
        onMouseDown={onMouseDown}
        onMouseMove={onMouseMove}
        onMouseUp={onMouseUp}
        onMouseLeave={() => { if (isDrawing) { setIsDrawing(false); } }}
      >
        <img
          ref={imgRef}
          src={artifact.url}
          alt={artifact.title}
          // The image needs to scale based on the container (which is 100% width)
          style={{ display: "block", width: "100%", height: "auto", maxWidth: "100%" }}
          draggable={false}
        />

        {/* live drawing rectangle */}
        {boxPx && (
          <div
            style={{
              position: "absolute",
              left: boxPx.x,
              top: boxPx.y,
              width: boxPx.width,
              height: boxPx.height,
              border: "2px solid rgba(24, 144, 255, 0.95)",
              background: "rgba(24, 144, 255, 0.12)",
              pointerEvents: "none",
              borderRadius: 4,
              boxSizing: "border-box",
              zIndex: 40
            }}
          />
        )}

        {/* saved boxes (from displayBoxes state) */}
        {displayBoxes.map(b => (
          <div
            key={b.id}
            title={b.text || ""}
            style={{
              position: "absolute",
              left: b.x,
              top: b.y,
              width: b.width,
              height: b.height,
              border: b.isHighlighted ? "2px solid rgba(0,200,120,0.95)" : "2px dashed rgba(0,200,120,0.95)",
              background: b.isHighlighted ? "rgba(0,200,120,0.12)" : "transparent",
              zIndex: 30,
              borderRadius: 4,
              boxSizing: "border-box",
              pointerEvents: "none"
            }}
          />
        ))}
      </div>
    </div>
  );
};

export default ImageArtifactView;