import React, { useState, useEffect, useRef } from 'react';
import Editor from '@monaco-editor/react';
import api from "../../api";
import { determineMonacoLanguage } from './utils';

const ArtifactEditorInput = ({ artifactId, value, onChange, disabled }) => {
    const [isLoading, setIsLoading] = useState(true);
    const [language, setLanguage] = useState("plaintext");

    // Tracks which artifact's text has been loaded
    const loadedArtifactIdRef = useRef(null);

    // Keep latest onChange ref stable across renders
    const onChangeRef = useRef(onChange);
    useEffect(() => { onChangeRef.current = onChange; }, [onChange]);

    useEffect(() => {
        let mounted = true;

        // If artifact changed, we'll load again
        if (artifactId !== loadedArtifactIdRef.current) {
            setIsLoading(true);
        }

        const loadArtifact = async () => {
            if (!artifactId) return;

            // 🔥 DO NOT DEPEND ON value — value may be ""
            if (artifactId === loadedArtifactIdRef.current) {
                setIsLoading(false);
                return;  // already loaded — DO NOT REFETCH
            }

            try {
                const meta = await api.get(`/api/artifacts/${artifactId}`);
                const fileRes = await api.get(
                    `/api/artifacts/${artifactId}/file?download=0`,
                    { responseType: "blob" }
                );
                const text = await fileRes.data.text();

                if (!mounted) return;

                setLanguage(determineMonacoLanguage(meta.data));

                // Write fetched artifact ONLY ONCE
                onChangeRef.current(text);

                loadedArtifactIdRef.current = artifactId;
                setIsLoading(false);
            } catch (err) {
                console.error(err);
                if (mounted) {
                    onChangeRef.current("// Error loading artifact.");
                    setIsLoading(false);
                }
            }
        };

        loadArtifact();
        return () => { mounted = false; };
    }, [artifactId]);

    const handleEditorChange = (newVal) => {
        onChange(newVal);
    };

    if (isLoading) {
        return (
            <div style={{ padding: 20, color: "var(--muted)", fontStyle: "italic" }}>
                Loading artifact...
            </div>
        );
    }

    return (
        <div style={{ border: "1px solid var(--glass)", borderRadius: 8, overflow: "hidden", marginTop: 8 }}>
            <div style={{
                background: "#0f172a",
                padding: "6px 12px",
                borderBottom: "1px solid var(--glass)",
                display: "flex",
                justifyContent: "space-between",
                fontSize: 12,
                color: "var(--muted)"
            }}>
                <span>Editing: {language}</span>
                <span>ID: {artifactId}</span>
            </div>

            <Editor
                height="300px"
                language={language}
                theme="vs-dark"
                value={value ?? ""}
                onChange={handleEditorChange}
                options={{
                    readOnly: disabled,
                    minimap: { enabled: false },
                    scrollBeyondLastLine: false,
                    fontSize: 13,
                    padding: { top: 10 }
                }}
            />
        </div>
    );
};

export default ArtifactEditorInput;
