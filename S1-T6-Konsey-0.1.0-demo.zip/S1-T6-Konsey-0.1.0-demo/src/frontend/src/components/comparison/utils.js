// utils.js

export const getLineAndColumnFromOffset = (content, offset) => {
    let line = 1;
    let column = 1;
    for (let i = 0; i < offset; i++) {
        if (content[i] === '\n') {
            line++;
            column = 1;
        } else {
            column++;
        }
    }
    return { line, column };
};

export function determineMonacoLanguage(artifact) {
    const title = artifact.title?.toLowerCase();
    const mime = artifact.contentType?.toLowerCase();
    const type = artifact.type?.toLowerCase();

    // FILE EXTENSION
    if (title) {
        if (title.endsWith(".py")) return "python";
        if (title.endsWith(".js")) return "javascript";
        if (title.endsWith(".ts")) return "typescript";
        if (title.endsWith(".java")) return "java";
        if (title.endsWith(".cpp") || title.endsWith(".h")) return "cpp";
        if (title.endsWith(".json")) return "json";
        if (title.endsWith(".sql")) return "sql";
        if (title.endsWith(".html")) return "html";
        if (title.endsWith(".css")) return "css";
        if (title.endsWith(".xml")) return "xml";
    }

    // MIME TYPE
    if (mime) {
        if (mime.includes("python")) return "python";
        if (mime.includes("javascript")) return "javascript";
        if (mime.includes("json")) return "json";
        if (mime.includes("html")) return "html";
        if (mime.includes("css")) return "css";
        if (mime.includes("java")) return "java";
        if (mime.includes("cpp")) return "cpp";
    }

    // BACKEND TYPE
    if (type === "python") return "python";
    if (type === "javascript") return "javascript";
    if (type === "java") return "java";

    return "plaintext";
}


export const getMonacoDecorations = (content, annotations, artifactId) => {
    const highlights = annotations.filter(a => a.isHighlighted && a.artifactId === artifactId);

    return highlights.map(a => {
        const startPos = getLineAndColumnFromOffset(content, a.startIndex);
        const endPos = getLineAndColumnFromOffset(content, a.endIndex);

        return {
            id: a.id,
            range: new monaco.Range(
                startPos.line,
                startPos.column,
                endPos.line,
                endPos.column
            ),
            options: {
                isStickey: true,
                className: 'monaco-review-highlight',
                hoverMessage: { value: a.comment || 'Highlighted text' },
                inlineClassName: 'monaco-review-highlight-span',
                minimap: { color: '#ff4500', position: 1 }
            }
        };
    });
};