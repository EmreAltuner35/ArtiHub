import React, { useEffect, useState, useMemo } from 'react';
import ArtifactComparisonView from './ArtifactComparisonView';
import api from '../../api';
import { determineMonacoLanguage } from './utils';

const TwoWayComparison = ({ artifactsToRender, isBlinded, ...props }) => {
    const [loadedArtifacts, setLoadedArtifacts] = useState([]);

    // 1. STABILITY FIX: Create a unique string key based on IDs.
    // This ensures useEffect only runs if the *IDs* change, not just because the array reference changed.
    const artifactIds = useMemo(() => {
        return artifactsToRender?.map(a => a.id).sort().join(',') || '';
    }, [artifactsToRender]);

    useEffect(() => {
        let isMounted = true;
        const createdUrls = []; // Track URLs to revoke them later

        async function loadAll() {
            if (!artifactsToRender?.length) return;

            // Use the prop directly here
            const inputs = artifactsToRender; 

            const results = await Promise.all(
                inputs.map(async (a) => {
                    const id = a?.id;
                    if (!id) {
                        return { ...a, content: "// Missing Artifact ID", language: "plaintext" };
                    }

                    // Optimization: If content is already passed in prop, don't fetch
                    if (a.content) {
                        return {
                            ...a,
                            language: determineMonacoLanguage(a)
                        };
                    }

                    try {
                        // Fetch Blob
                        const fileRes = await api.get(
                            `/api/artifacts/${id}/file?download=0`,
                            { responseType: "blob" }
                        );
                        const blob = fileRes.data;

                        // Check if Image (based on mimetype or type)
                        const metaRes = await api.get(`/api/artifacts/${id}`);
                        const metadata = metaRes.data || {};
                        
                        const isImage = (metadata.type && metadata.type.startsWith('image'));

                        if (isImage) {
                            const url = URL.createObjectURL(blob);
                            createdUrls.push(url); // Track for cleanup
                            return { 
                                ...a, 
                                url, 
                                type: 'image', 
                                content: null // Images don't have text content
                            };
                        } else {
                            // Handle Text
                            const content = await blob.text();
                            return {
                                ...a,
                                content,
                                language: determineMonacoLanguage(a)
                            };
                        }
                    } catch (err) {
                        console.error("Failed loading artifact content:", id, err);
                        return { ...a, content: "// Failed to load artifact", language: "plaintext" };
                    }
                })
            );

            if (isMounted) {
                setLoadedArtifacts(results);
            }
        }

        loadAll();

        // Cleanup function
        return () => {
            isMounted = false;
            // Revoke any image URLs created to free memory
            createdUrls.forEach(url => URL.revokeObjectURL(url));
        };
    // 2. DEPENDENCY FIX: Only re-run if the IDs string changes
    }, [artifactIds]); 

    return (
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
            {loadedArtifacts.map(a =>
                a?.id && <ArtifactComparisonView key={a.id} isBlinded={isBlinded} artifact={a} {...props} />
            )}
        </div>
    );
};

export default TwoWayComparison;