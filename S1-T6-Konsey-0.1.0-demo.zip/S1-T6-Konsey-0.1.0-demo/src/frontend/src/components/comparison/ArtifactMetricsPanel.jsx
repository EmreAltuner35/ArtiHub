import React, { useEffect, useState } from "react";
import api from "../../api";

const ArtifactMetricsPanel = ({ artifactId }) => {
    const [metrics, setMetrics] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        if (!artifactId) return;

        let cancelled = false;

        const fetchMetrics = async () => {
            try {
                const res = await api.get(`/api/artifacts/metrics/${artifactId}`);
                if (!cancelled) setMetrics(res.data);
            } catch (err) {
                // 404 is acceptable (no metrics calculated yet)
                if (!cancelled) setMetrics(null);
            } finally {
                if (!cancelled) setLoading(false);
            }
        };

        fetchMetrics();
        return () => { cancelled = true; };
    }, [artifactId]);

    if (loading) {
        return (
            <div style={{ padding: 10, color: "var(--muted)", fontSize: 13 }}>
                Loading metrics…
            </div>
        );
    }

    if (!metrics) {
        return (
            <div style={{ padding: 10, color: "var(--muted)", fontSize: 13 }}>
                Metrics not available.
            </div>
        );
    }

    return (
        <div
            style={{
                marginTop: 8,
                padding: 12,
                background: "var(--card)",
                borderTop: "1px solid var(--glass)",
                display: "flex",
                gap: 24,
                fontSize: 13
            }}
        >
            <div>
                <div style={{ color: "var(--muted)" }}>Cyclomatic Complexity</div>
                <div style={{ fontWeight: 600, color: "var(--accent)" }}>
                    {metrics.averageCyclomaticComplexity}
                </div>
            </div>

            <div>
                <div style={{ color: "var(--muted)" }}>Maintainability Index</div>
                <div style={{ fontWeight: 600 }}>
                    {metrics.maintainabilityIndex}
                </div>
            </div>
        </div>
    );
};

export default ArtifactMetricsPanel;
