import React, { useRef, useEffect } from 'react';
import Editor from '@monaco-editor/react';
import { getMonacoDecorations } from './utils';
import ImageArtifactView from './ImageArtifactView';
import ArtifactMetricsPanel from './ArtifactMetricsPanel';

const ArtifactComparisonView = ({
    artifact,
    annotations,
    setSelectionPopup,
    setSelectedArtifact,
    setHighlightRange,
    editorInstances,
    isBlinded,
}) => {
    const decorationIdsRef = useRef([]);

    useEffect(() => {
        const editor = editorInstances.current[artifact.id];
        if (!editor) return;
        if (artifact.type === 'image') return;

        const decorations = getMonacoDecorations(
            artifact.content,
            annotations,
            artifact.id
        );

        decorationIdsRef.current = editor.deltaDecorations(
            decorationIdsRef.current,
            decorations
        );
    }, [annotations, artifact.content, artifact.id, artifact.type, editorInstances]);

    const handleEditorDidMount = (editor, monacoInstance) => {
        if (!editor) return;

        editorInstances.current[artifact.id] = editor;
        editorInstances.current[`monaco-${artifact.id}`] = monacoInstance;

        if (annotations.length) {
            const decorations = getMonacoDecorations(
                artifact.content,
                annotations,
                artifact.id
            );
            decorationIdsRef.current = editor.deltaDecorations(
                decorationIdsRef.current,
                decorations
            );
        }

        try {
            const dom = editor.getDomNode();
            if (!dom) return;

            const onMouseUp = () => {
                const selection = editor.getSelection();
                if (!selection || selection.isEmpty()) {
                    setSelectionPopup(null);
                    return;
                }

                const selectedText = editor.getModel().getValueInRange(selection);
                if (!selectedText) {
                    setSelectionPopup(null);
                    return;
                }

                const startOffset = editor.getModel().getOffsetAt(selection.getStartPosition());
                const endOffset = editor.getModel().getOffsetAt(selection.getEndPosition());

                setSelectedArtifact(artifact);
                setHighlightRange({ startIndex: startOffset, endIndex: endOffset, selectedText });

                const rect = editor.getDomNode().getBoundingClientRect();
                const visiblePos = editor.getScrolledVisiblePosition(selection.getStartPosition());

                setSelectionPopup({
                    x: rect.left + window.scrollX,
                    y: rect.top + window.scrollY + (visiblePos?.top || 0) - 50
                });
            };

            dom.addEventListener('mouseup', onMouseUp);
            return () => dom.removeEventListener('mouseup', onMouseUp);
        } catch {
            // ignore
        }
    };

    if (artifact.type === 'image' || artifact.type?.startsWith?.('image/')) {
        return (
            <ImageArtifactView
                artifact={artifact}
                annotations={annotations}
                setSelectionPopup={setSelectionPopup}
                setSelectedArtifact={setSelectedArtifact}
                setHighlightRange={setHighlightRange}
            />
        );
    }

    return (
        <div
            key={artifact.id}
            style={{
                position: "relative",
                border: "1px solid var(--glass)",
                borderRadius: 8,
                overflow: "hidden"
            }}
        >
            <h3 style={{ color: "var(--accent)", padding: 10, margin: 0 }}>
                {isBlinded ? "Blinded Artifact" : artifact.title}
            </h3>

            <div style={{ height: "70vh" }}>
                <Editor
                    height="100%"
                    language={artifact.language || "plaintext"}
                    theme="vs-dark"
                    value={artifact.content || ""}
                    options={{
                        readOnly: true,
                        minimap: { enabled: true },
                        scrollBeyondLastLine: false,
                        selectionClipboard: false
                    }}
                    onMount={handleEditorDidMount}
                />
            </div>

            <ArtifactMetricsPanel artifactId={artifact.id} />
        </div>
    );
};

export default ArtifactComparisonView;
