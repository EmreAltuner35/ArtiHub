import React, { useEffect, useState, useMemo } from 'react';
import ArtifactComparisonView from './ArtifactComparisonView';
import api from '../../api';
import { determineMonacoLanguage } from './utils';

const ThreeWayComparison = ({ artifactsToRender, isBlinded, ...props }) => {
    const [loadedArtifacts, setLoadedArtifacts] = useState([]);

    // 1. STABILITY FIX: Generate a unique string based on IDs to prevent infinite loops
    // caused by array reference changes.
    const artifactIds = useMemo(() => {
        return artifactsToRender?.map(a => a.id).sort().join(',') || '';
    }, [artifactsToRender]);

    useEffect(() => {
        let isMounted = true;
        const createdUrls = []; // Track URLs to revoke them later

        async function loadAll() {
            if (!artifactsToRender?.length) return;

            // Use the prop directly
            const inputs = artifactsToRender;

            const results = await Promise.all(
                inputs.map(async (a) => {
                    const id = a?.id;
                    if (!id) {
                        return { ...a, content: "// Missing Artifact ID", language: "plaintext" };
                    }

                    // Optimization: If content is already passed via props, use it
                    if (a.content) {
                        return {
                            ...a,
                            language: determineMonacoLanguage(a)
                        };
                    }

                    try {
                        // Fetch Blob
                        const fileRes = await api.get(
                            `/api/artifacts/${id}/file?download=0`,
                            { responseType: "blob" }
                        );
                        const blob = fileRes.data;

                        // 2. IMAGE FIX: Check if artifact is an image
                        const metaRes = await api.get(`/api/artifacts/${id}`);
                        const metadata = metaRes.data || {};
                        
                        const isImage = (metadata.type && metadata.type.startsWith('image'));

                        if (isImage) {
                            const url = URL.createObjectURL(blob);
                            createdUrls.push(url); // Add to cleanup list
                            return { 
                                ...a, 
                                url, 
                                type: 'image', 
                                content: null 
                            };
                        } else {
                            // Handle Text/Code
                            const content = await blob.text();
                            return {
                                ...a,
                                content,
                                language: determineMonacoLanguage(a)
                            };
                        }

                    } catch (err) {
                        console.error("Failed loading artifact content:", id, err);
                        return { ...a, content: "// Failed to load artifact", language: "plaintext" };
                    }
                })
            );

            if (isMounted) {
                setLoadedArtifacts(results);
            }
        }

        loadAll();

        // Cleanup: Revoke URLs to prevent memory leaks and cancel async state updates
        return () => {
            isMounted = false;
            createdUrls.forEach(url => URL.revokeObjectURL(url));
        };
    }, [artifactIds]); // Only re-run if the IDs change

    return (
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 16 }}>
            {loadedArtifacts.map(a =>
                a?.id && <ArtifactComparisonView key={a.id} isBlinded={isBlinded} artifact={a} {...props} />
            )}
        </div>
    );
};

export default ThreeWayComparison;