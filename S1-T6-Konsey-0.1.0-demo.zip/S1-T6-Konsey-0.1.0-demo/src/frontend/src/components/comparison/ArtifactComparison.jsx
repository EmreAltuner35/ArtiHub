import React, { useState, useRef, useEffect, useContext } from 'react';
import api from "../../api"; 
import { useParams } from 'react-router-dom';
import TwoWayComparison from './TwoWayComparison';
import ThreeWayComparison from './ThreeWayComparison';
import SingleArtifactView from './SingleArtifactView';
import CriterionSubmission from './CriterionSubmission'; 
import { AuthContext } from "../../auth/AuthProvider";

const App = () => {
    const [taskData, setTaskData] = useState(null);
    const [annotations, setAnnotations] = useState([]);
    const [selectionPopup, setSelectionPopup] = useState(null);
    const [newComment, setNewComment] = useState("");
    const [isHighlighted, setIsHighlighted] = useState(false);
    const [selectedArtifact, setSelectedArtifact] = useState(null);
    const [highlightRange, setHighlightRange] = useState(null);
    const { user } = useContext(AuthContext);

    const [renderedArtifacts, setRenderedArtifacts] = useState([]); 
    const editorInstances = useRef({});
    const { studyId, taskId } = useParams();

    // --- Timer State ---
    const [elapsedTime, setElapsedTime] = useState(0); 

    const formatTime = (totalSeconds) => {
        const hours = Math.floor(totalSeconds / 3600);
        const minutes = Math.floor((totalSeconds % 3600) / 60);
        const seconds = totalSeconds % 60;
        const pad = (n) => String(n).padStart(2, '0');
        return `${pad(hours)}:${pad(minutes)}:${pad(seconds)}`;
    };

    // --- Timer Effect ---
    useEffect(() => {
        if (!taskData) return;
        const startTime = Date.now();
        const interval = setInterval(() => {
            setElapsedTime(Math.floor((Date.now() - startTime) / 1000));
        }, 1000);
        return () => clearInterval(interval);
    }, [taskData]);

    // --- Data Fetching ---
    useEffect(() => {
        const fetchTaskAndAnnotations = async () => {
            let task;
            try {
                const taskRes = await api.get(`/api/studies/${studyId}/tasks/${taskId}`);
                task = taskRes.data;
                setTaskData(task);
            } catch (err) {
                console.error("Error fetching task definition:", err);
                return;
            }

            if (!task?.artifacts?.length) return;

            // Fetch artifact metadata
            const artifactsWithMetadata = await Promise.all(
                task.artifacts.map(async (artifactId) => {
                    try {
                        const metaRes = await api.get(`/api/artifacts/${artifactId}`);
                        const data = metaRes.data;
                        // keep id consistent
                        return { ...data, id: artifactId };
                    } catch (err) {
                        console.error("Failed loading artifact metadata:", artifactId, err);
                        return { id: artifactId, title: "Error loading artifact" };
                    }
                })
            );

            setRenderedArtifacts(artifactsWithMetadata);

            // Fetch annotations for each artifact for this participant
            try {
                const annotationPromises = artifactsWithMetadata.map(artifact =>
                    api.get(`/api/studies/annotations/${taskId}/${artifact.id}/${user.id}`)
                        .then(res => ({ res, artifactId: artifact.id }))
                        .catch(err => {
                            console.warn("Annotation fetch failed for", artifact.id, err);
                            return { res: { data: [] }, artifactId: artifact.id };
                        })
                );

                const responses = await Promise.all(annotationPromises);

                // Normalize annotations into UI shape
                const allAnnotations = responses.flatMap(({ res, artifactId }) => {
                    const array = Array.isArray(res.data) ? res.data : (res.data?.data || []);
                    return array.map(a => ({
                        id: a.annotationId || a.annotationId, // may be UUID
                        artifactId: artifactId,
                        // FIX: Check for both 'isHighlighted' (local convention) and 'highlighted' (backend response)
                        isHighlighted: !!a.isHighlighted || !!a.highlighted, 
                        // END FIX
                        comment: a.annotationText || a.annotation_text || "",
                        // text fields (nullable)
                        startIndex: a.startIndex ?? a.start_index ?? null,
                        endIndex: a.endIndex ?? a.end_index ?? null,
                        // image fields (nullable)
                        x: a.x ?? null,
                        y: a.y ?? null,
                        width: a.width ?? null,
                        height: a.height ?? null,
                        timestamp: a.timestamp || a.createdAt || null
                    }));
                });

                setAnnotations(allAnnotations);
            } catch (err) {
                console.error("Error fetching annotations:", err);
            }
        };

        if (studyId && taskId && user?.id) fetchTaskAndAnnotations();
    }, [studyId, taskId, user?.id]);

    // --- Annotation saving ---
    const addAnnotation = async () => {
        if (!highlightRange || !selectedArtifact) return;

        // Build payload based on whether highlightRange is text-based or image-based
        const payload = {
            taskId,
            artifactId: selectedArtifact.id,
            participantId: user.id,
            // Backend expects 'highlighted', not 'isHighlighted'
            highlighted: isHighlighted, 
            annotationText: newComment || null
        };

        const isImageAnnotation = highlightRange && typeof highlightRange.x === 'number' && typeof highlightRange.y === 'number';
        const isTextAnnotation = highlightRange && typeof highlightRange.startIndex === 'number' && typeof highlightRange.endIndex === 'number';

        if (isTextAnnotation) {
            payload.startIndex = highlightRange.startIndex;
            payload.endIndex = highlightRange.endIndex;
        } else if (isImageAnnotation) {
            // Round numbers to ints to avoid floats
            payload.x = Math.round(highlightRange.x);
            payload.y = Math.round(highlightRange.y);
            payload.width = Math.round(highlightRange.width);
            payload.height = Math.round(highlightRange.height);
        } else {
            console.warn("Unknown highlightRange shape; aborting save.", highlightRange);
            return;
        }

        try {
            const res = await api.post("/api/studies/annotations", payload);
            const responseData = res.data;

            // Normalize response to UI shape
            const created = {
                id: responseData.annotationId || responseData.annotationId || (Date.now().toString()),
                artifactId: selectedArtifact.id,
                // Ensure new annotation is normalized correctly (checking both fields)
                isHighlighted: !!responseData.isHighlighted || !!responseData.highlighted,
                comment: responseData.annotationText || responseData.annotation_text || payload.annotationText || "",
                startIndex: responseData.startIndex ?? responseData.start_index ?? payload.startIndex ?? null,
                endIndex: responseData.endIndex ?? responseData.end_index ?? payload.endIndex ?? null,
                x: responseData.x ?? payload.x ?? null,
                y: responseData.y ?? payload.y ?? null,
                width: responseData.width ?? payload.width ?? null,
                height: responseData.height ?? payload.height ?? null,
                timestamp: responseData.timestamp || null
            };

            setAnnotations(prev => [...prev, created]);

            // reset popup + form
            setSelectionPopup(null);
            setNewComment("");
            setIsHighlighted(false);
            setHighlightRange(null);

            // Clear Monaco selection if the annotation was text-based
            if (isTextAnnotation) {
                const editor = editorInstances.current[selectedArtifact.id];
                const monacoInstance = editorInstances.current[`monaco-${selectedArtifact.id}`];
                if (editor && monacoInstance) {
                    try {
                        editor.setSelection(new monacoInstance.Selection(0,0,0,0));
                    } catch (err) {
                        // ignore if selection API differs
                    }
                }
            }
        } catch (err) {
            console.error("Error saving annotation:", err);
        }
    };

    const deleteAnnotation = async (annotationId) => {
        if (!window.confirm("Are you sure you want to delete this annotation?")) return;
        try {
            await api.delete(`/api/studies/annotations/${annotationId}`);
            setAnnotations(prev => prev.filter(a => a.id !== annotationId));
        } catch (err) {
            console.error("Error deleting annotation:", err);
        }
    };

    // --- Popup click outside ---
    useEffect(() => {
        const handleClickOutside = e => {
            const popupEl = document.getElementById("annotation-popup");
            if (selectionPopup && popupEl && !popupEl.contains(e.target)) {
                setSelectionPopup(null);
            }
        };
        document.addEventListener("mousedown", handleClickOutside);
        return () => document.removeEventListener("mousedown", handleClickOutside);
    }, [selectionPopup]);

    // --- Render artifact view ---
    const renderComparisonView = () => {
        if (!taskData) return <p style={{ color: 'var(--muted)' }}>Loading task definition...</p>;

        const commonProps = { annotations, setSelectionPopup, setSelectedArtifact, setHighlightRange, editorInstances };

        switch (taskData.viewType) {
            case 'SINGLE':
                return <SingleArtifactView artifactsToRender={renderedArtifacts.slice(0,1)} isBlinded={taskData.blinded} {...commonProps} />;
            case 'THREE_WAY':
                return <ThreeWayComparison artifactsToRender={renderedArtifacts} isBlinded={taskData.blinded} {...commonProps} />;
            case 'SIDE_BY_SIDE':
            default:
                return <TwoWayComparison artifactsToRender={renderedArtifacts.slice(0,2)} isBlinded={taskData.blinded} {...commonProps} />;
        }
    };

    // --- Submission ---
    const renderSubmissionComponent = () => {
        if (!taskData?.criteria?.length) {
            return <div style={{ padding:16, background:'var(--card)', color:'var(--muted)', marginTop:20 }}>
                {taskData?.scaleType} Submission (Criteria not defined or loaded).
            </div>;
        }

        return <CriterionSubmission
            renderedArtifacts={renderedArtifacts}
            criteriaList={taskData.criteria}
            annotations={annotations}
            submissionTimeSeconds={elapsedTime}
        />;
    };

    return (
        <div style={{ padding:24, color:'var(--text)' }}>
            <style>{`
                .monaco-review-highlight-span {
                    background-color: rgba(110, 231, 183, 0.2);
                    border-bottom: 2px solid var(--accent);
                }
            `}</style>

            <div style={{ color: 'var(--accent)', fontSize: 16, fontWeight: 600, marginBottom: 10 }}>
                Time Elapsed: {formatTime(elapsedTime)}
            </div>
            
            <h1>Artifact Comparison: {taskData?.name || "Loading..."}</h1>

            <div style={{ marginTop: 20 }}>{renderComparisonView()}</div>
            {renderSubmissionComponent()}

            {/* Annotations list */}
            <div style={{ marginTop:20 }}>
                <h2>Annotations</h2>
                {annotations.length === 0 && <div style={{ color: 'var(--muted)', padding: 12 }}>No annotations yet.</div>}
                {annotations.map(a => (
                    <div key={a.id} style={{ padding:12, background:'var(--card)', border:'1px solid var(--glass)', borderRadius:8, marginBottom:10, display:'flex', justifyContent:'space-between', alignItems:'center' }}>
                        <div>
                            <strong style={{color:'var(--accent)'}}>{a.artifactId}</strong>
                            {' '}
                            { (a.startIndex !== null && a.endIndex !== null) ? (
                                <span style={{color:'var(--muted)', marginLeft:8}}>[{a.startIndex}-{a.endIndex}]</span>
                            ) : ( (a.x !== null && a.y !== null) ? (
                                <span style={{color:'var(--muted)', marginLeft:8}}>[x:{a.x}, y:{a.y}, w:{a.width}, h:{a.height}]</span>
                            ) : null ) }
                            {a.isHighlighted && <span style={{ marginLeft:8, color:'var(--accent)', fontWeight:600}}>[HIGHLIGHTED]</span>}
                            <div style={{ fontSize:14, color:'var(--text)', opacity:0.9, marginTop:4 }}>{a.comment}</div>
                        </div>
                        <button onClick={() => deleteAnnotation(a.id)} style={{ background:'var(--danger)', color:'white', border:'none', borderRadius:6, padding:'6px 12px', fontSize:12, cursor:'pointer', fontWeight:600 }}>Delete</button>
                    </div>
                ))}
            </div>

            {/* Selection Popup */}
            {selectionPopup && (
                <div id="annotation-popup" style={{ position:'absolute', top:selectionPopup.y, left:selectionPopup.x, width:320, padding:16, background:'var(--card)', border:'1px solid var(--glass)', boxShadow:"0 8px 30px rgba(2,6,23,0.6)", zIndex:999 }}>
                    <label style={{ display:"block", fontSize:13, color:'var(--muted)', marginBottom:6 }}>
                        <input type="checkbox" checked={isHighlighted} onChange={e=>setIsHighlighted(e.target.checked)} style={{ marginRight:6 }}/> Highlight selected
                    </label>

                    <textarea value={newComment} onChange={e=>setNewComment(e.target.value)} placeholder="Write comment (optional)" style={{ width:'100%', height:70, marginTop:8, padding:10, borderRadius:8, background:'#0b1f23', border:'1px solid rgba(255,255,255,0.08)', color:'var(--text)', outline:'none', fontSize:13, resize:'none' }}/>

                    <div style={{ display:'flex', gap:8, marginTop:10 }}>
                        <button onClick={addAnnotation} style={{ flex:1, padding:10, borderRadius:8, background:'var(--accent)', color:'white', border:'none', cursor:'pointer' }}>Save</button>
                        <button onClick={()=>{ setSelectionPopup(null); setHighlightRange(null); setNewComment(""); setIsHighlighted(false); }} style={{ flex:1, padding:10, borderRadius:8, border:'1px solid var(--glass)', background:'var(--card)', color:'var(--muted)', cursor:'pointer' }}>Cancel</button>
                    </div>
                </div>
            )}
        </div>
    );
};

export default App;