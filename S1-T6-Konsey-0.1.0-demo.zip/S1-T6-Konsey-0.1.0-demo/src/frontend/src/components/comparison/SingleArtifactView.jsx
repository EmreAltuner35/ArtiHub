import React, { useEffect, useState } from 'react';
import ArtifactComparisonView from './ArtifactComparisonView';
import api from '../../api';
import { determineMonacoLanguage } from './utils';

const SingleArtifactView = ({ artifactsToRender, isBlinded, ...props }) => {
    const [loaded, setLoaded] = useState(null);

    const targetArtifact = artifactsToRender?.[0];
    const targetId = targetArtifact?.id;

    useEffect(() => {
        if (!targetId) {
            setLoaded(null);
            return;
        }

        let cancelled = false;

        const loadArtifact = async (artifactId) => {
            try {
                const metaRes = await api.get(`/api/artifacts/${artifactId}`);
                const metadata = metaRes.data || {};

                // If artifact is an image (mimetype or type), fetch as blob and create object URL
                const isImage = (metadata.type && metadata.type.startsWith('image'));

                if (isImage) {
                    const fileRes = await api.get(`/api/artifacts/${artifactId}/file?download=0`, { responseType: 'blob' });
                    const blob = fileRes.data;
                    const url = URL.createObjectURL(blob);

                    const result = { ...metadata, url, id: artifactId, type: 'image' };
                    if (!cancelled) return result;
                    return null;
                } else {
                    // assume text file
                    const fileRes = await api.get(`/api/artifacts/${artifactId}/file?download=0`, { responseType: 'blob' });
                    const blob = fileRes.data;
                    // Try to read text; if fails, fallback to object URL
                    let content = "";
                    try {
                        content = await blob.text();
                    } catch (err) {
                        // binary -> create object URL instead (won't be displayed as text)
                        const url = URL.createObjectURL(blob);
                        if (!cancelled) return { ...metadata, url, id: artifactId, type: metadata.type || 'plaintext' };
                        return null;
                    }
                    const language = determineMonacoLanguage(metadata);
                    const result = { ...metadata, content, language, id: artifactId };
                    if (!cancelled) return result;
                    return null;
                }
            } catch (err) {
                console.error("Failed loading artifact:", err);
                return { id: artifactId, title: "Error loading artifact" };
            }
        };

        (async () => {
            const art = await loadArtifact(targetId);
            if (!cancelled) setLoaded(art);
        })();

        return () => { cancelled = true; };
    }, [targetId]);

    if (!artifactsToRender?.length) {
        return <p style={{ color: 'var(--muted)' }}>No artifact loaded.</p>;
    }

    return (
        <div style={{ display: "grid", gridTemplateColumns: "1fr", gap: 16 }}>
            {loaded && <ArtifactComparisonView artifact={loaded} isBlinded={isBlinded} {...props} />}
        </div>
    );
};

export default SingleArtifactView;
