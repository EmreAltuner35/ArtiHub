import React, { useState, useContext, useCallback, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import api from "../../api";
import { AuthContext } from "../../auth/AuthProvider"; 
import ArtifactEditorInput from './ArtifactEditorInput';

// --- Sub-component: Five Star Rating ---
const FiveStarRating = ({ metricName, value, onChange, disabled }) => {
    const stars = Array.from({ length: 5 }, (_, i) => i + 1);
    const ratingValue = value || 0; 

    return (
        <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
            {stars.map(star => (
                <span
                    key={star}
                    onClick={() => !disabled && onChange(metricName, star)}
                    style={{
                        cursor: disabled ? 'default' : 'pointer',
                        color: star <= ratingValue ? 'gold' : 'var(--muted)',
                        fontSize: '20px',
                        transition: 'color 0.1s ease',
                    }}
                >
                    ★
                </span>
            ))}
            <span style={{ fontSize: 13, color: 'var(--muted)', marginLeft: 8 }}>
                ({ratingValue} / 5)
            </span>
        </div>
    );
};

// --- Main Component: CriterionSubmission ---
const CriterionSubmission = ({ criteriaList, annotations, renderedArtifacts, submissionTimeSeconds }) => {
    const { studyId, taskId } = useParams();
    const navigate = useNavigate();
    const { user } = useContext(AuthContext);
    const participantId = user?.id;
    
    // --- State Initialization ---
    const [multiChoiceSelections, setMultiChoiceSelections] = useState(() => {
        const initialState = {};
        criteriaList.filter(c => c.scaleType === 'MULTIPLE_CHOICE').forEach(c => initialState[c.criterionID] = '');
        return initialState;
    });

    const [fiveStarSelections, setFiveStarSelections] = useState(() => {
        const initialState = {};
        criteriaList.filter(c => c.scaleType === 'FIVESTAR').forEach(c => initialState[c.criterionID] = {});
        return initialState;
    });

    // Use null for initialization to distinguish between "loaded empty string" vs "not loaded yet"
    const [artifactEdits, setArtifactEdits] = useState(() => {
        const initialState = {};
        criteriaList.filter(c => c.scaleType === 'ARTIFACT_EDIT').forEach(c => initialState[c.criterionID] = null);
        return initialState;
    });

    // New State: Track expanded/collapsed status for ARTIFACT_EDIT
    const [expandedCriteria, setExpandedCriteria] = useState({});

    const [isSubmitting, setIsSubmitting] = useState(false);
    
    const artifactSubject = renderedArtifacts.length === 1 
        ? renderedArtifacts[0].name 
        : `Artifacts: ${renderedArtifacts.map(a => a.id).join(', ')}`;

    // --- Helper: Map Edit Questions to Artifacts ---
    const artifactMapping = useMemo(() => {
        const mapping = {};
        const editCriteria = criteriaList.filter(c => c.scaleType === 'ARTIFACT_EDIT');
        
        editCriteria.forEach((criterion, index) => {
            if (criterion.options[0]) {
                mapping[criterion.criterionID] = criterion.options[0];
            } else if (renderedArtifacts[index]) {
                // Map Nth question to Nth artifact
                mapping[criterion.criterionID] = renderedArtifacts[index].id;
            } else {
                // Fallback
                mapping[criterion.criterionID] = renderedArtifacts[0]?.id;
            }
        });
        return mapping;
    }, [criteriaList, renderedArtifacts]);

    // --- Validation Logic ---
    const allCriteriaSelected = criteriaList.every(criterion => {
        if (criterion.scaleType === 'MULTIPLE_CHOICE') {
            return multiChoiceSelections[criterion.criterionID] !== ''; 
        } else if (criterion.scaleType === 'FIVESTAR') {
            const val = fiveStarSelections[criterion.criterionID];
            return typeof val === 'object' && Object.keys(val).length > 0 && criterion.options.every(m => val[m] > 0);
        } else if (criterion.scaleType === 'ARTIFACT_EDIT') {
            // Ensure content has loaded (is not null)
            return artifactEdits[criterion.criterionID] !== null;
        }
        return false;
    });

    // --- Handlers ---
    const handleMultiChoiceChange = (criterionID, value) => {
        setMultiChoiceSelections(prev => ({ ...prev, [criterionID]: value }));
    };
    
    const handleFiveStarChange = (criterionID, metricName, rating) => {
        setFiveStarSelections(prev => ({
            ...prev,
            [criterionID]: { ...(prev[criterionID] || {}), [metricName]: rating }
        }));
    };

    const handleArtifactEditChange = useCallback((criterionID, newValue) => {
        setArtifactEdits(prev => ({
            ...prev,
            [criterionID]: newValue
        }));
    }, []);

    const toggleCriterionExpand = (criterionID) => {
        setExpandedCriteria(prev => ({
            ...prev,
            [criterionID]: !prev[criterionID]
        }));
    };

    // --- Submission ---
    const handleSubmit = async () => { 
        if (!allCriteriaSelected) {
            alert("Please complete all fields (wait for editors to load) before submitting.");
            return;
        }
        setIsSubmitting(true);
        
        const criteriaResponses = [];
        
        criteriaList.forEach(criterion => {
            if (criterion.scaleType === 'MULTIPLE_CHOICE') {
                const val = multiChoiceSelections[criterion.criterionID];
                criteriaResponses.push({ groupName: criterion.name, itemName: val || null, score: null });
            } else if (criterion.scaleType === 'FIVESTAR') {
                const sel = fiveStarSelections[criterion.criterionID];
                criterion.options.forEach(metric => {
                    if (sel && sel[metric]) {
                        criteriaResponses.push({ groupName: criterion.name, itemName: metric, score: sel[metric] });
                    }
                });
            } else if (criterion.scaleType === 'ARTIFACT_EDIT') {
                const editedContent = artifactEdits[criterion.criterionID];
                criteriaResponses.push({
                    groupName: criterion.name,
                    itemName: "ARTIFACT_EDIT_SUBMISSION", 
                    responseText: editedContent,
                    score: null
                });
            }
        });

        const submissionPayload = {
            studyId, taskId, participantId,
            criteriaResponses, 
            linkedAnnotationIds: annotations.map(a => a.id),
            submissionTime: submissionTimeSeconds
        };

        try {
            const response = await api.post("/api/studies/submissions", submissionPayload);

            navigate(`/${studyId}/tasks`);
            alert(`Submitted! ID: ${response.data.id || 'OK'}`);
        } catch (error) {
            console.error("Submission error:", error);
            alert(`Failed: ${error.message}`);
        } finally {
            setIsSubmitting(false);
        }
    };

    // --- Render Individual Input ---
    const renderCriterionInput = (criterion) => {
        if (criterion.scaleType === 'MULTIPLE_CHOICE') {
            return (
                <div style={{ marginBottom: 5 }}>
                    <label style={{ color: 'var(--muted)', fontSize: 14, marginBottom: 4, display: 'block' }}>{criterion.name}:</label>
                    <select
                        className="input-dark" 
                        value={multiChoiceSelections[criterion.criterionID] || ''}
                        onChange={(e) => handleMultiChoiceChange(criterion.criterionID, e.target.value)}
                        style={{ width: '100%', padding: '10px 12px' }}
                        disabled={isSubmitting}
                    >
                        <option value="" disabled>-- Select --</option>
                        {criterion.options.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                    </select>
                </div>
            );
        } 
        
        if (criterion.scaleType === 'FIVESTAR') {
            const ratings = fiveStarSelections[criterion.criterionID] || {};
            return (
                <div style={{ marginBottom: 5 }}>
                    <label style={{ color: 'var(--muted)', fontSize: 14, marginBottom: 4, display: 'block' }}>{criterion.name}:</label>
                    <div style={{ display: 'grid', gap: 8, marginTop: 8 }}>
                        {criterion.options.map(metric => (
                            <div key={`${criterion.criterionID}_${metric}`} style={{ display: 'flex', justifyContent: 'space-between' }}>
                                <span style={{ color: 'var(--muted)', fontSize: 13 }}>{metric}:</span>
                                <FiveStarRating 
                                    metricName={metric}
                                    value={ratings[metric]}
                                    onChange={(name, r) => handleFiveStarChange(criterion.criterionID, name, r)}
                                    disabled={isSubmitting}
                                />
                            </div>
                        ))}
                    </div>
                </div>
            );
        }

        if (criterion.scaleType === 'ARTIFACT_EDIT') {
            const targetId = artifactMapping[criterion.criterionID];
            const isExpanded = !!expandedCriteria[criterion.criterionID];

            if (!targetId) {
                return <div style={{ color: 'var(--danger)', fontSize: 13 }}>Loading editor...</div>;
            }

            return (
                <div style={{ border: '1px solid var(--glass)', borderRadius: 8, overflow: 'hidden', background: 'var(--card)' }}>
                    {/* Header / Toggle Button */}
                    <div 
                        onClick={() => toggleCriterionExpand(criterion.criterionID)}
                        style={{ 
                            padding: '12px 16px', 
                            cursor: 'pointer', 
                            background: 'rgba(255,255,255,0.05)', 
                            display: 'flex', 
                            justifyContent: 'space-between', 
                            alignItems: 'center',
                            userSelect: 'none'
                        }}
                    >
                        <span style={{ fontWeight: 600, color: 'var(--accent)' }}>
                             {criterion.name}
                        </span>
                        <span style={{ fontSize: 12, color: 'var(--muted)', opacity: 0.8 }}>
                            {isExpanded ? "Minimize ▲" : "Click to Open ▼"}
                        </span>
                    </div>

                    {/* Editor Content - Using display:none instead of conditional rendering to keep state/fetch alive */}
                    <div style={{ display: isExpanded ? 'block' : 'none', padding: 12, borderTop: '1px solid var(--glass)' }}>
                        <ArtifactEditorInput
                            artifactId={targetId}
                            value={artifactEdits[criterion.criterionID]}
                            onChange={(val) => handleArtifactEditChange(criterion.criterionID, val)}
                            disabled={isSubmitting}
                        />
                    </div>
                </div>
            );
        }
        
        return <p>Unsupported type</p>;
    };

    return (
        <div style={{ padding: 24, background: 'var(--card)', border: '1px solid var(--glass)', borderRadius: 8, marginTop: 20 }}>
            <h2 style={{ fontSize: 20, margin: '0 0 16px 0', color: 'var(--text)' }}>Questions</h2>
            
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
                {criteriaList.map(c => (
                    <div 
                        key={c.criterionID} 
                        style={{ 
                            // Span 2 columns for ARTIFACT_EDIT to give it full width
                            gridColumn: (c.scaleType === 'FIVESTAR' || c.scaleType === 'ARTIFACT_EDIT') ? 'span 2' : 'span 1' 
                        }}
                    >
                        {renderCriterionInput(c)}
                    </div>
                ))}
            </div>

            <button className="btn" onClick={handleSubmit} disabled={!allCriteriaSelected || isSubmitting} style={{ width: '100%', marginTop: 30 }}>
                {isSubmitting ? 'Submitting...' : 'Finalize Task Submission'}
            </button>
        </div>
    );
};

export default CriterionSubmission;