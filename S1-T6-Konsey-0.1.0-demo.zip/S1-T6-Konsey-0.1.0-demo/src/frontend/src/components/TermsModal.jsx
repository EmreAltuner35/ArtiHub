import React from "react";

export default function TermsModal({ onAgree, onClose }) {
  return (
    <div className="modal-overlay" role="dialog" aria-modal="true" aria-label="Terms and Conditions">
      <div className="modal modal--md modal--solid">
        <div className="modal-header">
          <h2 className="modal-title">ArtHub Terms & Acceptable Use</h2>
          <button type="button" className="modal-close" onClick={onClose} aria-label="Close">
            ✕
          </button>
        </div>

        <div className="modal-body">
          <div className="terms-scroll">
            <p>
              ArtHub is a research workflow platform where you can create studies, upload artifacts, invite participants/reviewers,
              and view analytics. By using ArtHub, you agree to the terms below.
            </p>

            <h3>1) Accounts and roles</h3>
            <ul>
              <li>You are responsible for activity under your account (including guest sessions on your device).</li>
              <li>Role-based features (e.g., researcher/reviewer) may require approval by administrators.</li>
            </ul>

            <h3>2) Content you upload</h3>
            <ul>
              <li>You retain ownership of your artifacts and study content.</li>
              <li>You must have the right to upload/share the content. Do not upload confidential data you are not allowed to store.</li>
              <li>Do not upload malware, illegal content, or anything intended to harm users or systems.</li>
            </ul>

            <h3>3) AI-generated content</h3>
            <ul>
              <li>AI outputs may be incorrect or incomplete. You must review before using or publishing.</li>
              <li>You are responsible for ensuring AI-generated artifacts do not violate third-party rights or policies.</li>
            </ul>

            <h3>4) Privacy and data</h3>
            <ul>
              <li>We store your account profile, studies, artifacts, and related metadata to provide the service.</li>
              <li>Analytics pages summarize study/task progress; they are informational and may not reflect real-world outcomes.</li>
            </ul>

            <h3>5) Deletion</h3>
            <ul>
              <li>You can delete your account. Deletion is permanent and cannot be undone.</li>
              <li>Some references (e.g., audit/history) may persist where technically required, but the goal is to remove your personal access.</li>
            </ul>

            <h3>6) Availability and liability</h3>
            <ul>
              <li>The service is provided “as is” without warranties.</li>
              <li>We are not liable for losses caused by downtime, data loss, or use of AI outputs.</li>
            </ul>

            <h3>7) Changes</h3>
            <p>
              We may update these terms as the platform evolves. Continued use means you accept the updated terms.
            </p>

            <div className="terms-note">
              If you do not agree, click Cancel and do not use the platform.
            </div>
          </div>
        </div>

        <div className="modal-footer">
          <button type="button" className="btn btn--ghost small" onClick={onClose}>
            Cancel
          </button>
          <button type="button" className="btn small" onClick={onAgree}>
            I Agree
          </button>
        </div>
      </div>
    </div>
  );
}
