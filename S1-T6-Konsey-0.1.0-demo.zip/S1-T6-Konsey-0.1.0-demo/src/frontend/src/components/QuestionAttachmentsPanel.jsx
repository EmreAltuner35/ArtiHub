import React, { useState, useEffect } from "react";
import api from "../api";

/**
 * QuestionAttachmentsPanel - A component for adding images and artifacts to quiz questions.
 * 
 * Props:
 * - attachments: Array of { type: 'image' | 'artifact', data: string (base64 or artifactId), title?: string }
 * - onAttachmentsChange: (attachments) => void
 */
export default function QuestionAttachmentsPanel({ attachments = [], onAttachmentsChange }) {
    const [activeTab, setActiveTab] = useState("upload"); // 'upload' | 'artifact'
    const [showArtifactPicker, setShowArtifactPicker] = useState(false);

    // Artifact picker state
    const [folders, setFolders] = useState([]);
    const [selectedFolderId, setSelectedFolderId] = useState(null);
    const [artifacts, setArtifacts] = useState([]);
    const [loadingFolders, setLoadingFolders] = useState(false);
    const [loadingArtifacts, setLoadingArtifacts] = useState(false);
    const [folderPage, setFolderPage] = useState(0);
    const [folderTotalPages, setFolderTotalPages] = useState(1);
    const [artifactPage, setArtifactPage] = useState(0);
    const [artifactTotalPages, setArtifactTotalPages] = useState(1);

    // Artifact thumbnails cache
    const [thumbnails, setThumbnails] = useState({});

    const PAGE_SIZE = 6;

    // Fetch folders
    const fetchFolders = async (page = 0) => {
        setLoadingFolders(true);
        try {
            const res = await api.get("/api/artifacts/folders", {
                params: { page, size: PAGE_SIZE },
            });
            const data = res.data || {};
            setFolders(Array.isArray(data.content) ? data.content : []);
            setFolderPage(data.page ?? page);
            setFolderTotalPages(data.totalPages ?? 1);
        } catch (err) {
            console.error("Failed to load folders", err);
        } finally {
            setLoadingFolders(false);
        }
    };

    // Fetch artifacts in a folder (or root if folderId is null)
    const fetchArtifacts = async (folderId, page = 0) => {
        setLoadingArtifacts(true);
        try {
            const res = await api.get("/api/artifacts", {
                params: { folderId, page, size: PAGE_SIZE },
            });
            const data = res.data || {};
            setArtifacts(Array.isArray(data.content) ? data.content : []);
            setArtifactPage(data.page ?? page);
            setArtifactTotalPages(data.totalPages ?? 1);
        } catch (err) {
            console.error("Failed to load artifacts", err);
        } finally {
            setLoadingArtifacts(false);
        }
    };

    // Load folder thumbnails for image artifacts
    const loadThumbnail = async (artifactId, contentType) => {
        if (thumbnails[artifactId] || !contentType?.startsWith("image")) return;
        try {
            const res = await api.get(`/api/artifacts/${artifactId}/file?download=0`, {
                responseType: "blob",
            });
            const url = URL.createObjectURL(res.data);
            setThumbnails((prev) => ({ ...prev, [artifactId]: url }));
        } catch (err) {
            console.error("Failed to load thumbnail", err);
        }
    };

    // Load thumbnails when artifacts change
    useEffect(() => {
        artifacts.forEach((art) => {
            if (art.contentType?.startsWith("image") || art.type?.startsWith("image")) {
                loadThumbnail(art.id, art.contentType || art.type);
            }
        });
    }, [artifacts]);

    // Open artifact picker
    const openArtifactPicker = () => {
        setShowArtifactPicker(true);
        setSelectedFolderId(null); // Start at root level
        fetchFolders(0);
        fetchArtifacts(null, 0); // Fetch root-level artifacts immediately
    };

    // Select folder (or toggle back to root if same folder clicked)
    const handleSelectFolder = (folderId) => {
        if (selectedFolderId === folderId) {
            // Toggle back to root
            setSelectedFolderId(null);
            setArtifactPage(0);
            fetchArtifacts(null, 0);
        } else {
            setSelectedFolderId(folderId);
            setArtifactPage(0);
            fetchArtifacts(folderId, 0);
        }
    };

    // Add artifact to attachments
    const addArtifact = (artifact) => {
        // Check if already added
        const exists = attachments.some(
            (a) => a.type === "artifact" && a.data === artifact.id
        );
        if (exists) {
            alert("This artifact is already added.");
            return;
        }
        const newAttachment = {
            type: "artifact",
            data: artifact.id,
            title: artifact.title || "Artifact",
            contentType: artifact.contentType || artifact.type,
        };
        onAttachmentsChange([...attachments, newAttachment]);
    };

    // Handle image upload
    const handleImageUpload = (event) => {
        const files = Array.from(event.target.files);
        const validFiles = files.filter((file) => {
            const validTypes = ["image/png", "image/jpeg", "image/jpg"];
            if (!validTypes.includes(file.type)) {
                alert(`File ${file.name} is not a valid image type. Please use PNG or JPG.`);
                return false;
            }
            if (file.size > 5 * 1024 * 1024) {
                alert(`File ${file.name} is too large. Maximum size is 5MB.`);
                return false;
            }
            return true;
        });

        validFiles.forEach((file) => {
            const reader = new FileReader();
            reader.onloadend = () => {
                const newAttachment = {
                    type: "image",
                    data: reader.result,
                    title: file.name,
                };
                onAttachmentsChange([...attachments, newAttachment]);
            };
            reader.readAsDataURL(file);
        });

        event.target.value = "";
    };

    // Remove attachment
    const removeAttachment = (index) => {
        const updated = attachments.filter((_, i) => i !== index);
        onAttachmentsChange(updated);
    };

    const tabStyle = (isActive) => ({
        padding: "8px 16px",
        border: "none",
        background: isActive ? "var(--accent)" : "transparent",
        color: isActive ? "#032027" : "var(--muted)",
        cursor: "pointer",
        fontWeight: isActive ? 600 : 400,
        borderRadius: "6px 6px 0 0",
        fontSize: "13px",
    });

    return (
        <div style={{ marginBottom: 12 }}>
            {/* Attachments Header */}
            <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 8 }}>
                <label style={{ margin: 0, fontWeight: 500 }}>Attachments</label>
                <span style={{ fontSize: 12, color: "var(--muted)" }}>
                    Images (PNG, JPG) or Artifacts
                </span>
            </div>

            {/* Action Buttons */}
            <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
                <label
                    style={{
                        display: "inline-flex",
                        alignItems: "center",
                        gap: 6,
                        padding: "6px 12px",
                        backgroundColor: "#8b5cf6",
                        color: "white",
                        borderRadius: "6px",
                        cursor: "pointer",
                        fontSize: "13px",
                        fontWeight: 500,
                    }}
                >
                    📷 Upload Image
                    <input
                        type="file"
                        accept=".png,.jpg,.jpeg"
                        multiple
                        onChange={handleImageUpload}
                        style={{ display: "none" }}
                    />
                </label>
                <button
                    type="button"
                    onClick={openArtifactPicker}
                    style={{
                        display: "inline-flex",
                        alignItems: "center",
                        gap: 6,
                        padding: "6px 12px",
                        backgroundColor: "#06b6d4",
                        color: "white",
                        border: "none",
                        borderRadius: "6px",
                        cursor: "pointer",
                        fontSize: "13px",
                        fontWeight: 500,
                    }}
                >
                    📁 Select Artifact
                </button>
            </div>

            {/* Attachments Preview */}
            {attachments.length > 0 && (
                <div
                    style={{
                        display: "flex",
                        flexWrap: "wrap",
                        gap: 10,
                        padding: 12,
                        background: "rgba(255,255,255,0.02)",
                        borderRadius: 8,
                        border: "1px solid rgba(255,255,255,0.05)",
                    }}
                >
                    {attachments.map((att, index) => (
                        <div
                            key={index}
                            style={{
                                position: "relative",
                                width: 90,
                                textAlign: "center",
                            }}
                        >
                            {att.type === "image" ? (
                                <img
                                    src={att.data}
                                    alt={att.title || `Image ${index + 1}`}
                                    style={{
                                        width: 80,
                                        height: 80,
                                        objectFit: "cover",
                                        borderRadius: 8,
                                        border: "1px solid #333",
                                    }}
                                />
                            ) : (
                                <div
                                    style={{
                                        width: 80,
                                        height: 80,
                                        borderRadius: 8,
                                        border: "1px solid #333",
                                        background: "rgba(6,182,212,0.1)",
                                        display: "flex",
                                        alignItems: "center",
                                        justifyContent: "center",
                                        overflow: "hidden",
                                    }}
                                >
                                    {thumbnails[att.data] ? (
                                        <img
                                            src={thumbnails[att.data]}
                                            alt={att.title}
                                            style={{ width: "100%", height: "100%", objectFit: "cover" }}
                                        />
                                    ) : att.contentType?.startsWith("image") ? (
                                        <span style={{ fontSize: 10, color: "var(--muted)" }}>Loading...</span>
                                    ) : (
                                        <span style={{ fontSize: 24 }}>📄</span>
                                    )}
                                </div>
                            )}
                            <div
                                style={{
                                    fontSize: 10,
                                    color: "var(--muted)",
                                    marginTop: 4,
                                    overflow: "hidden",
                                    textOverflow: "ellipsis",
                                    whiteSpace: "nowrap",
                                }}
                                title={att.title}
                            >
                                {att.type === "artifact" ? "🔗 " : ""}
                                {att.title?.slice(0, 12) || (att.type === "image" ? "Image" : "Artifact")}
                            </div>
                            <button
                                type="button"
                                onClick={() => removeAttachment(index)}
                                style={{
                                    position: "absolute",
                                    top: -6,
                                    right: 2,
                                    width: 20,
                                    height: 20,
                                    borderRadius: "50%",
                                    backgroundColor: "#ef4444",
                                    color: "white",
                                    border: "none",
                                    cursor: "pointer",
                                    fontSize: "12px",
                                    display: "flex",
                                    alignItems: "center",
                                    justifyContent: "center",
                                }}
                            >
                                ×
                            </button>
                        </div>
                    ))}
                </div>
            )}

            {/* Artifact Picker Modal */}
            {showArtifactPicker && (
                <div
                    style={{
                        position: "fixed",
                        top: 0,
                        left: 0,
                        right: 0,
                        bottom: 0,
                        background: "rgba(0,0,0,0.7)",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        zIndex: 1000,
                    }}
                    onClick={() => setShowArtifactPicker(false)}
                >
                    <div
                        style={{
                            background: "var(--card)",
                            borderRadius: 12,
                            padding: 24,
                            width: "90%",
                            maxWidth: 800,
                            maxHeight: "80vh",
                            overflow: "auto",
                        }}
                        onClick={(e) => e.stopPropagation()}
                    >
                        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 16 }}>
                            <h3 style={{ margin: 0 }}>Select Artifact</h3>
                            <button
                                type="button"
                                onClick={() => setShowArtifactPicker(false)}
                                style={{
                                    background: "none",
                                    border: "none",
                                    color: "var(--muted)",
                                    fontSize: 24,
                                    cursor: "pointer",
                                }}
                            >
                                ×
                            </button>
                        </div>

                        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
                            {/* Folders Column */}
                            <div>
                                <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 8 }}>
                                    Folders
                                    <span style={{ fontSize: 11, color: "var(--muted)", marginLeft: 8 }}>
                                        Page {folderPage + 1} / {folderTotalPages}
                                    </span>
                                </div>
                                <div
                                    style={{
                                        background: "rgba(255,255,255,0.02)",
                                        borderRadius: 8,
                                        padding: 8,
                                        minHeight: 200,
                                        maxHeight: 300,
                                        overflow: "auto",
                                    }}
                                >
                                    {loadingFolders && <div style={{ color: "var(--muted)" }}>Loading...</div>}
                                    {!loadingFolders && folders.length === 0 && (
                                        <div style={{ color: "var(--muted)" }}>No folders found.</div>
                                    )}
                                    {!loadingFolders &&
                                        folders.map((folder) => (
                                            <button
                                                key={folder.id}
                                                type="button"
                                                onClick={() => handleSelectFolder(folder.id)}
                                                style={{
                                                    display: "block",
                                                    width: "100%",
                                                    padding: "8px 12px",
                                                    marginBottom: 4,
                                                    background:
                                                        selectedFolderId === folder.id
                                                            ? "rgba(110,231,183,0.15)"
                                                            : "transparent",
                                                    border: "none",
                                                    borderRadius: 6,
                                                    textAlign: "left",
                                                    color: "var(--text)",
                                                    cursor: "pointer",
                                                }}
                                            >
                                                📁 {folder.name || "(unnamed)"}
                                            </button>
                                        ))}
                                </div>
                                <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
                                    <button
                                        type="button"
                                        className="btn small"
                                        onClick={() => fetchFolders(folderPage - 1)}
                                        disabled={folderPage === 0 || loadingFolders}
                                        style={{ opacity: folderPage === 0 ? 0.5 : 1 }}
                                    >
                                        Prev
                                    </button>
                                    <button
                                        type="button"
                                        className="btn small"
                                        onClick={() => fetchFolders(folderPage + 1)}
                                        disabled={folderPage + 1 >= folderTotalPages || loadingFolders}
                                        style={{ opacity: folderPage + 1 >= folderTotalPages ? 0.5 : 1 }}
                                    >
                                        Next
                                    </button>
                                </div>
                            </div>

                            {/* Artifacts Column */}
                            <div>
                                <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 8 }}>
                                    {selectedFolderId ? "Artifacts in Folder" : "Root Artifacts"}
                                    <span style={{ fontSize: 11, color: "var(--muted)", marginLeft: 8 }}>
                                        Page {artifactPage + 1} / {artifactTotalPages}
                                    </span>
                                </div>
                                <div
                                    style={{
                                        background: "rgba(255,255,255,0.02)",
                                        borderRadius: 8,
                                        padding: 8,
                                        minHeight: 200,
                                        maxHeight: 300,
                                        overflow: "auto",
                                    }}
                                >
                                    {loadingArtifacts && (
                                        <div style={{ color: "var(--muted)" }}>Loading...</div>
                                    )}
                                    {!loadingArtifacts && artifacts.length === 0 && (
                                        <div style={{ color: "var(--muted)" }}>
                                            {selectedFolderId ? "No artifacts in this folder." : "No root artifacts. Select a folder."}
                                        </div>
                                    )}
                                    {!loadingArtifacts &&
                                        artifacts.map((artifact) => (
                                            <button
                                                key={artifact.id}
                                                type="button"
                                                onClick={() => addArtifact(artifact)}
                                                style={{
                                                    display: "flex",
                                                    alignItems: "center",
                                                    gap: 8,
                                                    width: "100%",
                                                    padding: "8px 12px",
                                                    marginBottom: 4,
                                                    background: "transparent",
                                                    border: "none",
                                                    borderRadius: 6,
                                                    textAlign: "left",
                                                    color: "var(--text)",
                                                    cursor: "pointer",
                                                }}
                                            >
                                                {thumbnails[artifact.id] ? (
                                                    <img
                                                        src={thumbnails[artifact.id]}
                                                        alt=""
                                                        style={{ width: 32, height: 32, objectFit: "cover", borderRadius: 4 }}
                                                    />
                                                ) : artifact.contentType?.startsWith("image") ||
                                                    artifact.type?.startsWith("image") ? (
                                                    <div
                                                        style={{
                                                            width: 32,
                                                            height: 32,
                                                            background: "rgba(255,255,255,0.05)",
                                                            borderRadius: 4,
                                                            display: "flex",
                                                            alignItems: "center",
                                                            justifyContent: "center",
                                                            fontSize: 10,
                                                            color: "var(--muted)",
                                                        }}
                                                    >
                                                        ...
                                                    </div>
                                                ) : (
                                                    <span style={{ fontSize: 24 }}>📄</span>
                                                )}
                                                <span style={{ flex: 1, overflow: "hidden", textOverflow: "ellipsis" }}>
                                                    {artifact.title || artifact.id}
                                                </span>
                                                <span
                                                    style={{
                                                        fontSize: 10,
                                                        color: "var(--muted)",
                                                        background: "rgba(255,255,255,0.05)",
                                                        padding: "2px 6px",
                                                        borderRadius: 4,
                                                    }}
                                                >
                                                    {artifact.type || "file"}
                                                </span>
                                            </button>
                                        ))}
                                </div>
                                <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
                                    <button
                                        type="button"
                                        className="btn small"
                                        onClick={() => fetchArtifacts(selectedFolderId, artifactPage - 1)}
                                        disabled={artifactPage === 0 || loadingArtifacts}
                                        style={{ opacity: artifactPage === 0 ? 0.5 : 1 }}
                                    >
                                        Prev
                                    </button>
                                    <button
                                        type="button"
                                        className="btn small"
                                        onClick={() => fetchArtifacts(selectedFolderId, artifactPage + 1)}
                                        disabled={artifactPage + 1 >= artifactTotalPages || loadingArtifacts}
                                        style={{ opacity: artifactPage + 1 >= artifactTotalPages ? 0.5 : 1 }}
                                    >
                                        Next
                                    </button>
                                </div>
                            </div>
                        </div>

                        <div style={{ marginTop: 16, textAlign: "right" }}>
                            <button
                                type="button"
                                onClick={() => setShowArtifactPicker(false)}
                                className="btn"
                                style={{ background: "var(--accent)", color: "#032027" }}
                            >
                                Done
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}
