import React, { useState, useEffect } from "react";
import api from "../api";

export default function AddReviewerModal({ studyId, onClose, onSuccess }) {
  const [searchTerm, setSearchTerm] = useState("");
  const [users, setUsers] = useState([]);
  const [selectedUser, setSelectedUser] = useState(null);

  const [loading, setLoading] = useState(false);
  const [searching, setSearching] = useState(false);

  useEffect(() => {
    if (searchTerm.length > 2) {
      const t = setTimeout(() => {
        searchUsers();
      }, 450);
      return () => clearTimeout(t);
    }
    setUsers([]);
  }, [searchTerm]);

  const searchUsers = async () => {
    try {
      setSearching(true);
      const response = await api.get(`/api/users/search?keyword=${searchTerm}&role=REVIEWER`);
      setUsers(response.data.results || []);
    } catch (e) {
      console.error("Error searching users:", e);
      setUsers([]);
    } finally {
      setSearching(false);
    }
  };

  const canAdd = !!selectedUser && !loading;

  const handleAdd = async () => {
    if (!selectedUser) return;

    try {
      setLoading(true);
      await api.post(`/api/studies/${studyId}/reviewers`, { reviewerId: selectedUser.id });
      onSuccess?.();
      onClose();
    } catch (e) {
      console.error("Add reviewer failed:", e);
      alert("Failed to add reviewer.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="modal-overlay" onMouseDown={onClose}>
      <div className="modal modal--sm modal--solid" onMouseDown={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h3 className="modal-title">Add Reviewer</h3>
          <button className="modal-close" onClick={onClose} aria-label="Close">
            ×
          </button>
        </div>

        <div className="modal-body">
          <label>Search User (Display Name)</label>
          <input
            className="input-dark"
            type="text"
            value={searchTerm}
            onChange={(e) => {
              setSearchTerm(e.target.value);
              setSelectedUser(null);
            }}
            placeholder="Type at least 3 characters..."
          />
          {searching && <div className="helper-text">Searching...</div>}

          {users.length > 0 && (
            <div className="modal-list">
              {users.map((u) => (
                <div
                  key={u.id}
                  className={
                    "modal-list-item" + (selectedUser?.id === u.id ? " is-selected" : "")
                  }
                  onClick={() => setSelectedUser(u)}
                >
                  {u.displayName}
                </div>
              ))}
            </div>
          )}

          {selectedUser && (
            <div className="helper-text">
              Selected: <strong>{selectedUser.displayName}</strong>
            </div>
          )}
        </div>

        <div className="modal-footer">
          <button className="btn small btn-ghost" onClick={onClose}>
            Cancel
          </button>
          <button className="btn small" onClick={handleAdd} disabled={!canAdd}>
            {loading ? "Adding..." : "Add"}
          </button>
        </div>
      </div>
    </div>
  );
}
