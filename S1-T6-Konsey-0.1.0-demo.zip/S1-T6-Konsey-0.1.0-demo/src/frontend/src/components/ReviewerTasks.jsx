import React, { useEffect, useState, useContext } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import api from '../api';
import Navbar from './Navbar';
import { AuthContext } from '../auth/AuthProvider';
import ReviewQuizModal from './ReviewQuizModal';

const ParticipantCard = ({ participant, onClick }) => {
    const baseBorderColor = "rgba(110,231,183,0.4)";
    const baseBackground = "rgba(255,255,255,0.03)";
    const completed = participant.reviewOver;

    return (
        <div
            onClick={!completed ? onClick : undefined} // Disable click if completed
            style={{
                padding: "16px",
                marginTop: "12px",
                borderRadius: "8px",
                background: completed ? "rgba(255,255,255,0.05)" : baseBackground,
                border: `1px solid ${baseBorderColor}`,
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                cursor: completed ? "default" : "pointer",
                opacity: completed ? 0.7 : 1,
                transition: "0.15s",
            }}
            onMouseEnter={(e) => {
                if (!completed) e.currentTarget.style.background = "rgba(255,255,255,0.07)";
            }}
            onMouseLeave={(e) => {
                if (!completed) e.currentTarget.style.background = baseBackground;
            }}
        >
            <div>
                <div style={{ fontSize: "16px", fontWeight: 600 }}>
                    {participant.displayName || participant.email}
                </div>
                <div className="muted" style={{ fontSize: "12px", marginTop: "4px" }}>
                    {participant.email}
                </div>
            </div>

            <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                {completed && (
                    <span
                        style={{
                            fontSize: 12,
                            color: "#fff",
                            background: "#22c55e",
                            padding: "2px 8px",
                            borderRadius: 4,
                        }}
                    >
                        Completed
                    </span>
                )}

                {!completed && (
                    <span style={{ color: "var(--accent)", fontSize: 14 }}>
                        Review →
                    </span>
                )}
            </div>
        </div>
    );
};

export default function ReviewerTasks() {
    const { studyId } = useParams();
    const { user } = useContext(AuthContext);
    const navigate = useNavigate();

    // 🔄 participants instead of tasks
    const [participants, setParticipants] = useState([]);

    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    // Quiz grading state (UNCHANGED)
    const [invitations, setInvitations] = useState([]);
    const [showReviewModal, setShowReviewModal] = useState(false);
    const [selectedInvitation, setSelectedInvitation] = useState(null);

    useEffect(() => {
        const fetchStudyData = async () => {
            setLoading(true);
            try {
                // ✅ FETCH PARTICIPANTS
                const participantsRes = await api.get(
                    `/api/studies/${studyId}/participants`
                );
                setParticipants(participantsRes.data);

                // Quiz invitations (unchanged)
                const invitationsRes = await api.get(
                    `/api/studies/${studyId}/invitations`
                );
                setInvitations(invitationsRes.data);
            } catch (err) {
                console.error("Failed to load study participants:", err);
                setError("Could not load participants for this study.");
            } finally {
                setLoading(false);
            }
        };

        if (studyId && user?.id) {
            fetchStudyData();
        }
    }, [studyId, user?.id]);

    const handleReviewQuiz = (invitation) => {
        setSelectedInvitation(invitation);
        setShowReviewModal(true);
    };

    const handleReviewComplete = async () => {
        setShowReviewModal(false);
        const invitationsRes = await api.get(
            `/api/studies/${studyId}/invitations`
        );
        setInvitations(invitationsRes.data);
    };

    const handleStatusUpdate = async (invitationId, status) => {
        try {
            await api.put(
                `/api/studies/participant/invitations/${invitationId}/status?status=${status}`
            );
            const invitationsRes = await api.get(
                `/api/studies/${studyId}/invitations`
            );
            setInvitations(invitationsRes.data);
        } catch (err) {
            console.error('Failed to update status:', err);
            alert('Failed to update invitation status.');
        }
    };

    const pendingQuizReviews = invitations.filter(
        inv => inv.status === 'QUIZ_COMPLETED' && inv.quizId
    );

    if (!user) return <p className="error">Please log in.</p>;

    if (loading) {
        return (
            <>
                <Navbar />
                <div style={{ padding: 24, maxWidth: 800, margin: "0 auto" }}>
                    <div className="muted" style={{ marginTop: "50px" }}>
                        Loading study participants...
                    </div>
                </div>
            </>
        );
    }

    if (error) {
        return (
            <>
                <Navbar />
                <div style={{ padding: 24, maxWidth: 800, margin: "0 auto" }}>
                    <div className="error" style={{ marginTop: "50px" }}>
                        {error}
                    </div>
                </div>
            </>
        );
    }

    return (
        <div style={{ minHeight: "100vh" }}>
            <Navbar />

            <div style={{ padding: 24, maxWidth: 800, margin: "0 auto" }}>
                <h2 style={{ marginBottom: "24px" }}>
                    Participants for Study{" "}
                    <strong style={{ color: "var(--accent)" }}>{studyId}</strong>
                </h2>

                {/* Quiz Reviews (UNCHANGED) */}
                {pendingQuizReviews.length > 0 && (
                    <div style={{ marginBottom: '30px' }}>
                        <h3 style={{ marginBottom: "15px", color: '#f59e0b' }}>
                            📝 Pending Quiz Reviews ({pendingQuizReviews.length})
                        </h3>

                        {pendingQuizReviews.map(inv => (
                            <div key={inv.invitationId} style={{
                                padding: "16px",
                                marginBottom: "12px",
                                borderRadius: "8px",
                                background: "rgba(245, 158, 11, 0.1)",
                                border: "1px solid rgba(245, 158, 11, 0.4)",
                                display: "flex",
                                justifyContent: "space-between",
                            }}>
                                <div>
                                    <div style={{ fontWeight: 600 }}>
                                        {inv.userDisplayName || 'Participant'}
                                    </div>
                                    <div className="muted" style={{ fontSize: "12px" }}>
                                        Quiz completed – awaiting review
                                    </div>
                                </div>

                                <div style={{ display: 'flex', gap: '8px' }}>
                                    <button onClick={() => handleReviewQuiz(inv)}>
                                        Review Quiz
                                    </button>
                                    <button onClick={() => handleStatusUpdate(inv.invitationId, 'ACCEPTED')}>
                                        Accept
                                    </button>
                                    <button onClick={() => handleStatusUpdate(inv.invitationId, 'REJECTED')}>
                                        Reject
                                    </button>
                                </div>
                            </div>
                        ))}
                    </div>
                )}

                <h3 style={{ margin: "30px 0 10px 0" }}>
                    Participants
                </h3>

                {participants.length === 0 ? (
                    <div className="muted">
                        No participants in this study yet.
                    </div>
                ) : (
                    participants.map(p => (
                        <ParticipantCard
                            key={p.id}
                            participant={p}
                            onClick={() =>
                                navigate(`/study/${studyId}/participant/${p.id}/review`)
                            }
                        />
                    ))
                )}
            </div>

            {showReviewModal && selectedInvitation && (
                <ReviewQuizModal
                    invitation={selectedInvitation}
                    studyId={studyId}
                    onClose={() => setShowReviewModal(false)}
                    onReviewComplete={handleReviewComplete}
                />
            )}
        </div>
    );
}
