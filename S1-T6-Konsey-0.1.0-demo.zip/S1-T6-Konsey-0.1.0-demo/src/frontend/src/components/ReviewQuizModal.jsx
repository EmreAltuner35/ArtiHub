import React, { useState, useEffect } from 'react';
import api from '../api';
import QuizAttachmentViewer from './QuizAttachmentViewer';

export default function ReviewQuizModal({ invitation, studyId, onClose, onReviewComplete }) {
    const [quiz, setQuiz] = useState(null);
    const [answers, setAnswers] = useState({});
    const [loading, setLoading] = useState(true);
    const [submitting, setSubmitting] = useState(false);
    const [manualScores, setManualScores] = useState({});

    // Constants
    const POINTS_PER_QUESTION = 10;

    useEffect(() => {
        if (invitation.quizAnswers) {
            try {
                setAnswers(JSON.parse(invitation.quizAnswers));
            } catch (e) {
                console.error("Failed to parse answers", e);
            }
        }
        fetchQuiz();
    }, [invitation]);

    const fetchQuiz = async () => {
        try {
            const response = await api.get(`/api/quizzes/${invitation.quizId}`);
            setQuiz(response.data);
        } catch (error) {
            console.error("Error fetching quiz:", error);
            alert("Failed to load quiz details.");
            onClose();
        } finally {
            setLoading(false);
        }
    };

    const handleScoreChange = (questionId, isCorrect) => {
        setManualScores(prev => ({
            ...prev,
            [questionId]: isCorrect ? POINTS_PER_QUESTION : 0
        }));
    };

    const handleSave = async () => {
        if (!quiz) return;

        let totalScore = 0;

        quiz.questions.forEach(q => {
            if (q.questionType === 'TEXT') {
                totalScore += (manualScores[q.questionId] || 0);
            } else {
                // Re-calculate auto-score to be safe
                const userAnswer = answers[q.questionId];
                const correctAnswers = q.answers.filter(a => a.isCorrect).map(a => a.answerId);

                if (q.questionType === 'MULTIPLE_CHOICE') {
                    const userAnswersArr = Array.isArray(userAnswer) ? userAnswer : [];
                    const isCorrect = userAnswersArr.length === correctAnswers.length &&
                        userAnswersArr.every(val => correctAnswers.includes(val));
                    if (isCorrect) {
                        totalScore += POINTS_PER_QUESTION;
                    }
                } else {
                    // Single choice
                    if (correctAnswers.includes(userAnswer)) {
                        totalScore += POINTS_PER_QUESTION;
                    }
                }
            }
        });

        try {
            setSubmitting(true);
            // Endpoint: PUT /api/studies/{studyId}/invitations/{invitationId}/score?score={score}
            await api.put(`/api/studies/${studyId}/invitations/${invitation.invitationId}/score?score=${totalScore}`);
            alert("Quiz graded successfully!");
            onReviewComplete();
        } catch (error) {
            console.error("Error saving score:", error);
            alert("Failed to save score.");
        } finally {
            setSubmitting(false);
        }
    };

    if (loading) return null;

    return (
        <div style={{
            position: 'fixed',
            top: 0, left: 0, right: 0, bottom: 0,
            backgroundColor: 'rgba(0,0,0,0.9)',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            zIndex: 1000,
            overflowY: 'auto'
        }}>
            <div style={{
                backgroundColor: '#1e1e1e',
                padding: '30px',
                borderRadius: '10px',
                width: '800px',
                maxWidth: '95%',
                color: 'white',
                maxHeight: '90vh',
                overflowY: 'auto'
            }}>
                <h2 style={{ marginTop: 0 }}>Review Quiz: {quiz.title}</h2>
                <p style={{ color: '#ccc', marginBottom: '10px' }}>Participant: {invitation.userEmail}</p>
                <p style={{ color: '#ccc', marginBottom: '30px' }}>Current Score: {invitation.quizScore} / {invitation.quizMaxScore}</p>

                {quiz.questions.map((q, index) => (
                    <div key={q.questionId} style={{ marginBottom: '30px', padding: '20px', backgroundColor: '#2c2c2c', borderRadius: '8px', border: q.questionType === 'TEXT' ? '1px solid #8b5cf6' : '1px solid #444' }}>
                        <h4 style={{ marginTop: 0 }}>{index + 1}. {q.questionText} <span style={{ fontSize: '0.8em', color: '#aaa' }}>({q.questionType})</span></h4>

                        {/* Attachments */}
                        {q.images && q.images.length > 0 && (
                            <QuizAttachmentViewer
                                images={q.images}
                                questionId={q.questionId}
                            />
                        )}

                        {q.questionType === 'TEXT' ? (
                            <div>
                                <div style={{ marginBottom: '10px', padding: '10px', backgroundColor: '#333', borderRadius: '4px' }}>
                                    <strong>Participant Answer:</strong>
                                    <p style={{ whiteSpace: 'pre-wrap', marginTop: '5px' }}>{answers[q.questionId] || 'No answer provided.'}</p>
                                </div>
                                <div style={{ display: 'flex', gap: '20px', alignItems: 'center' }}>
                                    <span>Grade:</span>
                                    <label style={{ cursor: 'pointer', color: '#10b981' }}>
                                        <input
                                            type="radio"
                                            name={`grade-${q.questionId}`}
                                            checked={manualScores[q.questionId] === POINTS_PER_QUESTION}
                                            onChange={() => handleScoreChange(q.questionId, true)}
                                            style={{ marginRight: '5px' }}
                                        />
                                        Correct (+{POINTS_PER_QUESTION})
                                    </label>
                                    <label style={{ cursor: 'pointer', color: '#ef4444' }}>
                                        <input
                                            type="radio"
                                            name={`grade-${q.questionId}`}
                                            checked={manualScores[q.questionId] === 0}
                                            onChange={() => handleScoreChange(q.questionId, false)}
                                            style={{ marginRight: '5px' }}
                                        />
                                        Incorrect (0)
                                    </label>
                                </div>
                            </div>
                        ) : (
                            <div>
                                <div style={{ marginBottom: '10px' }}>
                                    {q.answers.map(a => {
                                        const userAnswer = answers[q.questionId];
                                        let isSelected = false;
                                        if (q.questionType === 'MULTIPLE_CHOICE') {
                                            isSelected = Array.isArray(userAnswer) && userAnswer.includes(a.answerId);
                                        } else {
                                            isSelected = userAnswer === a.answerId;
                                        }

                                        const isCorrect = a.isCorrect;
                                        let color = 'white';
                                        if (isSelected && isCorrect) color = '#10b981';
                                        else if (isSelected && !isCorrect) color = '#ef4444';
                                        else if (!isSelected && isCorrect) color = '#10b981'; // Show correct answer

                                        const icon = q.questionType === 'MULTIPLE_CHOICE'
                                            ? (isSelected ? '☑' : '☐')
                                            : (isSelected ? '●' : '○');

                                        return (
                                            <div key={a.answerId} style={{
                                                padding: '5px',
                                                color: color,
                                                fontWeight: (isSelected || isCorrect) ? 'bold' : 'normal',
                                                display: 'flex',
                                                alignItems: 'center'
                                            }}>
                                                <span style={{ marginRight: '8px', fontSize: '1.2em' }}>{icon}</span>
                                                {a.answerText}
                                                {isCorrect ? ' (Correct)' : ''}
                                            </div>
                                        );
                                    })}
                                </div>
                            </div>
                        )}
                    </div>
                ))}

                <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '20px', marginTop: '30px' }}>
                    <button
                        onClick={onClose}
                        style={{ padding: '10px 20px', borderRadius: '4px', border: 'none', backgroundColor: '#555', color: 'white', cursor: 'pointer' }}
                    >
                        Cancel
                    </button>
                    <button
                        onClick={handleSave}
                        disabled={submitting}
                        style={{
                            padding: '10px 20px',
                            borderRadius: '4px',
                            border: 'none',
                            backgroundColor: submitting ? '#4b5563' : '#10b981',
                            color: 'white',
                            cursor: 'pointer',
                            fontWeight: 'bold'
                        }}
                    >
                        {submitting ? 'Saving...' : 'Save Grades'}
                    </button>
                </div>
            </div>
        </div>
    );
}
