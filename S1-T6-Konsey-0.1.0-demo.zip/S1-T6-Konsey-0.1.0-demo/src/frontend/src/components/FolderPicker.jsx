export default function FolderPicker({
  open,
  onToggle,
  folders,
  page,
  totalPages,
  totalElements,
  loading,
  error,
  onPageChange,
  onFolderClick,
  onDeleteFolder,
}) {
  return (
    <section
      className={`folder-picker ${open ? "folder-picker--open" : ""}`}
    >
      {/* header row */}
      <div className="folder-picker-header">
        <div className="folder-picker-title">Folders</div>

        <div className="folder-picker-meta">
          {totalElements > 0 && <span>{totalElements} total</span>}
          {loading && <span>Loading…</span>}
          <button
            type="button"
            onClick={onToggle}
            className="btn btn-ghost btn-sm folder-picker-toggle-btn"
          >
            {open ? "Hide" : "Browse"}
          </button>
        </div>
      </div>

      {!open && null}

      {open && (
        <>
          {error && (
            <div className="folder-picker-error">
              {error}
            </div>
          )}

          <div className="folder-picker-grid">
            {folders.map((folder) => (
              <div
                key={folder.id}
                onClick={() => onFolderClick(folder)}
                className="folder-picker-item"
              >
                <span className="folder-picker-item-name">
                  {folder.name}
                </span>
                {onDeleteFolder && (
                  <button
                    type="button"
                    title="Delete folder"
                    onClick={(e) => {
                      e.stopPropagation();
                      onDeleteFolder(folder);
                    }}
                    className="icon-btn icon-btn--danger folder-picker-delete-btn"
                  >
                    X
                  </button>
                )}
                {typeof folder.artifactCount === "number" && (
                  <span className="folder-picker-item-count">
                    {folder.artifactCount} item
                    {folder.artifactCount === 1 ? "" : "s"}
                  </span>
                )}
              </div>
            ))}

            {folders.length === 0 && !loading && !error && (
              <div className="folder-picker-empty">
                No folders yet.
              </div>
            )}
          </div>

          {/* folder pagination */}
          {totalPages > 1 && (
            <div className="folder-picker-pagination">
              <span className="folder-picker-pagination-info">
                Page {page + 1} of {totalPages}
              </span>
              <div className="folder-picker-pagination-buttons">
                <button
                  type="button"
                  disabled={page === 0}
                  onClick={() => onPageChange(Math.max(0, page - 1))}
                  className="folder-picker-page-btn"
                >
                  Prev
                </button>
                <button
                  type="button"
                  disabled={page + 1 >= totalPages}
                  onClick={() =>
                    onPageChange(
                      page + 1 < totalPages ? page + 1 : totalPages - 1
                    )
                  }
                  className="folder-picker-page-btn"
                >
                  Next
                </button>
              </div>
            </div>
          )}
        </>
      )}
    </section>
  );
}
