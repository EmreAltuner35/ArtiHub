import React, { useContext } from "react";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "../auth/AuthProvider";

export default function GuestDashboard() {
  const navigate = useNavigate();
  const { logout } = useContext(AuthContext);

  const handleSignOut = () => {
    logout();
    navigate("/login");
  };

  return (
    <div style={{ padding: 24 }}>
      <div className="card" style={{ maxWidth: 900 }}>
        <h2>Guest Dashboard</h2>
        <div className="muted">You are signed in as a guest. Some features may be disabled.</div>
        <div style={{ marginTop: 24, display: 'flex', gap: '12px' }}>
          <button
            className="btn"
            onClick={() => navigate("/forums")}
          >
            Browse Forums
          </button>

          <button
            className="btn btn-secondary"
            onClick={handleSignOut}
          >
            Back to Sign In
          </button>
        </div>
      </div>
    </div>
  );
}
