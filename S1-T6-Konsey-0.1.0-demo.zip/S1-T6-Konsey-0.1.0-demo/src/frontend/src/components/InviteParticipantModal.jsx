import React, { useState, useEffect } from "react";
import api from "../api";

export default function InviteParticipantModal({ studyId, onClose, onInviteSuccess }) {
  const [searchTerm, setSearchTerm] = useState("");
  const [users, setUsers] = useState([]);
  const [selectedUser, setSelectedUser] = useState(null);

  const [attachQuiz, setAttachQuiz] = useState(false);
  const [quizzes, setQuizzes] = useState([]);
  const [selectedQuizId, setSelectedQuizId] = useState("");

  const [loading, setLoading] = useState(false);
  const [searching, setSearching] = useState(false);

  useEffect(() => {
    if (searchTerm.length > 2) {
      const t = setTimeout(() => {
        searchUsers();
      }, 450);
      return () => clearTimeout(t);
    }
    setUsers([]);
  }, [searchTerm]);

  useEffect(() => {
    if (attachQuiz) fetchQuizzes();
  }, [attachQuiz]);

  const searchUsers = async () => {
    try {
      setSearching(true);
      const response = await api.get(`/api/users/search?keyword=${searchTerm}&role=PARTICIPANT`);
      setUsers(response.data.results || []);
    } catch (e) {
      console.error("Error searching users:", e);
      setUsers([]);
    } finally {
      setSearching(false);
    }
  };

  const fetchQuizzes = async () => {
    try {
      const response = await api.get("/api/quizzes/my-quizzes");
      setQuizzes(response.data?.content || []);
    } catch (e) {
      console.error("Error fetching quizzes:", e);
    }
  };

  const canInvite =
    !!selectedUser && (!attachQuiz || (attachQuiz && !!selectedQuizId)) && !loading;

  const handleInvite = async () => {
    if (!selectedUser) return;
    if (attachQuiz && !selectedQuizId) return;

    try {
      setLoading(true);
      const payload = {
        userId: selectedUser.id,
        quizId: attachQuiz ? selectedQuizId : null,
        email: selectedUser.email,
      };
      await api.post(`/api/studies/${studyId}/invitations`, payload);
      onInviteSuccess();
      onClose();
    } catch (e) {
      console.error("Invite failed:", e);
      alert("Failed to send invitation.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="modal-overlay" onMouseDown={onClose}>
      <div className="modal modal--sm modal--solid" onMouseDown={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h3 className="modal-title">Invite Participant</h3>
          <button className="modal-close" onClick={onClose} aria-label="Close">
            ×
          </button>
        </div>

        <div className="modal-body">
          <label>Search User (Display Name)</label>
          <input
            className="input-dark"
            type="text"
            value={searchTerm}
            onChange={(e) => {
              setSearchTerm(e.target.value);
              setSelectedUser(null);
            }}
            placeholder="Type at least 3 characters..."
          />
          {searching && <div className="helper-text">Searching...</div>}

          {users.length > 0 && (
            <div className="modal-list">
              {users.map((u) => (
                <div
                  key={u.id}
                  className={
                    "modal-list-item" + (selectedUser?.id === u.id ? " is-selected" : "")
                  }
                  onClick={() => setSelectedUser(u)}
                >
                  {u.displayName}
                </div>
              ))}
            </div>
          )}

          {selectedUser && (
            <div className="helper-text">
              Selected: <strong>{selectedUser.displayName}</strong>
            </div>
          )}

          <div className="modal-row">
            <div className="muted">Attach Quiz</div>
            <label className="switch switch--sm">
              <input
                type="checkbox"
                checked={attachQuiz}
                onChange={(e) => {
                  const v = e.target.checked;
                  setAttachQuiz(v);
                  if (!v) setSelectedQuizId("");
                }}
              />
              <span className="switch-thumb" />
            </label>
          </div>

          {attachQuiz && (
            <div style={{ marginTop: 10 }}>
              <label>Select Quiz</label>
              <select
                className="select-dark"
                value={selectedQuizId}
                onChange={(e) => setSelectedQuizId(e.target.value)}
              >
                <option value="">-- Select a Quiz --</option>
                {quizzes.map((q) => (
                  <option key={q.quizId} value={q.quizId}>
                    {q.title}
                  </option>
                ))}
              </select>
            </div>
          )}
        </div>

        <div className="modal-footer">
          <button className="btn small btn-ghost" onClick={onClose}>
            Cancel
          </button>
          <button className="btn small" onClick={handleInvite} disabled={!canInvite}>
            {loading ? "Sending..." : "Invite"}
          </button>
        </div>
      </div>
    </div>
  );
}
