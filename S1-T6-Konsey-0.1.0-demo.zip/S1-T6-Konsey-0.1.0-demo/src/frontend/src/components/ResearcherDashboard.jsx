import React from 'react';
import { useNavigate } from 'react-router-dom';

export default function ResearcherDashboard({ user }) {
    const navigate = useNavigate();

    const actions = [
        {
            title: "Manage Studies",
            description: "Create and manage research studies.",
            path: "/studies",
            icon: "📊",
            color: "#3b82f6", // Blue
            gradient: "linear-gradient(135deg, #3b82f6 0%, #2563eb 100%)"
        },
        {
            title: "View Analytics",
            description: "Analyze study results and metrics.",
            path: "/analytics",
            icon: "📈",
            color: "#10b981", // Green
            gradient: "linear-gradient(135deg, #10b981 0%, #059669 100%)"
        },
        {
            title: "Manage Artifacts",
            description: "Upload and manage code artifacts.",
            path: "/artifacts",
            icon: "📦",
            color: "#f59e0b", // Amber
            gradient: "linear-gradient(135deg, #f59e0b 0%, #d97706 100%)"
        },
        {
            title: "Manage Quizzes",
            description: "Create and edit quizzes.",
            path: "/quizzes",
            icon: "📝",
            color: "#8b5cf6", // Purple
            gradient: "linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%)"
        },
        {
            title: "Community Forums",
            description: "Engage with participants.",
            path: "/forums",
            icon: "💬",
            color: "#ec4899", // Pink
            gradient: "linear-gradient(135deg, #ec4899 0%, #db2777 100%)"
        }
    ];

    return (
        <div style={{ color: '#ffffff' }}>
            <div style={{ padding: '0 0 20px 0' }}>
                <h1 style={{ marginBottom: '10px' }}>Welcome back, {user?.displayName || 'Researcher'}</h1>
                <p style={{ color: '#9ca3af', marginTop: 0 }}>
                    Manage your research studies and analyze data from here.
                </p>

                <h3 style={{ marginTop: '32px', marginBottom: '32px', borderBottom: '1px solid #374151', paddingBottom: '10px' }}>
                    Quick Actions
                </h3>

                {/* Actions Grid */}
                <div style={{
                    display: 'grid',
                    gridTemplateColumns: 'repeat(5, 1fr)',
                    gap: '16px',
                }}>
                    {actions.map((action, index) => (
                        <div
                            key={index}
                            onClick={() => navigate(action.path)}
                            style={{
                                position: 'relative',
                                background: action.gradient,
                                padding: '24px',
                                borderRadius: '16px',
                                boxShadow: '0 4px 6px rgba(0,0,0,0.3)',
                                cursor: 'pointer',
                                display: 'flex',
                                flexDirection: 'column',
                                gap: '12px',
                                justifyContent: 'center',
                                alignItems: 'center',
                                textAlign: 'center',
                                minHeight: '200px',
                                transition: 'all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1)'
                            }}
                            onMouseEnter={(e) => {
                                e.currentTarget.style.transform = 'translateY(-5px) scale(1.02)';
                                e.currentTarget.style.boxShadow = '0 10px 20px rgba(0,0,0,0.4)';
                            }}
                            onMouseLeave={(e) => {
                                e.currentTarget.style.transform = 'none';
                                e.currentTarget.style.boxShadow = '0 4px 6px rgba(0,0,0,0.3)';
                            }}
                        >
                            {/* Content */}
                            <div style={{
                                fontSize: '48px',
                                filter: 'drop-shadow(0 2px 4px rgba(0,0,0,0.3))'
                            }}>
                                {action.icon}
                            </div>

                            <div style={{
                                color: '#ffffff',
                                fontSize: '1.25rem',
                                fontWeight: '700',
                                textShadow: '0 1px 2px rgba(0,0,0,0.5)'
                            }}>
                                {action.title}
                            </div>

                            <p style={{
                                margin: 0,
                                color: 'rgba(255,255,255,0.9)',
                                lineHeight: '1.5',
                                fontSize: '0.9rem'
                            }}>
                                {action.description}
                            </p>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
}
