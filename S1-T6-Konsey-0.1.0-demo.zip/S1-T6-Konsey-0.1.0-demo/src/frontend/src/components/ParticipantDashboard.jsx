import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../api';
import TakeQuizModal from '../components/TakeQuizModal';

// Helper function to format the date string
const formatDate = (dateString) => {
  if (!dateString) return "No end date specified";
  try {
    return new Date(dateString).toLocaleDateString();
  } catch {
    return dateString; // Fallback if date is invalid
  }
};

export default function ParticipantDashboard() {
  const navigate = useNavigate();
  const [invitations, setInvitations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedInvitation, setSelectedInvitation] = useState(null);
  const [showQuizModal, setShowQuizModal] = useState(false);

  useEffect(() => {
    fetchInvitations();
  }, []);

  const fetchInvitations = async () => {
    try {
      setLoading(true);
      const response = await api.get('/api/studies/participant/invitations');
      console.log("Fetched invitations:", response.data);
      setInvitations(response.data);
    } catch (error) {
      console.error("Error fetching invitations:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleStatusUpdate = async (invitationId, status) => {
    try {
      await api.put(`/api/studies/participant/invitations/${invitationId}/status?status=${status}`);
      fetchInvitations();
    } catch (error) {
      console.error("Error updating status:", error);
      alert("Failed to update status.");
    }
  };

  const handleTakeQuiz = (invitation) => {
    setSelectedInvitation(invitation);
    setShowQuizModal(true);
  };

  const handleQuizSubmit = () => {
    setShowQuizModal(false);
    fetchInvitations();
  };

  if (loading) return (
    <div style={{ padding: 20, color: 'white' }}>Loading...</div>
  );

  const pendingInvitations = Array.isArray(invitations) ? invitations.filter(inv => inv && inv.status === 'PENDING') : [];
  const acceptedStudies = Array.isArray(invitations) ? invitations.filter(inv => inv && (inv.status === 'ACCEPTED' || inv.status === 'QUIZ_COMPLETED')) : [];

  return (
    <div style={{ color: '#ffffff' }}>
      <div style={{ padding: '20px', maxWidth: '1200px', margin: '0 auto' }}>
        <h1 style={{ marginBottom: '30px' }}>Participant Dashboard</h1>

        {/* Pending Invitations */}
        <section style={{ marginBottom: '40px' }}>
          <h2 style={{ borderBottom: '1px solid #333', paddingBottom: '10px' }}>My Invitations</h2>
          {pendingInvitations.length === 0 ? (
            <p style={{ color: '#aaa' }}>No pending invitations.</p>
          ) : (
            <div style={{ display: 'grid', gap: '20px', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))' }}>
              {pendingInvitations.map(inv => (
                <div key={inv.invitationId} style={{ backgroundColor: '#1e1e1e', padding: '20px', borderRadius: '8px', border: '1px solid #333' }}>
                  <h3 style={{ marginTop: 0 }}>Study Invitation</h3>
                  <p style={{ color: '#ccc' }}>You have been invited to participate in a study.</p>
                  {inv.quizId && (
                    <div style={{ marginBottom: '15px', padding: '8px', backgroundColor: '#333', borderRadius: '4px', fontSize: '0.9em' }}>
                      <span style={{ marginRight: '5px' }}>📝</span>
                      This invitation includes a required quiz.
                    </div>
                  )}
                  <div style={{ display: 'flex', gap: '10px', marginTop: '20px' }}>
                    {inv.quizId ? (
                      <button
                        onClick={() => handleTakeQuiz(inv)}
                        style={{ flex: 1, padding: '10px', backgroundColor: '#8b5cf6', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}
                      >
                        Take Quiz
                      </button>
                    ) : (
                      <button
                        onClick={() => handleStatusUpdate(inv.invitationId, 'ACCEPTED')}
                        style={{ flex: 1, padding: '10px', backgroundColor: '#10b981', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}
                      >
                        Accept
                      </button>
                    )}
                    <button
                      onClick={() => handleStatusUpdate(inv.invitationId, 'REJECTED')}
                      style={{ flex: 1, padding: '10px', backgroundColor: '#ef4444', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}
                    >
                      Reject
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>

        {/* My Studies */}
        <section>
          <h2 style={{ borderBottom: '1px solid #333', paddingBottom: '10px' }}>My Studies</h2>
          {acceptedStudies.length === 0 ? (
            <p style={{ color: '#aaa' }}>You are not participating in any studies yet.</p>
          ) : (
            <div style={{ display: 'grid', gap: '20px', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))' }}>
              {acceptedStudies.map(inv => (
                <div key={inv.invitationId} style={{ backgroundColor: '#1e1e1e', padding: '20px', borderRadius: '8px', border: '1px solid #333' }}>
                  <h3 style={{ marginTop: 0 }}>Study Participation</h3>
                  <div style={{ marginBottom: '10px' }}>
                    Status: <span style={{
                      fontWeight: 'bold',
                      color: inv.status === 'ACCEPTED' ? '#10b981' : '#f59e0b'
                    }}>{inv.status ? inv.status.replace('_', ' ') : 'UNKNOWN'}</span>
                  </div>
                  {inv.quizScore !== null && (
                    <div style={{ marginBottom: '10px', color: '#ccc' }}>
                      Quiz Score: <strong>{inv.quizScore} / {inv.quizMaxScore}</strong>
                    </div>
                  )}
                  {inv.status === 'ACCEPTED' ? (
                    <button
                      onClick={() => navigate(`/${inv.studyId}/tasks`)}
                      style={{ width: '100%', padding: '10px', backgroundColor: '#8b5cf6', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}
                    >
                      View Study Assignments
                    </button>
                  ) : (
                    <div style={{ width: '100%', padding: '10px', backgroundColor: '#4b5563', color: '#aaa', border: 'none', borderRadius: '4px', textAlign: 'center' }}>
                      Awaiting acceptance by researcher
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </section>
      </div>

      {showQuizModal && selectedInvitation && (
        <TakeQuizModal
          invitation={selectedInvitation}
          onClose={() => setShowQuizModal(false)}
          onSubmit={handleQuizSubmit}
        />
      )}
    </div>
  );
}