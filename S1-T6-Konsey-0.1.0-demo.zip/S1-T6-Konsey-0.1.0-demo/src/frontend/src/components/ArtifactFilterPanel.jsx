import React, { useState } from "react";
import DatePicker from "react-datepicker";
import api from "../api";

/**
 * Props:
 *  - selectedFilterTags (string[]), onSelectedFilterTags (string[] => void)
 *  - dateFrom: Date | null, onFromChange: (Date | null) => void
 *  - dateTo: Date | null, onToChange: (Date | null) => void
 *  - sortBy, onSortByChange
 *  - sortDir, onSortDirChange
 *  - requireAll (boolean), onTagsModeChange (boolean => void)
 */
export default function ArtifactFilterPanel({
  selectedFilterTags,
  onSelectedFilterTags,
  dateFrom,
  onFromChange,
  dateTo,
  onToChange,
  sortBy,
  onSortByChange,
  sortDir,
  onSortDirChange,
  requireAll,
  onTagsModeChange,
}) {
  const TAG_PAGE_SIZE = 5;

  const [tagQuery, setTagQuery] = useState("");
  const [tagResults, setTagResults] = useState([]);
  const [tagPage, setTagPage] = useState(0);
  const [tagHasMore, setTagHasMore] = useState(false);
  const [tagLoading, setTagLoading] = useState(false);

  const searchTags = async (query, page = 0) => {
    const trimmed = query.trim();
    if (!trimmed) {
      setTagResults([]);
      setTagHasMore(false);
      setTagPage(0);
      return;
    }

    try {
      setTagLoading(true);
      const res = await api.get("/api/artifacts/tags", {
        params: {
          q: trimmed,
          page,
          size: TAG_PAGE_SIZE,
        },
      });

      const pageData = res.data || {};
      const selectedSet = new Set(selectedFilterTags || []);
      const pageContent = (pageData.content || []).filter(
        (t) => !selectedSet.has(t.name)
      );

      if (page === 0) {
        setTagResults(pageContent);
      } else {
        setTagResults((prev) => [...prev, ...pageContent]);
      }

      setTagPage(pageData.pageNumber ?? 0);
      setTagHasMore(!pageData.last);
    } catch (err) {
      console.error("Tag search failed", err);
    } finally {
      setTagLoading(false);
    }
  };

  const handleTagSearchChange = (e) => {
    const value = e.target.value;
    setTagQuery(value);
    searchTags(value, 0);
  };

  const handleLoadMoreTags = () => {
    if (!tagHasMore || tagLoading) return;
    searchTags(tagQuery, tagPage + 1);
  };

  const handleAddTag = (tagName) => {
    if (selectedFilterTags.includes(tagName)) return;

    const updated = [...selectedFilterTags, tagName];
    onSelectedFilterTags(updated);

    setTagQuery("");
    setTagResults([]);
    setTagHasMore(false);
    setTagPage(0);
  };

  const handleRemoveTag = (tagName) => {
    const updated = selectedFilterTags.filter((t) => t !== tagName);
    onSelectedFilterTags(updated);
  };

  return (
    <aside className="artifact-filter-panel">
      <h3 className="filter-panel-title">Filters</h3>

      {/* TAG FILTER: search + chips */}
      <div className="filter-section">
        <label>Tags</label>
        <input
          type="text"
          value={tagQuery}
          onChange={handleTagSearchChange}
          placeholder="Search tags..."
          className="input-dark"
        />

        {selectedFilterTags.length > 0 && (
          <div className="filter-tag-chips">
            {selectedFilterTags.map((tag) => (
              <span key={tag} className="tag-chip">
                {tag}
                <button
                  type="button"
                  onClick={() => handleRemoveTag(tag)}
                  className="tag-chip-remove"
                >
                  ×
                </button>
              </span>
            ))}
          </div>
        )}

        {tagQuery.trim() !== "" && (
          <div className="tag-dropdown-wrapper">
            <div className="tag-dropdown">
              {tagLoading && (
                <div className="tag-dropdown-status">Searching...</div>
              )}

              {!tagLoading && tagResults.length === 0 && (
                <div className="tag-dropdown-status">No tags found.</div>
              )}

              {!tagLoading &&
                tagResults.map((tag) => (
                  <button
                    key={tag.id}
                    type="button"
                    onClick={() => handleAddTag(tag.name)}
                    className="tag-dropdown-item"
                  >
                    {tag.name}
                  </button>
                ))}

              {!tagLoading && tagHasMore && (
                <button
                  type="button"
                  onClick={handleLoadMoreTags}
                  className="tag-dropdown-footer"
                >
                  Load more...
                </button>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Tag match mode */}
      <div className="filter-section">
        <label className="filter-section-label">Tag match mode:</label>
        <div className="segmented" role="group" aria-label="Tag requirement">
          <button
            type="button"
            className={`seg-option ${requireAll ? "active" : ""}`}
            onClick={() => onTagsModeChange(true)}
          >
            All
          </button>
          <button
            type="button"
            className={`seg-option ${!requireAll ? "active" : ""}`}
            onClick={() => onTagsModeChange(false)}
          >
            Any
          </button>
        </div>
      </div>

      {/* Date filters (react-datepicker) */}
      <div className="filter-section">
        <div className="filter-date-group">
          <label>Created from</label>
          <DatePicker
            selected={dateFrom}
            onChange={onFromChange}
            dateFormat="dd/MM/yyyy"
            className="datepicker-dark"
            isClearable
            placeholderText="Select start date"
          />
        </div>

        <div className="filter-date-group">
          <label>Created to</label>
          <DatePicker
            selected={dateTo}
            onChange={onToChange}
            dateFormat="dd/MM/yyyy"
            className="datepicker-dark"
            isClearable
            placeholderText="Select end date"
          />
        </div>
      </div>

      {/* Sort controls */}
      <div className="filter-section">
        <div className="filter-sort-grid">
          <div>
            <label>Sort by</label>
            <select
              value={sortBy}
              onChange={onSortByChange}
              className="select-dark"
            >
              <option value="createdAt">Created At</option>
              <option value="title">Title</option>
            </select>
          </div>
          <div>
            <label>Direction</label>
            <select
              value={sortDir}
              onChange={onSortDirChange}
              className="select-dark"
            >
              <option value="asc">Asc</option>
              <option value="desc">Desc</option>
            </select>
          </div>
        </div>
      </div>
    </aside>
  );
}
