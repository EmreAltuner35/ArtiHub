import React, { useState } from "react";
import api from "../../api"; // make sure path is correct

export default function ConfirmModal({ message, onClose, onConfirm, type, id, fullHeight = false }) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleDelete = async () => {
    if (!id || !type) return;

    setLoading(true);
    setError("");

    try {
      if (type === "artifact") {
        await api.delete(`/api/artifacts/${id}`);
      } else if (type === "user") {
        await api.delete(`/api/users/${id}`);
      }

      // call parent callback
      onConfirm();
    } catch (err) {
      console.error("Failed to delete:", err);
      setError("Failed to delete. Check console for details.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={overlayStyle(fullHeight)}>
      <div style={modalStyle}>
        <p style={{ marginBottom: "12px" }}>{message}</p>
        {error && <p style={{ color: "red", marginBottom: "12px" }}>{error}</p>}
        <div style={{ display: "flex", justifyContent: "space-between" }}>
          <button style={cancelButtonStyle} onClick={onClose} disabled={loading}>
            Cancel
          </button>
          <button style={deleteButtonStyle} onClick={handleDelete} disabled={loading}>
            {loading ? "Deleting…" : "Delete"}
          </button>
        </div>
      </div>
    </div>
  );
}

// ===== STYLES =====
const overlayStyle = (fullHeight = false) => ({
  position: "fixed",
  inset: 0,
  backgroundColor: "rgba(0,0,0,0.6)",
  display: "flex",
  alignItems: fullHeight ? "stretch" : "center",
  justifyContent: "center",
  zIndex: 1000,
});

const modalStyle = {
  background: "#1e1e1e",
  color: "white",
  padding: "24px",
  borderRadius: "10px",
  width: "320px",
  boxShadow: "0 4px 20px rgba(0,0,0,0.4)",
  margin: "auto",
};

const cancelButtonStyle = {
  backgroundColor: "#555",
  color: "white",
  border: "none",
  padding: "8px 16px",
  borderRadius: "4px",
  cursor: "pointer",
};

const deleteButtonStyle = {
  backgroundColor: "#dc2626",
  color: "white",
  border: "none",
  padding: "8px 16px",
  borderRadius: "4px",
  cursor: "pointer",
};
