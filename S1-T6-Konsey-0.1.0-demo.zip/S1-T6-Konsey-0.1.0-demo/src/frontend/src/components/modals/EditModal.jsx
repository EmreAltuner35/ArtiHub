import React, { useState } from "react";
import api from "../../api";

export default function EditModal({ title, item, type, onClose, onSave, loading = false }) {
  const { password, sha256, storageKey, ...safeItem } = item;
  const [form, setForm] = useState(safeItem);

  const handleChange = (key) => (e) => setForm({ ...form, [key]: e.target.value });

  const blacklist = new Set(["id"]);
  const keys = Object.keys(form).filter((key) => !blacklist.has(key));

  const handleSave = async () => {
    try {
      if (type === "user") {
        await api.put(`/api/users/${item.id}`, form);
      } else if (type === "artifact") {
        await api.put(`/api/artifacts/${item.id}`, form);
      }
      onSave(form);
    } catch (err) {
      console.error("Failed to save:", err);
      alert("Failed to save changes");
    }
  };

  return (
    <div style={overlayStyle}>
      <div style={modalStyle}>
        <header style={headerStyle}>
          <h3>{title}</h3>
          <button onClick={onClose} style={closeButtonStyle} aria-label="Close">✕</button>
        </header>

        <div style={contentStyle}>
          <div style={formGridStyle}>
            {keys.map((key) => (
              <div key={key} style={fieldWrapperStyle}>
                <label style={labelStyle}>{key}</label>
                <input
                  type="text"
                  value={form[key] ?? ""}
                  onChange={handleChange(key)}
                  style={inputStyle}
                />
              </div>
            ))}
          </div>
        </div>

        <footer style={footerStyle}>
          <button type="button" onClick={onClose} style={cancelButtonStyle}>Cancel</button>
          <button
            type="button"
            onClick={handleSave}
            disabled={loading}
            style={{ ...saveButtonStyle, opacity: loading ? 0.6 : 1, cursor: loading ? "not-allowed" : "pointer" }}
          >
            {loading ? "Saving…" : "Save Changes"}
          </button>
        </footer>
      </div>
    </div>
  );
}


// ===== STYLES (same as your current modal) =====
const overlayStyle = {
  position: "fixed",
  inset: 0,
  backgroundColor: "rgba(11,15,19,0.85)",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  zIndex: 1000,
  backdropFilter: "blur(4px)",
};

const modalStyle = {
  background: "var(--card)",
  color: "var(--text)",
  padding: "24px",
  borderRadius: "12px",
  width: "760px",
  maxHeight: "85vh",
  display: "flex",
  flexDirection: "column",
  boxShadow: "0 8px 30px rgba(2,6,23,0.8)",
  animation: "fadeInScale .3s ease",
};

const headerStyle = {
  display: "flex",
  justifyContent: "space-between",
  alignItems: "center",
  marginBottom: "20px",
};

const closeButtonStyle = {
  background: "transparent",
  border: "none",
  color: "var(--muted)",
  fontSize: "20px",
  cursor: "pointer",
};

const contentStyle = {
  flex: "1 1 auto",
  overflowY: "auto",
  paddingRight: "8px",
};

const formGridStyle = {
  display: "grid",
  gridTemplateColumns: "1fr 1fr",
  gap: "20px 32px",
};

const fieldWrapperStyle = {
  display: "flex",
  flexDirection: "column",
};

const labelStyle = {
  fontSize: "13px",
  color: "var(--muted)",
  marginBottom: "6px",
};

const inputStyle = {
  width: "100%",
  padding: "10px 14px",
  borderRadius: "8px",
  border: "1px solid rgba(255,255,255,0.04)",
  background: "var(--glass)",
  color: "var(--text)",
  outline: "none",
};

const footerStyle = {
  display: "flex",
  justifyContent: "flex-end",
  gap: "12px",
  marginTop: "20px",
};

const cancelButtonStyle = {
  backgroundColor: "transparent",
  color: "var(--muted)",
  border: "1px solid rgba(255,255,255,0.2)",
  padding: "10px 18px",
  borderRadius: "8px",
  cursor: "pointer",
};

const saveButtonStyle = {
  backgroundColor: "var(--accent)",
  color: "#032027",
  border: "none",
  padding: "10px 18px",
  borderRadius: "8px",
  fontWeight: 600,
};

// Animation keyframes
const styleSheet = document.styleSheets[0];
styleSheet.insertRule(`
@keyframes fadeInScale {
  from { opacity: 0; transform: scale(0.95); }
  to { opacity: 1; transform: scale(1); }
}
`, styleSheet.cssRules.length);
