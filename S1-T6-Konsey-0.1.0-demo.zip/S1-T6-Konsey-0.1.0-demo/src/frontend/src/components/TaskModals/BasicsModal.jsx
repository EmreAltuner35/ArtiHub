import React from "react";

export default function BasicsModal({ basics, onChange }) {
  const handleField = (field, value) => {
    onChange({
      ...basics,
      [field]: value,
    });
  };

  return (
    <div className="task-step-one">
      <label>
        Task name
        <input
          className="input-dark"
          type="text"
          value={basics.name}
          onChange={(e) => handleField("name", e.target.value)}
          placeholder="Enter task name"
        />
      </label>

      <label>
        Instructions
        <textarea
          className="textarea-dark"
          rows={4}
          value={basics.instructions}
          onChange={(e) => handleField("instructions", e.target.value)}
          placeholder="Describe what participants should do"
        />
      </label>

      <div className="switch-row switch-row--lg">
        <div className="switch-label">Blinded task (hide artifact identity)</div>
        <label className="switch switch--sm">
          <input
            type="checkbox"
            checked={basics.isBlinded}
            onChange={(e) => handleField("isBlinded", e.target.checked)}
          />
          <span className="switch-thumb" />
        </label>
      </div>
    </div>
  );
}
