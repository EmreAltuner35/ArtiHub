import React from "react";

const VIEW_TYPES = {
  SINGLE: "Single",
  SIDE_BY_SIDE: "Two Way",
  THREE_WAY: "Three Way",
};

export default function ArtifactModal({
  viewType,
  onViewTypeChange,
  maxSelectable,

  folders,
  folderPage,
  folderTotalPages,
  loadingFolders,
  onFolderPageChange,
  selectedFolderId,
  onSelectFolder,

  artifacts,
  artifactPage,
  artifactTotalPages,
  loadingArtifacts,
  onArtifactPageChange,

  selectedArtifacts,
  onChangeSelected,
}) {
  const toggleArtifact = (artifact) => {
    if (selectedArtifacts.includes(artifact)) {
      onChangeSelected(selectedArtifacts.filter((x) => x !== artifact));
      return;
    }

    if (selectedArtifacts.length >= maxSelectable) return;
    onChangeSelected([...selectedArtifacts, artifact]);
  };

  const moveSelected = (artifact, direction) => {
    const idx = selectedArtifacts.indexOf(artifact);
    if (idx === -1) return;

    const swapWith = direction === "up" ? idx - 1 : idx + 1;
    if (swapWith < 0 || swapWith >= selectedArtifacts.length) return;

    const newOrder = [...selectedArtifacts];
    const tmp = newOrder[swapWith];
    newOrder[swapWith] = newOrder[idx];
    newOrder[idx] = tmp;

    onChangeSelected(newOrder);
  };

  const getArtifactLabel = (a) => a.title || a.id;

  const handleFolderPrev = () => {
    if (folderPage > 0 && !loadingFolders) onFolderPageChange(folderPage - 1);
  };

  const handleFolderNext = () => {
    if (folderPage + 1 < folderTotalPages && !loadingFolders) {
      onFolderPageChange(folderPage + 1);
    }
  };

  const handleArtifactPrev = () => {
    if (artifactPage > 0 && !loadingArtifacts && selectedFolderId) {
      onArtifactPageChange(artifactPage - 1);
    }
  };

  const handleArtifactNext = () => {
    if (
      artifactPage + 1 < artifactTotalPages &&
      !loadingArtifacts &&
      selectedFolderId
    ) {
      onArtifactPageChange(artifactPage + 1);
    }
  };

  return (
    <div className="task-step-two">
      <div className="task-step-head">
        <span className="task-step-head-label">View Type:</span>
        <div className="segmented">
          {Object.keys(VIEW_TYPES).map((vt) => (
            <button
              key={vt}
              type="button"
              className={`seg-option ${viewType === vt ? "active" : ""}`}
              onClick={() => onViewTypeChange(vt)}
            >
              {VIEW_TYPES[vt]}
            </button>
          ))}
        </div>
      </div>

      <p className="muted task-step-hint">
        You can select up to {maxSelectable} artifact{maxSelectable > 1 ? "s" : ""} for this view type.
      </p>

      <div className="task-artifacts-layout">
        <div className="task-artifacts-col">
          <div className="task-artifacts-col-head">
            <span className="task-artifacts-col-title">Folders</span>
            <span className="muted task-artifacts-col-meta">
              Page {folderTotalPages ? folderPage + 1 : 1}/{folderTotalPages || 1}
            </span>
          </div>

          <div className="task-artifacts-list">
            {loadingFolders && <div className="muted">Loading folders…</div>}

            {!loadingFolders && folders.length === 0 && (
              <div className="muted">No folders found.</div>
            )}

            {!loadingFolders &&
              folders.map((f) => (
                <button
                  key={f.id}
                  type="button"
                  className={
                    "task-folder-row" +
                    (selectedFolderId === f.id ? " task-folder-row--selected" : "")
                  }
                  onClick={() => onSelectFolder(f.id)}
                >
                  {f.name || "Untitled folder"}
                </button>
              ))}
          </div>

          <div className="task-pagination">
            <button
              type="button"
              className="btn small"
              onClick={handleFolderPrev}
              disabled={folderPage === 0 || loadingFolders}
            >
              Prev
            </button>
            <button
              type="button"
              className="btn small"
              onClick={handleFolderNext}
              disabled={folderPage + 1 >= folderTotalPages || loadingFolders}
            >
              Next
            </button>
          </div>
        </div>

        <div className="task-artifacts-col">
          <div className="task-artifacts-col-head">
            <span className="task-artifacts-col-title">Artifacts in folder</span>
            <span className="muted task-artifacts-col-meta">
              {selectedFolderId
                ? `Page ${artifactTotalPages ? artifactPage + 1 : 1}/${artifactTotalPages || 1}`
                : "Select a folder"}
            </span>
          </div>

          <div className="task-artifacts-list">
            {!selectedFolderId && (
              <div className="muted">Select a folder to list artifacts.</div>
            )}

            {selectedFolderId && loadingArtifacts && (
              <div className="muted">Loading artifacts…</div>
            )}

            {selectedFolderId &&
              !loadingArtifacts &&
              artifacts.length === 0 && (
                <div className="muted">No artifacts in this folder.</div>
              )}

            {selectedFolderId &&
              !loadingArtifacts &&
              artifacts.map((artifact) => (
                <button
                  key={artifact.id}
                  type="button"
                  onClick={() => toggleArtifact(artifact)}
                  className={
                    "task-artifact-row" +
                    (selectedArtifacts.includes(artifact)
                      ? " task-artifact-row--selected"
                      : " task-artifact-row--selectable")
                  }
                >
                  <span className="task-artifact-title">
                    {getArtifactLabel(artifact)}
                  </span>
                </button>
              ))}
          </div>

          <div className="task-pagination">
            <button
              type="button"
              className="btn small"
              onClick={handleArtifactPrev}
              disabled={!selectedFolderId || artifactPage === 0 || loadingArtifacts}
            >
              Prev
            </button>
            <button
              type="button"
              className="btn small"
              onClick={handleArtifactNext}
              disabled={
                !selectedFolderId ||
                artifactPage + 1 >= artifactTotalPages ||
                loadingArtifacts
              }
            >
              Next
            </button>
          </div>
        </div>

        <div className="task-artifacts-col">
          <div className="task-artifacts-col-head">
            <span className="task-artifacts-col-title">Selected order</span>
            <span className="muted task-artifacts-col-meta">
              {selectedArtifacts.length}/{maxSelectable}
            </span>
          </div>

          <div className="task-artifacts-list">
            {selectedArtifacts.length === 0 && (
              <div className="muted">
                Select artifacts in any folder to build the ordered list.
              </div>
            )}

            {selectedArtifacts.map((artifact, index) => {
              const label = artifact ? getArtifactLabel(artifact) : "";
              return (
                <div key={artifact.id} className="task-artifact-row">
                  <span className="task-artifact-index">{index + 1}.</span>
                  <span className="task-artifact-title">{label}</span>
                  <div className="task-artifact-actions">
                    <button
                      type="button"
                      className="btn small"
                      onClick={() => moveSelected(artifact, "up")}
                      disabled={index === 0}
                      title="Move up"
                    >
                      ↑
                    </button>
                    <button
                      type="button"
                      className="btn small"
                      onClick={() => moveSelected(artifact, "down")}
                      disabled={index === selectedArtifacts.length - 1}
                      title="Move down"
                    >
                      ↓
                    </button>
                    <button
                      type="button"
                      className="btn small"
                      onClick={() => toggleArtifact(artifact)}
                      title="Remove"
                    >
                      ✕
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          <p className="muted task-selected-hint">
            Order defines how artifacts will appear in the study view.
          </p>
        </div>
      </div>
    </div>
  );
}
