import React from "react";

export default function StepsBar({ steps, currentStep, onStepChange }) {
  return (
    <div className="stepper">
      {steps.map((label, index) => {
        const stepNumber = index + 1;
        const isActive = stepNumber === currentStep;
        const isCompleted = stepNumber < currentStep;

        return (
          <button
            key={label}
            type="button"
            className={[
              "stepper-step",
              isActive ? "stepper-step--active" : "",
              isCompleted ? "stepper-step--completed" : "",
            ]
              .filter(Boolean)
              .join(" ")}
            onClick={() => onStepChange(stepNumber)}
          >
            <div className="stepper-circle">
              {isCompleted ? "✓" : stepNumber}
            </div>
            <div className="stepper-label">{label}</div>
          </button>
        );
      })}
    </div>
  );
}
