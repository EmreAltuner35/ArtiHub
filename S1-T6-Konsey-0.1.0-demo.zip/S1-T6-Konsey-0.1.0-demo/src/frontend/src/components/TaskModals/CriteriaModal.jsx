import React from "react";

const SCALE_TYPES = ["FIVESTAR", "YESNO", "MULTIPLE_CHOICE"];

export default function CriteriaModal({ criteria, onChange, onAddCriterion }) {
  const updateCriterion = (id, field, value) => {
    const updated = criteria.map((c) => (c.id === id ? { ...c, [field]: value } : c));
    onChange(updated);
  };

  const removeCriterion = (id) => {
    const updated = criteria.filter((c) => c.id !== id);
    onChange(updated);
  };

  const addOption = (id) => {
    const updated = criteria.map((c) =>
      c.id === id ? { ...c, options: [...(c.options || []), ""] } : c
    );
    onChange(updated);
  };

  const updateOption = (criterionId, optionIndex, value) => {
    const updated = criteria.map((c) => {
      if (c.id !== criterionId) return c;
      const opts = [...(c.options || [])];
      opts[optionIndex] = value;
      return { ...c, options: opts };
    });
    onChange(updated);
  };

  const removeOption = (criterionId, optionIndex) => {
    const updated = criteria.map((c) => {
      if (c.id !== criterionId) return c;
      const opts = [...(c.options || [])];
      opts.splice(optionIndex, 1);
      return { ...c, options: opts };
    });
    onChange(updated);
  };

  return (
    <div className="criteria-editor">
      <div className="criteria-toolbar">
        <div className="criterion-title">Criteria</div>
        <button type="button" className="btn small" onClick={onAddCriterion}>
          + Add criterion
        </button>
      </div>

      {criteria.length === 0 && (
        <p className="muted">No criteria yet. Add at least one.</p>
      )}

      <div className="criteria-list">
        {criteria.map((c, idx) => (
          <div key={c.id} className="criterion-card">
            <div className="criterion-head">
              <div className="criterion-title">Criterion {idx + 1}</div>
              <button type="button" className="btn small" onClick={() => removeCriterion(c.id)}>
                Remove
              </button>
            </div>

            <div className="criterion-fields">
              <label>
                Name
                <input
                  className="input-dark"
                  type="text"
                  value={c.name}
                  onChange={(e) => updateCriterion(c.id, "name", e.target.value)}
                  placeholder="Clarity, usefulness, etc."
                />
              </label>

              <label>
                Description
                <textarea
                  className="textarea-dark"
                  rows={3}
                  value={c.description}
                  onChange={(e) => updateCriterion(c.id, "description", e.target.value)}
                  placeholder="Explain how this criterion should be evaluated."
                />
              </label>

              <label>
                Scale type
                <select
                  className="select-dark"
                  value={c.scaleType}
                  onChange={(e) => updateCriterion(c.id, "scaleType", e.target.value)}
                >
                  {SCALE_TYPES.map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
              </label>
            </div>

            <div className="criterion-options">
              <div className="criterion-options-head">
                <div className="muted">Options</div>
                <button type="button" className="btn small" onClick={() => addOption(c.id)}>
                  + Add option
                </button>
              </div>

              {(c.options || []).length === 0 && (
                <p className="muted">Add one or more answer options.</p>
              )}

              <div className="criterion-options-list">
                {(c.options || []).map((opt, optionIdx) => (
                  <div key={optionIdx} className="criterion-option-row">
                    <input
                      className="input-dark"
                      type="text"
                      value={opt}
                      onChange={(e) => updateOption(c.id, optionIdx, e.target.value)}
                      placeholder={`Option ${optionIdx + 1}`}
                    />
                    <button
                      type="button"
                      className="btn small"
                      onClick={() => removeOption(c.id, optionIdx)}
                      title="Remove option"
                    >
                      ✕
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
