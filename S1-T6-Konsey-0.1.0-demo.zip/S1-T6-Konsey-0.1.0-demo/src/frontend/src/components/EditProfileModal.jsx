import React, { useState } from "react";
import api from "../api";

export default function EditProfileModal({ user, onClose, onUpdated }) {
  const [displayName, setDisplayName] = useState(user?.displayName || "");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Build payload dynamically — only include non-empty fields
    const payload = {};
    if (displayName && displayName !== user.displayName) {
      payload.displayName = displayName;
    }
    if (password.trim()) {
      payload.password = password;
    }

    if (Object.keys(payload).length === 0) {
      alert("No changes detected.");
      return;
    }

    setLoading(true);
    try {
      await api.put("/api/users/me", payload);
      alert("Profile updated successfully.");
      onUpdated();
      onClose();
    } catch (err) {
      console.error("Update failed:", err);
      alert("Failed to update profile. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        backgroundColor: "rgba(0,0,0,0.6)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        zIndex: 1000,
      }}
    >
      <div
        style={{
          background: "#1e1e1e",
          color: "white",
          padding: "24px",
          borderRadius: "10px",
          width: "320px",
          boxShadow: "0 4px 20px rgba(0,0,0,0.4)",
        }}
      >
        <h3 style={{ marginBottom: "16px" }}>Edit Profile</h3>
        <form onSubmit={handleSubmit}>
          <label style={{ display: "block", marginBottom: "8px" }}>
            Display Name:
          </label>
          <input
            type="text"
            value={displayName}
            onChange={(e) => setDisplayName(e.target.value)}
            style={{
              width: "100%",
              padding: "8px",
              marginBottom: "12px",
              borderRadius: "4px",
              border: "1px solid #555",
              backgroundColor: "#2c2c2c",
              color: "white",
            }}
          />

          <label style={{ display: "block", marginBottom: "8px" }}>
            New Password:
          </label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            style={{
              width: "100%",
              padding: "8px",
              marginBottom: "20px",
              borderRadius: "4px",
              border: "1px solid #555",
              backgroundColor: "#2c2c2c",
              color: "white",
            }}
            placeholder="Leave blank to keep current password"
          />

          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
            }}
          >
            <button
              type="button"
              onClick={onClose}
              style={{
                backgroundColor: "#555",
                color: "white",
                border: "none",
                padding: "8px 16px",
                borderRadius: "4px",
                cursor: "pointer",
              }}
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              style={{
                backgroundColor: loading ? "#1d4ed8a0" : "#2563eb",
                color: "white",
                border: "none",
                padding: "8px 16px",
                borderRadius: "4px",
                cursor: "pointer",
              }}
            >
              {loading ? "Saving..." : "Save"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
