import React, { useState, useEffect } from 'react';
import api from '../api';

/**
 * ForumPostAttachmentViewer - Displays post attachments (linked artifacts) in forum posts.
 * 
 * Similar to QuizAttachmentViewer but works with backend AttachmentResponse format.
 * 
 * Props:
 * - attachments: Array of { attachmentId, type, artifactId, fileName, fileUrl, contentType }
 */
export default function ForumPostAttachmentViewer({ attachments = [] }) {
    const [loadedAttachments, setLoadedAttachments] = useState([]);
    const [currentIndex, setCurrentIndex] = useState(0);
    const [loading, setLoading] = useState(true);
    const [expandedArtifact, setExpandedArtifact] = useState(null);

    useEffect(() => {
        loadAttachments();
    }, [attachments]);

    const loadAttachments = async () => {
        if (!attachments || attachments.length === 0) {
            setLoadedAttachments([]);
            setLoading(false);
            return;
        }

        setLoading(true);
        const loaded = await Promise.all(
            attachments.map(async (att) => {
                try {
                    // If it has artifactId, fetch from artifact service
                    if (att.artifactId) {
                        // Fetch artifact metadata
                        const metaRes = await api.get(`/api/artifacts/${att.artifactId}`);
                        const artifact = metaRes.data;

                        // Determine if it's an image or text/code/pdf
                        const contentType = artifact.contentType || att.contentType || '';
                        const isImage = contentType.startsWith('image');
                        const isPdf = contentType === 'application/pdf';

                        if (isPdf) {
                            // For PDFs, return link to open in new tab
                            return {
                                type: 'pdf',
                                url: `/api/artifacts/${att.artifactId}/file`,
                                title: artifact.title || att.fileName || 'PDF Document',
                            };
                        }

                        // Fetch the file content
                        const fileRes = await api.get(`/api/artifacts/${att.artifactId}/file?download=0`, {
                            responseType: isImage ? 'blob' : 'text',
                        });

                        if (isImage) {
                            const blobUrl = URL.createObjectURL(fileRes.data);
                            return {
                                type: 'image',
                                src: blobUrl,
                                title: artifact.title || att.fileName || 'Image',
                                isBlob: true,
                            };
                        } else {
                            // Text/code content
                            const content = typeof fileRes.data === 'string'
                                ? fileRes.data
                                : await fileRes.data.text();
                            return {
                                type: 'text',
                                content,
                                title: artifact.title || att.fileName || 'Document',
                                language: getLanguageFromType(contentType, artifact.title),
                            };
                        }
                    } else if (att.fileUrl) {
                        // Direct file URL (uploaded file)
                        const contentType = att.contentType || '';
                        const isImage = contentType.startsWith('image');
                        const isPdf = contentType === 'application/pdf';

                        if (isPdf) {
                            return {
                                type: 'pdf',
                                url: att.fileUrl,
                                title: att.fileName || 'PDF Document',
                            };
                        }

                        if (isImage) {
                            return {
                                type: 'image',
                                src: att.fileUrl,
                                title: att.fileName || 'Image',
                                isBlob: false,
                            };
                        }

                        return {
                            type: 'link',
                            url: att.fileUrl,
                            title: att.fileName || 'File',
                        };
                    }

                    return {
                        type: 'error',
                        title: 'Unknown attachment type',
                    };
                } catch (err) {
                    console.error('Failed to load attachment:', att, err);
                    return {
                        type: 'error',
                        title: att.fileName || 'Failed to load',
                    };
                }
            })
        );

        setLoadedAttachments(loaded);
        setCurrentIndex(0);
        setLoading(false);
    };

    // Cleanup blob URLs on unmount
    useEffect(() => {
        return () => {
            loadedAttachments.forEach((att) => {
                if (att.isBlob) {
                    URL.revokeObjectURL(att.src);
                }
            });
        };
    }, [loadedAttachments]);

    const getLanguageFromType = (contentType, filename) => {
        if (contentType.includes('json')) return 'json';
        if (contentType.includes('xml')) return 'xml';
        if (contentType.includes('javascript')) return 'javascript';
        if (contentType.includes('python')) return 'python';
        if (contentType.includes('java')) return 'java';
        if (contentType.includes('html')) return 'html';
        if (contentType.includes('css')) return 'css';
        if (filename) {
            const ext = filename.split('.').pop()?.toLowerCase();
            const langMap = {
                js: 'javascript', ts: 'typescript', py: 'python',
                java: 'java', json: 'json', xml: 'xml', html: 'html',
                css: 'css', md: 'markdown', txt: 'plaintext', pdf: 'pdf',
            };
            return langMap[ext] || 'plaintext';
        }
        return 'plaintext';
    };

    const handlePrev = () => {
        setCurrentIndex((prev) => (prev - 1 + loadedAttachments.length) % loadedAttachments.length);
    };

    const handleNext = () => {
        setCurrentIndex((prev) => (prev + 1) % loadedAttachments.length);
    };

    if (!attachments || attachments.length === 0) return null;
    if (loading) {
        return (
            <div style={{ marginTop: 12, textAlign: 'center', color: '#9ca3af', fontSize: 12 }}>
                Loading attachments...
            </div>
        );
    }
    if (loadedAttachments.length === 0) return null;

    const current = loadedAttachments[currentIndex];

    return (
        <div style={{ marginTop: 12, paddingTop: 12, borderTop: '1px solid #374151' }}>
            <div style={{ fontSize: 12, color: '#9ca3af', marginBottom: 8 }}>Attachments:</div>

            {/* Carousel Display */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                {/* Previous Button */}
                {loadedAttachments.length > 1 && (
                    <button
                        type="button"
                        onClick={handlePrev}
                        style={{
                            width: 32,
                            height: 32,
                            borderRadius: '50%',
                            backgroundColor: 'rgba(6, 182, 212, 0.8)',
                            color: 'white',
                            border: 'none',
                            cursor: 'pointer',
                            fontSize: 16,
                            fontWeight: 'bold',
                        }}
                    >
                        ‹
                    </button>
                )}

                {/* Content Display */}
                <div style={{ flex: 1, display: 'flex', justifyContent: 'center' }}>
                    {current.type === 'image' ? (
                        <img
                            src={current.src}
                            alt={current.title}
                            style={{
                                maxWidth: '100%',
                                maxHeight: 200,
                                objectFit: 'contain',
                                borderRadius: 8,
                                border: '1px solid #3f3f46',
                                cursor: 'pointer',
                            }}
                            onClick={() => setExpandedArtifact(current)}
                        />
                    ) : current.type === 'text' ? (
                        <div
                            style={{
                                width: '100%',
                                maxHeight: 200,
                                overflow: 'auto',
                                backgroundColor: '#1e1e1e',
                                borderRadius: 8,
                                border: '1px solid #3f3f46',
                                cursor: 'pointer',
                            }}
                            onClick={() => setExpandedArtifact(current)}
                        >
                            <div style={{
                                padding: '6px 10px',
                                borderBottom: '1px solid #3f3f46',
                                backgroundColor: '#2d2d2d',
                                fontSize: 11,
                                color: '#06b6d4',
                                fontWeight: 600,
                            }}>
                                📄 {current.title}
                                <span style={{ marginLeft: 6, color: '#9ca3af', fontWeight: 400 }}>
                                    (click to expand)
                                </span>
                            </div>
                            <pre style={{
                                margin: 0,
                                padding: 10,
                                fontSize: 11,
                                lineHeight: 1.4,
                                color: '#e5e7eb',
                                fontFamily: 'monospace',
                                whiteSpace: 'pre-wrap',
                                wordBreak: 'break-word',
                            }}>
                                {current.content.slice(0, 300)}
                                {current.content.length > 300 && '...'}
                            </pre>
                        </div>
                    ) : current.type === 'pdf' ? (
                        <a
                            href={current.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            style={{
                                display: 'flex',
                                alignItems: 'center',
                                gap: 8,
                                padding: '16px 24px',
                                backgroundColor: '#1e1e1e',
                                borderRadius: 8,
                                border: '1px solid #3f3f46',
                                color: '#60a5fa',
                                textDecoration: 'none',
                                fontSize: 14,
                            }}
                        >
                            📑 {current.title}
                            <span style={{ fontSize: 11, color: '#9ca3af' }}>(Open PDF)</span>
                        </a>
                    ) : current.type === 'link' ? (
                        <a
                            href={current.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            style={{
                                display: 'flex',
                                alignItems: 'center',
                                gap: 8,
                                padding: '16px 24px',
                                backgroundColor: '#1e1e1e',
                                borderRadius: 8,
                                border: '1px solid #3f3f46',
                                color: '#60a5fa',
                                textDecoration: 'none',
                                fontSize: 14,
                            }}
                        >
                            📎 {current.title}
                            <span style={{ fontSize: 11, color: '#9ca3af' }}>(Download)</span>
                        </a>
                    ) : (
                        <div style={{
                            padding: 16,
                            backgroundColor: '#27272a',
                            borderRadius: 8,
                            color: '#ef4444',
                            fontSize: 13,
                        }}>
                            ⚠️ {current.title || 'Error loading attachment'}
                        </div>
                    )}
                </div>

                {/* Next Button */}
                {loadedAttachments.length > 1 && (
                    <button
                        type="button"
                        onClick={handleNext}
                        style={{
                            width: 32,
                            height: 32,
                            borderRadius: '50%',
                            backgroundColor: 'rgba(6, 182, 212, 0.8)',
                            color: 'white',
                            border: 'none',
                            cursor: 'pointer',
                            fontSize: 16,
                            fontWeight: 'bold',
                        }}
                    >
                        ›
                    </button>
                )}
            </div>

            {/* Page Indicator */}
            {loadedAttachments.length > 1 && (
                <div style={{ textAlign: 'center', marginTop: 8, color: '#9ca3af', fontSize: 11 }}>
                    {currentIndex + 1} / {loadedAttachments.length}
                </div>
            )}

            {/* Expanded View Modal */}
            {expandedArtifact && (
                <div
                    style={{
                        position: 'fixed',
                        top: 0,
                        left: 0,
                        right: 0,
                        bottom: 0,
                        backgroundColor: 'rgba(0,0,0,0.95)',
                        zIndex: 2000,
                        display: 'flex',
                        flexDirection: 'column',
                        padding: 20,
                    }}
                    onClick={() => setExpandedArtifact(null)}
                >
                    <div style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        marginBottom: 16,
                    }}>
                        <h3 style={{ margin: 0, color: '#06b6d4' }}>
                            {expandedArtifact.title}
                        </h3>
                        <button
                            type="button"
                            onClick={() => setExpandedArtifact(null)}
                            style={{
                                padding: '8px 16px',
                                borderRadius: 6,
                                border: 'none',
                                backgroundColor: '#3f3f46',
                                color: 'white',
                                cursor: 'pointer',
                            }}
                        >
                            Close ✕
                        </button>
                    </div>
                    <div
                        style={{
                            flex: 1,
                            overflow: 'auto',
                            display: 'flex',
                            justifyContent: 'center',
                            alignItems: 'flex-start',
                        }}
                        onClick={(e) => e.stopPropagation()}
                    >
                        {expandedArtifact.type === 'image' ? (
                            <img
                                src={expandedArtifact.src}
                                alt={expandedArtifact.title}
                                style={{
                                    maxWidth: '100%',
                                    maxHeight: '90vh',
                                    objectFit: 'contain',
                                }}
                            />
                        ) : (
                            <pre style={{
                                margin: 0,
                                padding: 20,
                                backgroundColor: '#1e1e1e',
                                borderRadius: 8,
                                fontSize: 14,
                                lineHeight: 1.6,
                                color: '#e5e7eb',
                                fontFamily: 'monospace',
                                whiteSpace: 'pre-wrap',
                                wordBreak: 'break-word',
                                width: '100%',
                                maxWidth: 1000,
                            }}>
                                {expandedArtifact.content}
                            </pre>
                        )}
                    </div>
                </div>
            )}
        </div>
    );
}
