import React, { useState, useEffect, useRef } from 'react';
import api from '../api';
import QuizAttachmentViewer from './QuizAttachmentViewer';

export default function TakeQuizModal({ invitation, onClose, onSubmit }) {
    const [quiz, setQuiz] = useState(null);
    const [answers, setAnswers] = useState({});
    const [loading, setLoading] = useState(true);
    const [submitting, setSubmitting] = useState(false);
    const [timeLeft, setTimeLeft] = useState(null); // Time in seconds
    const timerRef = useRef(null);

    useEffect(() => {
        fetchQuiz();
        return () => {
            if (timerRef.current) clearInterval(timerRef.current);
        };
    }, [invitation.quizId]);

    useEffect(() => {
        if (timeLeft === 0) {
            handleSubmit();
        }
    }, [timeLeft]);

    const fetchQuiz = async () => {
        try {
            const response = await api.get(`/api/quizzes/${invitation.quizId}`);
            const fetchedQuiz = response.data;
            setQuiz(fetchedQuiz);

            // Initialize timer if timeLimit exists
            if (fetchedQuiz.timeLimit && fetchedQuiz.timeLimit > 0) {
                setTimeLeft(fetchedQuiz.timeLimit);
                timerRef.current = setInterval(() => {
                    setTimeLeft(prev => {
                        if (prev <= 1) {
                            clearInterval(timerRef.current);
                            return 0;
                        }
                        return prev - 1;
                    });
                }, 1000);
            }
        } catch (error) {
            console.error("Error fetching quiz:", error);
            alert("Failed to load quiz.");
            onClose();
        } finally {
            setLoading(false);
        }
    };

    const formatTime = (seconds) => {
        const mins = Math.floor(seconds / 60);
        const secs = seconds % 60;
        return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
    };

    const handleAnswerChange = (questionId, value, type) => {
        if (type === 'MULTIPLE_CHOICE') {
            setAnswers(prev => {
                const currentAnswers = prev[questionId] || [];
                if (currentAnswers.includes(value)) {
                    return { ...prev, [questionId]: currentAnswers.filter(id => id !== value) };
                } else {
                    return { ...prev, [questionId]: [...currentAnswers, value] };
                }
            });
        } else {
            setAnswers(prev => ({
                ...prev,
                [questionId]: value
            }));
        }
    };

    const handleSubmit = async () => {
        if (!quiz || submitting) return;

        // Calculate auto-score
        let autoScore = 0;
        let maxScore = 0;

        // Assuming each question is worth 10 points for simplicity
        const POINTS_PER_QUESTION = 10;

        quiz.questions.forEach(q => {
            maxScore += POINTS_PER_QUESTION;

            if (q.questionType === 'SINGLE_CHOICE') {
                const userAnswer = answers[q.questionId];
                const correctAnswers = q.answers.filter(a => a.isCorrect).map(a => a.answerId);
                if (correctAnswers.includes(userAnswer)) {
                    autoScore += POINTS_PER_QUESTION;
                }
            } else if (q.questionType === 'MULTIPLE_CHOICE') {
                const userAnswers = answers[q.questionId] || [];
                const correctAnswers = q.answers.filter(a => a.isCorrect).map(a => a.answerId);

                // Check if user selected exactly the correct answers
                const isCorrect = userAnswers.length === correctAnswers.length &&
                    userAnswers.every(val => correctAnswers.includes(val));

                if (isCorrect) {
                    autoScore += POINTS_PER_QUESTION;
                }
            }
            // Text questions get 0 auto-score, will be graded manually.
        });

        const payload = {
            autoScore: autoScore,
            maxScore: maxScore,
            answers: JSON.stringify(answers)
        };

        try {
            setSubmitting(true);
            if (timerRef.current) clearInterval(timerRef.current);

            await api.post(`/api/studies/participant/invitations/${invitation.invitationId}/quiz`, payload);

            if (timeLeft === 0) {
                alert(`Time's up! Quiz submitted automatically. Your preliminary score is ${autoScore}/${maxScore}.`);
            } else {
                alert(`Quiz submitted! Your preliminary score is ${autoScore}/${maxScore}. Text answers will be reviewed.`);
            }
            onSubmit();
        } catch (error) {
            console.error("Error submitting quiz:", error);
            alert("Failed to submit quiz.");
            setSubmitting(false); // Only reset if error, otherwise component unmounts
        }
    };

    if (loading) return null;

    return (
        <div style={{
            position: 'fixed',
            top: 0, left: 0, right: 0, bottom: 0,
            backgroundColor: 'rgba(0,0,0,0.95)',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            zIndex: 1000,
            backdropFilter: 'blur(5px)'
        }}>
            <div style={{
                backgroundColor: '#121212',
                borderRadius: '0',
                width: '100%',
                height: '100%',
                color: 'white',
                overflowY: 'auto',
                display: 'flex',
                flexDirection: 'column'
            }}>
                {/* Fixed Timer in Top-Right Corner */}
                {timeLeft !== null && (
                    <div style={{
                        position: 'fixed',
                        top: '20px',
                        right: '20px',
                        zIndex: 100,
                        fontSize: '1.8rem',
                        fontWeight: 'bold',
                        color: timeLeft < 60 ? '#ef4444' : '#10b981',
                        backgroundColor: 'rgba(0,0,0,0.9)',
                        padding: '15px 25px',
                        borderRadius: '12px',
                        border: `2px solid ${timeLeft < 60 ? '#ef4444' : '#10b981'}`,
                        boxShadow: '0 10px 25px rgba(0, 0, 0, 0.5)'
                    }}>
                        ⏱ {formatTime(timeLeft)}
                    </div>
                )}

                {/* Header */}
                <div style={{
                    position: 'sticky',
                    top: 0,
                    zIndex: 10,
                    backgroundColor: '#1e1e1e',
                    borderBottom: '1px solid #333',
                    padding: '20px 40px',
                    display: 'flex',
                    justifyContent: 'flex-start',
                    alignItems: 'center',
                    boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.3)'
                }}>
                    <div>
                        <h2 style={{ margin: 0, fontSize: '1.8rem', color: '#f3f4f6' }}>{quiz.title}</h2>
                        <p style={{ margin: '5px 0 0', color: '#9ca3af', fontSize: '1rem' }}>{quiz.description}</p>
                    </div>
                </div>

                {/* Content */}
                <div style={{
                    flex: 1,
                    padding: '40px',
                    maxWidth: '1200px',
                    margin: '0 auto',
                    width: '100%'
                }}>
                    {quiz.questions.map((q, index) => {
                        return (
                            <div key={q.questionId} style={{
                                marginBottom: '40px',
                                padding: '30px',
                                backgroundColor: '#1e1e1e',
                                borderRadius: '12px',
                                border: '1px solid #3f3f46',
                                boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                            }}>
                                <h4 style={{ marginTop: 0, marginBottom: '10px', fontSize: '1.3rem', color: '#e5e7eb', lineHeight: '1.5' }}>
                                    <span style={{ color: '#8b5cf6', marginRight: '15px' }}>{index + 1}.</span>
                                    {q.questionText}
                                </h4>
                                {q.questionType !== 'TEXT' && (
                                    <p style={{
                                        margin: '0 0 20px 0',
                                        fontSize: '0.9rem',
                                        color: q.questionType === 'MULTIPLE_CHOICE' ? '#f59e0b' : '#3b82f6',
                                        fontStyle: 'italic'
                                    }}>
                                        {q.questionType === 'MULTIPLE_CHOICE' ? '📋 Select all that apply' : '🔘 Select one answer'}
                                    </p>
                                )}

                                {/* Attachments (Images and Artifacts) */}
                                {q.images && q.images.length > 0 && (
                                    <QuizAttachmentViewer
                                        images={q.images}
                                        questionId={q.questionId}
                                    />
                                )}

                                {q.questionType === 'TEXT' ? (
                                    <textarea
                                        value={answers[q.questionId] || ''}
                                        onChange={(e) => handleAnswerChange(q.questionId, e.target.value, 'TEXT')}
                                        style={{
                                            width: '100%',
                                            minHeight: '150px',
                                            padding: '20px',
                                            borderRadius: '8px',
                                            backgroundColor: '#27272a',
                                            color: 'white',
                                            border: '1px solid #52525b',
                                            fontSize: '1.1rem',
                                            resize: 'vertical',
                                            outline: 'none',
                                            fontFamily: 'inherit'
                                        }}
                                        placeholder="Type your answer here..."
                                        onFocus={(e) => e.target.style.borderColor = '#8b5cf6'}
                                        onBlur={(e) => e.target.style.borderColor = '#52525b'}
                                    />
                                ) : (
                                    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                                        {q.answers.map(a => (
                                            <label key={a.answerId} style={{
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'space-between',
                                                cursor: 'pointer',
                                                padding: '20px',
                                                borderRadius: '8px',
                                                backgroundColor: (q.questionType === 'MULTIPLE_CHOICE'
                                                    ? (answers[q.questionId] || []).includes(a.answerId)
                                                    : answers[q.questionId] === a.answerId) ? '#312e81' : '#27272a',
                                                border: (q.questionType === 'MULTIPLE_CHOICE'
                                                    ? (answers[q.questionId] || []).includes(a.answerId)
                                                    : answers[q.questionId] === a.answerId) ? '1px solid #8b5cf6' : '1px solid #3f3f46',
                                                transition: 'all 0.2s',
                                                width: '100%'
                                            }}
                                                onMouseEnter={(e) => {
                                                    if (!((q.questionType === 'MULTIPLE_CHOICE'
                                                        ? (answers[q.questionId] || []).includes(a.answerId)
                                                        : answers[q.questionId] === a.answerId))) {
                                                        e.currentTarget.style.borderColor = '#8b5cf6';
                                                        e.currentTarget.style.backgroundColor = '#3f3f46';
                                                    }
                                                }}
                                                onMouseLeave={(e) => {
                                                    if (!((q.questionType === 'MULTIPLE_CHOICE'
                                                        ? (answers[q.questionId] || []).includes(a.answerId)
                                                        : answers[q.questionId] === a.answerId))) {
                                                        e.currentTarget.style.borderColor = '#3f3f46';
                                                        e.currentTarget.style.backgroundColor = '#27272a';
                                                    }
                                                }}
                                            >
                                                <span style={{ fontSize: '1.1rem', textAlign: 'left', flexGrow: 1, paddingRight: '30px' }}>{a.answerText}</span>
                                                <input
                                                    type={q.questionType === 'MULTIPLE_CHOICE' ? "checkbox" : "radio"}
                                                    name={q.questionId}
                                                    value={a.answerId}
                                                    checked={q.questionType === 'MULTIPLE_CHOICE'
                                                        ? (answers[q.questionId] || []).includes(a.answerId)
                                                        : answers[q.questionId] === a.answerId
                                                    }
                                                    onChange={() => handleAnswerChange(q.questionId, a.answerId, q.questionType)}
                                                    style={{ display: 'none' }}
                                                />
                                            </label>
                                        ))}
                                    </div>
                                )}
                            </div>
                        );
                    })}
                </div>

                {/* Footer */}
                <div style={{
                    position: 'sticky',
                    bottom: 0,
                    backgroundColor: '#1e1e1e',
                    borderTop: '1px solid #333',
                    padding: '20px 40px',
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    boxShadow: '0 -4px 6px -1px rgba(0, 0, 0, 0.3)'
                }}>
                    <button
                        onClick={onClose}
                        style={{
                            padding: '16px 32px',
                            borderRadius: '8px',
                            border: '1px solid #4b5563',
                            backgroundColor: 'transparent',
                            color: '#d1d5db',
                            cursor: 'pointer',
                            fontSize: '1.1rem',
                            transition: 'background-color 0.2s',
                            fontWeight: '600'
                        }}
                        onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#374151'}
                        onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
                    >
                        Cancel
                    </button>
                    <button
                        onClick={handleSubmit}
                        disabled={submitting}
                        style={{
                            padding: '16px 48px',
                            borderRadius: '8px',
                            border: 'none',
                            backgroundColor: submitting ? '#4b5563' : '#8b5cf6',
                            color: 'white',
                            cursor: 'pointer',
                            fontWeight: 'bold',
                            fontSize: '1.2rem',
                            boxShadow: '0 10px 15px -3px rgba(139, 92, 246, 0.3)',
                            transition: 'all 0.2s',
                            transform: submitting ? 'none' : 'translateY(-2px)'
                        }}
                        onMouseEnter={(e) => !submitting && (e.currentTarget.style.backgroundColor = '#7c3aed')}
                        onMouseLeave={(e) => !submitting && (e.currentTarget.style.backgroundColor = '#8b5cf6')}
                    >
                        {submitting ? 'Submitting...' : 'Submit Quiz'}
                    </button>
                </div>
            </div>
        </div>
    );
}
