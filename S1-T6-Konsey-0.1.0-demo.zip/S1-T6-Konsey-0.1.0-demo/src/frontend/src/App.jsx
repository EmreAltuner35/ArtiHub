import React from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Dashboard from "./pages/Dashboard";
import ProtectedRoute from "./auth/ProtectedRoute";
import Analytics from "./pages/Analytics";
import Studies from "./pages/Studies";
import Artifacts from "./pages/Artifacts";
import Assignments from "./pages/Assignments";
import Account from "./pages/Account";
import UploadArtifactPage from "./pages/UploadArtifact";
import GenerateArtifact from "./pages/GenerateArtifact";
import GenerateQuiz from "./pages/GenerateQuiz";
import ArtifactDetail from "./pages/ArtifactDetail";
import StudyCreationPage from './pages/StudyCreationPage';
import ManageStudy from './pages/ManageStudy';
import ManageTask from './pages/ManageTask';
import Quizzes from "./pages/Quizzes";
import CreateQuiz from "./pages/CreateQuiz";
import EditQuiz from "./pages/EditQuiz";
import QuizDetail from "./pages/QuizDetail";
import TaskView from "./pages/TaskView";
import AddTask from "./pages/AddTask"
import StudyTasks from "./pages/StudyTasks";
import ViewTask from "./pages/ViewTask";
import ViewStudy from "./pages/ViewStudy";
import StudyAnalytics from "./pages/StudyAnalytics";
import TaskAnalytics from "./pages/TaskAnalytics";
import ReviewerTaskView from "./components/ReviewerView/ReviewerTaskView";
import ReviewerTasks from "./components/ReviewerTasks";
import FinalizeParticipantReview from "./components/ReviewerView/FinalizeParticipantReview";
import Forums from "./pages/Forums";
import ForumDetail from "./pages/ForumDetail";
import ThreadDetail from "./pages/ThreadDetail";
import RoleApplicationPage from "./pages/RoleApplication";


export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Navigate to="/login" replace />} />
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />

      {/* Dashboards */}
      <Route
        path="/dashboard"
        element={
          <ProtectedRoute roles={["all"]}>
            <Dashboard />
          </ProtectedRoute>
        }
      />

      {/* Researcher routes */}
      <Route
        path="/analytics"
        element={
          <ProtectedRoute roles={["admin", "researcher"]}>
            <Analytics />
          </ProtectedRoute>
        }
      />
      <Route
        path="/StudyCreationPage"
        element={
          <ProtectedRoute roles={["researcher"]}>
            <StudyCreationPage />
          </ProtectedRoute>
        }
      />
      <Route
        path="/studies"
        element={
          <ProtectedRoute roles={["researcher"]}>
            <Studies />
          </ProtectedRoute>
        }
      />
      <Route
        path="/study/:id/tasks"
        element={
          <ProtectedRoute roles={["researcher", "admin"]}>
            <ManageStudy />
          </ProtectedRoute>
        }
      />
      <Route
        path="/study/:studyId/task/:taskId"
        element={
          <ProtectedRoute roles={["researcher", "admin"]}>
            <ManageTask />
          </ProtectedRoute>
        }
      />
      <Route
        path="/study/:studyId/addTask"
        element={
          <ProtectedRoute roles={["researcher", "admin"]}>
            <AddTask />
          </ProtectedRoute>
        }
      />
      <Route
        path="/study/:studyId/viewstudy"
        element={
          <ProtectedRoute roles={["researcher", "admin"]}>
            <ViewStudy />
          </ProtectedRoute>
        }
      />
      <Route
        path="/study/:studyId/task/:taskId/viewtask"
        element={
          <ProtectedRoute roles={["researcher", "admin"]}>
            <ViewTask />
          </ProtectedRoute>
        }
      />
      <Route
        path="/analytics/:studyId"
        element={
          <ProtectedRoute roles={["researcher", "admin", "reviewer"]}>
            <StudyAnalytics />
          </ProtectedRoute>
        }
      />
      <Route
        path="/analytics/:studyId/:taskId"
        element={
          <ProtectedRoute roles={["researcher", "admin", "reviewer"]}>
            <TaskAnalytics />
          </ProtectedRoute>
        }
      />
      <Route
        path="/artifacts"
        element={
          <ProtectedRoute roles={["researcher"]}>
            <Artifacts />
          </ProtectedRoute>
        }
      />
      <Route
        path="/artifacts/:id"
        element={
          <ArtifactDetail />
        }
      />
      <Route
        path="/quizzes"
        element={
          <ProtectedRoute roles={["researcher"]}>
            <Quizzes />
          </ProtectedRoute>
        }
      />
      <Route
        path="/quizzes/create"
        element={
          <ProtectedRoute roles={["researcher"]}>
            <CreateQuiz />
          </ProtectedRoute>
        }
      />
      <Route
        path="/quizzes/:id"
        element={
          <ProtectedRoute roles={["researcher"]}>
            <QuizDetail />
          </ProtectedRoute>
        }
      />
      <Route
        path="/quizzes/:id/edit"
        element={
          <ProtectedRoute roles={["researcher"]}>
            <EditQuiz />
          </ProtectedRoute>
        }
      />

      {/* Participant routes */}
      <Route
        path="/assignments"
        element={
          <ProtectedRoute roles={["participant"]}>
            <Assignments />
          </ProtectedRoute>
        }
      />

      {/* Account page for all roles */}
      <Route
        path="/account"
        element={
          <ProtectedRoute roles={["admin", "researcher", "participant", "reviwer"]}>
            <Account />
          </ProtectedRoute>
        }
      />

      <Route
        path="/account/role-application"
        element={
          <ProtectedRoute roles={["participant"]}>
            <RoleApplicationPage />
          </ProtectedRoute>
        }
      />

      {/* Upload page for artifacts */}
      <Route
        path="/artifacts/upload"
        element={
          <ProtectedRoute roles={["researcher"]}>
            <UploadArtifactPage />
          </ProtectedRoute>
        }
      />
      <Route
        path="/artifacts/generate"
        element={
          <ProtectedRoute roles={["researcher"]}>
            <GenerateArtifact />
          </ProtectedRoute>
        }
      />
      <Route
        path="/quizzes/generate"
        element={
          <ProtectedRoute roles={["researcher"]}>
            <GenerateQuiz />
          </ProtectedRoute>
        }
      />
      {/* Comparison view */}
      <Route
        path="/:studyId/tasks/:taskId"
        element={
          <ProtectedRoute roles={["all"]}>
            <TaskView />
          </ProtectedRoute>
        }
      />
      {/* Comparison view */}
      <Route
        path="/:studyId/tasks"
        element={
          <ProtectedRoute roles={["all"]}>
            <StudyTasks />
          </ProtectedRoute>
        }
      />

      <Route
        path="/study/:studyId/participant/:participantId/review"
        element={
          <ProtectedRoute roles={["reviewer", "admin", "researcher"]}>
            <ReviewerTaskView />
          </ProtectedRoute>
        }
      />

      <Route
        path="/study/:studyId/list"
        element={
          <ProtectedRoute roles={["reviewer", "admin", "researcher"]}>
            <ReviewerTasks />
          </ProtectedRoute>
        }
      />
      
        <Route
        path="/study/:studyId/participant/:participantId/review/finalize"
        element={
          <ProtectedRoute roles={["reviewer", "admin", "researcher"]}>
            <FinalizeParticipantReview />
          </ProtectedRoute>
        }
      />

      {/* Forum routes */}
      <Route
        path="/forums"
        element={
          <ProtectedRoute roles={["all"]}>
            <Forums />
          </ProtectedRoute>
        }
      />
      <Route
        path="/forums/:id"
        element={
          <ProtectedRoute roles={["all"]}>
            <ForumDetail />
          </ProtectedRoute>
        }
      />
      <Route
        path="/forums/:forumId/threads/:threadId"
        element={
          <ProtectedRoute roles={["all"]}>
            <ThreadDetail />
          </ProtectedRoute>
        }
      />

      {/* fallback */}
      <Route path="*" element={<div style={{ padding: 20 }}>Not found</div>} />
    </Routes>
  );
}
