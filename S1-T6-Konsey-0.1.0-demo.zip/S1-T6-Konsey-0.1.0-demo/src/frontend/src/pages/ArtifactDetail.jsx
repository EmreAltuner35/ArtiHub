import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import Navbar from "../components/Navbar";
import api from "../api";

export default function ArtifactDetail() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [artifact, setArtifact] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [downloading, setDownloading] = useState(false);
  const [downloadError, setDownloadError] = useState("");

  useEffect(() => {
    const fetchArtifact = async () => {
      try {
        const res = await api.get(`/api/artifacts/${id}`);
        setArtifact(res.data);
      } catch (e) {
        console.error("Failed to fetch artifact:", e);
        setError("Failed to load artifact");
      } finally {
        setLoading(false);
      }
    };
    fetchArtifact();
  }, [id]);

  const formatDate = (iso) => {
    if (!iso) return "-";
    return new Date(iso).toLocaleString();
  };

  const formatBytes = (bytes) => {
    if (bytes === 0 || bytes == null) return "0 B";
    const k = 1024;
    const sizes = ["B", "KB", "MB", "GB", "TB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
  };

  const resolveFileName = (contentDispositionHeader) => {
    if (contentDispositionHeader) {
      const cd = contentDispositionHeader;
      const nameMatch = cd.match(/name\s*=\s*(".*?"|[^;]+)/i);
      if (nameMatch && nameMatch[1]) {
        let value = nameMatch[1].trim();
        value = value.replace(/^"(.*)"$/, "$1");
        return value;
      }
    }
  };

  const handleDownload = async () => {
    if (!id || downloading) return;

    setDownloadError("");
    setDownloading(true);

    try {
      const res = await api.get(`/api/artifacts/${id}/file`, {
        params: { mode: "download" },
        responseType: "blob",
      });

      const contentDisposition = res.headers["content-disposition"];
      const contentType = res.headers["content-type"] || "application/octet-stream";
      const fileName = resolveFileName(contentDisposition);

      const blob = new Blob([res.data], { type: contentType });
      const url = window.URL.createObjectURL(blob);

      const link = document.createElement("a");
      link.href = url;
      link.download = fileName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      window.URL.revokeObjectURL(url);
    } catch (e) {
      console.error("Failed to download artifact:", e);
      setDownloadError("Failed to download artifact");
    } finally {
      setDownloading(false);
    }
  };

  return (
    <>
      <Navbar />

      <div className="page page--narrow">
        <header className="page-header">
          <div>
            <h1 className="page-title">Artifact Detail</h1>
            <p className="page-subtitle">Artifact ID: {id}</p>
          </div>
          <button
            onClick={() => navigate("/artifacts")}
            className="btn btn-sm btn-secondary"
          >
            Back
          </button>
        </header>

        <div className="card artifact-detail-card">
          {loading && <div>Loading artifact...</div>}
          {error && <div className="error">{error}</div>}

          {!loading && !error && artifact && (
            <>
              <div className="artifact-detail-header">
                <h2>{artifact.title}</h2>
                {artifact.isAIGenerated && (
                  <span className="artifact-card-ai-badge">
                    AI Generated
                  </span>
                )}
              </div>

              <div className="artifact-detail-meta-grid">
                <div>
                  <label>Type</label>
                  <div>{artifact.type || "-"}</div>
                </div>
                <div>
                  <label>Content Type</label>
                  <div>{artifact.contentType || "-"}</div>
                </div>
                <div>
                  <label>Size</label>
                  <div>{formatBytes(artifact.sizeBytes)}</div>
                </div>
                <div>
                  <label>Created At</label>
                  <div>{formatDate(artifact.createdAt)}</div>
                </div>
              </div>

              <div className="artifact-detail-hash">
                <label>SHA-256</label>
                <div className="artifact-detail-hash-value">
                  {artifact.sha256 || "-"}
                </div>
              </div>

              <div>
                <label>Tags</label>
                {artifact.tags && artifact.tags.length > 0 ? (
                  <div className="artifact-card-tags">
                    {artifact.tags.map((tag) => (
                      <span key={tag} className="artifact-tag-chip">
                        #{tag}
                      </span>
                    ))}
                  </div>
                ) : (
                  <p className="muted">No tags</p>
                )}
              </div>

              <div className="form-actions">
                <button
                  className="btn btn-sm"
                  onClick={handleDownload}
                  disabled={downloading}
                >
                  {downloading ? "Downloading..." : "Download"}
                </button>
              </div>

              {downloadError && <div className="error">{downloadError}</div>}
            </>
          )}
        </div>
      </div>
    </>
  );
}
