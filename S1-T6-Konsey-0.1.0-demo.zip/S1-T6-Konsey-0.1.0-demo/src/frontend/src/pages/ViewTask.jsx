import React, { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import Navbar from "../components/Navbar";
import api from "../api";

export default function ViewTask() {
  const { studyId, taskId } = useParams();
  const navigate = useNavigate();

  const [task, setTask] = useState(null);
  const [criteria, setCriteria] = useState([]);
  const [allArtifacts, setAllArtifacts] = useState([]);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetch = async () => {
      try {
        setLoading(true);
        setError("");

        const taskRes = await api.get(`/api/studies/${studyId}/tasks/${taskId}`);
        const t = taskRes.data;
        setTask(t);
        setCriteria(t.criteria || []);

        const artRes = await api.get("/api/artifacts", { params: { page: 0, size: 2000 } });
        setAllArtifacts(artRes.data?.content || []);
      } catch (e) {
        console.error("Failed to load task", e);
        setError("Failed to load task details.");
      } finally {
        setLoading(false);
      }
    };

    if (studyId && taskId) fetch();
  }, [studyId, taskId]);

  const artifactById = useMemo(() => {
    const map = new Map();
    for (const a of allArtifacts) map.set(a.id, a);
    return map;
  }, [allArtifacts]);

  const goBack = () => navigate(`/study/${studyId}/viewstudy`);

  return (
    <>
      <Navbar />

      <div className="page view-task">
        <header className="page-header">
          <div>
            <h2 className="page-title">View Task</h2>
            <p className="page-subtitle">{task ? task.name : "Task details and criteria."}</p>
          </div>

          <button className="btn small btn-ghost" onClick={goBack}>
            ← Back to Study
          </button>
        </header>

        {loading && <div className="muted">Loading task…</div>}
        {!loading && error && <div className="error">{error}</div>}
        {!loading && !error && !task && <div className="muted">Task not found.</div>}

        {!loading && !error && task && (
          <div className="vt-layout">
            {/* Left: artifacts + instructions */}
            <section className="vt-panel">
              <div className="vt-panel-header">
                <h3 className="vt-panel-title">Artifacts</h3>
                <span className="muted">
                  {(task.artifacts?.length || 0)} assigned
                </span>
              </div>

              <div className="vt-block">
                <div className="vt-label">Instructions</div>
                <div className="vt-text">{task.instructions || "No instructions provided."}</div>
              </div>

              <div className="vt-artifacts">
                {!task.artifacts || task.artifacts.length === 0 ? (
                  <div className="muted">No artifacts associated with this task.</div>
                ) : (
                  task.artifacts.map((artifactId, idx) => {
                    const a = artifactById.get(artifactId);
                    const title = a?.title || `Artifact ID: ${artifactId}`;
                    const type = a?.type || "Unknown type";

                    return (
                      <div className="vt-artifact-row" key={artifactId}>
                        <span className="vt-artifact-index">{idx + 1}</span>
                        <span className="vt-artifact-title" title={title}>
                          {title}
                        </span>
                        <span className="vt-artifact-type">{type}</span>
                      </div>
                    );
                  })
                )}
              </div>
            </section>

            {/* Right: criteria */}
            <section className="vt-panel">
              <div className="vt-panel-header">
                <h3 className="vt-panel-title">Criteria</h3>
                <span className="muted">{criteria.length} criterion</span>
              </div>

              {criteria.length === 0 ? (
                <div className="muted">No criteria assigned to this task.</div>
              ) : (
                <div className="vt-criteria">
                  {criteria.map((c) => (
                    <div className="vt-criterion" key={c.criterionID || c.id || c.name}>
                      <h4 className="vt-criterion-title">{c.name || "Unnamed Criterion"}</h4>
                      <div className="vt-criterion-desc">
                        {c.description || "No description."}
                      </div>
                      <div className="vt-pill">Scale: {c.scaleType || "N/A"}</div>
                    </div>
                  ))}
                </div>
              )}
            </section>
          </div>
        )}
      </div>
    </>
  );
}
