import React, { useState, useEffect } from "react";
import api from "../../api";
import EditModal from "../../components/modals/EditModal";
import ConfirmModal from "../../components/modals/ConfirmModal";


export default function ManageArtifacts() {
  const [artifacts, setArtifacts] = useState([]);
  const [search, setSearch] = useState("");
  const [activeSearchTerm, setActiveSearchTerm] = useState(""); 
  const [editItem, setEditItem] = useState(null);
  const [deleteItem, setDeleteItem] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const itemsPerPage = 10;
  
  const handleSearchClick = () => {
    setActiveSearchTerm(search);
    setCurrentPage(1); 
  };

  const fetchArtifacts = async (page = 1, searchTerm = "") => {
    setLoading(true);
    const apiPage = page - 1;
    try {
      const res = await api.get("/api/artifacts", {
        params: {
          page: apiPage, 
          size: itemsPerPage,
          q: searchTerm || undefined,
        },
      });

      const fetchedContent = res.data.content || [];
      setArtifacts(fetchedContent);
      setTotalPages(res.data.totalPages || 1);
      if (fetchedContent.length === 0 && page > 1) {
        setCurrentPage(page - 1);
        return;
      }
    } catch (err) {
      console.error("Failed to fetch artifacts:", err);
      setError("Failed to load artifacts.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchArtifacts(currentPage, activeSearchTerm);
  }, [currentPage, activeSearchTerm]);

  const actionButtonStyle = {
    minWidth: "60px",
    height: "32px",
    fontSize: "14px",
    cursor: "pointer",
  };
  
  const searchButtonStyle = {
    padding: "8px 12px",
    borderRadius: "0 8px 8px 0",
    border: "1px solid var(--glass)",
    background: "#2dd4bf", 
    color: "#fff",
    cursor: "pointer",
    borderLeft: 'none',
  };
  
  const paginationButtonStyle = {
    padding: "6px 12px",
    borderRadius: "6px",
    border: "1px solid rgba(255,255,255,0.2)",
    transition: "all 0.2s",
  };
  
  const disabledPaginationStyle = {
    backgroundColor: "rgba(255,255,255,0.05)",
    color: "var(--muted)",
    cursor: "not-allowed",
  };

  if (loading) return <div style={{ padding: 24 }}>Loading artifacts...</div>;
  if (error) return <div style={{ padding: 24, color: "var(--danger)" }}>{error}</div>;

  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", width: "100%" }}>
      <div style={{ display: 'flex', marginBottom: '16px', width: "100%", maxWidth: "500px", alignItems: "stretch" }}>
        <input
          type="text"
          placeholder="Search artifacts..."
          value={search}
          onChange={(e) => setSearch(e.target.value)} 
          onKeyDown={(e) => {
            if (e.key === 'Enter') {
              handleSearchClick();
            }
          }}
          style={{
            padding: "8px 12px",
            borderRadius: "8px 0 0 8px", 
            border: "1px solid var(--glass)",
            background: "var(--glass)",
            color: "var(--text)",
            flexGrow: 1,
          }}
        />
        <button
          onClick={handleSearchClick}
          style={searchButtonStyle}
          disabled={search === activeSearchTerm} 
        >
          Search
        </button>
      </div>

      <div className="card" style={{ padding: "24px", width: "100%", maxWidth: "2000px", margin: "0 auto" }}>
        <table style={{ width: "100%", borderCollapse: "collapse", color: "var(--text)", textAlign: "center", tableLayout: "fixed", wordWrap: "break-word" }}>
          <thead>
            <tr style={{ color: "var(--muted)", borderBottom: "1px solid rgba(255,255,255,0.1)" }}>
              <th style={{ paddingBottom: "12px", width: "20%" }}>ID</th>
              <th style={{ paddingBottom: "12px", width: "10%" }}>Title</th>
              <th style={{ paddingBottom: "12px", width: "10%" }}>Type</th>
              <th style={{ paddingBottom: "12px", width: "15%" }}>Tags</th>
              <th style={{ paddingBottom: "12px", width: "10%" }}>Size</th>
              <th style={{ paddingBottom: "12px", width: "20%" }}>Created</th>
              <th style={{ paddingBottom: "12px", width: "7%" }}>AI</th>
              <th style={{ paddingBottom: "12px", width: "8%" }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {artifacts.map((a) => (
              <tr key={a.id} style={{ borderTop: "1px solid rgba(255,255,255,0.05)" }}>
                <td style={{ padding: "12px 8px", wordBreak: "break-all" }}>{a.id}</td>
                <td style={{ padding: "12px 8px" }}>{a.title}</td>
                <td style={{ padding: "12px 8px" }}>{a.type}</td>
                <td style={{ padding: "12px 8px", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }} title={a.tags?.join(", ") || "None"}>
                  {a.tags?.length ? a.tags.join(", ") : "None"}
                </td>
                <td style={{ padding: "12px 8px" }}>{(a.sizeBytes / 1024).toFixed(1)} KB</td>
                <td style={{ padding: "12px 8px", whiteSpace: "nowrap" }}>{new Date(a.createdAt).toLocaleString()}</td>
                <td style={{ padding: "12px 8px" }}>{a.aigenerated ? <span style={{ background: "var(--accent)", color: "#032027", fontSize: "12px", padding: "2px 8px", borderRadius: "6px", fontWeight: "600" }}>Yes</span> : <span style={{ color: "var(--muted)" }}>No</span>}</td>
                <td style={{ padding: "12px 8px" }}>
                  <div style={{ display: "flex", justifyContent: "center", gap: "8px", flexWrap: "wrap" }}>
                    <button className="btn small" style={actionButtonStyle} onClick={() => setEditItem(a)}>Edit</button>
                    <button className="btn small" style={{ ...actionButtonStyle, background: "var(--danger)", color: "#fff" }} onClick={() => setDeleteItem(a)}>Delete</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div style={{ marginTop: "16px", display: "flex", gap: "12px", alignItems: "center" }}>
        {totalPages >= 1 && (
          <>
            <button
              onClick={() => setCurrentPage((p) => Math.max(p - 1, 1))}
              disabled={currentPage === 1}
              style={{
                ...paginationButtonStyle,
                backgroundColor: currentPage === 1 ? disabledPaginationStyle.backgroundColor : "var(--glass)",
                color: currentPage === 1 ? disabledPaginationStyle.color : "var(--text)",
                cursor: currentPage === 1 ? disabledPaginationStyle.cursor : "pointer",
              }}
            >
              ◀ Previous
            </button>

            <span style={{ color: "var(--text)", fontWeight: "500" }}>Page {currentPage} of {totalPages}</span>

            <button
              onClick={() => setCurrentPage((p) => Math.min(p + 1, totalPages))}
              disabled={currentPage === totalPages}
              style={{
                ...paginationButtonStyle,
                backgroundColor: currentPage === totalPages ? disabledPaginationStyle.backgroundColor : "var(--glass)",
                color: currentPage === totalPages ? disabledPaginationStyle.color : "var(--text)",
                cursor: currentPage === totalPages ? disabledPaginationStyle.cursor : "pointer",
              }}
            >
              Next ▶
            </button>
          </>
        )}
      </div>

      {editItem && (
        <EditModal
          title="Edit Artifact"
          item={editItem}
          type="artifact"
          onClose={() => setEditItem(null)}
          onSave={(data) => {
            console.log("Artifact updated:", data);
            fetchArtifacts(currentPage, activeSearchTerm); 
            setEditItem(null);
          }}
          fullHeight
        />
      )}

      {deleteItem && (
        <ConfirmModal
          message={`Are you sure you want to delete "${deleteItem.title}"?`}
          type="artifact"
          id={deleteItem.id}
          onClose={() => setDeleteItem(null)}
          onConfirm={async () => {
            fetchArtifacts(currentPage, activeSearchTerm); 
            setDeleteItem(null);
          }}
          fullHeight
        />
      )}
    </div>
  );
}
