// src/pages/admin/ManageRoleApplications.jsx
import React, { useEffect, useState } from "react";
import api from "../../api";

const PAGE_SIZE = 10;

export default function ManageRoleApplications() {
  const [applications, setApplications] = useState([]);
  const [page, setPage] = useState(0);
  const [totalPages, setTotalPages] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  // decision modal state
  const [decisionTarget, setDecisionTarget] = useState(null); // application object
  const [decisionStatus, setDecisionStatus] = useState("APPROVED"); // APPROVED / REJECTED
  const [decisionComment, setDecisionComment] = useState("");
  const [savingDecision, setSavingDecision] = useState(false);

  useEffect(() => {
    const controller = new AbortController();

    const fetchApplications = async () => {
      setLoading(true);
      setError("");

      try {
        const params = { page, size: PAGE_SIZE };

        const res = await api.get("/api/users/role", {
          params,
          signal: controller.signal,
        });

        console.log(res);

        setApplications(res.data.results || []);
        setTotalPages(res.data.totalPages ?? 0);
      } catch (e) {
        if (e.name === "CanceledError") return;
        console.error("Failed to fetch role applications", e);
        const msg =
          e.response?.data?.detail ||
          e.response?.data?.message ||
          e.response?.data?.error ||
          e.response?.data?.title ||
          "Failed to load role applications.";
        setError(msg);
      } finally {
        setLoading(false);
      }
    };

    fetchApplications();
    return () => controller.abort();
  }, [page]);

  const openDecision = (app, status) => {
    setDecisionTarget(app);
    setDecisionStatus(status);
    setDecisionComment("");
  };

  const closeDecision = () => {
    setDecisionTarget(null);
    setDecisionComment("");
    setDecisionStatus("APPROVED");
    setSavingDecision(false);
  };

  const reloadPage = async () => {
    try {
      const params = { page, size: PAGE_SIZE };
      const res = await api.get("/api/users/role", { params });
      setApplications(res.data.results || []);
      setTotalPages(res.data.totalPages ?? 0);
    } catch (e) {
      console.error("Failed to reload role applications", e);
      const msg =
        e.response?.data?.detail ||
        e.response?.data?.message ||
        e.response?.data?.error ||
        e.response?.data?.title ||
        "Failed to reload role applications.";
      setError(msg);
    }
  };

  const handleDecisionSubmit = async (e) => {
    e.preventDefault();
    if (!decisionTarget) return;

    setSavingDecision(true);
    setError("");

    try {
      await api.put(`/api/users/role/${decisionTarget.id}`, {
        status: decisionStatus,
        comment: decisionComment,
      });

      await reloadPage();
      closeDecision();
    } catch (e) {
      console.error("Failed to update role application", e);
      const msg =
        e.response?.data?.detail ||
        e.response?.data?.message ||
        e.response?.data?.error ||
        e.response?.data?.title ||
        "Failed to update role application.";
      setError(msg);
      setSavingDecision(false);
    }
  };

  const formatDateTime = (v) => {
    if (!v) return "-";
    const d = new Date(v);
    if (Number.isNaN(d.getTime())) return v;
    return d.toLocaleString();
  };

  const statusPillStyle = (status) => {
    const base = {
      display: "inline-flex",
      alignItems: "center",
      padding: "2px 10px",
      borderRadius: "999px",
      fontSize: "11px",
      fontWeight: 600,
    };

    // they will all be PENDING in this list, but keep for safety
    switch (status) {
      case "APPROVED":
        return {
          ...base,
          background: "rgba(110, 231, 183, 0.12)",
          border: "1px solid rgba(110, 231, 183, 0.7)",
          color: "var(--accent)",
        };
      case "REJECTED":
        return {
          ...base,
          background: "rgba(255, 107, 107, 0.12)",
          border: "1px solid rgba(255, 107, 107, 0.7)",
          color: "var(--danger)",
        };
      case "PENDING":
      default:
        return {
          ...base,
          background: "rgba(148, 163, 184, 0.18)",
          border: "1px solid rgba(148, 163, 184, 0.8)",
          color: "var(--muted)",
        };
    }
  };

  return (
    <>
      <div className="topbar" style={{ marginBottom: "12px" }}>
        <h3 style={{ margin: 0, fontSize: "18px" }}>Pending role applications</h3>
      </div>

      {error && <div className="error">{error}</div>}

      {loading ? (
        <p className="muted">Loading applications…</p>
      ) : applications.length === 0 ? (
        <p className="muted">There are no pending role applications.</p>
      ) : (
        <>
          <div
            style={{
              display: "flex",
              flexDirection: "column",
              gap: "10px",
              marginTop: "8px",
            }}
          >
            {applications.map((app) => (
              <div
                key={app.id}
                className="criterion-card"
                style={{ textAlign: "left" }}
              >
                <div
                  className="topbar"
                  style={{ marginBottom: "6px", alignItems: "flex-start" }}
                >
                  <div>
                    <div style={{ fontSize: "14px", fontWeight: 600 }}>
                      {app.applicantDisplayName || app.applicantEmail}
                    </div>
                    <div
                      className="muted"
                      style={{ fontSize: "12px", marginTop: "2px" }}
                    >
                      Requested role: {app.requestedRole}
                    </div>
                  </div>
                  <span style={statusPillStyle(app.status)}>
                    {app.status === "PENDING" && "Pending review"}
                    {app.status === "APPROVED" && "Approved"}
                    {app.status === "REJECTED" && "Rejected"}
                  </span>
                </div>

                <div style={{ marginTop: "6px" }}>
                  <div
                    style={{
                      fontSize: "12px",
                      color: "var(--muted)",
                      marginBottom: "4px",
                    }}
                  >
                    Motivation
                  </div>
                  <div
                    style={{
                      fontSize: "13px",
                      whiteSpace: "pre-wrap",
                      maxHeight: "80px",
                      overflowY: "auto",
                      background: "rgba(15,23,42,0.9)",
                      borderRadius: "8px",
                      padding: "8px 10px",
                      border: "1px solid rgba(255,255,255,0.06)",
                    }}
                  >
                    {app.motivation && app.motivation.trim().length > 0
                      ? app.motivation
                      : "No motivation text."}
                  </div>
                </div>

                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    gap: "12px",
                    fontSize: "11px",
                    color: "var(--muted)",
                    marginTop: "8px",
                  }}
                >
                  <span>Created: {formatDateTime(app.createdAt)}</span>
                  <span>Updated: {formatDateTime(app.updatedAt)}</span>
                </div>

                <div
                  style={{
                    display: "flex",
                    justifyContent: "flex-end",
                    gap: "8px",
                    marginTop: "10px",
                  }}
                >
                  <button
                    type="button"
                    className="btn small"
                    style={{
                      background: "var(--accent)",
                      color: "#032027",
                    }}
                    onClick={() => openDecision(app, "APPROVED")}
                    disabled={savingDecision}
                  >
                    Approve
                  </button>
                  <button
                    type="button"
                    className="btn small"
                    style={{
                      background: "transparent",
                      color: "var(--danger)",
                      border: "1px solid rgba(248,113,113,0.8)",
                    }}
                    onClick={() => openDecision(app, "REJECTED")}
                    disabled={savingDecision}
                  >
                    Reject
                  </button>
                </div>
              </div>
            ))}
          </div>

          {totalPages > 1 && (
            <div
              style={{
                display: "flex",
                justifyContent: "flex-end",
                alignItems: "center",
                gap: "8px",
                marginTop: "16px",
                fontSize: "12px",
              }}
            >
              <button
                type="button"
                className="btn small"
                style={{ marginTop: 0 }}
                disabled={page === 0}
                onClick={() => setPage((p) => Math.max(0, p - 1))}
              >
                Previous
              </button>
              <span className="muted">
                Page {page + 1} / {totalPages}
              </span>
              <button
                type="button"
                className="btn small"
                style={{ marginTop: 0 }}
                disabled={page + 1 >= totalPages}
                onClick={() =>
                  setPage((p) => (p + 1 < totalPages ? p + 1 : p))
                }
              >
                Next
              </button>
            </div>
          )}
        </>
      )}

      {/* Decision modal */}
      {decisionTarget && (
        <div className="modal-overlay" onClick={closeDecision}>
          <div
            className="modal-card"
            onClick={(e) => e.stopPropagation()}
            style={{ maxWidth: "420px" }}
          >
            <div className="topbar" style={{ marginBottom: "8px" }}>
              <h3 style={{ margin: 0, fontSize: "16px" }}>
                {decisionStatus === "APPROVED" ? "Approve role" : "Reject role"}
              </h3>
              <button
                type="button"
                onClick={closeDecision}
                style={{
                  border: "none",
                  background: "transparent",
                  color: "var(--muted)",
                  cursor: "pointer",
                  fontSize: 18,
                  lineHeight: 1,
                  padding: "2px 4px",
                }}
              >
                ×
              </button>
            </div>

            <p className="muted" style={{ fontSize: "12px" }}>
              {decisionStatus === "APPROVED"
                ? "You are about to approve this role application."
                : "You are about to reject this role application."}
            </p>

            <div
              style={{
                fontSize: "13px",
                marginBottom: "8px",
                textAlign: "left",
              }}
            >
              <div style={{ fontWeight: 600 }}>
                {decisionTarget.applicantDisplayName ||
                  decisionTarget.applicantEmail}
              </div>
              <div className="muted" style={{ fontSize: "12px" }}>
                Requested role: {decisionTarget.requestedRole}
              </div>
            </div>

            <form onSubmit={handleDecisionSubmit}>
              <label htmlFor="decisionComment">
                Reviewer comment (optional but recommended)
              </label>
              <textarea
                id="decisionComment"
                className="input-dark"
                rows={3}
                value={decisionComment}
                onChange={(e) => setDecisionComment(e.target.value)}
                placeholder="Explain your decision (this will be visible to the user)."
              />

              <div
                style={{
                  display: "flex",
                  justifyContent: "flex-end",
                  gap: "8px",
                  marginTop: "12px",
                }}
              >
                <button
                  type="button"
                  className="btn small"
                  style={{
                    marginTop: 0,
                    background: "var(--glass)",
                    color: "var(--text)",
                  }}
                  onClick={closeDecision}
                  disabled={savingDecision}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="btn small"
                  style={{
                    marginTop: 0,
                    background:
                      decisionStatus === "APPROVED"
                        ? "var(--accent)"
                        : "var(--danger)",
                    color: "#032027",
                  }}
                  disabled={savingDecision}
                >
                  {savingDecision ? "Saving…" : "Confirm"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
}
