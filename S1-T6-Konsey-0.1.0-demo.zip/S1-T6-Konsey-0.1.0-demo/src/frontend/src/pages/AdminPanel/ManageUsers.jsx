import React, { useState, useEffect } from "react";
import api from "../../api";
import EditModal from "../../components/modals/EditModal";
import ConfirmModal from "../../components/modals/ConfirmModal";

export default function ManageUsers() {
  const [users, setUsers] = useState([]);
  const [search, setSearch] = useState("");
  const [activeSearchTerm, setActiveSearchTerm] = useState(""); 
  const [editUser, setEditUser] = useState(null);
  const [deleteUser, setDeleteUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const itemsPerPage = 10;

  const handleSearchClick = () => {
    setActiveSearchTerm(search);
    setCurrentPage(1); 
  };
  
  const fetchUsers = async (page, searchTerm) => {
    setLoading(true);
    const apiPage = page - 1;
    try {
      const res = await api.get("/api/users/search", {
        params: { page: apiPage, size: itemsPerPage, keyword: searchTerm || undefined },
      });
      const fetchedContent = res.data.content || res.data.results || [];
      setUsers(fetchedContent);
      setTotalPages(res.data.totalPages || 1);
      if (fetchedContent.length === 0 && page > 1) {
        setCurrentPage(page - 1);
        return;
      }
    } catch (err) {
      console.error(err);
      setError("Failed to load users. You must be an admin.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers(currentPage, activeSearchTerm);
  }, [currentPage, activeSearchTerm]);
  
  const actionButtonStyle = {
    minWidth: "60px",
    height: "32px",
    fontSize: "14px",
    cursor: "pointer",
  };

  if (loading) return <div style={{ padding: 24 }}>Loading users...</div>;
  if (error) return <div style={{ padding: 24, color: "var(--danger)" }}>{error}</div>;

  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", width: "100%" }}>
      <div style={{ display: "flex", marginBottom: "16px", width: "100%", maxWidth: "500px" }}>
        <input
          type="text"
          placeholder="Search users..."
          value={search}
          onChange={(e) => setSearch(e.target.value)} 
          onKeyDown={(e) => {
            if (e.key === "Enter") handleSearchClick();
          }}
          style={{
            padding: "10px 14px",
            borderRadius: "8px 0 0 8px",
            border: "1px solid var(--glass)",
            background: "var(--glass)",
            color: "var(--text)",
            flexGrow: 1,
            fontSize: "15px",
            height: "32px",
            boxSizing: "border-box",
          }}
        />
        <button
          onClick={handleSearchClick}
          style={{
              padding: "8px 12px",
              borderRadius: "0 8px 8px 0",
              border: "1px solid var(--glass)",
              background: "#2dd4bf", 
              color: "#fff",
              cursor: "pointer",
              borderLeft: 'none',
              height: "40px",
          }}
          disabled={search === activeSearchTerm}
        >
          Search
        </button>
      </div>

      <div className="card" style={{ padding: "24px", width: "100%", maxWidth: "950px", margin: "0 auto" }}>
        <table style={{ width: "100%", borderCollapse: "collapse", color: "var(--text)", tableLayout: "auto", textAlign: "center" }}>
          <thead>
            <tr style={{ color: "var(--muted)", borderBottom: "1px solid rgba(255,255,255,0.1)" }}>
              <th style={{ paddingBottom: "12px", minWidth: "220px" }}>ID</th>
              <th style={{ paddingBottom: "12px", minWidth: "150px" }}>Name</th>
              <th style={{ paddingBottom: "12px", minWidth: "200px" }}>Email</th>
              <th style={{ paddingBottom: "12px", minWidth: "100px" }}>Role</th>
              <th style={{ paddingBottom: "12px", minWidth: "150px" }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {users.length > 0 ? (
              users.map((u) => (
                <tr key={u.id} style={{ borderTop: "1px solid rgba(255,255,255,0.05)" }}>
                  <td style={{ padding: "12px 8px", wordBreak: "break-all" }}>{u.id}</td>
                  <td style={{ padding: "12px 8px" }}>{u.displayName || u.name}</td>
                  <td style={{ padding: "12px 8px" }}>{u.email}</td>
                  <td style={{ padding: "12px 8px" }}>{u.role}</td>
                  <td style={{ padding: "12px 8px" }}>
                    <div style={{ display: "flex", justifyContent: "center", gap: "8px" }}>
                      <button className="btn small" style={actionButtonStyle} onClick={() => setEditUser(u)}>Edit</button>
                      <button
                        className="btn small"
                        style={{ ...actionButtonStyle, background: "var(--danger)", color: "#fff" }}
                        onClick={() => setDeleteUser(u)}
                      >
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="5" style={{ padding: "24px 8px", textAlign: "center", color: "var(--muted)" }}>
                  No users found for "{activeSearchTerm || "all users"}".
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <div style={{ marginTop: "16px", display: "flex", gap: "12px", alignItems: "center" }}>
        {totalPages >= 1 && (
          <>
            <button
              onClick={() => setCurrentPage((p) => Math.max(p - 1, 1))}
              disabled={currentPage === 1}
              style={{
                padding: "6px 12px",
                borderRadius: "6px",
                border: "1px solid rgba(255,255,255,0.2)",
                backgroundColor: currentPage === 1 ? "rgba(255,255,255,0.05)" : "var(--glass)",
                color: currentPage === 1 ? "var(--muted)" : "var(--text)",
                cursor: currentPage === 1 ? "not-allowed" : "pointer",
                transition: "all 0.2s",
              }}
            >
              ◀ Previous
            </button>

            <span style={{ color: "var(--text)", fontWeight: "500" }}>
              Page {currentPage} of {totalPages}
            </span>

            <button
              onClick={() => setCurrentPage((p) => Math.min(p + 1, totalPages))}
              disabled={currentPage === totalPages}
              style={{
                padding: "6px 12px",
                borderRadius: "6px",
                border: "1px solid rgba(255,255,255,0.2)",
                backgroundColor: currentPage === totalPages ? "rgba(255,255,255,0.05)" : "var(--glass)",
                color: currentPage === totalPages ? "var(--muted)" : "var(--text)",
                cursor: currentPage === totalPages ? "not-allowed" : "pointer",
                transition: "all 0.2s",
              }}
            >
              Next ▶
            </button>
          </>
        )}
      </div>

      {editUser && (
        <EditModal
          title="Edit User"
          item={editUser}
          type="user"
          onClose={() => setEditUser(null)}
          onSave={(data) => {
            fetchUsers(currentPage, activeSearchTerm); 
            setEditUser(null);
          }}
          fullHeight
        />
      )}

      {deleteUser && (
        <ConfirmModal
          message={`Are you sure you want to delete ${deleteUser.name || deleteUser.displayName}?`}
          type="user"
          id={deleteUser.id}
          onClose={() => setDeleteUser(null)}
          onConfirm={async () => {
            fetchUsers(currentPage, activeSearchTerm); 
            setDeleteUser(null);
          }}
          fullHeight
        />
      )}
    </div>
  );
}
