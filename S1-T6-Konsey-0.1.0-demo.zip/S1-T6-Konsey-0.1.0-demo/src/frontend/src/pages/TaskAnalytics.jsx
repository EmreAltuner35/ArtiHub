import React, { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import Navbar from "../components/Navbar";
import api from "../api";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip as RechartsTooltip,
  Cell,
} from "recharts";
import { ArrowLeft, Download, BarChart2, PieChart as PieIco, ChevronLeft, ChevronRight } from "lucide-react";
import * as XLSX from "xlsx";

const convertJsonArrayToCsv = (jsonData, keysOrder) => {
  if (!jsonData || jsonData.length === 0) return "";
  const header = keysOrder.join(",");
  const rows = jsonData.map((obj) =>
    keysOrder
      .map((key) => {
        let value = obj[key] == null ? "" : String(obj[key]);
        value = value.replace(/"/g, '""');
        if (value.includes(",") || value.includes('"') || value.includes("\n")) value = `"${value}"`;
        return value;
      })
      .join(",")
  );
  return [header, ...rows].join("\n");
};

const downloadCsv = (csvString, filename) => {
  const blob = new Blob([csvString], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.setAttribute("download", filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
};

const formatTime = (seconds) => {
  const n = Number(seconds);
  if (!n || Number.isNaN(n)) return "N/A";
  const m = Math.floor(n / 60);
  const s = Math.round(n % 60);
  return m > 0 ? `${m}m ${s}s` : `${s}s`;
};

const CompletionCard = ({ rate, avgTime }) => {
  const percentage = Math.max(0, Math.min(100, Math.round(Number(rate || 0) * 100)));

  let color = "#ef4444";
  let label = "In Progress";
  if (percentage >= 75) {
    color = "#10b981";
    label = "Excellent";
  } else if (percentage >= 50) {
    color = "#f59e0b";
    label = "Good";
  }
  if (percentage >= 100) label = "Completed";

  const radius = 34;
  const svgSize = 92;
  const center = svgSize / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (percentage / 100) * circumference;

  return (
    <div className="card completion-card">
      <div className="completion-side">
        <div>
          <h2 style={{ margin: 0 }}>Task Completion Rate</h2>
          <p className="muted" style={{ marginTop: 6, marginBottom: 0 }}>
            Overall progress across all participants
          </p>
        </div>

        <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
          <div className="ring">
            <svg>
              <circle
                cx={center}
                cy={center}
                r={radius}
                stroke="rgba(255,255,255,0.10)"
                strokeWidth="8"
                fill="transparent"
              />
              <circle
                cx={center}
                cy={center}
                r={radius}
                stroke={color}
                strokeWidth="8"
                fill="transparent"
                strokeDasharray={circumference}
                strokeDashoffset={offset}
                strokeLinecap="round"
              />
            </svg>
            <div className="ring-center">{percentage}%</div>
          </div>

          <div className="badge-soft" style={{ borderColor: `${color}55`, color }}>
            {label}
          </div>
        </div>
      </div>

      <div className="completion-side">
        <div>
          <h2 style={{ margin: 0 }}>Avg. Completion Time</h2>
          <p className="muted" style={{ marginTop: 6, marginBottom: 0 }}>
            Time taken by participants to finish
          </p>
        </div>

        <div className="kpi-value">{formatTime(avgTime)}</div>
      </div>
    </div>
  );
};

const CriterionChart = ({ item }) => {
  const isFiveStar = item.type === "FIVE_STAR";

  const data = (item.options || []).map((opt, idx) => ({
    name: opt,
    value: isFiveStar
      ? Number(item.averages?.[idx] || 0)
      : Number(item.optionCounts?.[idx] || 0),
    count: isFiveStar
      ? Number(item.counts?.[idx] || 0)
      : Number(item.optionCounts?.[idx] || 0),
  }));

  return (
    <div className="card chart-card">
      <div className="chart-title-row">
        <h3 className="chart-title" title={item.criterion?.name || ""}>
          {item.criterion?.name || "Untitled Criterion"}
        </h3>
        <span className="muted" style={{ display: "inline-flex", gap: 6, alignItems: "center" }}>
          {isFiveStar ? <BarChart2 size={14} /> : <PieIco size={14} />}
          {isFiveStar ? "Five-star avg" : "Multi-choice count"}
        </span>
      </div>

      <div className="chart-wrap">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 8, right: 8, bottom: 18, left: -18 }}>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(255,255,255,0.06)" />
            <XAxis
              dataKey="name"
              tick={{ fill: "#9aa5b1", fontSize: 12 }}
              axisLine={false}
              tickLine={false}
              interval={0}
              dy={10}
            />
            <YAxis
              tick={{ fill: "#9aa5b1", fontSize: 12 }}
              axisLine={false}
              tickLine={false}
              domain={isFiveStar ? [0, 5] : [0, "auto"]}
              allowDecimals={isFiveStar}
            />
            <RechartsTooltip
              cursor={{ fill: "rgba(255,255,255,0.05)" }}
              contentStyle={{
                backgroundColor: "#0f1720",
                border: "1px solid rgba(255,255,255,0.10)",
                borderRadius: 10,
                color: "#e6eef6",
              }}
            />
            <Bar dataKey="value" radius={[6, 6, 0, 0]} barSize={42}>
              {data.map((_, i) => (
                <Cell key={i} fill={isFiveStar ? "#f59e0b" : "#3b82f6"} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

const Pagination = ({ currentPage, totalPages, onPageChange }) => (
  <div className="pager">
    <button
      className="btn btn-sm"
      onClick={() => onPageChange(Math.max(1, currentPage - 1))}
      disabled={currentPage === 1}
    >
      <ChevronLeft size={16} style={{ marginRight: 6 }} />
      Previous
    </button>

    <span className="muted">
      Page <b style={{ color: "var(--text)" }}>{currentPage}</b> of{" "}
      <b style={{ color: "var(--text)" }}>{totalPages}</b>
    </span>

    <button
      className="btn btn-sm"
      onClick={() => onPageChange(Math.min(totalPages, currentPage + 1))}
      disabled={currentPage === totalPages}
    >
      Next
      <ChevronRight size={16} style={{ marginLeft: 6 }} />
    </button>
  </div>
);

export default function TaskAnalytics() {
  const navigate = useNavigate();
  const { studyId, taskId } = useParams();

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [data, setData] = useState(null);

  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 6;

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        setError("");

        const res = await api.get(`/api/studies/${studyId}/tasks/analytics/${taskId}`);
        setData(res.data);
      } catch (e) {
        console.error("Failed to fetch task analytics:", e);
        setError("Failed to load task analytics.");
      } finally {
        setLoading(false);
      }
    };

    if (studyId && taskId) fetchData();
  }, [studyId, taskId]);

  const { paginatedItems, totalPages, totalCount } = useMemo(() => {
    if (!data) return { paginatedItems: [], totalPages: 1, totalCount: 0 };

    const fiveStar = (data.fiveStarRatingDistributionList || []).map((x) => ({ ...x, type: "FIVE_STAR" }));
    const multi = (data.ratingDistributionList || []).map((x) => ({ ...x, type: "MULT_CHOICE" }));
    const all = [...fiveStar, ...multi];

    const totalPages = Math.max(1, Math.ceil(all.length / itemsPerPage));
    const start = (currentPage - 1) * itemsPerPage;
    const end = start + itemsPerPage;

    return { paginatedItems: all.slice(start, end), totalPages, totalCount: all.length };
  }, [data, currentPage]);

  const exportCsv = () => {
    if (!data) return;

    const rows = [];

    if (data.ratingDistributionList) {
      data.ratingDistributionList.forEach((dist) => {
        const criterionName = dist.criterion?.name || "Criterion_MultChoice";
        (dist.options || []).forEach((opt, idx) => {
          rows.push({
            RatingType: "MultipleChoice",
            Criterion: criterionName,
            Option: opt,
            Count: dist.optionCounts?.[idx] ?? 0,
            AverageScore: "N/A",
          });
        });
      });
    }

    if (data.fiveStarRatingDistributionList) {
      data.fiveStarRatingDistributionList.forEach((dist) => {
        const criterionName = dist.criterion?.name || "Criterion_FiveStar";
        (dist.options || []).forEach((opt, idx) => {
          rows.push({
            RatingType: "FiveStar",
            Criterion: criterionName,
            Option: opt,
            Count: dist.counts?.[idx] ?? 0,
            AverageScore: dist.averages?.[idx] ?? 0,
          });
        });
      });
    }

    const metrics = [
      { Metric: "Completion Rate", Value: data.completionRate },
      { Metric: "Avg Completion Time", Value: data.avgCompletionTime },
    ];

    const metricsCsv = convertJsonArrayToCsv(metrics, ["Metric", "Value"]);
    const distCsv = convertJsonArrayToCsv(rows, ["RatingType", "Criterion", "Option", "Count", "AverageScore"]);

    downloadCsv([metricsCsv, "", distCsv].join("\n"), `task_analytics_${taskId}.csv`);
  };

  const exportXlsx = () => {
    if (!data) return;

    const rows = [];

    if (data.ratingDistributionList) {
      data.ratingDistributionList.forEach((dist) => {
        const criterionName = dist.criterion?.name || "Criterion_MultChoice";
        (dist.options || []).forEach((opt, idx) => {
          rows.push(["MultipleChoice", criterionName, opt, dist.optionCounts?.[idx] ?? 0, "N/A"]);
        });
      });
    }

    if (data.fiveStarRatingDistributionList) {
      data.fiveStarRatingDistributionList.forEach((dist) => {
        const criterionName = dist.criterion?.name || "Criterion_FiveStar";
        (dist.options || []).forEach((opt, idx) => {
          rows.push(["FiveStar", criterionName, opt, dist.counts?.[idx] ?? 0, dist.averages?.[idx] ?? 0]);
        });
      });
    }

    const sheetData = [];
    sheetData.push(["Metric", "Value"]);
    sheetData.push(["Completion Rate", data.completionRate]);
    sheetData.push(["Avg Completion Time", data.avgCompletionTime]);
    sheetData.push([]);
    sheetData.push(["Rating Type", "Criterion", "Option", "Count", "Average Score"]);
    rows.forEach((r) => sheetData.push(r));

    const ws = XLSX.utils.aoa_to_sheet(sheetData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Task Analytics");
    XLSX.writeFile(wb, `task_analytics_${taskId}.xlsx`);
  };

  if (loading) {
    return (
      <>
        <Navbar />
        <div className="page analytics">
          <div className="muted">Loading task analytics…</div>
        </div>
      </>
    );
  }

  if (error) {
    return (
      <>
        <Navbar />
        <div className="page analytics">
          <div className="error">{error}</div>
          <button className="btn btn-sm" onClick={() => navigate(-1)} style={{ marginTop: 10 }}>
            Go Back
          </button>
        </div>
      </>
    );
  }

  return (
    <>
      <Navbar />

      <div className="page analytics">
        <header className="page-header task-analytics-head">
          <div>
            <h2 className="page-title">Task Analytics</h2>
            <p className="page-subtitle">Criterion distributions and completion metrics.</p>
          </div>

          <div className="task-analytics-head-right">
            <button className="btn btn-sm" onClick={exportCsv} disabled={!data}>
              <Download size={16} style={{ marginRight: 6 }} />
              Export CSV
            </button>
            <button className="btn btn-sm" onClick={exportXlsx} disabled={!data}>
              <Download size={16} style={{ marginRight: 6 }} />
              Export XLSX
            </button>
            <button className="btn small btn-ghost" onClick={() => navigate(-1)}>
              <ArrowLeft size={16} style={{ marginRight: 6 }} />
              Back
            </button>
          </div>
        </header>

        {data && <CompletionCard rate={data.completionRate} avgTime={data.avgCompletionTime} />}

        <div className="card chart-card" style={{ marginTop: 14 }}>
          <div className="chart-title-row">
            <h3 className="chart-title">Criterion Distributions</h3>
            <span className="muted">{totalCount} total</span>
          </div>

          {paginatedItems.length === 0 ? (
            <div className="chart-empty">No criteria data available for this task.</div>
          ) : (
            <>
              <div className="analytics-kpis" style={{ gridTemplateColumns: "repeat(2, minmax(0, 1fr))" }}>
                {paginatedItems.map((item, idx) => (
                  <CriterionChart key={idx} item={item} />
                ))}
              </div>
              <Pagination currentPage={currentPage} totalPages={totalPages} onPageChange={setCurrentPage} />
            </>
          )}
        </div>
      </div>
    </>
  );
}
