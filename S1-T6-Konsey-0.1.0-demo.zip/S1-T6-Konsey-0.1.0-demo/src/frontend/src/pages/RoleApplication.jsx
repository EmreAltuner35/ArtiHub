import React, { useState } from "react";
import { Link } from "react-router-dom";
import api from "../api";
import Navbar from "../components/Navbar";

function RoleApplicationPage() {
  const [requestedRole, setRequestedRole] = useState("");
  const [motivation, setMotivation] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setSuccess("");

    if (!requestedRole) {
      setError("Please select a role you want to apply for.");
      return;
    }

    try {
      await api.post("/api/users/role/apply", {
        requestedRole,
        motivation,
      });

      setSuccess("Your role change request has been submitted.");
      setRequestedRole("");
      setMotivation("");
    } catch (err) {
      console.error("Failed to submit role application", err);
      const msg =
        err.response?.data?.detail ||
        err.response?.data?.message ||
        err.response?.data?.error ||
        err.response?.data?.title ||
        "An error occurred while submitting your request.";
      setError(msg);
    }
  };

  return (
    <>
      <Navbar />
      <div className="center-screen">
        <div className="card card--narrow">
          <div className="topbar">
            <h2>Apply for role change</h2>
            <Link to="/account" className="link-muted">Back</Link>
          </div>

          {error && <div className="error">{error}</div>}
          {success && <div className="success">{success}</div>}

          <form onSubmit={handleSubmit}>
            <label htmlFor="requestedRole">Requested role</label>
            <select
              id="requestedRole"
              className="select-dark"
              value={requestedRole}
              onChange={(e) => setRequestedRole(e.target.value)}
            >
              <option value="">Select a role</option>
              {/* match your Role enum values */}
              <option value="RESEARCHER">RESEARCHER</option>
              <option value="REVIEWER">REVIEWER</option>
            </select>

            <label htmlFor="motivation">
              Motivation (optional but recommended)
            </label>
            <textarea
              id="motivation"
              rows={4}
              className="input-dark"
              value={motivation}
              onChange={(e) => setMotivation(e.target.value)}
              placeholder="Explain why you need this role, what you will do with it, etc."
            />

            <button type="submit" className="btn">
              Submit role request
            </button>

            <p className="muted" style={{ marginTop: "8px" }}>
              Your request will be reviewed by an administrator. You will see the
              status in your account once it is processed.
            </p>
          </form>
        </div>
      </div>
    </>
  );
}

export default RoleApplicationPage;
