import React, { useState, useRef } from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "../components/Navbar";
import api from "../api";

const TAG_PAGE_SIZE = 5;

export default function UploadArtifactPage() {
  const navigate = useNavigate();

  const [mode, setMode] = useState("single");

  const [file, setFile] = useState(null);
  const [isDragActive, setIsDragActive] = useState(false);
  const fileInputRef = useRef(null);

  const [title, setTitle] = useState("");
  const [type, setType] = useState("");
  const [isAIGenerated, setIsAIGenerated] = useState(false);

  const [selectedTags, setSelectedTags] = useState([]);
  const [tagQuery, setTagQuery] = useState("");
  const [tagResults, setTagResults] = useState([]);
  const [tagPage, setTagPage] = useState(0);
  const [tagHasMore, setTagHasMore] = useState(false);
  const [tagLoading, setTagLoading] = useState(false);

  const [folderPath, setFolderPath] = useState("");

  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const isSingleMode = mode === "single";

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setSuccess("");

    if (!file) {
      setError(isSingleMode ? "File is required." : "ZIP file is required.");
      return;
    }

    if (isSingleMode) {
      if (!title.trim()) {
        setError("Title is required.");
        return;
      }
      if (!type.trim()) {
        setError("Type is required.");
        return;
      }

      const meta = {
        title: title.trim(),
        type: type.trim(),
        isAIGenerated,
        tags: selectedTags,
      };

      const formData = new FormData();
      formData.append("file", file);
      formData.append("meta", JSON.stringify(meta));

      try {
        setSubmitting(true);
        await api.post("/api/artifacts", formData);
        setSuccess("Artifact uploaded successfully.");
        navigate("/artifacts");
      } catch (err) {
        const backendMsg =
          err.response?.data?.message ||
          err.response?.data ||
          err.message ||
          "Something went wrong.";
        setError(backendMsg);
      } finally {
        setSubmitting(false);
      }
    } else {
      if (!folderPath.trim()) {
        setError("Folder path is required for bulk upload.");
        return;
      }

      const meta = {
        folderPath: folderPath.trim(),
      };

      const formData = new FormData();
      formData.append("file", file);
      formData.append("meta", JSON.stringify(meta));

      try {
        setSubmitting(true);
        await api.post("/api/artifacts/bulk", formData);
        setSuccess("Bulk artifact upload started successfully.");
        navigate("/artifacts");
      } catch (err) {
        const backendMsg =
          err.response?.data?.message ||
          err.response?.data ||
          err.message ||
          "Something went wrong.";
        setError(backendMsg);
      } finally {
        setSubmitting(false);
      }
    }
  };

  const searchTags = async (query, page = 0) => {
    const trimmed = query.trim();
    if (!trimmed) {
      setTagResults([]);
      setTagHasMore(false);
      setTagPage(0);
      return;
    }

    try {
      setTagLoading(true);
      const res = await api.get("/api/artifacts/tags", {
        params: {
          q: trimmed,
          page,
          size: TAG_PAGE_SIZE,
        },
      });

      const pageData = res.data;

      const selectedSet = new Set(selectedTags);
      const pageContent = (pageData.content || []).filter(
        (t) => !selectedSet.has(t.name)
      );

      if (page === 0) {
        setTagResults(pageContent);
      } else {
        setTagResults((prev) => [...prev, ...pageContent]);
      }

      setTagPage(pageData.pageNumber);
      setTagHasMore(!pageData.last);
    } catch (err) {
      console.error("Tag search failed", err);
    } finally {
      setTagLoading(false);
    }
  };

  const handleTagSearchChange = (e) => {
    const value = e.target.value;
    setTagQuery(value);
    searchTags(value, 0);
  };

  const handleLoadMoreTags = () => {
    if (!tagHasMore || tagLoading) return;
    searchTags(tagQuery, tagPage + 1);
  };

  const handleAddTag = (tagName) => {
    if (selectedTags.includes(tagName)) return;

    setError("");
    setSelectedTags((prev) => [...prev, tagName]);

    setTagQuery("");
    setTagResults([]);
    setTagHasMore(false);
    setTagPage(0);
  };

  const handleRemoveTag = (tagName) => {
    setError("");
    setSelectedTags((prev) => prev.filter((t) => t !== tagName));
  };

  const handleFileChange = (e) => {
    const selected = e.target.files && e.target.files[0];
    setFile(selected || null);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragActive(false);

    const dt = e.dataTransfer;
    if (!dt || !dt.files || dt.files.length === 0) return;

    const droppedFile = dt.files[0];
    setFile(droppedFile || null);
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    e.stopPropagation();
    e.dataTransfer.dropEffect = "copy";
    setIsDragActive(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragActive(false);
  };

  const openFileDialog = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  return (
    <>
      <Navbar />

      <div className="page page--narrow upload-page">
        <header className="page-header">
          <div>
            <h1 className="page-title">Upload Artifact</h1>
            <p className="page-subtitle">
              Upload a single artifact or a ZIP folder of artifacts.
            </p>
          </div>
        </header>

        {/* Upload mode segmented control */}
        <div className="upload-mode-row">
          <span className="upload-mode-label">Upload mode:</span>
          <div className="segmented">
            <button
              type="button"
              className={`seg-option ${isSingleMode ? "active" : ""}`}
              onClick={() => {
                setMode("single");
                setError("");
                setSuccess("");
              }}
            >
              Single
            </button>

            <button
              type="button"
              className={`seg-option ${!isSingleMode ? "active" : ""}`}
              onClick={() => {
                setMode("bulk");
                setError("");
                setSuccess("");
              }}
            >
              Bulk (ZIP)
            </button>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="upload-form form-vertical">
          {isSingleMode && (
            <>
              <div className="upload-section">
                <label>Title</label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  required
                  className="input-dark"
                />
              </div>

              <div className="upload-section">
                <label>Type</label>
                <input
                  type="text"
                  value={type}
                  onChange={(e) => setType(e.target.value)}
                  required
                  placeholder="e.g. code, document, report"
                  className="input-dark"
                />
              </div>

              <div className="upload-section">
                <label>Tags</label>
                <input
                  type="text"
                  value={tagQuery}
                  onChange={handleTagSearchChange}
                  placeholder="Search tags..."
                  className="input-dark"
                />

                {selectedTags.length > 0 && (
                  <div className="filter-tag-chips">
                    {selectedTags.map((tag) => (
                      <span key={tag} className="tag-chip">
                        {tag}
                        <button
                          type="button"
                          onClick={() => handleRemoveTag(tag)}
                          className="tag-chip-remove"
                        >
                          ×
                        </button>
                      </span>
                    ))}
                  </div>
                )}

                {tagQuery.trim() !== "" && (
                  <div className="tag-dropdown-wrapper">
                    <div className="tag-dropdown">
                      {tagLoading && (
                        <div className="tag-dropdown-status">
                          Searching...
                        </div>
                      )}

                      {!tagLoading && tagResults.length === 0 && (
                        <div className="tag-dropdown-status">
                          No tags found.
                        </div>
                      )}

                      {!tagLoading &&
                        tagResults.map((tag) => (
                          <button
                            key={tag.id}
                            type="button"
                            onClick={() => handleAddTag(tag.name)}
                            className="tag-dropdown-item"
                          >
                            {tag.name}
                          </button>
                        ))}

                      {!tagLoading && tagHasMore && (
                        <button
                          type="button"
                          onClick={handleLoadMoreTags}
                          className="tag-dropdown-footer"
                        >
                          Load more...
                        </button>
                      )}
                    </div>
                  </div>
                )}
              </div>

              <div className="upload-section switch-row">
                <span className="switch-label">AI Generated:</span>
                <label className="switch switch--sm">
                  <input
                    type="checkbox"
                    checked={isAIGenerated}
                    onChange={(e) => setIsAIGenerated(e.target.checked)}
                  />
                  <span className="switch-thumb" />
                </label>
              </div>
            </>
          )}

          {!isSingleMode && (
            <div className="upload-section">
              <label>Folder path</label>
              <input
                type="text"
                value={folderPath}
                onChange={(e) => setFolderPath(e.target.value)}
                required
                placeholder="e.g. MyFolder"
                className="input-dark"
              />
            </div>
          )}

          {/* File upload */}
          <div className="upload-section">
            <label>File</label>
            <div
              className={`file-dropzone ${
                isDragActive ? "file-dropzone--hover" : ""
              }`}
              onClick={openFileDialog}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
            >
              <div className="file-dropzone-title">
                {file
                  ? file.name
                  : isSingleMode
                  ? "Drop a file here"
                  : "Drop a ZIP file here"}
              </div>
              <div className="file-dropzone-sub">
                or click to browse from your device
              </div>
            </div>

            <input
              ref={fileInputRef}
              type="file"
              style={{ display: "none" }}
              onChange={handleFileChange}
              accept={isSingleMode ? undefined : ".zip"}
            />
          </div>

          {error && <div className="error upload-status">{error}</div>}
          {success && <div className="success upload-status">{success}</div>}

          <div className="form-actions">
            <button type="submit" disabled={submitting} className="btn btn-full">
              {submitting
                ? isSingleMode
                  ? "Uploading..."
                  : "Uploading ZIP..."
                : isSingleMode
                ? "Upload Single Artifact"
                : "Upload Bulk ZIP"}
            </button>
          </div>
        </form>
      </div>
    </>
  );
}
