import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import api from "../api";

import StepsBar from "../components/TaskModals/StepsBar";
import BasicsModal from "../components/TaskModals/BasicsModal";
import ArtifactModal from "../components/TaskModals/ArtifactModal";
import CriteriaModal from "../components/TaskModals/CriteriaModal";
import Navbar from "../components/Navbar";

export default function ManageTask() {
  const navigate = useNavigate();
  const { studyId, taskId } = useParams();

  const [currentStep, setCurrentStep] = useState(1);

  const [basics, setBasics] = useState({
    name: "",
    instructions: "",
    isBlinded: false,
  });

  const [viewType, setViewType] = useState("SINGLE");
  const [selectedArtifacts, setSelectedArtifacts] = useState([]);

  const [folderPage, setFolderPage] = useState({
    content: [],
    page: 0,
    totalPages: 1,
  });
  const [artifactPage, setArtifactPage] = useState({
    content: [],
    page: 0,
    totalPages: 1,
  });

  const [loadingFolders, setLoadingFolders] = useState(false);
  const [loadingArtifacts, setLoadingArtifacts] = useState(false);

  const folderPageSize = 10;
  const artifactPageSize = 10;

  const [selectedFolderId, setSelectedFolderId] = useState("");
  const [criteria, setCriteria] = useState([createEmptyCriterion()]);

  const [loadingTask, setLoadingTask] = useState(true);
  const [taskLoadError, setTaskLoadError] = useState("");

  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState("");
  const [error, setError] = useState("");

  const fetchFolders = async (page = 0) => {
    setLoadingFolders(true);
    setError("");
    try {
      const res = await api.get("/api/artifacts/folders", {
        params: { page, size: folderPageSize },
      });
      const data = res.data || {};
      setFolderPage({
        content: Array.isArray(data.content) ? data.content : [],
        page: typeof data.page === "number" ? data.page : page,
        totalPages:
          typeof data.totalPages === "number" && data.totalPages > 0 ? data.totalPages : 1,
      });
    } catch (e) {
      console.error("Failed to load folders", e);
      setError("Failed to load artifact folders.");
      setFolderPage((prev) => ({ ...prev, content: [] }));
    } finally {
      setLoadingFolders(false);
    }
  };

  const fetchArtifacts = async (folderId, page = 0) => {
    setLoadingArtifacts(true);
    setError("");
    try {
      const res = await api.get("/api/artifacts", {
        params: { folderId, page, size: artifactPageSize },
      });
      const data = res.data || {};
      setArtifactPage({
        content: Array.isArray(data.content) ? data.content : [],
        page: typeof data.page === "number" ? data.page : page,
        totalPages:
          typeof data.totalPages === "number" && data.totalPages > 0 ? data.totalPages : 1,
      });
    } catch (e) {
      console.error("Failed to load artifacts", e);
      setError("Failed to load artifacts for the selected folder.");
      setArtifactPage((prev) => ({ ...prev, content: [] }));
    } finally {
      setLoadingArtifacts(false);
    }
  };

  useEffect(() => {
    fetchFolders(0);
  }, []);

  useEffect(() => {
    fetchArtifacts(selectedFolderId, 0);
  }, [selectedFolderId]);

  useEffect(() => {
    const fetchTask = async () => {
      setLoadingTask(true);
      setTaskLoadError("");
      setError("");
      setSuccess("");

      try {
        const res = await api.get(`/api/studies/${studyId}/tasks/${taskId}`);
        const data = res.data || {};

        setBasics({
          name: data.name || "",
          instructions: data.instructions || "",
          isBlinded: !!data.isBlinded,
        });

        const vt = data.viewType || "SINGLE";
        setViewType(vt);

        if (Array.isArray(data.artifacts)) {
          console.log(data.artifacts);
          const artifacts = await Promise.all(
            data.artifacts.map(async (a) => {
              const res2 = await api.get(`/api/artifacts/${a}`);
              return res2.data;
            })
          );
          setSelectedArtifacts(artifacts.slice(0, getMaxArtifactsForView(vt)));
        } else {
          setSelectedArtifacts([]);
        }

        if (Array.isArray(data.criteria) && data.criteria.length > 0) {
          setCriteria(
            data.criteria.map((c) => ({
              id: c.id || Date.now().toString(36) + Math.random().toString(36).slice(2),
              name: c.name || "",
              description: c.description || "",
              scaleType: c.scaleType || "FIVESTAR",
              options: Array.isArray(c.options) ? c.options : [],
            }))
          );
        } else {
          setCriteria([createEmptyCriterion()]);
        }
      } catch (e) {
        console.error("Failed to load task", e);
        setTaskLoadError("Failed to load task.");
      } finally {
        setLoadingTask(false);
      }
    };

    fetchTask();
  }, [studyId, taskId]);

  const steps = ["Task details", "View & artifacts", "Criteria"];

  const goNext = () => {
    setError("");
    if (currentStep < 3) setCurrentStep((s) => s + 1);
  };

  const goPrev = () => {
    setError("");
    if (currentStep > 1) setCurrentStep((s) => s - 1);
  };

  const handleViewTypeChange = (newType) => {
    const max = getMaxArtifactsForView(newType);
    setViewType(newType);
    setSelectedArtifacts((prev) => prev.slice(0, max));
  };

  const handleSelectedFolderId = (folderId) => {
    if (selectedFolderId === folderId) setSelectedFolderId("");
    else setSelectedFolderId(folderId);
  };

  const handleSubmit = async () => {
    setError("");
    setSuccess("");

    if (!basics.name.trim()) {
      setError("Please provide a task name.");
      setCurrentStep(1);
      return;
    }
    if (selectedArtifacts.length === 0) {
      setError("Please select at least one artifact.");
      setCurrentStep(2);
      return;
    }
    if (criteria.length === 0 || !criteria.some((c) => c.name.trim())) {
      setError("Please add at least one criterion with a name.");
      setCurrentStep(3);
      return;
    }

    const payload = {
      name: basics.name.trim(),
      instructions: basics.instructions.trim(),
      isBlinded: basics.isBlinded,
      viewType,
      artifacts: selectedArtifacts.map((a) => a.id),
      criteria: criteria.map((c) => ({
        name: c.name.trim(),
        description: c.description.trim(),
        scaleType: c.scaleType,
        options: (c.options || []).filter((o) => o.trim().length > 0),
      })),
    };

    try {
      setSubmitting(true);
      await api.put(`/api/studies/${studyId}/tasks/${taskId}`, payload);
      setSuccess("Task has been updated successfully.");
      navigate(`/study/${studyId}/tasks`);
    } catch (e) {
      console.error("Failed to update task", e);
      setError("Failed to update task.");
    } finally {
      setSubmitting(false);
    }
  };

  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return <BasicsModal basics={basics} onChange={setBasics} />;
      case 2:
        return (
          <ArtifactModal
            viewType={viewType}
            onViewTypeChange={handleViewTypeChange}
            maxSelectable={getMaxArtifactsForView(viewType)}
            folders={folderPage.content}
            folderPage={folderPage.page}
            folderTotalPages={folderPage.totalPages}
            loadingFolders={loadingFolders}
            onFolderPageChange={fetchFolders}
            selectedFolderId={selectedFolderId}
            onSelectFolder={handleSelectedFolderId}
            artifacts={artifactPage.content}
            artifactPage={artifactPage.page}
            artifactTotalPages={artifactPage.totalPages}
            loadingArtifacts={loadingArtifacts}
            onArtifactPageChange={(newPage) => fetchArtifacts(selectedFolderId, newPage)}
            selectedArtifacts={selectedArtifacts}
            onChangeSelected={setSelectedArtifacts}
          />
        );
      case 3:
        return (
          <CriteriaModal
            criteria={criteria}
            onChange={setCriteria}
            onAddCriterion={() => setCriteria((prev) => [...prev, createEmptyCriterion()])}
          />
        );
      default:
        return null;
    }
  };

  return (
    <>
      <Navbar />

      <div className="center-screen">
        <div className="card task-card task-wizard">
          <div className="task-wizard-head">
            <div>
              <h2>Edit Task</h2>
              <p className="muted task-wizard-subtitle">
                Update task details, artifacts, and evaluation criteria.
              </p>
            </div>
          </div>

          {loadingTask && <div className="muted">Loading task…</div>}
          {taskLoadError && <div className="error">{taskLoadError}</div>}

          {!taskLoadError && (
            <>
              <StepsBar steps={steps} currentStep={currentStep} onStepChange={setCurrentStep} />

              <div className="task-wizard-messages">
                {error && <div className="error">{error}</div>}
                {success && <div className="success">{success}</div>}
              </div>

              {!loadingTask && <div className="task-wizard-step">{renderStep()}</div>}

              <div className="task-wizard-nav">
                <button
                  type="button"
                  className="btn small"
                  onClick={goPrev}
                  disabled={currentStep === 1 || submitting || loadingTask}
                >
                  Previous
                </button>

                <button
                  type="button"
                  className="btn small"
                  onClick={() => navigate(`/study/${studyId}/tasks`)}
                  disabled={submitting}
                >
                  Return
                </button>

                <div className="task-wizard-nav-right">
                  {currentStep < 3 ? (
                    <button
                      type="button"
                      className="btn small"
                      onClick={goNext}
                      disabled={submitting || loadingTask}
                    >
                      Next
                    </button>
                  ) : (
                    <button
                      type="button"
                      className="btn small"
                      onClick={handleSubmit}
                      disabled={submitting || loadingTask}
                    >
                      {submitting ? "Updating..." : "Update task"}
                    </button>
                  )}
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </>
  );
}

const createEmptyCriterion = () => ({
  id: Date.now().toString(36) + Math.random().toString(36).slice(2),
  name: "",
  description: "",
  scaleType: "FIVESTAR",
  options: [],
});

const getMaxArtifactsForView = (viewType) => {
  switch (viewType) {
    case "SINGLE":
      return 1;
    case "SIDE_BY_SIDE":
      return 2;
    case "THREE_WAY":
      return 3;
    default:
      return 1;
  }
};
