import React, { useState, useEffect, useMemo } from "react";
import { useParams, useNavigate } from "react-router-dom";
import Navbar from "../components/Navbar";
import api from "../api";
import InviteParticipantModal from "../components/InviteParticipantModal";
import AddReviewerModal from "../components/AddReviewerModal";
import ReviewQuizModal from "../components/ReviewQuizModal";

export default function ManageStudy() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [study, setStudy] = useState(null);
  const [tasks, setTasks] = useState([]);
  const [invitations, setInvitations] = useState([]);
  const [reviewers, setReviewers] = useState([]);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const [showUpdateModal, setShowUpdateModal] = useState(false);
  const [showInviteModal, setShowInviteModal] = useState(false);
  const [showReviewerModal, setShowReviewerModal] = useState(false);

  const [showReviewModal, setShowReviewModal] = useState(false);
  const [selectedInvitation, setSelectedInvitation] = useState(null);

  // Form state for update
  const [updateFormData, setUpdateFormData] = useState({
    title: "",
    description: "",
    status: "DRAFT",
  });

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);

        const studyResponse = await api.get(`/api/studies/${id}`);
        setStudy(studyResponse.data);
        setUpdateFormData({
          title: studyResponse.data.title || "",
          description: studyResponse.data.description || "",
          status: studyResponse.data.status || "DRAFT",
        });

        const tasksResponse = await api.get(`/api/studies/${id}/tasks`);
        setTasks(tasksResponse.data);

        const invitationsResponse = await api.get(`/api/studies/${id}/invitations`);
        setInvitations(invitationsResponse.data);

        const reviewersResponse = await api.get(`/api/studies/${id}/reviewers`);
        const reviewerIds = reviewersResponse.data;
        const reviewersWithNames = await Promise.all(
          reviewerIds.map(async (reviewerId) => {
            try {
              const userRes = await api.get(`/api/users/${reviewerId}`);
              return { id: reviewerId, displayName: userRes.data.displayName || 'Unknown' };
            } catch {
              return { id: reviewerId, displayName: 'Unknown User' };
            }
          })
        );
        setReviewers(reviewersWithNames);
      } catch (err) {
        console.error(err);
        setError("Failed to load study details.");
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [id]);

  const statusPill = useMemo(() => {
    const s = (study?.status || "").toUpperCase();
    if (s === "ACTIVE") return "pill pill--green";
    if (s === "COMPLETED") return "pill pill--amber";
    if (s === "DRAFT") return "pill pill--neutral";
    return "pill pill--neutral";
  }, [study]);

  const invitationPill = (status) => {
    const s = (status || "").toUpperCase();
    if (s === "ACCEPTED") return "pill pill--green";
    if (s === "REJECTED") return "pill pill--red";
    if (s === "QUIZ_COMPLETED") return "pill pill--amber";
    return "pill pill--neutral";
  };

  const handleCreateTask = () => {
    navigate(`/study/${id}/addTask`);
  };

  const handleManageTask = (taskId) => {
    navigate(`/study/${id}/task/${taskId}`);
  };

  const handleInviteSuccess = async () => {
    const invitationsResponse = await api.get(`/api/studies/${id}/invitations`);
    setInvitations(invitationsResponse.data);
  };

  const handleUpdateInvitationStatus = async (invitationId, status) => {
    try {
      await api.put(`/api/studies/${id}/invitations/${invitationId}?status=${status}`);
      await handleInviteSuccess();
    } catch (err) {
      console.error("Failed to update invitation status", err);
      alert("Failed to update invitation status.");
    }
  };

  const handleReviewQuiz = (invitation) => {
    setSelectedInvitation(invitation);
    setShowReviewModal(true);
  };

  const handleReviewComplete = async () => {
    setShowReviewModal(false);
    setSelectedInvitation(null);
    await handleInviteSuccess();
  };

  const handleUpdateSubmit = async (e) => {
    e.preventDefault();
    try {
      await api.put(`/api/studies/${id}`, updateFormData);
      setStudy((prev) => ({ ...prev, ...updateFormData }));
      setShowUpdateModal(false);
      alert("Study updated successfully!");
      if (updateFormData.status === "ACTIVE") {
        navigate("/Studies");
      }
    } catch (err) {
      console.error(err);
      alert("Failed to update study.");
    }
  };

  if (loading) {
    return (
      <>
        <Navbar />
        <div className="ms-page">
          <div className="muted">Loading...</div>
        </div>
      </>
    );
  }

  if (error) {
    return (
      <>
        <Navbar />
        <div className="ms-page">
          <div className="error">{error}</div>
        </div>
      </>
    );
  }

  if (!study) {
    return (
      <>
        <Navbar />
        <div className="ms-page">
          <div className="muted">Study not found.</div>
        </div>
      </>
    );
  }

  return (
    <>
      <Navbar />

      <div className="ms-page">
        <div className="ms-header">
          <div>
            <h1 className="ms-title">Manage Study</h1>
            <div className="ms-subtitle">
              <span>{study.title}</span>
              <span className={statusPill}>{study.status}</span>
            </div>
          </div>

          <div className="ms-header-actions">
            <button className="btn small btn-ghost" onClick={() => navigate("/studies")}>
              ← Back
            </button>
            <button className="btn small" onClick={() => setShowUpdateModal(true)}>
              Update Study
            </button>
            <button className="btn small btn-secondary" onClick={handleCreateTask}>
              Create Task
            </button>
          </div>
        </div>

        <div className="ms-layout">
          {/* Left sidebar */}
          <aside>
            <div className="ms-card">
              <h3 className="ms-card-title">Study Details</h3>

              <div className="ms-kv">
                <div className="ms-k">Title</div>
                <div className="ms-v">{study.title}</div>
              </div>

              <div className="ms-kv">
                <div className="ms-k">Start</div>
                <div className="ms-v">{study.startDate}</div>
              </div>

              <div className="ms-kv">
                <div className="ms-k">End</div>
                <div className="ms-v">{study.endDate}</div>
              </div>

              <div className="ms-kv">
                <div className="ms-k">Status</div>
                <div className="ms-v">
                  <span className={statusPill}>{study.status}</span>
                </div>
              </div>
            </div>

            <div className="ms-card">
              <h3 className="ms-card-title">Description</h3>
              <div className="muted" style={{ whiteSpace: "pre-wrap", lineHeight: 1.5 }}>
                {study.description || "No description"}
              </div>
            </div>
          </aside>

          {/* Right main content */}
          <main>
            <section className="ms-section">
              <div className="ms-section-header">
                <h3 className="ms-section-title">Tasks</h3>
                <div className="ms-count">{tasks.length} total</div>
              </div>

              {tasks.length === 0 ? (
                <div className="muted">No tasks found for this study.</div>
              ) : (
                <div className="ms-task-grid">
                  {tasks.map((task) => (
                    <div
                      key={task.taskId}
                      className="ms-task-card"
                      onClick={() => handleManageTask(task.taskId)}
                    >
                      <h4 className="ms-task-title">{task.name || "Unnamed Task"}</h4>
                      <p className="ms-task-desc">{task.instructions || "No instructions"}</p>
                      <div className="ms-task-meta">
                        {task.criteria?.length ? `${task.criteria.length} criteria` : "No Criteria"}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </section>

            <section className="ms-section">
              <div className="ms-section-header">
                <h3 className="ms-section-title">Participants</h3>
                <div className="ms-header-actions">
                  <button className="btn small btn-secondary" onClick={() => setShowInviteModal(true)}>
                    Invite
                  </button>
                </div>
              </div>

              {invitations.length === 0 ? (
                <div className="muted">No participants invited yet.</div>
              ) : (
                <div className="ms-list">
                  {invitations.map((inv) => (
                    <div key={inv.invitationId} className="ms-item">
                      <div className="ms-item-main">
                        <h4 className="ms-item-title">
                          {inv.userDisplayName} <span className="muted">({inv.userEmail})</span>
                        </h4>
                        <div className="ms-item-sub">
                          <span>Status:</span>
                          <span className={invitationPill(inv.status)}>{inv.status}</span>
                          {typeof inv.quizScore === "number" && typeof inv.quizMaxScore === "number" && (
                            <span className="muted">
                              Quiz: {inv.quizScore}/{inv.quizMaxScore}
                            </span>
                          )}
                        </div>
                      </div>

                      <div className="ms-item-actions">
                        {inv.status === "QUIZ_COMPLETED" && (
                          <button className="btn small btn-secondary" onClick={() => handleReviewQuiz(inv)}>
                            Review Quiz
                          </button>
                        )}
                        <button
                          className="btn small"
                          onClick={() => handleUpdateInvitationStatus(inv.invitationId, "ACCEPTED")}
                        >
                          Accept
                        </button>
                        <button
                          className="btn small btn-danger"
                          onClick={() => handleUpdateInvitationStatus(inv.invitationId, "REJECTED")}
                        >
                          Reject
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </section>

            <section className="ms-section">
              <div className="ms-section-header">
                <h3 className="ms-section-title">Reviewers</h3>
                <button className="btn small btn-secondary" onClick={() => setShowReviewerModal(true)}>
                  Add Reviewer
                </button>
              </div>

              {reviewers.length === 0 ? (
                <div className="muted">No reviewers assigned yet.</div>
              ) : (
                <div className="ms-list">
                  {reviewers.map((r) => (
                    <div key={r.id} className="ms-item">
                      <div className="ms-item-main">
                        <h4 className="ms-item-title">{r.displayName}</h4>
                        <div className="ms-item-sub">
                          <span className="pill pill--green">Reviewer</span>
                        </div>
                      </div>

                      <div className="ms-item-actions">
                        <button
                          className="btn small btn-danger"
                          onClick={async () => {
                            try {
                              await api.delete(`/api/studies/${id}/reviewers/${r.id}`);
                              setReviewers((prev) => prev.filter((x) => x.id !== r.id));
                            } catch (err) {
                              console.error(err);
                              alert("Failed to remove reviewer.");
                            }
                          }}
                        >
                          Remove
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </section>
          </main>
        </div>

        {/* Update Study Modal */}
        {showUpdateModal && (
          <div className="modal-overlay" onMouseDown={() => setShowUpdateModal(false)}>
            <div className="modal modal--sm" onMouseDown={(e) => e.stopPropagation()}>
              <div className="modal-header">
                <h3 className="modal-title">Update Study</h3>
                <button className="modal-close" onClick={() => setShowUpdateModal(false)} aria-label="Close">
                  ×
                </button>
              </div>

              <form onSubmit={handleUpdateSubmit}>
                <div className="modal-body">
                  <label>Title</label>
                  <input
                    className="input-dark"
                    value={updateFormData.title}
                    onChange={(e) => setUpdateFormData({ ...updateFormData, title: e.target.value })}
                  />

                  <label>Description</label>
                  <textarea
                    className="textarea-dark"
                    value={updateFormData.description}
                    onChange={(e) => setUpdateFormData({ ...updateFormData, description: e.target.value })}
                  />

                  <label>Status</label>
                  <select
                    className="select-dark"
                    value={updateFormData.status}
                    onChange={(e) => setUpdateFormData({ ...updateFormData, status: e.target.value })}
                  >
                    <option value="DRAFT">DRAFT</option>
                    <option value="ACTIVE">ACTIVE</option>
                    <option value="COMPLETED">COMPLETED</option>
                  </select>
                </div>

                <div className="modal-footer">
                  <button type="button" className="btn small btn-ghost" onClick={() => setShowUpdateModal(false)}>
                    Cancel
                  </button>
                  <button type="submit" className="btn small">
                    Submit
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Invite Modal */}
        {showInviteModal && (
          <InviteParticipantModal
            studyId={id}
            onClose={() => setShowInviteModal(false)}
            onInviteSuccess={handleInviteSuccess}
          />
        )}

        {/* Review Quiz Modal */}
        {showReviewModal && selectedInvitation && (
          <ReviewQuizModal
            invitation={selectedInvitation}
            studyId={id}
            onClose={() => setShowReviewModal(false)}
            onReviewComplete={handleReviewComplete}
          />
        )}

        {/* Add Reviewer Modal */}
        {showReviewerModal && (
          <AddReviewerModal
            studyId={id}
            onClose={() => setShowReviewerModal(false)}
            onSuccess={async () => {
              // Refresh reviewers list
              try {
                const reviewersResponse = await api.get(`/api/studies/${id}/reviewers`);
                const reviewerIds = reviewersResponse.data;
                const reviewersWithNames = await Promise.all(
                  reviewerIds.map(async (reviewerId) => {
                    try {
                      const userRes = await api.get(`/api/users/${reviewerId}`);
                      return { id: reviewerId, displayName: userRes.data.displayName || 'Unknown' };
                    } catch {
                      return { id: reviewerId, displayName: 'Unknown User' };
                    }
                  })
                );
                setReviewers(reviewersWithNames);
              } catch (err) {
                console.error(err);
              }
            }}
          />
        )}
      </div>
    </>
  );
}
