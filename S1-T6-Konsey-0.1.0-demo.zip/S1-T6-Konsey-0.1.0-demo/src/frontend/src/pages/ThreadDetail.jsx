import React, { useState, useEffect, useContext } from "react";
import Navbar from "../components/Navbar";
import { useParams, useNavigate } from 'react-router-dom';
import api from "../api";
import { AuthContext } from "../auth/AuthProvider";
import ForumAttachmentPicker from "../components/ForumAttachmentPicker";
import ForumPostAttachmentViewer from "../components/ForumPostAttachmentViewer";

export default function ThreadDetail() {
    const { forumId, threadId } = useParams();
    const navigate = useNavigate();
    const { user } = useContext(AuthContext);

    const [forum, setForum] = useState(null);
    const [thread, setThread] = useState(null);
    const [posts, setPosts] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState(null);
    const [replyContent, setReplyContent] = useState('');
    const [replyArtifacts, setReplyArtifacts] = useState([]);
    const [replyFiles, setReplyFiles] = useState([]);
    const [submitting, setSubmitting] = useState(false);
    const [editingPostId, setEditingPostId] = useState(null);
    const [editContent, setEditContent] = useState('');

    const userRole = user?.role?.toString().toUpperCase();
    // User response uses 'id', but some parts might use 'userId'. Check both.
    const userId = user?.id || user?.userId;
    const canModerate = userRole === 'ADMIN' || userRole === 'RESEARCHER';
    const canLinkArtifacts = userRole === 'ADMIN' || userRole === 'RESEARCHER';

    const fetchData = async () => {
        try {
            setIsLoading(true);
            const [forumRes, threadRes, postsRes] = await Promise.all([
                api.get(`/api/forums/${forumId}`),
                api.get(`/api/forums/threads/${threadId}`),
                api.get(`/api/forums/threads/${threadId}/posts`),
            ]);
            setForum(forumRes.data);
            setThread(threadRes.data);
            setPosts(postsRes.data);
            setError(null);
        } catch (err) {
            console.error("Failed to fetch thread data:", err);
            setError("Failed to load thread. Please try again later.");
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        fetchData();
    }, [forumId, threadId]);

    const handleSubmitReply = async (e) => {
        e.preventDefault();
        if (!replyContent.trim()) return;

        try {
            setSubmitting(true);
            const postData = {
                content: replyContent,
                artifactIds: replyArtifacts.map(a => a.artifactId)
            };
            // Extract the actual File object from the wrapper
            const filesToUpload = replyFiles.map(f => f.file);

            const formData = new FormData();
            const jsonBlob = new Blob([JSON.stringify(postData)], { type: 'application/json' });
            formData.append('data', jsonBlob);
            if (filesToUpload && filesToUpload.length > 0) {
                filesToUpload.forEach(file => formData.append('files', file));
            }

            await api.post(`/api/forums/threads/${threadId}/posts`, formData);
            setReplyContent('');
            setReplyArtifacts([]);
            setReplyFiles([]);
            fetchData();
        } catch (err) {
            console.error("Failed to post reply:", err);
            alert(err.response?.data?.message || "Failed to post reply. Please try again.");
        } finally {
            setSubmitting(false);
        }
    };

    const handleEditPost = (post) => {
        setEditingPostId(post.postId);
        setEditContent(post.content);
    };

    const handleSaveEdit = async (postId) => {
        if (!editContent.trim()) return;

        try {
            await api.put(`/api/forums/posts/${postId}`, { content: editContent });
            setEditingPostId(null);
            setEditContent('');
            fetchData();
        } catch (err) {
            console.error("Failed to update post:", err);
            alert(err.response?.data?.message || "Failed to update post.");
        }
    };

    const handleCancelEdit = () => {
        setEditingPostId(null);
        setEditContent('');
    };

    const handleDeletePost = async (postId) => {
        if (!window.confirm("Are you sure you want to delete this post?")) return;

        try {
            await api.delete(`/api/forums/posts/${postId}`);
            fetchData();
        } catch (err) {
            console.error("Failed to delete post:", err);
            alert(err.response?.data?.message || "Failed to delete post.");
        }
    };

    // Update isAuthor to use string comparison to avoid type issues
    const isAuthor = (postAuthorId) => {
        return userId && postAuthorId && String(userId) === String(postAuthorId);
    };

    if (isLoading) {
        return (
            <>
                <Navbar />
                <div style={{ padding: 24, color: '#9ca3af' }}>Loading thread...</div>
            </>
        );
    }

    if (error || !thread) {
        return (
            <>
                <Navbar />
                <div style={{ padding: 24 }}>
                    <button className="btn btn-secondary" onClick={() => navigate(`/forums/${forumId}`)}>
                        ← Back to Forum
                    </button>
                    <p style={{ color: '#ef4444', marginTop: '16px' }}>{error || "Thread not found"}</p>
                </div>
            </>
        );
    }

    const isReadOnly = forum?.status === 'ARCHIVED' || forum?.status === 'CLOSED';
    const isLocked = thread.locked;
    const isGuest = userRole === 'GUEST';
    const canReply = !isReadOnly && !isLocked && !isGuest;

    return (
        <>
            <Navbar />
            <div style={{ padding: 24, maxWidth: '900px', margin: '0 auto' }}>
                {/* Header */}
                <div style={{ marginBottom: '24px' }}>
                    <button
                        className="btn btn-secondary"
                        style={{ marginBottom: '16px' }}
                        onClick={() => navigate(`/forums/${forumId}`)}
                    >
                        ← Back to {forum?.title || 'Forum'}
                    </button>

                    <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '8px' }}>
                        <h2 style={{ margin: 0, color: '#f3f4f6' }}>{thread.title}</h2>
                        {isLocked && (
                            <span style={{
                                backgroundColor: '#ef4444',
                                color: 'white',
                                padding: '4px 8px',
                                borderRadius: '4px',
                                fontSize: '12px'
                            }}>
                                🔒 Locked
                            </span>
                        )}
                    </div>
                    <div style={{ fontSize: '14px', color: '#6b7280' }}>
                        Started by <strong style={{ color: '#9ca3af' }}>{thread.authorName || 'Unknown'}</strong>
                        <span style={{ margin: '0 8px' }}>•</span>
                        {new Date(thread.createdAt).toLocaleString()}
                    </div>
                </div>

                {/* Original Post */}
                <div className="card" style={{
                    padding: '20px',
                    marginBottom: '24px',
                    borderLeft: '4px solid #3b82f6'
                }}>
                    <div style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'flex-start',
                        marginBottom: '12px'
                    }}>
                        <div style={{ fontSize: '14px', color: '#9ca3af' }}>
                            <strong>{thread.authorName || 'Unknown'}</strong>
                            <span style={{ margin: '0 8px', color: '#6b7280' }}>•</span>
                            <span style={{ color: '#6b7280' }}>{new Date(thread.createdAt).toLocaleString()}</span>
                            <span style={{
                                marginLeft: '8px',
                                backgroundColor: '#3b82f6',
                                color: 'white',
                                padding: '2px 6px',
                                borderRadius: '4px',
                                fontSize: '11px'
                            }}>
                                Original Post
                            </span>
                        </div>
                    </div>
                    <div style={{ color: '#e5e7eb', lineHeight: '1.6', whiteSpace: 'pre-wrap' }}>
                        {thread.body}
                    </div>
                    {/* Display Thread Attachments */}
                    {thread.attachments && thread.attachments.length > 0 && (
                        <ForumPostAttachmentViewer attachments={thread.attachments} />
                    )}
                </div>

                {/* Replies */}
                {posts.length > 0 && (
                    <div style={{ marginBottom: '24px' }}>
                        <h3 style={{ color: '#f3f4f6', marginBottom: '16px' }}>
                            Replies ({posts.length})
                        </h3>
                        <div style={{ display: 'grid', gap: '12px' }}>
                            {posts.map((post) => (
                                <div key={post.postId} className="card" style={{ padding: '16px 20px', opacity: post.deleted ? 0.7 : 1 }}>
                                    <div style={{
                                        display: 'flex',
                                        justifyContent: 'space-between',
                                        alignItems: 'flex-start',
                                        marginBottom: '12px'
                                    }}>
                                        <div style={{ fontSize: '14px', color: '#9ca3af' }}>
                                            <strong>{post.authorName || 'Unknown'}</strong>
                                            <span style={{ margin: '0 8px', color: '#6b7280' }}>•</span>
                                            <span style={{ color: '#6b7280' }}>{new Date(post.createdAt).toLocaleString()}</span>
                                            {/* Edited Label */}
                                            {post.updatedAt && !post.deleted && new Date(post.updatedAt).getTime() > new Date(post.createdAt).getTime() + 1000 && (
                                                <span style={{ color: '#6b7280', fontStyle: 'italic', marginLeft: '8px' }}>
                                                    (edited)
                                                </span>
                                            )}
                                            {/* Deleted Label */}
                                            {post.deleted && (
                                                <span style={{ color: '#ef4444', fontStyle: 'italic', marginLeft: '8px', fontWeight: 'bold' }}>
                                                    [DELETED]
                                                </span>
                                            )}
                                        </div>

                                        {/* Post Actions */}
                                        {(isAuthor(post.authorId) || canModerate) && !isLocked && !post.deleted && (
                                            <div style={{ display: 'flex', gap: '8px' }}>
                                                {isAuthor(post.authorId) && editingPostId !== post.postId && (
                                                    <button
                                                        className="btn btn-secondary"
                                                        style={{ fontSize: '11px', padding: '4px 8px' }}
                                                        onClick={() => handleEditPost(post)}
                                                    >
                                                        Edit
                                                    </button>
                                                )}
                                                <button
                                                    className="btn"
                                                    style={{ fontSize: '11px', padding: '4px 8px', backgroundColor: '#ef4444' }}
                                                    onClick={() => handleDeletePost(post.postId)}
                                                >
                                                    Delete
                                                </button>
                                            </div>
                                        )}
                                    </div>

                                    {/* Content Area */}
                                    {post.deleted ? (
                                        <div style={{ color: '#6b7280', fontStyle: 'italic' }}>
                                            This post has been deleted.
                                        </div>
                                    ) : (
                                        <>
                                            {editingPostId === post.postId ? (
                                                <div>
                                                    <textarea
                                                        className="input"
                                                        value={editContent}
                                                        onChange={(e) => setEditContent(e.target.value)}
                                                        rows={4}
                                                        style={{ width: '100%', marginBottom: '12px', color: '#f3f4f6', backgroundColor: '#374151' }}
                                                    />
                                                    <div style={{ display: 'flex', gap: '8px' }}>
                                                        <button
                                                            className="btn"
                                                            onClick={() => handleSaveEdit(post.postId)}
                                                            disabled={!editContent.trim()}
                                                        >
                                                            Save
                                                        </button>
                                                        <button
                                                            className="btn btn-secondary"
                                                            onClick={handleCancelEdit}
                                                        >
                                                            Cancel
                                                        </button>
                                                    </div>
                                                </div>
                                            ) : (
                                                <>
                                                    <div style={{ color: '#e5e7eb', lineHeight: '1.6', whiteSpace: 'pre-wrap' }}>
                                                        {post.content}
                                                    </div>
                                                    {/* Display Attachments */}
                                                    {post.attachments && post.attachments.length > 0 && (
                                                        <ForumPostAttachmentViewer attachments={post.attachments} />
                                                    )}
                                                </>
                                            )}
                                        </>
                                    )}
                                </div>
                            ))}
                        </div>
                    </div>
                )}

                {/* Reply Form */}
                {canReply ? (
                    <div className="card" style={{ padding: '20px' }}>
                        <h4 style={{ margin: '0 0 16px 0', color: '#f3f4f6' }}>Post a Reply</h4>
                        <form onSubmit={handleSubmitReply}>
                            <textarea
                                className="input"
                                value={replyContent}
                                onChange={(e) => setReplyContent(e.target.value)}
                                placeholder="Write your reply..."
                                rows={4}
                                style={{ width: '100%', marginBottom: '12px', resize: 'vertical', color: '#f3f4f6', backgroundColor: '#374151' }}
                            />
                            <ForumAttachmentPicker
                                selectedArtifacts={replyArtifacts}
                                selectedFiles={replyFiles}
                                onArtifactsChange={setReplyArtifacts}
                                onFilesChange={setReplyFiles}
                                showArtifactLink={canLinkArtifacts}
                            />
                            <div style={{ marginTop: '12px' }}>
                                <button
                                    type="submit"
                                    className="btn"
                                    disabled={submitting || !replyContent.trim()}
                                >
                                    {submitting ? 'Posting...' : 'Post Reply'}
                                </button>
                            </div>
                        </form>
                    </div>
                ) : (
                    <div style={{
                        padding: '16px',
                        backgroundColor: '#374151',
                        borderRadius: '8px',
                        textAlign: 'center',
                        color: '#9ca3af'
                    }}>
                        {isLocked
                            ? '🔒 This thread is locked. No new replies are allowed.'
                            : isGuest
                                ? '🔒 You must sign in to reply.'
                                : '📁 This forum is archived/closed. No new replies are allowed.'
                        }
                    </div>
                )}
            </div>
        </>
    );
}
