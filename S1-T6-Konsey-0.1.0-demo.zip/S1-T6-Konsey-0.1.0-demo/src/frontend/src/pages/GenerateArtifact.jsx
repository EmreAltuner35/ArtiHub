import React, { useState, useContext } from "react";
import { useNavigate } from "react-router-dom";
import api from "../api";
import Navbar from "../components/Navbar";
import { AuthContext } from "../auth/AuthProvider";

const TAG_PAGE_SIZE = 5;

export default function GenerateArtifact() {
  const navigate = useNavigate();
  const { user } = useContext(AuthContext);

  // Mode: "single" or "bulk"
  const [mode, setMode] = useState("single");

  // Single Generation State
  const [singleType, setSingleType] = useState("code");
  const [singleParams, setSingleParams] = useState({});
  const [singleTitle, setSingleTitle] = useState("");

  const [selectedTags, setSelectedTags] = useState([]);
  const [tagQuery, setTagQuery] = useState("");
  const [tagResults, setTagResults] = useState([]);
  const [tagPage, setTagPage] = useState(0);
  const [tagHasMore, setTagHasMore] = useState(false);
  const [tagLoading, setTagLoading] = useState(false);

  // Bulk Generation State
  const [bulkTitle, setBulkTitle] = useState("");
  const [bulkDescription, setBulkDescription] = useState("");
  const [bulkStack, setBulkStack] = useState("");
  const [bulkType, setBulkType] = useState("spring-boot"); // default project type

  // Job State
  const [jobId, setJobId] = useState(null);
  const [jobStatus, setJobStatus] = useState(null); // queued, processing, succeeded, failed
  const [generatedPreview, setGeneratedPreview] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  // Helper to update single params
  const updateSingleParam = (key, value) => {
    setSingleParams((prev) => ({ ...prev, [key]: value }));
  };

  const handleGenerate = async (e) => {
    e.preventDefault();
    setError("");
    setJobId(null);
    setJobStatus(null);
    setGeneratedPreview(null);
    setLoading(true);

    try {
      let payload = {};

      if (mode === "single") {
        payload = {
          type: singleType,
          ownerId: "current-user", // Backend handles this via JWT, but field is required
          params: {
            title: singleTitle,
            ...singleParams
          }
        };
      } else {
        payload = {
          type: "project",
          ownerId: "current-user",
          params: {
            title: bulkTitle,
            description: bulkDescription,
            stack: bulkStack,
            type: bulkType
          }
        };
      }

      const res = await api.post("/api/ai-artifacts", payload);
      setJobId(res.data.jobId);
      setJobStatus("queued");
      pollJob(res.data.jobId);

    } catch (err) {
      console.error("Generation failed", err);
      setError("Failed to start generation job.");
      setLoading(false);
    }
  };

  const pollJob = async (id) => {
    const interval = setInterval(async () => {
      try {
        const res = await api.get(`/api/ai-artifacts/jobs/${id}`);
        const status = res.data.status;
        setJobStatus(status);

        if (status === "succeeded") {
          clearInterval(interval);
          setLoading(false);
          setGeneratedPreview(res.data.preview);
        } else if (status === "failed") {
          clearInterval(interval);
          setLoading(false);
          setError(res.data.error || "Generation failed.");
        }
      } catch (err) {
        clearInterval(interval);
        setLoading(false);
        setError("Failed to poll job status.");
      }
    }, 2000);
  };

  const handleSave = async () => {
    if (!jobId) return;
    setSaving(true);
    setError("");

    try {
      const payload = {
        title: mode === "single" ? singleTitle : bulkTitle,
        tags: mode === "single" ? selectedTags : ["project", "ai-generated"],
        ownerId: user?.id
      };

      await api.post(`/api/ai-artifacts/jobs/${jobId}/save`, payload);
      navigate("/artifacts");
    } catch (err) {
      console.error("Save failed", err);
      // Check for 422 specifically
      if (err.response && err.response.status === 422) {
        setError(err.response.data.message || "Content invalid. Please regenerate.");
      } else {
        setError("Failed to save artifact.");
      }
    } finally {
      setSaving(false);
    }
  };

  const searchTags = async (query, page = 0) => {
    const trimmed = query.trim();
    if (!trimmed) {
      setTagResults([]);
      setTagHasMore(false);
      setTagPage(0);
      return;
    }

    try {
      setTagLoading(true);
      const res = await api.get("/api/artifacts/tags", {
        params: {
          q: trimmed,
          page,
          size: TAG_PAGE_SIZE,
        },
      });

      const pageData = res.data;

      const selectedSet = new Set(selectedTags);
      const pageContent = (pageData.content || []).filter(
        (t) => !selectedSet.has(t.name)
      );

      if (page === 0) {
        setTagResults(pageContent);
      } else {
        setTagResults((prev) => [...prev, ...pageContent]);
      }

      setTagPage(pageData.pageNumber);
      setTagHasMore(!pageData.last);
    } catch (err) {
      console.error("Tag search failed", err);
    } finally {
      setTagLoading(false);
    }
  };

  const handleTagSearchChange = (e) => {
    const value = e.target.value;
    setTagQuery(value);
    searchTags(value, 0);
  };

  const handleLoadMoreTags = () => {
    if (!tagHasMore || tagLoading) return;
    searchTags(tagQuery, tagPage + 1);
  };

  const handleAddTag = (tagName) => {
    if (selectedTags.includes(tagName)) return;

    setError("");
    setSelectedTags((prev) => [...prev, tagName]);

    setTagQuery("");
    setTagResults([]);
    setTagHasMore(false);
    setTagPage(0);
  };

  const handleRemoveTag = (tagName) => {
    setError("");
    setSelectedTags((prev) => prev.filter((t) => t !== tagName));
  };

  // Render dynamic fields for single mode
  const renderSingleFields = () => {
    switch (singleType) {
      case "code":
        return (
          <>
            <div style={{ marginBottom: "1rem" }}>
              <label>Language</label>
              <input
                type="text"
                className="input-dark"
                placeholder="e.g. Java, Python"
                onChange={(e) => updateSingleParam("language", e.target.value)}
              />
            </div>
            <div style={{ marginBottom: "1rem" }}>
              <label>Goal</label>
              <textarea
                className="input-dark"
                rows={3}
                placeholder="What should this code do?"
                onChange={(e) => updateSingleParam("goal", e.target.value)}
              />
            </div>
          </>
        );
      case "uml":
        return (
          <div style={{ marginBottom: "1rem" }}>
            <label>Description</label>
            <textarea
              className="input-dark"
              rows={3}
              placeholder="Describe the system to diagram..."
              onChange={(e) => updateSingleParam("domain", e.target.value)}
            />
          </div>
        );

      case "tests":
        return (
          <div style={{ marginBottom: "1rem" }}>
            <label>Target Class/Code</label>
            <textarea
              className="input-dark"
              rows={4}
              placeholder="Paste the code to test..."
              onChange={(e) => updateSingleParam("target", e.target.value)}
            />
          </div>
        );
      default:
        return (
          <div style={{ marginBottom: "1rem" }}>
            <label>Topic/Prompt</label>
            <textarea
              className="input-dark"
              rows={3}
              placeholder="Enter your prompt..."
              onChange={(e) => updateSingleParam("topic", e.target.value)}
            />
          </div>
        );
    }
  };

  return (
    <>
      <Navbar />

      <div className="page page--narrow">
        <header className="page-header">
          <div>
            <h2 className="page-title">Generate AI Artifact</h2>
            <p className="page-subtitle">Generate a single artifact or a project template with AI.</p>
          </div>
        </header>

        {/* Mode Toggle */}
        <div className="section-header">
          <div className="segmented">
            <button
              type="btn"
              className={`seg-option ${mode === "single" ? "active" : ""}`}
              onClick={() => setMode("single")}
            >
              Single Artifact
            </button>
            <button
              type="btn"
              className={`seg-option ${mode === "bulk" ? "active" : ""}`}
              onClick={() => setMode("bulk")}
            >
              Bulk Project
            </button>
          </div>
        </div>

        <div className="panel">
          <form className="ai-form" onSubmit={handleGenerate}>
            {/* SINGLE MODE FORM */}
            {mode === "single" && (
              <>
                <div>
                  <label>Artifact Type</label>
                  <select
                    className="select-dark"
                    value={singleType}
                    onChange={(e) => setSingleType(e.target.value)}
                  >
                    <option value="code">Code Snippet</option>
                    <option value="uml">UML Diagram</option>
                    <option value="tests">Unit Tests</option>
                    <option value="requirements">Requirements</option>
                    <option value="txt">Plain Text</option>
                    <option value="report">Report</option>
                  </select>
                </div>

                <div>
                  <label>Title</label>
                  <input
                    type="text"
                    className="input-dark"
                    required
                    value={singleTitle}
                    onChange={(e) => setSingleTitle(e.target.value)}
                    placeholder="Artifact Title"
                  />
                </div>

                {renderSingleFields()}

                <div>
                  <label>Tags</label>
                  <input
                    type="text"
                    value={tagQuery}
                    onChange={handleTagSearchChange}
                    placeholder="Search tags..."
                    className="input-dark"
                  />

                  {selectedTags.length > 0 && (
                    <div className="filter-tag-chips">
                      {selectedTags.map((tag) => (
                        <span key={tag} className="tag-chip">
                          {tag}
                          <button
                            type="button"
                            onClick={() => handleRemoveTag(tag)}
                            className="tag-chip-remove"
                          >
                            ×
                          </button>
                        </span>
                      ))}
                    </div>
                  )}

                  {tagQuery.trim() !== "" && (
                    <div className="tag-dropdown-wrapper">
                      <div className="tag-dropdown">
                        {tagLoading && (
                          <div className="tag-dropdown-status">
                            Searching...
                          </div>
                        )}

                        {!tagLoading && tagResults.length === 0 && (
                          <div className="tag-dropdown-status">
                            No tags found.
                          </div>
                        )}

                        {!tagLoading &&
                          tagResults.map((tag) => (
                            <button
                              key={tag.id}
                              type="button"
                              onClick={() => handleAddTag(tag.name)}
                              className="tag-dropdown-item"
                            >
                              {tag.name}
                            </button>
                          ))}

                        {!tagLoading && tagHasMore && (
                          <button
                            type="button"
                            onClick={handleLoadMoreTags}
                            className="tag-dropdown-footer"
                          >
                            Load more...
                          </button>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </>
            )}

            {/* BULK MODE FORM */}
            {mode === "bulk" && (
              <>
                <div>
                  <label>Project Name</label>
                  <input
                    type="text"
                    className="input-dark"
                    required
                    value={bulkTitle}
                    onChange={(e) => setBulkTitle(e.target.value)}
                    placeholder="e.g. E-commerce API"
                  />
                </div>

                <div>
                  <label>Project Type</label>
                  <select
                    className="select-dark"
                    value={bulkType}
                    onChange={(e) => setBulkType(e.target.value)}
                  >
                    <option value="spring-boot">Spring Boot</option>
                    <option value="react">React</option>
                    <option value="python-script">Python Script</option>
                    <option value="generic">Generic Project</option>
                  </select>
                </div>

                <div>
                  <label>Tech Stack</label>
                  <input
                    type="text"
                    className="input-dark"
                    value={bulkStack}
                    onChange={(e) => setBulkStack(e.target.value)}
                    placeholder="e.g. Java 17, H2 Database, Lombok"
                  />
                </div>

                <div>
                  <label>Description / Requirements</label>
                  <textarea
                    className="input-dark"
                    rows={5}
                    required
                    value={bulkDescription}
                    onChange={(e) => setBulkDescription(e.target.value)}
                    placeholder="Describe the project structure and features..."
                  />
                </div>
              </>
            )}

            <div className="form-actions">
              <button
                type="submit"
                className={`btn btn-ai ${loading ? "" : ""}`}
                disabled={loading || jobStatus === "queued" || jobStatus === "processing"}
              >
                {loading
                  ? "Generating..."
                  : mode === "single"
                  ? "Generate Artifact"
                  : "Generate Project"}
              </button>
            </div>
          </form>

          {/* STATUS & PREVIEW */}
          {error && <div className="error" style={{ marginTop: 12 }}>{error}</div>}

          {jobStatus && (
            <div className="ai-job">
              <div className="ai-job-head">
                <div className="ai-status">
                  <strong>Status:</strong>{" "}
                  <span style={{ color: jobStatus === "succeeded" ? "var(--accent)" : "var(--text)" }}>
                    {jobStatus.toUpperCase()}
                  </span>
                </div>

                {jobStatus === "succeeded" && (
                  <button className="btn btn-sm btn-ai" onClick={handleSave} disabled={saving}>
                    {saving ? "Saving..." : "Save to Artifacts"}
                  </button>
                )}
              </div>

              {generatedPreview && (
                <div className="ai-preview">
                  <label>Preview ({generatedPreview.format})</label>
                  <pre>{generatedPreview.content}</pre>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </>
  );
}
