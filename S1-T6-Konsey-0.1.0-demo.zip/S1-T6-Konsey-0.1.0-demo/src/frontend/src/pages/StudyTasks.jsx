import React, { useEffect, useState, useContext, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import api from '../api';
import Navbar from '../components/Navbar';
import { AuthContext } from '../auth/AuthProvider';

// Helper component for displaying an individual Task card
const TaskCard = ({ task, onStart }) => {
    // 🎯 Use the dynamically calculated status field
    const isCompleted = task.status === 'completed'; 
    const isPending = task.status === 'pending'; // Changed from isOngoing
    
    // Define base and dynamic styles
    const statusStyle = isCompleted 
        ? { color: 'var(--accent)', borderColor: 'var(--accent)' } // Completed
        : { color: 'var(--text)', borderColor: 'rgba(255,255,255,0.06)' }; // Pending
    
    // Background based on status
    const cardBaseBackground = isCompleted ? 'rgba(110, 231, 183, 0.05)' : 'rgba(255,255,255,0.03)';
    
    // Hover effect properties
    const cardHoverStyle = {
        transform: "translateY(-2px)",
        boxShadow: "0 6px 12px rgba(0,0,0,0.3)",
        background: isCompleted ? 'rgba(110, 231, 183, 0.1)' : 'rgba(255,255,255,0.05)',
        borderColor: statusStyle.borderColor,
    };

    return (
        <div 
            onClick={() => isCompleted ? null : onStart(task.taskId)} 
            onMouseEnter={(e) => {
                if (isCompleted) return;
                e.currentTarget.style.transform = cardHoverStyle.transform;
                e.currentTarget.style.boxShadow = cardHoverStyle.boxShadow;
                e.currentTarget.style.background = cardHoverStyle.background;
                e.currentTarget.style.border = `1px solid ${statusStyle.borderColor}`;
            }}
            onMouseLeave={(e) => {
                if (isCompleted) return;
                e.currentTarget.style.transform = 'none';
                e.currentTarget.style.boxShadow = 'none';
                e.currentTarget.style.background = cardBaseBackground;
                e.currentTarget.style.border = `1px solid ${statusStyle.borderColor}`;
            }}
            style={{
                padding: '16px',
                marginTop: '12px',
                borderRadius: '8px',
                background: cardBaseBackground,
                border: `1px solid ${statusStyle.borderColor}`,
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                cursor: isCompleted ? 'default' : 'pointer',
                transition: 'all 0.2s ease',
                boxShadow: 'none',
            }}
        >
            <div style={{ flexGrow: 1 }}>
                {/* Task Name */}
                <div style={{ fontSize: '18px', fontWeight: 600, color: statusStyle.color }}>
                    {task.name}
                </div>
                {/* Task Status Text */}
                <div className="muted" style={{ fontSize: '12px', marginTop: '4px' }}>
                    {isCompleted ? 'Completed' : 'Click to Start'}
                </div>
            </div>

            {/* Status Indicator/Icon */}
            <div>
                {isCompleted ? (
                    <span className="success small" style={{ padding: '6px 10px', fontSize: '13px' }}>
                        ✅ Finished
                    </span>
                ) : (
                    <span style={{ fontSize: '13px', color: 'var(--muted)' }}>
                        ▶️ Start
                    </span>
                )}
            </div>
        </div>
    );
};


export default function StudyTasks() {
    const { studyId } = useParams();
    const { user } = useContext(AuthContext);
    const [tasks, setTasks] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const navigate = useNavigate();

    // 1. Fetch Study Details and Tasks
    useEffect(() => {
        const fetchStudyData = async () => {
            setLoading(true);
            try {
                // 1. Get ALL tasks for the study
                const tasksRes = await api.get(`/api/studies/${studyId}/tasks`);
                const tasksList = tasksRes.data;

                // 2. Get UNFINISHED tasks for the participant
                const participantsUnfinishedRes = await api.get(`/api/studies/${studyId}/tasks/unfinished/${user.id}`);
                
                // 3. Extract the IDs of unfinished tasks (using t.taskId as confirmed)
                const unfinishedTaskIds = new Set(participantsUnfinishedRes.data.map(t => t.taskId));
                
                // 4. Map tasks to include status
                const tasksWithStatus = tasksList.map(task => ({
                    ...task,
                    // If the task.id (from the main tasks list) is present in the unfinished set, it's pending.
                    // Otherwise, it is assumed completed.
                    status: unfinishedTaskIds.has(task.taskId) ? 'pending' : 'completed', 
                }));

                setTasks(tasksWithStatus);
                
            } catch (err) {
                console.error("Failed to load study tasks:", err);
                setError("Could not load tasks for this study.");
            } finally {
                setLoading(false);
            }
        };

        if (studyId && user?.id) {
            fetchStudyData();
        }
    }, [studyId, user?.id]);

    // 2. Calculate Progress (Memoized for efficiency)
    const { totalTasks, completedTasks, progressPercentage } = useMemo(() => {
        const total = tasks.length;
        const completed = tasks.filter(t => t.status === 'completed').length;
        const percentage = total > 0 ? Math.round((completed / total) * 100) : 0;
        return { totalTasks: total, completedTasks: completed, progressPercentage: percentage };
    }, [tasks]);


    // 3. Handle Task Start/Navigation
    const handleStartTask = (taskId) => {
        // Navigate to the task-specific form/interface
        navigate(`/${studyId}/tasks/${taskId}`);
    };
    
    // --- Render Content ---
    
    // ... (rest of the render logic remains the same)

    if (!user) return <p className="error">Please log in to view tasks.</p>;

    if (loading) {
        return (
            <>
                <Navbar />
                <div style={{ padding: 24, maxWidth: 800, margin: "0 auto" }}>
                    <div className="muted" style={{ marginTop: '50px' }}>Loading study tasks...</div>
                </div>
            </>
        );
    }

    if (error) {
        return (
            <>
                <Navbar />
                <div style={{ padding: 24, maxWidth: 800, margin: "0 auto" }}>
                    <div className="error" style={{ marginTop: '50px' }}>{error}</div>
                </div>
            </>
        );
    }

    return (
        <div style={{ minHeight: "100vh" }}>
            <Navbar />

            <div style={{ padding: 24, maxWidth: 800, margin: "0 auto" }}>
                <h2 style={{ marginBottom: '24px' }}>
                    Tasks for Study <strong style={{color: 'var(--accent)'}}>{studyId}</strong>
                </h2>

                {/* Progress Bar Display */}
                <div className="dashboard-block" style={{ padding: '20px', marginBottom: '30px', border: '1px solid rgba(110,231,183,0.3)' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <h3 style={{ margin: 0, fontSize: '16px' }}>
                            Your Progress
                        </h3>
                        <span style={{ fontSize: '18px', fontWeight: 700, color: 'var(--accent)' }}>
                            {progressPercentage}%
                        </span>
                    </div>

                    <div style={{ 
                        height: '10px', 
                        width: '100%', 
                        background: 'rgba(255,255,255,0.1)', 
                        borderRadius: '5px', 
                        marginTop: '12px',
                        overflow: 'hidden',
                    }}>
                        <div style={{ 
                            width: `${progressPercentage}%`, 
                            height: '100%', 
                            background: 'linear-gradient(90deg, #2dd4bf, #06b6d4)', 
                            transition: 'width 0.5s ease',
                        }}></div>
                    </div>

                    <div className="muted" style={{ marginTop: '10px', fontSize: '13px' }}>
                        {completedTasks} of {totalTasks} tasks completed.
                    </div>
                </div>

                {/* Task List */}
                <h3 style={{ margin: '30px 0 10px 0', fontSize: '18px', color: 'var(--text)' }}>
                    Task List
                </h3>

                {tasks.length === 0 ? (
                    <div className="muted">No tasks defined for this study yet.</div>
                ) : (
                    tasks.map((task) => (
                        <TaskCard 
                            key={task.taskId} 
                            task={task} 
                            onStart={handleStartTask} 
                        />
                    ))
                )}
            </div>
        </div>
    );
}