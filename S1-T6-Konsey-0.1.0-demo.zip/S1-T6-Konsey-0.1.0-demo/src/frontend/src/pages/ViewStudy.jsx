import React, { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import Navbar from "../components/Navbar";
import api from "../api";

function formatDateGB(value) {
  if (!value) return "N/A";
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return String(value);
  return d.toLocaleDateString("en-GB"); // dd/MM/yyyy
}

export default function ViewStudy() {
  const { studyId } = useParams();
  const navigate = useNavigate();

  const [study, setStudy] = useState(null);
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        setError("");

        const studyRes = await api.get(`/api/studies/${studyId}`);
        setStudy(studyRes.data);

        const tasksRes = await api.get(`/api/studies/${studyId}/tasks`);
        setTasks(tasksRes.data || []);
      } catch (e) {
        console.error("Failed to load study", e);
        setError("Failed to load study. Please try again later.");
      } finally {
        setLoading(false);
      }
    };

    if (studyId) fetchData();
  }, [studyId]);

  const statusClass = useMemo(() => {
    const s = String(study?.status || "").toUpperCase();
    if (s === "ACTIVE") return "vs-badge vs-badge--active";
    return "vs-badge vs-badge--neutral";
  }, [study]);

  const goBack = () => navigate("/Studies");
  const viewTask = (taskId) => navigate(`/study/${studyId}/task/${taskId}/viewtask`);

  return (
    <>
      <Navbar />

      <div className="page view-study">
        <header className="page-header">
          <div>
            <h2 className="page-title">Study Overview</h2>
            <p className="page-subtitle">
              {study ? study.title : "View study details and tasks."}
            </p>
          </div>

          <button className="btn small btn-ghost" onClick={goBack}>
            ← Back to Studies
          </button>
        </header>

        {loading && <div className="muted">Loading study…</div>}
        {!loading && error && <div className="error">{error}</div>}
        {!loading && !error && !study && <div className="muted">Study not found.</div>}

        {!loading && !error && study && (
          <div className="vs-layout">
            {/* Left: details */}
            <section className="vs-panel">
              <div className="vs-panel-header">
                <h3 className="vs-panel-title">Details</h3>
                <span className={statusClass}>{study.status || "N/A"}</span>
              </div>

              <div className="vs-meta">
                <div className="vs-kv">
                  <div className="vs-k">Title</div>
                  <div className="vs-v vs-v--wrap">{study.title || "N/A"}</div>
                </div>

                <div className="vs-kv">
                  <div className="vs-k">Start Date</div>
                  <div className="vs-v">{formatDateGB(study.startDate)}</div>
                </div>

                <div className="vs-kv">
                  <div className="vs-k">End Date</div>
                  <div className="vs-v">{formatDateGB(study.endDate)}</div>
                </div>
              </div>

              <div style={{ marginTop: 14 }}>
                <div className="vs-k">Description</div>
                <div className="vs-v vs-v--wrap">{study.description || "No description."}</div>
              </div>
            </section>

            {/* Right: tasks */}
            <section className="vs-panel">
              <div className="vs-panel-header">
                <h3 className="vs-panel-title">Tasks</h3>
                <span className="muted">{tasks.length} task(s)</span>
              </div>

              {tasks.length === 0 ? (
                <div className="muted">No tasks found for this study.</div>
              ) : (
                <div className="vs-task-list">
                  {tasks.map((t) => (
                    <div className="vs-task-row" key={t.taskId}>
                      <div className="vs-task-main">
                        <h4 className="vs-task-title">{t.name || "Unnamed Task"}</h4>

                        <div className="vs-task-meta">
                          <span>View: {t.viewType || "N/A"}</span>
                          <span>Blinded: {t.isBlinded ? "Yes" : "No"}</span>
                          <span>
                            Criteria: {Array.isArray(t.criteria) ? t.criteria.length : 0}
                          </span>
                        </div>

                        <div className="vs-task-desc">
                          {t.instructions || "No instructions."}
                        </div>
                      </div>

                      <button className="btn btn-sm" onClick={() => viewTask(t.taskId)}>
                        View Task
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </section>
          </div>
        )}
      </div>
    </>
  );
}
