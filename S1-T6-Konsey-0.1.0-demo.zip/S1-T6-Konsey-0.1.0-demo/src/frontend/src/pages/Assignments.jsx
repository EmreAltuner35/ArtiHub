import Navbar from "../components/Navbar";
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../api";

// Helper function to format the date string
const formatDate = (dateString) => {
    if (!dateString) return "No end date specified";
    try {
        return new Date(dateString).toLocaleDateString();
    } catch {
        return dateString; // Fallback if date is invalid
    }
};

export default function Assignments() {

  const [continuing, setContinuing] = useState([]);
  const [past, setPast] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate(); //  Initialize useNavigate

  useEffect(() => {
    const load = async () => {
      try {
        const res = await api.get("/api/studies/enrolled");

        const today = new Date();
        // Set hours/minutes/seconds to 0 for accurate date comparison
        today.setHours(0, 0, 0, 0);

        const ongoing = [];
        const completed = [];

        res.data.forEach((s) => {
          const end = s.endDate ? new Date(s.endDate) : null;

          // Check if study is ongoing (no end date or end date is today or later)
          if (!end || end >= today) ongoing.push(s);
          else completed.push(s);
        });

        setContinuing(ongoing);
        setPast(completed);
      } catch (e) {
        console.error("Failed to load studies", e);
      }

      setLoading(false);
    };

    load();
  }, []);

  if (loading) return <div className="muted">Loading studies...</div>;

  //  Define base styles and hover styles outside the map function for cleanliness and performance
  const studyCardBaseStyle = {
    padding: "12px 14px",
    marginTop: 10,
    borderRadius: 8,
    cursor: "pointer", // Make it look clickable
    transition: "all 0.2s ease",
    boxShadow: "0 2px 4px rgba(0,0,0,0.1)",
  };

  const studyCardHoverStyle = {
    transform: "translateY(-2px)",
    boxShadow: "0 6px 12px rgba(0,0,0,0.3)",
    background: "rgba(255,255,255,0.05)", // Slight bump in background color
    borderColor: "var(--accent)", // Highlight border on hover
  };

  // Function to handle click navigation
  const handleStudyClick = (studyId) => {
    navigate(`/${studyId}/tasks`);
  };
  return (
    <>
      <Navbar />
      <div style={{ padding: 24 }}>
        <div style={{ marginTop: 10 }}>

      <h2>Assignments</h2>
      {/* CONTINUING STUDIES */}
      <div className="dashboard-block">
        <h3 style={{ margin: "0 0 10px", fontSize: 18, color: "var(--accent)" }}>
           Continuing Studies
        </h3>

        {continuing.length === 0 && (
          <div className="muted">No active or ongoing studies.</div>
        )}

        {continuing.map((s) => (
          <div
            key={s.studyId}
            onClick={() => handleStudyClick(s.studyId)} //  Add click handler
            // Use inline style for dynamic hover effects
            onMouseEnter={(e) => {
                e.currentTarget.style.transform = studyCardHoverStyle.transform;
                e.currentTarget.style.boxShadow = studyCardHoverStyle.boxShadow;
                e.currentTarget.style.background = studyCardHoverStyle.background;
                e.currentTarget.style.borderColor = "var(--accent)";
            }}
            onMouseLeave={(e) => {
                e.currentTarget.style.transform = "none";
                e.currentTarget.style.boxShadow = studyCardBaseStyle.boxShadow;
                e.currentTarget.style.background = "rgba(255,255,255,0.03)";
                e.currentTarget.style.borderColor = "rgba(255,255,255,0.04)";
            }}
            style={{
              ...studyCardBaseStyle,
              background: "rgba(255,255,255,0.03)",
              border: "1px solid rgba(255,255,255,0.04)",
            }}
          >
            <div style={{ fontSize: 20, fontWeight: 700 }}>{s.title}</div>
            <div className="muted" style={{ marginTop: 4 }}>
              Ends on: <strong>{formatDate(s.endDate)}</strong>
            </div>
          </div>
        ))}
      </div>

      {/* PAST STUDIES */}
      <div className="dashboard-block" style={{ marginTop: 20 }}>
        <h3 style={{ margin: "0 0 10px", fontSize: 18, color: "var(--muted)" }}>
           Past Studies
        </h3>

        {past.length === 0 && (
          <div className="muted">No past studies found.</div>
        )}

        {past.map((s) => (
          <div
            key={s.studyId}
            onClick={() => handleStudyClick(s.studyId)} //  Add click handler
            // Use inline style for dynamic hover effects
            onMouseEnter={(e) => {
                e.currentTarget.style.transform = studyCardHoverStyle.transform;
                e.currentTarget.style.boxShadow = studyCardHoverStyle.boxShadow;
                e.currentTarget.style.background = studyCardHoverStyle.background;
                e.currentTarget.style.borderColor = "var(--muted)";
            }}
            onMouseLeave={(e) => {
                e.currentTarget.style.transform = "none";
                e.currentTarget.style.boxShadow = studyCardBaseStyle.boxShadow;
                e.currentTarget.style.background = "rgba(255,255,255,0.02)";
                e.currentTarget.style.borderColor = "rgba(255,255,255,0.03)";
            }}
            style={{
              ...studyCardBaseStyle,
              background: "rgba(255,255,255,0.02)",
              border: "1px solid rgba(255,255,255,0.03)",
            }}
          >
            <div style={{ fontSize: 20, fontWeight: 700 }}>{s.title}</div>
            <div className="muted" style={{ marginTop: 4 }}>
              Ended: <strong>{formatDate(s.endDate)}</strong>
            </div>
          </div>
        ))}
      </div>
    </div>
      </div>
    </>
  );
}