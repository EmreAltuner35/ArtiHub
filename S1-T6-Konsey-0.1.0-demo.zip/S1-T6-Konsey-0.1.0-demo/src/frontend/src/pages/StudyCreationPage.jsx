import React, { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "../components/Navbar";
import api from "../api";

import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";

export default function StudyCreationPage() {
  const navigate = useNavigate();

  const today = useMemo(() => {
    const d = new Date();
    d.setHours(0, 0, 0, 0);
    return d;
  }, []);

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [startDate, setStartDate] = useState(today);
  const [endDate, setEndDate] = useState(today);

  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  // bulk task creation
  const [bulkMode, setBulkMode] = useState(false);
  const [csvFile, setCsvFile] = useState(null);
  const [csvHover, setCsvHover] = useState(false);

  // folder selection
  const [folderQuery, setFolderQuery] = useState("");
  const [folderResults, setFolderResults] = useState([]);
  const [folderLoading, setFolderLoading] = useState(false);
  const [selectedFolder, setSelectedFolder] = useState(null); // { id, name }

  const resetBulk = () => {
    setCsvFile(null);
    setSelectedFolder(null);
    setFolderQuery("");
    setFolderResults([]);
  };

  const handleSearchFolders = async (q) => {
    const trimmed = q.trim();
    if (!trimmed) {
      setFolderResults([]);
      return;
    }
    try {
      setFolderLoading(true);
      const res = await api.get("/api/artifacts/folders", {
        params: { q: trimmed, page: 0, size: 10 },
      });
      setFolderResults(res.data?.content || []);
    } catch (e) {
      console.error("Failed to search folders", e);
    } finally {
      setFolderLoading(false);
    }
  };

  const handleFolderInputChange = (e) => {
    const value = e.target.value;
    setFolderQuery(value);
    setSelectedFolder(null);
    handleSearchFolders(value);
  };

  const handleSelectFolder = (folder) => {
    setSelectedFolder({ id: folder.id, name: folder.name });
    setFolderQuery(folder.name);
    setFolderResults([]);
  };

  const handleDropCsv = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setCsvHover(false);

    const file = e.dataTransfer.files?.[0];
    if (file) setCsvFile(file);
  };

  const handleBrowseCsv = (e) => {
    const file = e.target.files?.[0];
    if (file) setCsvFile(file);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    if (!title.trim() || !description.trim()) {
      setError("Title and Description cannot be empty.");
      return;
    }
    if (startDate < today) {
      setError("Start date cannot be before today.");
      return;
    }
    if (endDate <= startDate) {
      setError("End date must be after start date.");
      return;
    }

    if (bulkMode) {
      if (!selectedFolder?.id) {
        setError("Please select a folder for artifacts.");
        return;
      }
      if (!csvFile) {
        setError("Please provide a CSV file for bulk task creation.");
        return;
      }
    }

    setIsLoading(true);
    try {
      if (!bulkMode) {
        await api.post("/api/studies", {
          title: title.trim(),
          description: description.trim(),
          startDate: startDate.toISOString(),
          endDate: endDate.toISOString(),
        });
        setSuccess("Study created successfully!");
      } else {
        const meta = {
          title: title.trim(),
          description: description.trim(),
          startDate: startDate.toISOString(),
          endDate: endDate.toISOString(),
          artifactFolder: selectedFolder.id,
        };

        const formData = new FormData();
        formData.append("file", csvFile);
        formData.append("meta", JSON.stringify(meta));

        await api.post("/api/studies/bulk", formData, {
          headers: { "Content-Type": "multipart/form-data" },
        });

        setSuccess("Study created and tasks imported from CSV successfully.");
      }

      setTitle("");
      setDescription("");
      setStartDate(today);
      setEndDate(today);
      setBulkMode(false);
      resetBulk();

      setTimeout(() => navigate("/studies"), 900);
    } catch (err) {
      const backendMsg =
        err.response?.data?.message ||
        err.response?.data ||
        err.message ||
        "An error occurred while creating the study.";
      setError(backendMsg);
    } finally {
      setIsLoading(false);
    }
  };

  const showFolderMenu =
    bulkMode && folderQuery.trim().length > 0 && folderResults.length > 0;

  return (
    <>
      <Navbar />

      <div className="page">
        <header className="page-header">
          <div>
            <h2 className="page-title">Create Study</h2>
            <p className="page-subtitle">
              Create a study and optionally import tasks from a CSV.
            </p>
          </div>

          <button
            type="button"
            className="btn btn-secondary btn-sm"
            onClick={() => navigate("/studies")}
          >
            ← Back
          </button>
        </header>

        <div className="study-create-layout">
          {/* Main form card */}
          <div className="study-create-card">
            <form className="study-create-form" onSubmit={handleSubmit}>
              {error && <div className="error">{error}</div>}
              {success && <div className="success">{success}</div>}

              <div className="form-group">
                <label>Study Title</label>
                <input
                  type="text"
                  className="input-dark"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Enter a study title..."
                  disabled={isLoading}
                  required
                />
              </div>

              <div className="form-group">
                <label>Study Description</label>
                <textarea
                  className="textarea-dark"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Provide a brief summary of the study's goals and methods."
                  disabled={isLoading}
                  required
                />
              </div>

              <div className="study-create-grid-2">
                <div className="form-group">
                  <label>Start Date</label>
                  <DatePicker
                    selected={startDate}
                    onChange={(date) => {
                      if (!date) return;
                      setStartDate(date);
                      if (date > endDate) setEndDate(date);
                    }}
                    minDate={today}
                    dateFormat="dd/MM/yyyy"
                    className="datepicker-dark"
                    disabled={isLoading}
                  />
                </div>

                <div className="form-group">
                  <label>End Date</label>
                  <DatePicker
                    selected={endDate}
                    onChange={(date) => {
                      if (!date) return;
                      setEndDate(date);
                    }}
                    minDate={startDate}
                    dateFormat="dd/MM/yyyy"
                    className="datepicker-dark"
                    disabled={isLoading}
                  />
                </div>
              </div>

              <div className="panel">
                <div className="switch-row">
                  <div>
                    <div className="panel-title">Bulk task creation from CSV</div>
                    <div className="panel-sub">
                      Upload a CSV and auto-generate tasks using artifacts from a folder.
                    </div>
                  </div>

                  <label className="switch switch--sm">
                    <input
                      type="checkbox"
                      checked={bulkMode}
                      onChange={(e) => {
                        const enabled = e.target.checked;
                        setBulkMode(enabled);
                        if (!enabled) resetBulk();
                      }}
                      disabled={isLoading}
                    />
                    <span className="switch-thumb" />
                  </label>
                </div>

                {bulkMode && (
                  <div className="study-create-bulk">
                    <div className="menu-anchor">
                      <label>Artifact folder</label>
                      <input
                        type="text"
                        className="input-dark"
                        value={folderQuery}
                        onChange={handleFolderInputChange}
                        placeholder="Search folders by name..."
                        disabled={isLoading}
                      />

                      {folderLoading && (
                        <div className="helper-text">Loading folders…</div>
                      )}

                      {showFolderMenu && (
                        <div className="menu">
                          {folderResults.map((f) => (
                            <button
                              key={f.id}
                              type="button"
                              className="menu-item"
                              onClick={() => handleSelectFolder(f)}
                            >
                              {f.name}
                            </button>
                          ))}
                        </div>
                      )}
                    </div>

                    {selectedFolder && (
                      <div className="chip-row">
                        <span className="chip">
                          Selected: <strong>{selectedFolder.name}</strong>
                        </span>
                        <button
                          type="button"
                          className="btn-link"
                          onClick={() => {
                            setSelectedFolder(null);
                            setFolderQuery("");
                            setFolderResults([]);
                          }}
                          disabled={isLoading}
                        >
                          Clear
                        </button>
                      </div>
                    )}

                    <div className="form-group">
                      <label>Tasks CSV</label>

                      <div
                        className={
                          "file-dropzone" + (csvHover ? " file-dropzone--hover" : "")
                        }
                        onDrop={handleDropCsv}
                        onDragOver={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          setCsvHover(true);
                        }}
                        onDragLeave={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          setCsvHover(false);
                        }}
                        onClick={() => {
                          const input = document.getElementById("study-bulk-csv-input");
                          if (input) input.click();
                        }}
                        role="button"
                        tabIndex={0}
                      >
                        <div className="file-dropzone-title">
                          {csvFile ? (
                            <>
                              Selected file: <strong>{csvFile.name}</strong>
                            </>
                          ) : (
                            <>Drag and drop a CSV file here</>
                          )}
                        </div>
                        <div className="file-dropzone-sub">
                          {csvFile ? "Click to replace." : "Or click to browse."}
                        </div>
                      </div>

                      <input
                        id="study-bulk-csv-input"
                        type="file"
                        accept=".csv,text/csv"
                        className="hidden-input"
                        onChange={handleBrowseCsv}
                        disabled={isLoading}
                      />

                      <div className="helper-text">
                        The CSV should follow the agreed structure (tasks, criteria, options).
                      </div>
                    </div>
                  </div>
                )}
              </div>

              <div className="study-create-actions">
                <button
                  type="submit"
                  className="btn btn--no-mt"
                  disabled={isLoading}
                >
                  {isLoading ? "Creating..." : "Create Study"}
                </button>
              </div>
            </form>
          </div>

          {/* Right side: small help card (like UploadArtifact’s side info) */}
          <aside className="study-create-side">
            <div className="card">
              <h3 style={{ marginTop: 0 }}>Tips</h3>
              <div className="muted" style={{ fontSize: 13, lineHeight: 1.5 }}>
                Use a clear title and description. If you enable bulk creation, pick an
                artifact folder and upload a CSV that follows your agreed format.
              </div>
            </div>
          </aside>
        </div>
      </div>
    </>
  );
}
