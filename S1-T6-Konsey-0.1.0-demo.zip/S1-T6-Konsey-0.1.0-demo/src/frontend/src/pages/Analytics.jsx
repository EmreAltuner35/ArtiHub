// src/pages/Analytics.jsx
import React, { useEffect, useMemo, useState } from "react";
import Navbar from "../components/Navbar";
import api from "../api";
import { useNavigate } from "react-router-dom";

import { ResponsiveContainer, PieChart, Pie, Cell, Tooltip, Legend } from "recharts";

const formatDateGB = (value) => {
  if (!value) return "N/A";
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return String(value);
  return d.toLocaleDateString("en-GB"); // dd/MM/yyyy
};

const pillClassForStudy = (status) => {
  const s = String(status || "").toUpperCase();
  if (s === "ACTIVE") return "status-pill status-pill--active";
  if (s === "DRAFT") return "status-pill status-pill--draft";
  if (s === "COMPLETED") return "status-pill status-pill--completed";
  return "status-pill";
};

export default function Analytics() {
  const navigate = useNavigate();

  const [studies, setStudies] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState("");

  const fetchStudies = async () => {
    try {
      setIsLoading(true);
      setError("");
      const res = await api.get(`/api/studies/mine`);
      setStudies(res.data || []);
    } catch (e) {
      console.error("Failed to fetch studies:", e);
      setError("Failed to load studies. Please try again later.");
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchStudies();
  }, []);

  const counts = useMemo(() => {
    let draft = 0;
    let active = 0;
    let completed = 0;

    for (const s of studies) {
      const st = String(s.status || "").toUpperCase();
      if (st === "DRAFT") draft++;
      else if (st === "ACTIVE") active++;
      else if (st === "COMPLETED") completed++;
    }

    return { draft, active, completed, total: studies.length };
  }, [studies]);

  const statusPieData = useMemo(() => {
    return [
      { name: "Active", value: counts.active, key: "ACTIVE" },
      { name: "Draft", value: counts.draft, key: "DRAFT" },
      { name: "Completed", value: counts.completed, key: "COMPLETED" },
    ].filter((x) => x.value > 0);
  }, [counts]);

  // Keep colors stable (not random). If you prefer different colors, tell me your palette.
  const pieColors = useMemo(
    () => ({
      ACTIVE: "#10b981",
      DRAFT: "#f59e0b",
      COMPLETED: "#a5b4fc",
    }),
    []
  );

  const visibleStudies = useMemo(
    () => studies.filter((s) => String(s.status || "").toUpperCase() !== "DRAFT"),
    [studies]
  );

  return (
    <>
      <Navbar />

      <div className="page analytics">
        <header className="page-header analytics-topbar">
          <div>
            <h2 className="page-title">Analytics</h2>
            <p className="page-subtitle">
              View analytics for your studies.
            </p>
          </div>

          <div className="analytics-actions">
            <button className="btn btn-sm" onClick={fetchStudies} disabled={isLoading}>
              Refresh
            </button>
          </div>
        </header>

        {isLoading && <div className="muted">Loading studies…</div>}
        {error && <div className="error">{error}</div>}

        {/* Big centered pie chart */}
        {!isLoading && !error && counts.total > 0 && (
          <div className="analytics-hero">
            <div className="card chart-card analytics-hero-card">
              <div className="chart-title-row">
                <h3 className="chart-title">Study Status Distribution</h3>
                <span className="muted">{counts.total} total</span>
              </div>

              {statusPieData.length === 0 ? (
                <div className="chart-empty">No data.</div>
              ) : (
                <div className="analytics-hero-wrap">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={statusPieData}
                        dataKey="value"
                        nameKey="name"
                        cx="50%"
                        cy="50%"
                        innerRadius={90}
                        outerRadius={140}
                        paddingAngle={4}
                        labelLine={false}
                      >
                        {statusPieData.map((entry) => (
                          <Cell
                            key={entry.key}
                            fill={pieColors[entry.key] || "#6b7280"}
                            stroke={pieColors[entry.key] || "#6b7280"}
                          />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Study cards in 3-column grid */}
        {!isLoading && !error && (
          <div className="analytics-studies-grid-3">
            {visibleStudies.length === 0 ? (
              <div className="muted">No active/completed studies found.</div>
            ) : (
              visibleStudies.map((study) => (
                <div key={study.studyId} className="card analytics-item">
                  <div className="analytics-item-main">
                    <h3 className="analytics-item-title" title={study.title || ""}>
                      {study.title || "Untitled Study"}{" "}
                      <span className={pillClassForStudy(study.status)}>{study.status}</span>
                    </h3>

                    <div className="analytics-item-sub">
                      {study.description
                        ? `${study.description.slice(0, 120)}${
                            study.description.length > 120 ? "…" : ""
                          }`
                        : "No description provided."}

                      <div className="muted" style={{ marginTop: 6 }}>
                        Dates: {formatDateGB(study.startDate)} – {formatDateGB(study.endDate)}
                      </div>
                    </div>
                  </div>

                  <button
                    className="btn btn-sm"
                    onClick={() => navigate(`/analytics/${study.studyId}`)}
                  >
                    View Analytics
                  </button>
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </>
  );
}
