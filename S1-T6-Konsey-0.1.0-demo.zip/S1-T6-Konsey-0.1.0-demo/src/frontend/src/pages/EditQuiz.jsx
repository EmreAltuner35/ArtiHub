import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import Navbar from "../components/Navbar";
import api from "../api";

export default function EditQuiz() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [studyId, setStudyId] = useState("");
  const [timeLimitMinutes, setTimeLimitMinutes] = useState("");
  const [timeLimitSeconds, setTimeLimitSeconds] = useState("");
  const [status, setStatus] = useState("DRAFT");
  const [questions, setQuestions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [fetching, setFetching] = useState(true);
  const [studyIdError, setStudyIdError] = useState("");

  // UUID validation function
  const isValidUUID = (str) => {
    if (!str || str.trim() === "") return true; // Empty is valid (optional field)
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
    return uuidRegex.test(str.trim());
  };

  const handleStudyIdChange = (e) => {
    const value = e.target.value;
    setStudyId(value);
    if (value.trim() && !isValidUUID(value)) {
      setStudyIdError("Please enter a valid UUID format (e.g., 123e4567-e89b-12d3-a456-426614174000)");
    } else {
      setStudyIdError("");
    }
  };

  useEffect(() => {
    fetchQuiz();
  }, [id]);

  const fetchQuiz = async () => {
    try {
      setFetching(true);
      const response = await api.get(`/api/quizzes/${id}`);
      const quiz = response.data;
      setTitle(quiz.title || "");
      setDescription(quiz.description || "");
      setStudyId(quiz.studyId ? String(quiz.studyId) : "");
      setStatus(quiz.status || "DRAFT");

      if (quiz.timeLimit) {
        const mins = Math.floor(quiz.timeLimit / 60);
        const secs = quiz.timeLimit % 60;
        setTimeLimitMinutes(String(mins));
        setTimeLimitSeconds(String(secs));
      } else {
        setTimeLimitMinutes("");
        setTimeLimitSeconds("");
      }

      // Load questions and ensure TEXT questions have empty answers
      const loadedQuestions = (quiz.questions || []).map(q => {
        if (q.questionType === "TEXT") {
          return {
            ...q,
            answers: [] // TEXT questions should have no answers
          };
        }
        return q;
      });
      setQuestions(loadedQuestions);
      setStudyIdError(""); // Clear any previous errors
    } catch (err) {
      console.error("Failed to fetch quiz:", err);
      alert("Failed to load quiz. Please try again.");
      navigate("/quizzes");
    } finally {
      setFetching(false);
    }
  };

  const addQuestion = () => {
    setQuestions([
      ...questions,
      {
        questionText: "",
        questionType: "SINGLE_CHOICE",
        questionOrder: questions.length + 1,
        answers: [
          { answerText: "", isCorrect: false, answerOrder: 1 },
          { answerText: "", isCorrect: false, answerOrder: 2 },
        ],
      },
    ]);
  };

  const removeQuestion = (index) => {
    if (questions.length === 1) {
      alert("A quiz must have at least one question");
      return;
    }
    const updated = questions.filter((_, i) => i !== index);
    updated.forEach((q, i) => {
      q.questionOrder = i + 1;
    });
    setQuestions(updated);
  };

  const updateQuestion = (index, field, value) => {
    const updated = [...questions];
    updated[index][field] = value;
    setQuestions(updated);
  };

  const addAnswer = (questionIndex) => {
    const updated = [...questions];
    const question = updated[questionIndex];
    question.answers.push({
      answerText: "",
      isCorrect: false,
      answerOrder: question.answers.length + 1,
    });
    setQuestions(updated);
  };

  const removeAnswer = (questionIndex, answerIndex) => {
    const updated = [...questions];
    const question = updated[questionIndex];
    if (question.answers.length === 2) {
      alert("A question must have at least 2 answers");
      return;
    }
    question.answers = question.answers.filter((_, i) => i !== answerIndex);
    question.answers.forEach((a, i) => {
      a.answerOrder = i + 1;
    });
    setQuestions(updated);
  };

  const updateAnswer = (questionIndex, answerIndex, field, value) => {
    const updated = [...questions];
    const question = updated[questionIndex];
    const answer = question.answers[answerIndex];
    answer[field] = value;

    if (field === "isCorrect" && value && question.questionType === "SINGLE_CHOICE") {
      question.answers.forEach((a, i) => {
        if (i !== answerIndex) {
          a.isCorrect = false;
        }
      });
    }

    setQuestions(updated);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    if (!title.trim()) {
      alert("Please enter a quiz title");
      setLoading(false);
      return;
    }

    // Validate studyId if provided
    if (studyId.trim() && !isValidUUID(studyId)) {
      alert("Please enter a valid UUID for Study ID or leave it empty");
      setLoading(false);
      return;
    }

    for (let i = 0; i < questions.length; i++) {
      const q = questions[i];
      if (!q.questionText.trim()) {
        alert(`Please enter text for question ${i + 1}`);
        setLoading(false);
        return;
      }

      // TEXT questions don't need answers
      if (q.questionType === "TEXT") {
        // Ensure answers array is empty for TEXT questions
        q.answers = [];
        continue;
      }

      // For SINGLE_CHOICE and MULTIPLE_CHOICE, validate answers
      if (q.answers.length < 2) {
        alert(`Question ${i + 1} must have at least 2 answers`);
        setLoading(false);
        return;
      }
      for (let j = 0; j < q.answers.length; j++) {
        if (!q.answers[j].answerText.trim()) {
          alert(`Please enter text for answer ${j + 1} in question ${i + 1}`);
          setLoading(false);
          return;
        }
      }
      // Check if at least one answer is correct
      if (!q.answers.some((a) => a.isCorrect)) {
        alert(`Question ${i + 1} must have at least one correct answer`);
        setLoading(false);
        return;
      }
    }

    try {
      // Prepare studyId - only include if it's a valid UUID
      let parsedStudyId = null;
      if (studyId.trim()) {
        if (isValidUUID(studyId)) {
          parsedStudyId = studyId.trim();
        } else {
          alert("Please enter a valid UUID for Study ID or leave it empty");
          setLoading(false);
          return;
        }
      }

      // Prepare questions - ensure TEXT questions have empty answers array
      const preparedQuestions = questions.map(q => {
        if (q.questionType === "TEXT") {
          return {
            ...q,
            answers: [] // TEXT questions should have no answers
          };
        }
        return q;
      });

      // Calculate time limit in seconds
      let calculatedTimeLimit = null;
      const mins = parseInt(timeLimitMinutes) || 0;
      const secs = parseInt(timeLimitSeconds) || 0;
      if (mins > 0 || secs > 0) {
        calculatedTimeLimit = (mins * 60) + secs;
      }

      const payload = {
        title: title.trim(),
        description: description.trim() || null,
        studyId: parsedStudyId,
        timeLimit: calculatedTimeLimit,
        status: status,
        questions: preparedQuestions,
      };

      await api.put(`/api/quizzes/${id}`, payload);
      alert("Quiz updated successfully!");
      navigate(`/quizzes/${id}`);
    } catch (err) {
      console.error("Failed to update quiz:", err);
      alert(err.response?.data?.error || "Failed to update quiz. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  if (fetching) {
    return (
      <>
        <Navbar />
        <div style={{ padding: 24 }}>
          <div className="muted">Loading quiz...</div>
        </div>
      </>
    );
  }

  return (
    <>
      <Navbar />
      <div style={{ padding: 24, maxWidth: 1000, margin: "0 auto" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24 }}>
          <h2>Edit Quiz</h2>
          <button onClick={() => navigate(`/quizzes/${id}`)} className="btn small">
            Back to Quiz
          </button>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="card" style={{ marginBottom: 24 }}>
            <h3>Quiz Information</h3>
            <div style={{ marginBottom: 16 }}>
              <label>
                Title <span style={{ color: "var(--danger)" }}>*</span>
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Enter quiz title"
                required
                style={{ width: "100%", padding: 8, marginTop: 4 }}
              />
            </div>
            <div style={{ marginBottom: 16 }}>
              <label>Description</label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Enter quiz description (optional)"
                rows={3}
                style={{
                  width: "100%",
                  padding: 8,
                  marginTop: 4,
                  resize: "vertical",
                  color: "var(--text)",
                  backgroundColor: "var(--glass)",
                  border: "1px solid rgba(255,255,255,0.03)",
                  borderRadius: "8px",
                  outline: "none"
                }}
              />
            </div>
            <div style={{ marginBottom: 16 }}>
              <label>Study ID (optional)</label>
              <input
                type="text"
                value={studyId}
                onChange={handleStudyIdChange}
                placeholder="Enter study ID (UUID format, e.g., 123e4567-e89b-12d3-a456-426614174000)"
                style={{
                  width: "100%",
                  padding: 8,
                  marginTop: 4,
                  borderColor: studyIdError ? "var(--danger)" : undefined
                }}
              />
              {studyIdError && (
                <div style={{ color: "var(--danger)", fontSize: 12, marginTop: 4 }}>
                  {studyIdError}
                </div>
              )}
              <div style={{ fontSize: 12, color: "var(--text-secondary)", marginTop: 4 }}>
                Leave empty if not associating with a study
              </div>
            </div>

            <div style={{ marginBottom: 16 }}>
              <label>Time Limit</label>
              <div style={{ display: "flex", gap: 12, alignItems: "center", marginTop: 4 }}>
                <div style={{ flex: 1 }}>
                  <input
                    type="number"
                    min="0"
                    value={timeLimitMinutes}
                    onChange={(e) => setTimeLimitMinutes(e.target.value)}
                    placeholder="Minutes"
                    style={{ width: "100%", padding: 8 }}
                  />
                  <div style={{ fontSize: 12, color: "var(--text-secondary)", marginTop: 4 }}>Minutes</div>
                </div>
                <div style={{ flex: 1 }}>
                  <input
                    type="number"
                    min="0"
                    max="59"
                    value={timeLimitSeconds}
                    onChange={(e) => setTimeLimitSeconds(e.target.value)}
                    placeholder="Seconds"
                    style={{ width: "100%", padding: 8 }}
                  />
                  <div style={{ fontSize: 12, color: "var(--text-secondary)", marginTop: 4 }}>Seconds</div>
                </div>
              </div>
            </div>

            <div style={{ marginBottom: 16 }}>
              <label>Status</label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value)}
                style={{ width: "100%", padding: 8, marginTop: 4 }}
              >
                <option value="DRAFT">Draft</option>
                <option value="PUBLISHED">Published</option>
                <option value="ARCHIVED">Archived</option>
              </select>
            </div>
          </div>

          <div style={{ marginBottom: 24 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
              <h3>Questions</h3>
              <button type="button" onClick={addQuestion} className="btn small">
                Add Question
              </button>
            </div>

            {questions.map((question, qIndex) => (
              <div key={qIndex} className="card" style={{ marginBottom: 16 }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 12 }}>
                  <h4 style={{ margin: 0 }}>Question {qIndex + 1}</h4>
                  <button
                    type="button"
                    onClick={() => removeQuestion(qIndex)}
                    className="btn small"
                    style={{ backgroundColor: "var(--danger)", color: "white" }}
                  >
                    Remove
                  </button>
                </div>

                <div style={{ marginBottom: 12 }}>
                  <label>
                    Question Text <span style={{ color: "var(--danger)" }}>*</span>
                  </label>
                  <textarea
                    value={question.questionText}
                    onChange={(e) => updateQuestion(qIndex, "questionText", e.target.value)}
                    placeholder="Enter your question"
                    rows={2}
                    required
                    style={{
                      width: "100%",
                      padding: 8,
                      marginTop: 4,
                      resize: "vertical",
                      color: "var(--text)",
                      backgroundColor: "var(--glass)",
                      border: "1px solid rgba(255,255,255,0.03)",
                      borderRadius: "8px",
                      outline: "none"
                    }}
                  />
                </div>

                <div style={{ marginBottom: 12 }}>
                  <label>Question Type</label>
                  <select
                    value={question.questionType}
                    onChange={(e) => {
                      const newType = e.target.value;
                      updateQuestion(qIndex, "questionType", newType);
                      const updated = [...questions];
                      const q = updated[qIndex];

                      if (newType === "TEXT") {
                        // Clear all answers for TEXT questions
                        q.answers = [];
                      } else if (newType === "SINGLE_CHOICE") {
                        // Reset correct answers if switching to single choice
                        const firstCorrectIndex = q.answers.findIndex((a) => a.isCorrect);
                        if (firstCorrectIndex === -1 && q.answers.length > 0) {
                          q.answers[0].isCorrect = true;
                        } else {
                          q.answers.forEach((a, i) => {
                            a.isCorrect = i === firstCorrectIndex;
                          });
                        }
                      }
                      setQuestions(updated);
                    }}
                    style={{ width: "100%", padding: 8, marginTop: 4 }}
                  >
                    <option value="SINGLE_CHOICE">Single Choice</option>
                    <option value="MULTIPLE_CHOICE">Multiple Choice</option>
                    <option value="TEXT">Text Answer (Open Ended)</option>
                  </select>
                </div>

                {question.questionType !== "TEXT" && (
                  <div style={{ marginBottom: 12 }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
                      <label>Answers</label>
                      <button type="button" onClick={() => addAnswer(qIndex)} className="btn small">
                        Add Answer
                      </button>
                    </div>

                    {question.answers.map((answer, aIndex) => (
                      <div key={aIndex} style={{ display: "flex", gap: 8, marginBottom: 8, alignItems: "flex-start" }}>
                        <input
                          type="text"
                          value={answer.answerText}
                          onChange={(e) => updateAnswer(qIndex, aIndex, "answerText", e.target.value)}
                          placeholder="Enter answer text"
                          required
                          style={{ flex: 1, padding: 8 }}
                        />
                        <label style={{ display: "flex", alignItems: "center", gap: 4, whiteSpace: "nowrap" }}>
                          <input
                            type={question.questionType === "SINGLE_CHOICE" ? "radio" : "checkbox"}
                            name={`question-${qIndex}`}
                            checked={answer.isCorrect}
                            onChange={(e) => updateAnswer(qIndex, aIndex, "isCorrect", e.target.checked)}
                          />
                          Correct
                        </label>
                        <button
                          type="button"
                          onClick={() => removeAnswer(qIndex, aIndex)}
                          className="btn small"
                          style={{ backgroundColor: "var(--danger)", color: "white" }}
                        >
                          Remove
                        </button>
                      </div>
                    ))}
                  </div>
                )}

                {question.questionType === "TEXT" && (
                  <div style={{ marginBottom: 12, padding: 12, backgroundColor: "#f5f5f5", borderRadius: 4 }}>
                    <p style={{ margin: 0, color: "#000000", fontSize: 14 }}>
                      This is an open-ended question. Participants will provide a text answer when taking the quiz.
                    </p>
                  </div>
                )}
              </div>
            ))}
          </div>

          <div style={{ display: "flex", gap: 12, justifyContent: "flex-end" }}>
            <button type="button" onClick={() => navigate(`/quizzes/${id}`)} className="btn">
              Cancel
            </button>
            <button type="submit" className="btn" disabled={loading} style={{
              background: "linear-gradient(90deg, #2dd4bf, #06b6d4)",
              color: "#032027",
            }}>
              {loading ? "Updating..." : "Update Quiz"}
            </button>
          </div>
        </form>
      </div>
    </>
  );
}

