import React, { useState, useEffect } from "react";
import Navbar from "../components/Navbar";
import { useNavigate } from "react-router-dom";
import StudyItem from "../components/StudyItem";
import api from "../api";

export default function Studies() {
  const navigate = useNavigate();

  const [studies, setStudies] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState("");

  const fetchStudies = async () => {
    try {
      setIsLoading(true);
      const response = await api.get(`/api/studies/mine`);
      setStudies(response.data || []);
      setError("");
    } catch (err) {
      console.error("Failed to fetch studies:", err);
      setError("Failed to load studies. Please try again later.");
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchStudies();
  }, []);

  return (
    <>
      <Navbar />

      <div className="page">
        <header className="page-header">
          <div>
            <h2 className="page-title">My Studies</h2>
            <p className="page-subtitle">Create and manage your studies.</p>
          </div>

          <button className="btn btn-sm" onClick={() => navigate("/StudyCreationPage")}>
            Create New Study
          </button>
        </header>

        <div className="studies-list">
          {isLoading && <div className="muted">Loading studies…</div>}
          {error && <div className="error">{error}</div>}

          {!isLoading && !error && (!studies || studies.length === 0) && (
            <div className="muted">No studies yet.</div>
          )}

          {!isLoading &&
            !error &&
            studies?.map((study) => (
              <StudyItem key={study.studyId} study={study} onStudyDeleted={fetchStudies} />
            ))}
        </div>
      </div>
    </>
  );
}
