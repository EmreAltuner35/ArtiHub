import React, { useState, useEffect, useContext } from "react";
import Navbar from "../components/Navbar";
import { useNavigate } from 'react-router-dom';
import api from "../api";
import { AuthContext } from "../auth/AuthProvider";

export default function Forums() {
    const navigate = useNavigate();
    const { user } = useContext(AuthContext);
    const [forums, setForums] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState(null);
    const [showCreateModal, setShowCreateModal] = useState(false);
    const [newForum, setNewForum] = useState({ title: '', description: '' });
    const [creating, setCreating] = useState(false);

    const userRole = user?.role?.toUpperCase();
    const canManageForums = userRole === 'ADMIN' || userRole === 'RESEARCHER';

    const fetchForums = async () => {
        try {
            setIsLoading(true);
            const { data } = await api.get('/api/forums');
            setForums(data);
            setError(null);
        } catch (err) {
            console.error("Failed to fetch forums:", err);
            setError("Failed to load forums. Please try again later.");
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        fetchForums();
    }, []);

    const handleCreateForum = async (e) => {
        e.preventDefault();
        if (!newForum.title.trim()) return;

        try {
            setCreating(true);
            await api.post('/api/forums', newForum);
            setNewForum({ title: '', description: '' });
            setShowCreateModal(false);
            fetchForums();
        } catch (err) {
            console.error("Failed to create forum:", err);
            alert("Failed to create forum. Please try again.");
        } finally {
            setCreating(false);
        }
    };

    const handleDeleteForum = async (forumId) => {
        if (!window.confirm("Are you sure you want to delete this forum?")) return;

        try {
            await api.delete(`/api/forums/${forumId}`);
            fetchForums();
        } catch (err) {
            console.error("Failed to delete forum:", err);
            alert("Failed to delete forum. Only admins can delete forums.");
        }
    };

    const handleArchiveForum = async (forumId) => {
        try {
            await api.put(`/api/forums/${forumId}/archive`);
            fetchForums();
        } catch (err) {
            console.error("Failed to archive forum:", err);
            alert("Failed to archive forum.");
        }
    };

    const handleCloseForum = async (forumId) => {
        try {
            await api.put(`/api/forums/${forumId}/close`);
            fetchForums();
        } catch (err) {
            console.error("Failed to close forum:", err);
            alert("Failed to close forum.");
        }
    };

    const handleReopenForum = async (forumId) => {
        try {
            await api.put(`/api/forums/${forumId}/reopen`);
            fetchForums();
        } catch (err) {
            console.error("Failed to reopen forum:", err);
            alert("Failed to reopen forum.");
        }
    };

    const getStatusBadge = (status) => {
        const styles = {
            ACTIVE: { backgroundColor: '#10b981', color: 'white' },
            ARCHIVED: { backgroundColor: '#f59e0b', color: 'white' },
            CLOSED: { backgroundColor: '#ef4444', color: 'white' }
        };
        return (
            <span style={{
                ...styles[status],
                padding: '4px 8px',
                borderRadius: '4px',
                fontSize: '12px',
                fontWeight: '600'
            }}>
                {status}
            </span>
        );
    };

    const renderForums = () => {
        if (isLoading) {
            return <p style={{ color: '#9ca3af' }}>Loading forums...</p>;
        }

        if (error) {
            return <p style={{ color: '#ef4444' }}>{error}</p>;
        }

        if (forums.length === 0) {
            return (
                <div style={{ textAlign: 'center', padding: '40px', color: '#9ca3af' }}>
                    <p>No forums available.</p>
                    {canManageForums && (
                        <p>Click "Create New Forum" to get started!</p>
                    )}
                </div>
            );
        }

        return (
            <div style={{ display: 'grid', gap: '16px' }}>
                {forums.map((forum) => (
                    <div
                        key={forum.forumId}
                        className="card"
                        style={{
                            padding: '20px',
                            cursor: 'pointer',
                            transition: 'transform 0.2s, box-shadow 0.2s'
                        }}
                        onClick={() => navigate(`/forums/${forum.forumId}`)}
                        onMouseEnter={(e) => {
                            e.currentTarget.style.transform = 'translateY(-2px)';
                            e.currentTarget.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.3)';
                        }}
                        onMouseLeave={(e) => {
                            e.currentTarget.style.transform = 'translateY(0)';
                            e.currentTarget.style.boxShadow = '';
                        }}
                    >
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                            <div style={{ flex: 1 }}>
                                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
                                    <h3 style={{ margin: 0, color: '#f3f4f6' }}>{forum.title}</h3>
                                    {getStatusBadge(forum.status)}
                                </div>
                                <p style={{ color: '#9ca3af', margin: '0 0 12px 0' }}>
                                    {forum.description || 'No description'}
                                </p>
                                <div style={{ display: 'flex', gap: '16px', fontSize: '14px', color: '#6b7280' }}>
                                    <span>📝 {forum.threadCount || 0} threads</span>
                                    <span>📅 {new Date(forum.createdAt).toLocaleDateString()}</span>
                                </div>
                            </div>

                            {canManageForums && (
                                <div style={{ display: 'flex', gap: '8px' }} onClick={(e) => e.stopPropagation()}>
                                    {forum.status === 'ACTIVE' && (
                                        <>
                                            <button
                                                className="btn btn-secondary"
                                                style={{ fontSize: '12px', padding: '6px 12px' }}
                                                onClick={() => handleArchiveForum(forum.forumId)}
                                            >
                                                Archive
                                            </button>
                                            <button
                                                className="btn btn-secondary"
                                                style={{ fontSize: '12px', padding: '6px 12px' }}
                                                onClick={() => handleCloseForum(forum.forumId)}
                                            >
                                                Close
                                            </button>
                                        </>
                                    )}
                                    {(forum.status === 'ARCHIVED' || forum.status === 'CLOSED') && (
                                        <button
                                            className="btn btn-secondary"
                                            style={{ fontSize: '12px', padding: '6px 12px' }}
                                            onClick={() => handleReopenForum(forum.forumId)}
                                        >
                                            Reopen
                                        </button>
                                    )}
                                    {userRole === 'ADMIN' && (
                                        <button
                                            className="btn"
                                            style={{ fontSize: '12px', padding: '6px 12px', backgroundColor: '#ef4444' }}
                                            onClick={() => handleDeleteForum(forum.forumId)}
                                        >
                                            Delete
                                        </button>
                                    )}
                                </div>
                            )}
                        </div>
                    </div>
                ))}
            </div>
        );
    };

    return (
        <>
            <Navbar />
            <div style={{ padding: 24 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px' }}>
                    <h2 style={{ color: '#f3f4f6' }}>Forums</h2>
                    {canManageForums && (
                        <button className="btn" onClick={() => setShowCreateModal(true)}>
                            Create New Forum
                        </button>
                    )}
                </div>

                {renderForums()}

                {/* Create Forum Modal */}
                {showCreateModal && (
                    <div style={{
                        position: 'fixed',
                        top: 0,
                        left: 0,
                        right: 0,
                        bottom: 0,
                        backgroundColor: 'rgba(0, 0, 0, 0.7)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        zIndex: 1000
                    }}>
                        <div className="card" style={{ width: '100%', maxWidth: '500px', padding: '24px' }}>
                            <h3 style={{ marginTop: 0, color: '#f3f4f6' }}>Create New Forum</h3>
                            <form onSubmit={handleCreateForum}>
                                <div style={{ marginBottom: '16px' }}>
                                    <label style={{ display: 'block', marginBottom: '8px', color: '#d1d5db' }}>
                                        Forum Title *
                                    </label>
                                    <input
                                        type="text"
                                        className="input"
                                        value={newForum.title}
                                        onChange={(e) => setNewForum({ ...newForum, title: e.target.value })}
                                        placeholder="Enter forum title"
                                        required
                                        style={{ width: '100%', color: '#f3f4f6', backgroundColor: '#374151' }}
                                    />
                                </div>
                                <div style={{ marginBottom: '24px' }}>
                                    <label style={{ display: 'block', marginBottom: '8px', color: '#d1d5db' }}>
                                        Description
                                    </label>
                                    <textarea
                                        className="input"
                                        value={newForum.description}
                                        onChange={(e) => setNewForum({ ...newForum, description: e.target.value })}
                                        placeholder="Enter forum description"
                                        rows={4}
                                        style={{ width: '100%', resize: 'vertical', color: '#f3f4f6', backgroundColor: '#374151' }}
                                    />
                                </div>
                                <div style={{ display: 'flex', gap: '12px', justifyContent: 'flex-end' }}>
                                    <button
                                        type="button"
                                        className="btn btn-secondary"
                                        onClick={() => {
                                            setShowCreateModal(false);
                                            setNewForum({ title: '', description: '' });
                                        }}
                                    >
                                        Cancel
                                    </button>
                                    <button
                                        type="submit"
                                        className="btn"
                                        disabled={creating || !newForum.title.trim()}
                                    >
                                        {creating ? 'Creating...' : 'Create Forum'}
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                )}
            </div>
        </>
    );
}
