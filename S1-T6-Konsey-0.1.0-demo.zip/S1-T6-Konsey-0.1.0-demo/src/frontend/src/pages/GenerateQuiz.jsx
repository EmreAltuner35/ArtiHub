import React, { useState, useContext } from "react";
import { useNavigate } from "react-router-dom";
import api from "../api";
import Navbar from "../components/Navbar";
import { AuthContext } from "../auth/AuthProvider";

export default function GenerateQuiz() {
    const navigate = useNavigate();
    const { user } = useContext(AuthContext);

    // Form State
    const [topic, setTopic] = useState("");
    const [difficulty, setDifficulty] = useState("Medium");
    const [questionCount, setQuestionCount] = useState(10);
    const [language, setLanguage] = useState("English");
    const [timeLimitMinutes, setTimeLimitMinutes] = useState("");
    const [timeLimitSeconds, setTimeLimitSeconds] = useState("");

    // Job State
    const [jobId, setJobId] = useState(null);
    const [jobStatus, setJobStatus] = useState(null); // queued, processing, succeeded, failed
    const [generatedContent, setGeneratedContent] = useState(null);
    const [error, setError] = useState("");
    const [loading, setLoading] = useState(false);
    const [saving, setSaving] = useState(false);

    const handleGenerate = async (e) => {
        e.preventDefault();
        setError("");
        setJobId(null);
        setJobStatus(null);
        setGeneratedContent(null);
        setLoading(true);

        try {
            const payload = {
                topic,
                difficulty,
                questionCount: parseInt(questionCount),
                language,
                ownerId: user?.id || "unknown"
            };

            const res = await api.post("/api/ai-quizzes", payload);
            setJobId(res.data.jobId);
            setJobStatus("queued");
            pollJob(res.data.jobId);

        } catch (err) {
            console.error("Generation failed", err);
            setError("Failed to start generation job.");
            setLoading(false);
        }
    };

    const pollJob = async (id) => {
        const interval = setInterval(async () => {
            try {
                const res = await api.get(`/api/ai-quizzes/jobs/${id}`);
                const status = res.data.status.toLowerCase();
                setJobStatus(status);

                if (status === "succeeded") {
                    clearInterval(interval);
                    setLoading(false);
                    // Try to parse content as JSON
                    let rawContent = res.data.preview.content;
                    try {
                        // 1. Remove markdown code blocks if present
                        // Regex to match ```json ... ``` or just ``` ... ```
                        // Updated to allow unclosed blocks (handling truncation)
                        const markdownRegex = /```(?:json)?\s*([\s\S]*?)(?:```|$)/;
                        const match = rawContent.match(markdownRegex);
                        if (match && match[1]) {
                            rawContent = match[1];
                        }

                        // 2. Try simple parse
                        let content = JSON.parse(rawContent);
                        setGeneratedContent(content);
                    } catch (e) {
                        console.warn("JSON parse failed, attempting cleanup", e);
                        // 3. Fallback: Extract JSON from substring
                        try {
                            const firstBrace = rawContent.indexOf('{');
                            const lastBrace = rawContent.lastIndexOf('}');
                            if (firstBrace !== -1 && lastBrace !== -1) {
                                const jsonSubstring = rawContent.substring(firstBrace, lastBrace + 1);
                                const content = JSON.parse(jsonSubstring);
                                setGeneratedContent(content);
                            } else {
                                throw new Error("No JSON object found");
                            }
                        } catch (e2) {
                            console.error("Critical JSON parse failure", e2);
                            // If completely failed, store as string but invalid for saving
                            setGeneratedContent(res.data.preview.content);
                        }
                    }
                } else if (status === "failed") {
                    clearInterval(interval);
                    setLoading(false);
                    setError(res.data.error || "Generation failed.");
                }
            } catch (err) {
                clearInterval(interval);
                setLoading(false);
                setError("Failed to poll job status.");
            }
        }, 2000);
    };

    const handleSave = async () => {
        if (!generatedContent) return;
        setSaving(true);
        setError("");

        try {
            // Map AI response to DTO structure
            // Prioritize keys from updated prompt: questionText, answerText, isCorrect
            const questions = (generatedContent.questions || (Array.isArray(generatedContent) ? generatedContent : [])).map((q, index) => ({
                questionText: q.questionText || q.text,
                questionType: "MULTIPLE_CHOICE", // Default to multiple choice
                questionOrder: q.questionOrder || q.order || index + 1,
                answers: (q.answers || q.options || []).map((opt, aIndex) => ({
                    answerText: typeof opt === 'string' ? opt : (opt.answerText || opt.text),
                    isCorrect: typeof opt === 'string' ? (opt === q.correctAnswer) : (opt.isCorrect !== undefined ? opt.isCorrect : opt.correct),
                    answerOrder: opt.answerOrder || opt.order || aIndex + 1
                }))
            }));

            // Calculate time limit in seconds
            let calculatedTimeLimit = null;
            const mins = parseInt(timeLimitMinutes) || 0;
            const secs = parseInt(timeLimitSeconds) || 0;
            if (mins > 0 || secs > 0) {
                calculatedTimeLimit = (mins * 60) + secs;
            }

            const quizPayload = {
                title: generatedContent.title || `Quiz: ${topic}`,
                description: generatedContent.description || `AI Generated quiz about ${topic}`,
                questions: questions,
                studyId: null,
                timeLimit: calculatedTimeLimit
            };

            await api.post("/api/quizzes", quizPayload);
            navigate("/quizzes");
        } catch (err) {
            console.error("Save failed", err);
            if (err.response && err.response.data) {
                // If it's a validation error (400), show specific fields
                if (typeof err.response.data === 'object') {
                    const messages = Object.entries(err.response.data)
                        .map(([key, msg]) => `${key}: ${msg}`)
                        .join(", ");
                    setError(`Save failed: ${messages}`);
                } else {
                    setError(`Save failed: ${err.response.data.error || err.response.data}`);
                }
            } else {
                setError("Failed to save quiz. Please try again.");
            }
        } finally {
            setSaving(false);
        }
    };

    return (
        <>
            <Navbar />
            <div style={{ maxWidth: "800px", margin: "2rem auto", padding: "0 1rem" }}>
                <h1>Generate AI Quiz</h1>

                <div className="card">
                    <form onSubmit={handleGenerate}>
                        <div style={{ marginBottom: "1rem" }}>
                            <label>Topic</label>
                            <input
                                type="text"
                                className="input-dark"
                                required
                                value={topic}
                                onChange={(e) => setTopic(e.target.value)}
                                placeholder="e.g. Java Streams, World History, Quantum Physics"
                            />
                        </div>

                        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "1rem", marginBottom: "1rem" }}>
                            <div>
                                <label>Difficulty</label>
                                <select
                                    className="select-dark"
                                    value={difficulty}
                                    onChange={(e) => setDifficulty(e.target.value)}
                                >
                                    <option value="Easy">Easy</option>
                                    <option value="Medium">Medium</option>
                                    <option value="Hard">Hard</option>
                                </select>
                            </div>

                            <div>
                                <label>Questions</label>
                                <input
                                    type="number"
                                    className="input-dark"
                                    min="1"
                                    max="50"
                                    value={questionCount}
                                    onChange={(e) => setQuestionCount(e.target.value)}
                                />
                            </div>

                            <div>
                                <label>Language</label>
                                <select
                                    className="select-dark"
                                    value={language}
                                    onChange={(e) => setLanguage(e.target.value)}
                                >
                                    <option value="English">English</option>
                                    <option value="Turkish">Turkish</option>
                                    <option value="Spanish">Spanish</option>
                                    <option value="French">French</option>
                                    <option value="German">German</option>
                                </select>
                            </div>
                        </div>

                        {/* TIME LIMIT SECTION - MATCHING CREATE QUIZ UI */}
                        <div style={{ marginBottom: "1rem" }}>
                            <label>Time Limit</label>
                            <div style={{ display: "flex", gap: 12, alignItems: "center", marginTop: 4 }}>
                                <div style={{ flex: 1 }}>
                                    <input
                                        type="number"
                                        min="0"
                                        className="input-dark"
                                        value={timeLimitMinutes}
                                        onChange={(e) => setTimeLimitMinutes(e.target.value)}
                                        placeholder="Minutes"
                                        style={{ width: "100%" }}
                                    />
                                    <div style={{ fontSize: 12, color: "var(--text-secondary)", marginTop: 4 }}>Minutes</div>
                                </div>
                                <div style={{ flex: 1 }}>
                                    <input
                                        type="number"
                                        min="0"
                                        max="59"
                                        className="input-dark"
                                        value={timeLimitSeconds}
                                        onChange={(e) => setTimeLimitSeconds(e.target.value)}
                                        placeholder="Seconds"
                                        style={{ width: "100%" }}
                                    />
                                    <div style={{ fontSize: 12, color: "var(--text-secondary)", marginTop: 4 }}>Seconds</div>
                                </div>
                            </div>
                        </div>

                        <button type="submit" className="btn" disabled={loading || (jobStatus === "queued" || jobStatus === "processing")}>
                            {loading ? "Generating..." : "Generate Quiz"}
                        </button>
                    </form>

                    {/* STATUS & PREVIEW */}
                    {error && <div className="error" style={{ marginTop: "1rem" }}>{error}</div>}

                    {jobStatus && (
                        <div style={{ marginTop: "1rem", padding: "1rem", background: "rgba(255,255,255,0.05)", borderRadius: "8px" }}>
                            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "1rem" }}>
                                <strong>Status: <span style={{ color: jobStatus === "succeeded" ? "var(--accent)" : "var(--text)" }}>{jobStatus.toUpperCase()}</span></strong>
                                {jobStatus === "succeeded" && (
                                    <button className="btn small" onClick={handleSave} disabled={saving}>
                                        {saving ? "Saving..." : "Save to Quizzes"}
                                    </button>
                                )}
                            </div>

                            {generatedContent && (
                                <div>
                                    <label>Preview</label>
                                    <div style={{ maxHeight: "400px", overflow: "auto", background: "rgba(0,0,0,0.2)", padding: "1rem", borderRadius: "4px" }}>
                                        {generatedContent.questions ? (
                                            generatedContent.questions.map((q, i) => (
                                                <div key={i} style={{ marginBottom: "1rem", borderBottom: "1px solid rgba(255,255,255,0.1)", paddingBottom: "0.5rem" }}>
                                                    <div style={{ fontWeight: "bold", marginBottom: "0.5rem" }}>{i + 1}. {q.text || q.questionText}</div>
                                                    <div style={{ paddingLeft: "1rem", fontSize: "0.9em", color: "var(--muted)" }}>
                                                        {(q.answers || q.options || []).map((ans, j) => {
                                                            const answerText = typeof ans === 'string' ? ans : (ans.text || ans.answerText);
                                                            const isCorrect = typeof ans === 'string' ? (ans === q.correctAnswer) : (ans.correct || ans.isCorrect);
                                                            return (
                                                                <div key={j} style={{ color: isCorrect ? "var(--accent)" : "inherit" }}>
                                                                    - {answerText} {isCorrect && "(Correct)"}
                                                                </div>
                                                            );
                                                        })}
                                                    </div>
                                                </div>
                                            ))
                                        ) : (
                                            <pre>{JSON.stringify(generatedContent, null, 2)}</pre>
                                        )}
                                    </div>
                                </div>
                            )}
                        </div>
                    )}
                </div>
            </div>
        </>
    );
}
