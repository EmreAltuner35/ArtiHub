import React, { useState, useEffect, useContext } from "react";
import Navbar from "../components/Navbar";
import { useParams, useNavigate } from 'react-router-dom';
import api from "../api";
import { AuthContext } from "../auth/AuthProvider";
import ForumAttachmentPicker from "../components/ForumAttachmentPicker";

export default function ForumDetail() {
    const { id: forumId } = useParams();
    const navigate = useNavigate();
    const { user } = useContext(AuthContext);

    const [forum, setForum] = useState(null);
    const [threads, setThreads] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState(null);
    const [showCreateModal, setShowCreateModal] = useState(false);
    const [newThread, setNewThread] = useState({ title: '', body: '' });
    const [threadArtifacts, setThreadArtifacts] = useState([]);
    const [threadFiles, setThreadFiles] = useState([]);
    const [creating, setCreating] = useState(false);

    const userRole = user?.role?.toUpperCase();
    const canModerate = userRole === 'ADMIN' || userRole === 'RESEARCHER';
    const canCreateThread = userRole === 'ADMIN' || userRole === 'RESEARCHER';
    const canLinkArtifacts = userRole === 'ADMIN' || userRole === 'RESEARCHER';

    const fetchData = async () => {
        try {
            setIsLoading(true);
            const [forumRes, threadsRes] = await Promise.all([
                api.get(`/api/forums/${forumId}`),
                api.get(`/api/forums/${forumId}/threads`),
            ]);
            setForum(forumRes.data);
            setThreads(threadsRes.data);
            setError(null);
        } catch (err) {
            console.error("Failed to fetch forum data:", err);
            setError("Failed to load forum. Please try again later.");
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        fetchData();
    }, [forumId]);

    const handleCreateThread = async (e) => {
        e.preventDefault();
        if (!newThread.title.trim() || !newThread.body.trim()) return;

        try {
            setCreating(true);
            const threadData = {
                ...newThread,
                artifactIds: threadArtifacts.map(a => a.artifactId)
            };
            // Extract the actual File object from the wrapper
            const filesToUpload = threadFiles.map(f => f.file);

            const formData = new FormData();
            const jsonBlob = new Blob([JSON.stringify(threadData)], { type: 'application/json' });
            formData.append('data', jsonBlob);
            if (filesToUpload && filesToUpload.length > 0) {
                filesToUpload.forEach(file => formData.append('files', file));
            }

            await api.post(`/api/forums/${forumId}/threads`, formData);
            setNewThread({ title: '', body: '' });
            setThreadArtifacts([]);
            setThreadFiles([]);
            setShowCreateModal(false);
            fetchData();
        } catch (err) {
            console.error("Failed to create thread:", err);
            alert(err.response?.data?.message || "Failed to create thread. Please try again.");
        } finally {
            setCreating(false);
        }
    };

    const handleLockThread = async (threadId) => {
        try {
            await api.put(`/api/forums/threads/${threadId}/lock`);
            fetchData();
        } catch (err) {
            console.error("Failed to lock thread:", err);
            alert("Failed to lock thread.");
        }
    };

    const handleUnlockThread = async (threadId) => {
        try {
            await api.put(`/api/forums/threads/${threadId}/unlock`);
            fetchData();
        } catch (err) {
            console.error("Failed to unlock thread:", err);
            alert("Failed to unlock thread.");
        }
    };

    const handleDeleteThread = async (threadId) => {
        if (!window.confirm("Are you sure you want to delete this thread?")) return;

        try {
            await api.delete(`/api/forums/threads/${threadId}`);
            fetchData();
        } catch (err) {
            console.error("Failed to delete thread:", err);
            alert("Failed to delete thread.");
        }
    };

    const getStatusBadge = (status) => {
        const styles = {
            ACTIVE: { backgroundColor: '#10b981', color: 'white' },
            ARCHIVED: { backgroundColor: '#f59e0b', color: 'white' },
            CLOSED: { backgroundColor: '#ef4444', color: 'white' }
        };
        return (
            <span style={{
                ...styles[status],
                padding: '4px 8px',
                borderRadius: '4px',
                fontSize: '12px',
                fontWeight: '600'
            }}>
                {status}
            </span>
        );
    };

    if (isLoading) {
        return (
            <>
                <Navbar />
                <div style={{ padding: 24, color: '#9ca3af' }}>Loading forum...</div>
            </>
        );
    }

    if (error || !forum) {
        return (
            <>
                <Navbar />
                <div style={{ padding: 24 }}>
                    <button className="btn btn-secondary" onClick={() => navigate('/forums')}>
                        ← Back to Forums
                    </button>
                    <p style={{ color: '#ef4444', marginTop: '16px' }}>{error || "Forum not found"}</p>
                </div>
            </>
        );
    }

    const isReadOnly = forum.status === 'ARCHIVED' || forum.status === 'CLOSED';

    return (
        <>
            <Navbar />
            <div style={{ padding: 24 }}>
                {/* Header */}
                <div style={{ marginBottom: '24px' }}>
                    <button
                        className="btn btn-secondary"
                        style={{ marginBottom: '16px' }}
                        onClick={() => navigate('/forums')}
                    >
                        ← Back to Forums
                    </button>

                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                        <div>
                            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
                                <h2 style={{ margin: 0, color: '#f3f4f6' }}>{forum.title}</h2>
                                {getStatusBadge(forum.status)}
                            </div>
                            <p style={{ color: '#9ca3af', margin: 0 }}>
                                {forum.description || 'No description'}
                            </p>
                        </div>

                        {canCreateThread && !isReadOnly && (
                            <button className="btn" onClick={() => setShowCreateModal(true)}>
                                Create Thread
                            </button>
                        )}
                    </div>

                    {isReadOnly && (
                        <div style={{
                            marginTop: '16px',
                            padding: '12px 16px',
                            backgroundColor: '#fef3c7',
                            borderRadius: '8px',
                            color: '#92400e'
                        }}>
                            ⚠️ This forum is {forum.status.toLowerCase()}. New threads and replies are not allowed.
                        </div>
                    )}
                </div>

                {/* Threads List */}
                <h3 style={{ color: '#f3f4f6', marginBottom: '16px' }}>Threads ({threads.length})</h3>

                {threads.length === 0 ? (
                    <div style={{ textAlign: 'center', padding: '40px', color: '#9ca3af' }}>
                        <p>No threads yet.</p>
                        {canCreateThread && !isReadOnly && (
                            <p>Be the first to start a discussion!</p>
                        )}
                    </div>
                ) : (
                    <div style={{ display: 'grid', gap: '12px' }}>
                        {threads.map((thread) => (
                            <div
                                key={thread.threadId}
                                className="card"
                                style={{
                                    padding: '16px 20px',
                                    cursor: 'pointer',
                                    transition: 'background-color 0.2s'
                                }}
                                onClick={() => navigate(`/forums/${forumId}/threads/${thread.threadId}`)}
                                onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#374151'}
                                onMouseLeave={(e) => e.currentTarget.style.backgroundColor = ''}
                            >
                                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                                    <div style={{ flex: 1 }}>
                                        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '4px' }}>
                                            <h4 style={{ margin: 0, color: '#f3f4f6' }}>{thread.title}</h4>
                                            {thread.locked && (
                                                <span style={{
                                                    backgroundColor: '#ef4444',
                                                    color: 'white',
                                                    padding: '2px 6px',
                                                    borderRadius: '4px',
                                                    fontSize: '11px'
                                                }}>
                                                    🔒 Locked
                                                </span>
                                            )}
                                        </div>
                                        <div style={{ fontSize: '14px', color: '#6b7280' }}>
                                            <span>By {thread.authorName || 'Unknown'}</span>
                                            <span style={{ margin: '0 8px' }}>•</span>
                                            <span>{new Date(thread.createdAt).toLocaleString()}</span>
                                            <span style={{ margin: '0 8px' }}>•</span>
                                            <span>💬 {thread.replyCount || 0} replies</span>
                                        </div>
                                    </div>

                                    {canModerate && (
                                        <div style={{ display: 'flex', gap: '8px' }} onClick={(e) => e.stopPropagation()}>
                                            {thread.locked ? (
                                                <button
                                                    className="btn btn-secondary"
                                                    style={{ fontSize: '11px', padding: '4px 8px' }}
                                                    onClick={() => handleUnlockThread(thread.threadId)}
                                                >
                                                    Unlock
                                                </button>
                                            ) : (
                                                <button
                                                    className="btn btn-secondary"
                                                    style={{ fontSize: '11px', padding: '4px 8px' }}
                                                    onClick={() => handleLockThread(thread.threadId)}
                                                >
                                                    Lock
                                                </button>
                                            )}
                                            <button
                                                className="btn"
                                                style={{ fontSize: '11px', padding: '4px 8px', backgroundColor: '#ef4444' }}
                                                onClick={() => handleDeleteThread(thread.threadId)}
                                            >
                                                Delete
                                            </button>
                                        </div>
                                    )}
                                </div>
                            </div>
                        ))}
                    </div>
                )}

                {/* Create Thread Modal */}
                {showCreateModal && (
                    <div style={{
                        position: 'fixed',
                        top: 0,
                        left: 0,
                        right: 0,
                        bottom: 0,
                        backgroundColor: 'rgba(0, 0, 0, 0.7)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        zIndex: 1000
                    }}>
                        <div className="card" style={{ width: '100%', maxWidth: '600px', padding: '24px' }}>
                            <h3 style={{ marginTop: 0, color: '#f3f4f6' }}>Create New Thread</h3>
                            <form onSubmit={handleCreateThread}>
                                <div style={{ marginBottom: '16px' }}>
                                    <label style={{ display: 'block', marginBottom: '8px', color: '#d1d5db' }}>
                                        Thread Title *
                                    </label>
                                    <input
                                        type="text"
                                        className="input"
                                        value={newThread.title}
                                        onChange={(e) => setNewThread({ ...newThread, title: e.target.value })}
                                        placeholder="Enter thread title"
                                        required
                                        style={{ width: '100%', color: '#f3f4f6', backgroundColor: '#374151' }}
                                    />
                                </div>

                                <div style={{ marginBottom: '16px' }}>
                                    <label style={{ display: 'block', marginBottom: '8px', color: '#d1d5db' }}>
                                        Content *
                                    </label>
                                    <textarea
                                        className="input"
                                        value={newThread.body}
                                        onChange={(e) => setNewThread({ ...newThread, body: e.target.value })}
                                        placeholder="Write your message..."
                                        rows={6}
                                        required
                                        style={{ width: '100%', resize: 'vertical', color: '#f3f4f6', backgroundColor: '#374151' }}
                                    />
                                </div>

                                {/* Attachment Picker */}
                                <div style={{ marginBottom: '24px' }}>
                                    <label style={{ display: 'block', marginBottom: '8px', color: '#d1d5db' }}>
                                        Attachments (optional)
                                    </label>
                                    <ForumAttachmentPicker
                                        selectedArtifacts={threadArtifacts}
                                        selectedFiles={threadFiles}
                                        onArtifactsChange={setThreadArtifacts}
                                        onFilesChange={setThreadFiles}
                                        showArtifactLink={canLinkArtifacts}
                                    />
                                </div>

                                <div style={{ display: 'flex', gap: '12px', justifyContent: 'flex-end' }}>
                                    <button
                                        type="button"
                                        className="btn btn-secondary"
                                        onClick={() => {
                                            setShowCreateModal(false);
                                            setNewThread({ title: '', body: '' });
                                            setThreadArtifacts([]);
                                            setThreadFiles([]);
                                        }}
                                    >
                                        Cancel
                                    </button>
                                    <button
                                        type="submit"
                                        className="btn"
                                        disabled={creating || !newThread.title.trim() || !newThread.body.trim()}
                                    >
                                        {creating ? 'Creating...' : 'Create Thread'}
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                )}
            </div>
        </>
    );
}
