import React, { useState, useEffect } from "react";
import Navbar from "../components/Navbar";
import ArtifactComparison from "../components/comparison/ArtifactComparison";

export default function TaskView() {

  return (
    <>
      <Navbar />
      <div style={{ padding: 24 }}>
        <ArtifactComparison />
      </div>
    </>
  );
}
