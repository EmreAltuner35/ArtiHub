import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "../components/Navbar";
import api from "../api";

export default function Quizzes() {
  const navigate = useNavigate();
  const [quizzes, setQuizzes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(0);
  const [totalPages, setTotalPages] = useState(0);

  useEffect(() => {
    fetchQuizzes();
  }, [page]);

  const fetchQuizzes = async () => {
    try {
      setLoading(true);
      const response = await api.get(`/api/quizzes/my-quizzes?page=${page}&size=10`);
      setQuizzes(response.data.content || []);
      setTotalPages(response.data.totalPages || 0);
    } catch (err) {
      console.error("Failed to fetch quizzes:", err);
      const errorMessage = err.response?.data?.error || err.response?.data?.message || err.message || "Failed to load quizzes. Please try again.";
      console.error("Error details:", err.response?.data);
      alert(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (quizId) => {
    if (!window.confirm("Are you sure you want to delete this quiz?")) {
      return;
    }

    try {
      await api.delete(`/api/quizzes/${quizId}`);
      alert("Quiz deleted successfully");
      fetchQuizzes();
    } catch (err) {
      console.error("Failed to delete quiz:", err);
      alert("Failed to delete quiz. Please try again.");
    }
  };

  if (loading) {
    return (
      <>
        <Navbar />
        <div style={{ padding: 24 }}>
          <div className="muted">Loading quizzes...</div>
        </div>
      </>
    );
  }

  return (
    <>
      <Navbar />
      <div style={{ padding: 24, maxWidth: 1200, margin: "0 auto" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24 }}>
          <h2>My Quizzes</h2>
          <div style={{ display: "flex", gap: "1rem" }}>
            <button
              onClick={() => navigate("/quizzes/generate")}
              className="btn"
              style={{
                background: "linear-gradient(90deg, #8b5cf6, #d946ef)",
                color: "white",
              }}
            >
              Generate AI Quiz
            </button>
            <button
              onClick={() => navigate("/quizzes/create")}
              className="btn"
              style={{
                background: "linear-gradient(90deg, #2dd4bf, #06b6d4)",
                color: "#032027",
              }}
            >
              Create New Quiz
            </button>
          </div>
        </div>

        {quizzes.length === 0 ? (
          <div className="card">
            <p className="muted">No quizzes found. Create your first quiz to get started!</p>
          </div>
        ) : (
          <>
            <div style={{ display: "grid", gap: 16 }}>
              {quizzes.map((quiz) => (
                <div key={quiz.quizId} className="card">
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                    <div style={{ flex: 1 }}>
                      <h3 style={{ marginTop: 0, marginBottom: 8 }}>{quiz.title}</h3>
                      <p className="muted" style={{ marginBottom: 12 }}>
                        {quiz.description || "No description"}
                      </p>
                      <div style={{ display: "flex", gap: 12, fontSize: 14, color: "var(--text-secondary)" }}>
                        <span>Status: {quiz.status}</span>
                        <span>•</span>
                        <span>Questions: {quiz.questions?.length || 0}</span>
                        {quiz.studyId && (
                          <>
                            <span>•</span>
                            <span>Study ID: {quiz.studyId}</span>
                          </>
                        )}
                      </div>
                    </div>
                    <div style={{ display: "flex", gap: 8 }}>
                      <button
                        onClick={() => navigate(`/quizzes/${quiz.quizId}`)}
                        className="btn small"
                      >
                        View
                      </button>
                      <button
                        onClick={() => navigate(`/quizzes/${quiz.quizId}/edit`)}
                        className="btn small"
                      >
                        Edit
                      </button>
                      <button
                        onClick={() => handleDelete(quiz.quizId)}
                        className="btn small"
                        style={{ backgroundColor: "var(--danger)", color: "white" }}
                      >
                        Delete
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {totalPages > 1 && (
              <div style={{ display: "flex", justifyContent: "center", gap: 8, marginTop: 24 }}>
                <button
                  onClick={() => setPage(page - 1)}
                  disabled={page === 0}
                  className="btn small"
                >
                  Previous
                </button>
                <span style={{ padding: "8px 16px" }}>
                  Page {page + 1} of {totalPages}
                </span>
                <button
                  onClick={() => setPage(page + 1)}
                  disabled={page >= totalPages - 1}
                  className="btn small"
                >
                  Next
                </button>
              </div>
            )}
          </>
        )}
      </div>
    </>
  );
}

