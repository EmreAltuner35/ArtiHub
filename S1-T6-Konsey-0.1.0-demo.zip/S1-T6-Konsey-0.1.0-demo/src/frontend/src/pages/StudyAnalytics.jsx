import React, { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import Navbar from "../components/Navbar";
import api from "../api";
import { ResponsiveContainer, PieChart, Pie, Cell, Tooltip, Legend } from "recharts";
import { Users, ClipboardList, Activity, ChevronLeft } from "lucide-react";

const STATUS_COLORS = {
  COMPLETED: "#10b981",
  IN_PROGRESS: "#3b82f6",
  DROPPED: "#ef4444",
  ENROLLED_PENDING: "#9ca3af",
};

const prettyStatus = (raw) => {
  const s = String(raw || "");
  if (!s) return "Unknown";
  if (s === "ENROLLED_PENDING") return "Enrolled (Pending)";
  if (s === "IN_PROGRESS") return "In Progress";
  return s.replace(/_/g, " ").toLowerCase().replace(/\b\w/g, (c) => c.toUpperCase());
};

const pillForParticipant = (raw) => {
  const s = String(raw || "").toUpperCase();
  if (s === "COMPLETED") return "status-pill status-pill--active";
  if (s === "DROPPED") return "status-pill status-pill--completed";
  return "status-pill";
};

const calcCompletionText = (rate) => {
  if (rate == null || Number.isNaN(Number(rate))) return "N/A";
  return `${(Number(rate) * 100).toFixed(1)}%`;
};

export default function StudyAnalytics() {
  const navigate = useNavigate();
  const { studyId } = useParams();

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const [analyticsDto, setAnalyticsDto] = useState(null);
  const [tasks, setTasks] = useState([]);
  const [taskCardMap, setTaskCardMap] = useState({});
  const [participants, setParticipants] = useState([]);

  const fetchAll = async () => {
    try {
      setLoading(true);
      setError("");

      const analyticsRes = await api.get(`/api/studies/${studyId}/analytics`);
      const dto = analyticsRes.data;
      setAnalyticsDto(dto);

      const tasksRes = await api.get(`/api/studies/${studyId}/tasks`);
      setTasks(tasksRes.data || []);

      try {
        const mapRes = await api.get(`/api/studies/${studyId}/tasks/analytics`);
        setTaskCardMap(mapRes.data || {});
      } catch (e) {
        console.warn("Task card analytics map fetch failed:", e);
        setTaskCardMap({});
      }

      const statusMap = dto?.participantStatusMap || {};
      const participantIds = Object.keys(statusMap);

      const userPromises = participantIds.map(async (id) => {
        try {
          const u = await api.get(`/api/users/${id}`);
          return { id, name: u.data?.displayName || "Unknown", rawStatus: statusMap[id] };
        } catch {
          return { id, name: `User ${id.slice(0, 6)}…`, rawStatus: statusMap[id] };
        }
      });

      const detailed = await Promise.all(userPromises);
      setParticipants(detailed);
    } catch (e) {
      console.error("Failed to load study analytics:", e);
      setError("Failed to load study analytics.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (studyId) fetchAll();
  }, [studyId]);

  const pieData = useMemo(() => {
    const statusMap = analyticsDto?.participantStatusMap || {};
    const counts = {};
    for (const s of Object.values(statusMap)) {
      const key = String(s || "UNKNOWN");
      counts[key] = (counts[key] || 0) + 1;
    }
    return Object.entries(counts)
      .map(([k, v]) => ({
        key: k,
        name: prettyStatus(k),
        value: v,
        color: STATUS_COLORS[k] || "#6b7280",
      }))
      .filter((x) => x.value > 0);
  }, [analyticsDto]);

  const totalParticipants = analyticsDto?.totalParticipants ?? participants.length ?? 0;

  return (
    <>
      <Navbar />

      <div className="page analytics">
        <header className="page-header analytics-topbar">
          <div>
            <h2 className="page-title">Study Analytics</h2>
            <p className="page-subtitle">Participants, status distribution, and task completion.</p>
          </div>

          <div className="analytics-actions">
            <button className="btn small btn-ghost" onClick={() => navigate("/analytics")}>
              <ChevronLeft size={16} style={{ marginRight: 6 }} />
              Back
            </button>
            <button className="btn btn-sm" onClick={fetchAll} disabled={loading}>
              Refresh
            </button>
          </div>
        </header>

        {loading && <div className="muted">Loading analytics…</div>}
        {error && <div className="error">{error}</div>}

        {!loading && !error && (
          <>
            <div className="analytics-kpis">
              <div className="card kpi-card">
                <div className="kpi-ico">
                  <Users size={18} />
                </div>
                <div className="kpi-meta">
                  <p className="kpi-title">Total participants</p>
                  <p className="kpi-value">{totalParticipants}</p>
                </div>
              </div>

              <div className="card kpi-card">
                <div className="kpi-ico">
                  <ClipboardList size={18} />
                </div>
                <div className="kpi-meta">
                  <p className="kpi-title">Tasks</p>
                  <p className="kpi-value">{tasks.length}</p>
                </div>
              </div>

              <div className="card kpi-card">
                <div className="kpi-ico">
                  <Activity size={18} />
                </div>
                <div className="kpi-meta">
                  <p className="kpi-title">Status categories</p>
                  <p className="kpi-value">{pieData.length}</p>
                </div>
              </div>
            </div>

            <div className="analytics-charts">
              <div className="card chart-card">
                <div className="chart-title-row">
                  <h3 className="chart-title">Participant Status</h3>
                  <span className="muted">{totalParticipants} total</span>
                </div>

                {pieData.length === 0 ? (
                  <div className="chart-empty">No status data.</div>
                ) : (
                  <div className="chart-wrap">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={pieData}
                          dataKey="value"
                          nameKey="name"
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={85}
                          paddingAngle={4}
                          labelLine={false}
                        >
                          {pieData.map((entry, idx) => (
                            <Cell key={idx} fill={entry.color} stroke={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip
                          contentStyle={{
                            backgroundColor: "#0f1720",
                            border: "1px solid rgba(255,255,255,0.1)",
                            borderRadius: 10,
                            color: "#e6eef6",
                          }}
                        />
                        <Legend />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                )}
              </div>

              <div className="card chart-card">
                <div className="chart-title-row">
                  <h3 className="chart-title">Participants</h3>
                  <span className="muted">{participants.length}</span>
                </div>

                <div className="analytics-table">
                  {participants.length === 0 ? (
                    <div className="muted">No participants.</div>
                  ) : (
                    participants.map((p) => (
                      <div key={p.id} className="row-card">
                        <div className="row-left">
                          <h4 className="row-title" title={p.name}>
                            {p.name}
                          </h4>
                          <div className="row-meta">
                            <span className={pillForParticipant(p.rawStatus)}>
                              {prettyStatus(p.rawStatus)}
                            </span>
                            <span className="muted">{p.id}</span>
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>

              <div className="card chart-card">
                <div className="chart-title-row">
                  <h3 className="chart-title">Tasks</h3>
                  <span className="muted">Click to open task analytics</span>
                </div>

                <div className="analytics-table">
                  {tasks.length === 0 ? (
                    <div className="muted">No tasks found.</div>
                  ) : (
                    tasks.map((t) => {
                      const a = taskCardMap?.[t.taskId];
                      const rate = a?.completion_rate;
                      const percent = rate != null ? Math.round(rate * 100) : 0;

                      return (
                        <div key={t.taskId} className="row-card">
                          <div className="row-left">
                            <h4 className="row-title" title={t.name}>
                              {t.name || "Unnamed Task"}
                            </h4>
                            <div className="row-meta">
                              <span>View: {t.viewType || "N/A"}</span>
                              <span>Blinded: {t.isBlinded ? "Yes" : "No"}</span>
                              <span>Completion: {calcCompletionText(rate)}</span>
                            </div>
                            <div className="progressbar">
                              <span style={{ width: `${percent}%` }} />
                            </div>
                          </div>

                          <button
                            className="btn btn-sm"
                            onClick={() => navigate(`/analytics/${studyId}/${t.taskId}`)}
                          >
                            View
                          </button>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            </div>
          </>
        )}
      </div>
    </>
  );
}
