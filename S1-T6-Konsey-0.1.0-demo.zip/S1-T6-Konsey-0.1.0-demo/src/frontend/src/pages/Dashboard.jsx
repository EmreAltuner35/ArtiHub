import React, { useContext, useState } from "react";
import { AuthContext } from "../auth/AuthProvider";
import { useNavigate } from "react-router-dom";
import api from "../api";
import Navbar from "../components/Navbar";
import EditProfileModal from "../components/EditProfileModal";
import ParticipantDashboard from "../components/ParticipantDashboard";
import AdminDashboard from "../components/AdminDashboard";
import GuestDashboard from "../components/GuestDashboard";
import ResearcherDashboard from "../components/ResearcherDashboard";
import ReviewerDashboard from "../components/ReviewerDashboard";

export default function Dashboard() {
  const { user, logout } = useContext(AuthContext);
  const navigate = useNavigate();
  const [showEdit, setShowEdit] = useState(false);

  const role = user?.role?.toLowerCase() || "guest";

  return (
    <div style={{ minHeight: "100vh" }}>
      {/* ✅ Role-based navbar */}
      <Navbar />

      <div style={{ padding: 24, position: "relative", maxWidth: 1500, margin: "0 auto" }}>
        {/* Top bar */}
        <div className="topbar" style={{ marginBottom: 16 }}>
          <div>
            Signed in as:{" "}
            <strong>{user?.displayName || user?.email || "Guest"}</strong>
          </div>
          {role !== "guest" && (
            <button onClick={logout} className="btn small">
              Logout
            </button>
          )}
        </div>

        {/* Dashboard card */}
        <div className="card" style={{ marginTop: 20, maxWidth: '100%' }}>
          <h2>{role.charAt(0).toUpperCase() + role.slice(1)} Dashboard</h2>

          {/* Conditional rendering based on role */}
          {role === "admin" && <AdminDashboard />}
          {role === "researcher" && <ResearcherDashboard user={user} />}
          {role === "participant" && <ParticipantDashboard user={user} />}
          {role === "guest" && <GuestDashboard />}
          {role === "reviewer" && <ReviewerDashboard />}

          {!role && (
            <div className="muted">
              No role-specific content available for your account.
            </div>
          )}
        </div>

      </div>
    </div>
  );
}
