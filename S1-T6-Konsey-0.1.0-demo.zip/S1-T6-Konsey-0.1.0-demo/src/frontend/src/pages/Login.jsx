import React, { useState, useContext } from "react";
import { Link, useNavigate } from "react-router-dom";
import api from "../api";
import { AuthContext } from "../auth/AuthProvider";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState("");
  const navigate = useNavigate();
  const { setUser } = useContext(AuthContext);

  async function handleSubmit(e) {
    e.preventDefault();
    setErr("");
    try {
      const res = await api.post("/api/users/login", { email, password });
      const data = res.data;
      const token = data.accessToken;
      if (!token) {
        setErr("Login response did not include accessToken.");
        return;
      }
      localStorage.setItem("token", token);

      const meRes = await api.get("/api/users/me");
      setUser(meRes.data);
      navigate("/dashboard");
    } catch (error) {
      console.error(error);
      setErr(
        error?.response?.data?.message ||
          error?.response?.data ||
          "Login failed"
      );
    }
  }

  async function handleGuest() {
    setErr("");
    try {
      const res = await api.post("/api/users/guest");
      const data = res.data;
      const token = data.accessToken;
      if (!token) {
        setErr("Guest login response did not include accessToken.");
        return;
      }
      localStorage.setItem("token", token);
      const meRes = await api.get("/api/users/me");
      setUser(meRes.data);
      navigate("/dashboard");
    } catch (error) {
      console.error(error);
      setErr("Unable to start guest session.");
    }
  }

  return (
    <div className="center-screen">
      <form className="card card--narrow" onSubmit={handleSubmit}>
        <h2>Sign in</h2>
        {err && <div className="error">{String(err)}</div>}

        <label>Email</label>
        <input
          className="input-dark"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />

        <label>Password</label>
        <input
          className="input-dark"
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />

        <button type="submit" className="btn">Sign in</button>

        <div className="muted">
          No account? <Link to="/register">Register</Link>
        </div>

        <hr className="auth-divider" />

        <button type="button" onClick={handleGuest} className="btn btn-ghost">
          Continue as Guest
        </button>
      </form>
    </div>
  );
}
