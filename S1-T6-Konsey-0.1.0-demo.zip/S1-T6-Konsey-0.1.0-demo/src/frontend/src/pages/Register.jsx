import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import api from "../api";
import TermsModal from "../components/TermsModal"; // ⬅️ import the modal

export default function Register() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [err, setErr] = useState("");
  const [success, setSuccess] = useState("");
  const [showTerms, setShowTerms] = useState(false); // ⬅️ modal control
  const navigate = useNavigate();

  async function registerUser() {
    try {
      await api.post("/api/users/register", { email, password, displayName });
      setSuccess("Registered successfully. Please login.");
      setTimeout(() => navigate("/login"), 1000);
    } catch (error) {
      console.error(error);
      setErr(
        error?.response?.data?.message ||
          error?.response?.data ||
          "Registration failed"
      );
    }
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setErr("");
    setSuccess("");
    setShowTerms(true); // show the terms modal instead of submitting immediately
  }

  const handleAgree = () => {
    setShowTerms(false);
    registerUser();
  };

  return (
    <div className="center-screen">
      <form className="card card--narrow" onSubmit={handleSubmit}>
        <h2>Create account</h2>
        {err && <div className="error">{String(err)}</div>}
        {success && <div className="success">{success}</div>}

        <label>Display Name</label>
        <input
          className="input-dark"
          value={displayName}
          onChange={(e) => setDisplayName(e.target.value)}
          required
        />

        <label>Email</label>
        <input
          className="input-dark"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />

        <label>Password</label>
        <input
          className="input-dark"
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />

        <button type="submit" className="btn">Register</button>

        <div className="muted">
          Have an account? <Link to="/login">Sign in</Link>
        </div>
      </form>

      {showTerms && (
        <TermsModal onAgree={handleAgree} onClose={() => setShowTerms(false)} />
      )}
    </div>
  );
}
