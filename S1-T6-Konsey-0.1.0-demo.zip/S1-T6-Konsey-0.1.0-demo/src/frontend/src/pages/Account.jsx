import React, { useEffect, useState, useContext } from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "../components/Navbar";
import api from "../api";
import { AuthContext } from "../auth/AuthProvider";
import RoleApplicationStatusModal from "../components/AccountModals/RoleApplicationStatusModal";

export default function Account() {
  const navigate = useNavigate();
  const { logout } = useContext(AuthContext) || {};

  const [loading, setLoading] = useState(true);

  const [form, setForm] = useState({
    email: "",
    displayName: "",
    currentPassword: "",
    newPassword: "",
  });

  const [role, setRole] = useState("");
  const [application, setApplication] = useState(null);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [deleting, setDeleting] = useState(false);

  const [showStatusModal, setShowStatusModal] = useState(false);

  useEffect(() => {
    const controller = new AbortController();

    const fetchMe = async () => {
      setLoading(true);
      setError("");
      try {
        const res = await api.get("/api/users/me", {
          signal: controller.signal,
        });

        setForm((prev) => ({
          ...prev,
          email: res.data.email,
          displayName: res.data.displayName,
        }));
        if (res.data.role) {
          setRole(res.data.role);
        }
      } catch (e) {
        if (e.name === "CanceledError") return;
        console.error("Failed to load user", e);
        setError("Failed to load account information.");
      } finally {
        setLoading(false);
      }
    };

    fetchMe();

    return () => controller.abort();
  }, []);

  useEffect(() => {
    const controller = new AbortController();

    const fetchRoleApplication = async () => {
      setLoading(true);
      try {
        const res = await api.get("/api/users/role/mine", {
          signal: controller.signal,
        });
        setApplication(res.data);
      } catch (e) {
        if (e.name === "CanceledError") return;
        setApplication(null);
      } finally {
        setLoading(false);
      }
    };

    fetchRoleApplication();

    return () => controller.abort();
  }, []);

  const handleChange = (field) => (e) => {
    setForm((prev) => ({
      ...prev,
      [field]: e.target.value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setSuccess("");

    if (form.newPassword && !form.currentPassword) {
      setError("Current password is required to set a new password.");
      return;
    }

    try {
      const payload = {
        email: form.email,
        displayName: form.displayName,
      };

      if (form.newPassword) {
        payload.currentPassword = form.currentPassword;
        payload.newPassword = form.newPassword;
      }

      const res = await api.put("api/users/me", payload);

      setForm((prev) => ({
        ...prev,
        email: res.data.email,
        displayName: res.data.displayName,
        currentPassword: "",
        newPassword: "",
      }));
      if (res.data.role) {
        setRole(res.data.role);
      }

      setSuccess("Account updated successfully.");
    } catch (e) {
      console.error("Failed to update account", e);
      const msg =
        e.response?.data?.detail ||
        e.response?.data?.message ||
        e.response?.data?.error ||
        e.response?.data?.title ||
        "Failed to update account.";
      setError(msg);
    }
  };

  const handleDelete = async () => {
    setError("");
    setSuccess("");

    const confirmed = window.confirm(
      "This will permanently delete your account and cannot be undone. Do you want to continue?"
    );
    if (!confirmed) return;

    try {
      setDeleting(true);
      await api.delete("api/users/me");

      if (logout) {
        logout();
      }
      navigate("/");
    } catch (e) {
      console.error("Failed to delete account", e);
      const msg =
        e.response?.data?.detail ||
        e.response?.data?.message ||
        e.response?.data?.error ||
        e.response?.data?.title ||
        "Failed to delete account.";
      setError(msg);
    } finally {
      setDeleting(false);
    }
  };

  if (loading) {
    return (
      <>
        <Navbar />
        <div className="center-screen">
          <div className="card">
            <h2>Account</h2>
            <p className="muted">Loading account information…</p>
          </div>
        </div>
      </>
    );
  }

  return (
    <>
      <Navbar />
      <div className="center-screen">
        <div className="card card--narrow">
          <div className="topbar">
            <h2>Account</h2>
          </div>

          <div className="topbar" style={{ marginTop: "6px" }}>
            {role && (
              <span className="muted" style={{ fontSize: "12px" }}>
                Role: {role}
              </span>
            )}

            {role && role === "PARTICIPANT" && !application && (
              <button
                onClick={() => navigate("/account/role-application")}
                className="btn"
              >
                Apply for role change
              </button>
            )}

            {role && role === "PARTICIPANT" && application && (
              <button
                type="button"
                onClick={() => setShowStatusModal(true)}
                className="btn"
              >
                See role change application
              </button>
            )}
          </div>

          {error && <div className="error">{error}</div>}
          {success && <div className="success">{success}</div>}

          <form onSubmit={handleSubmit}>
            {/* Email */}
            <label htmlFor="email">Email</label>
            <input
              id="email"
              className="input-dark"
              type="email"
              value={form.email}
              onChange={handleChange("email")}
              required
            />

            {/* Display name */}
            <label htmlFor="displayName">Display name</label>
            <input
              id="displayName"
              className="input-dark"
              type="text"
              value={form.displayName}
              onChange={handleChange("displayName")}
              required
            />

            <hr
              style={{
                marginTop: "16px",
                marginBottom: "8px",
                border: 0,
                borderTop: "1px solid rgba(148,163,184,0.4)",
              }}
            />

            <label htmlFor="currentPassword">Current password</label>
            <input
              id="currentPassword"
              className="input-dark"
              type="password"
              value={form.currentPassword}
              onChange={handleChange("currentPassword")}
              placeholder="Required if you set a new password"
            />

            <label htmlFor="newPassword">New password</label>
            <input
              id="newPassword"
              className="input-dark"
              type="password"
              value={form.newPassword}
              onChange={handleChange("newPassword")}
              placeholder="Leave empty to keep current password"
            />

            <button type="submit" className="btn">
              Save changes
            </button>
          </form>

          {/* Danger zone */}
          <div
            style={{
              marginTop: "20px",
              paddingTop: "12px",
              borderTop: "1px solid rgba(148,163,184,0.35)",
            }}
          >
            <button
              type="button"
              onClick={handleDelete}
              disabled={deleting}
              className="btn small"
              style={{
                background: "transparent",
                color: "var(--danger)",
                border: "1px solid rgba(248,113,113,0.7)",
                marginTop: 0,
              }}
            >
              {deleting ? "Deleting…" : "Delete my account"}
            </button>
          </div>
        </div>
      </div>

      {/* Modal rendered at root level so it overlays everything */}
      <RoleApplicationStatusModal
        application={application}
        open={showStatusModal}
        onClose={() => setShowStatusModal(false)}
      />
    </>
  );
}
