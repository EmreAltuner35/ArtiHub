import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import Navbar from "../components/Navbar";
import api from "../api";

export default function QuizDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [quiz, setQuiz] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchQuiz();
  }, [id]);

  const fetchQuiz = async () => {
    try {
      setLoading(true);
      const response = await api.get(`/api/quizzes/${id}`);
      setQuiz(response.data);
    } catch (err) {
      console.error("Failed to fetch quiz:", err);
      alert("Failed to load quiz. Please try again.");
      navigate("/quizzes");
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <>
        <Navbar />
        <div style={{ padding: 24 }}>
          <div className="muted">Loading quiz...</div>
        </div>
      </>
    );
  }

  if (!quiz) {
    return (
      <>
        <Navbar />
        <div style={{ padding: 24 }}>
          <div className="muted">Quiz not found</div>
        </div>
      </>
    );
  }

  return (
    <>
      <Navbar />
      <div style={{ padding: 24, maxWidth: 1000, margin: "0 auto" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24 }}>
          <h2>{quiz.title}</h2>
          <div style={{ display: "flex", gap: 8 }}>
            <button onClick={() => navigate("/quizzes")} className="btn small">
              Back to Quizzes
            </button>
            <button onClick={() => navigate(`/quizzes/${id}/edit`)} className="btn small">
              Edit
            </button>
          </div>
        </div>

        <div className="card" style={{ marginBottom: 24 }}>
          <h3>Quiz Information</h3>
          <div style={{ marginBottom: 12 }}>
            <strong>Title:</strong> {quiz.title}
          </div>
          {quiz.description && (
            <div style={{ marginBottom: 12 }}>
              <strong>Description:</strong> {quiz.description}
            </div>
          )}
          <div style={{ marginBottom: 12 }}>
            <strong>Status:</strong> {quiz.status}
          </div>
          {quiz.studyId && (
            <div style={{ marginBottom: 12 }}>
              <strong>Study ID:</strong> {quiz.studyId}
            </div>
          )}
          <div style={{ marginBottom: 12 }}>
            <strong>Number of Questions:</strong> {quiz.questions?.length || 0}
          </div>
          {quiz.createdAt && (
            <div style={{ marginBottom: 12 }}>
              <strong>Created:</strong> {new Date(quiz.createdAt).toLocaleString()}
            </div>
          )}
          {quiz.updatedAt && (
            <div>
              <strong>Last Updated:</strong> {new Date(quiz.updatedAt).toLocaleString()}
            </div>
          )}
        </div>

        <div>
          <h3>Questions</h3>
          {quiz.questions && quiz.questions.length > 0 ? (
            <div style={{ display: "grid", gap: 16 }}>
              {quiz.questions.map((question, qIndex) => (
                <div key={qIndex} className="card">
                  <div style={{ marginBottom: 12 }}>
                    <strong>Question {qIndex + 1}:</strong> {question.questionText}
                  </div>
                  <div style={{ marginBottom: 8 }}>
                    <strong>Type:</strong> {question.questionType}
                  </div>
                  <div>
                    <strong>Answers:</strong>
                    <ul style={{ marginTop: 8, paddingLeft: 20 }}>
                      {question.answers.map((answer, aIndex) => (
                        <li
                          key={aIndex}
                          style={{
                            marginBottom: 8,
                            color: answer.isCorrect ? "var(--accent)" : "var(--text)",
                            fontWeight: answer.isCorrect ? 600 : 400,
                          }}
                        >
                          {answer.answerText} {answer.isCorrect && "✓ (Correct)"}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="card">
              <p className="muted">No questions in this quiz</p>
            </div>
          )}
        </div>
      </div>
    </>
  );
}

