import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "../components/Navbar";
import FolderPicker from "../components/FolderPicker";
import ArtifactList from "../components/ArtifactList";
import ArtifactFilterPanel from "../components/ArtifactFilterPanel";
import api from "../api";

const ARTIFACT_PAGE_SIZE = 12;
const FOLDER_PAGE_SIZE = 12;

export default function Artifacts() {
  const navigate = useNavigate();

  const [search, setSearch] = useState("");
  const [page, setPage] = useState(0);

  const [currentFolderId, setCurrentFolderId] = useState(null);
  const [currentFolderName, setCurrentFolderName] = useState(null);

  const [folderPage, setFolderPage] = useState(0);
  const [folders, setFolders] = useState([]);
  const [folderTotalPages, setFolderTotalPages] = useState(0);
  const [folderTotalElements, setFolderTotalElements] = useState(0);
  const [folderLoading, setFolderLoading] = useState(false);
  const [folderError, setFolderError] = useState("");
  const [folderPanelOpen, setFolderPanelOpen] = useState(false);

  const [selectedFilterTags, setSelectedFilterTags] = useState([]);
  const [dateFrom, setDateFrom] = useState(null);
  const [dateTo, setDateTo] = useState(null);
  const [sortBy, setSortBy] = useState("createdAt");
  const [sortDir, setSortDir] = useState("desc");
  const [requireAll, setRequireAll] = useState(false);

  const [artifacts, setArtifacts] = useState([]);
  const [totalPages, setTotalPages] = useState(0);
  const [totalElements, setTotalElements] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  // Reloads
  const [artifactReloadToken, setArtifactReloadToken] = useState(0);
  const [folderReloadToken, setFolderReloadToken] = useState(0);

  const debouncedSearch = useDebounce(search, 300);

  useEffect(() => {
    if (currentFolderId !== null) return;

    const controller = new AbortController();

    const fetchFolders = async () => {
      setFolderLoading(true);
      setFolderError("");

      try {
        const res = await api.get("/api/artifacts/folders", {
          params: { page: folderPage, size: FOLDER_PAGE_SIZE },
          signal: controller.signal,
        });

        const pageData = res.data || {};
        setFolders(pageData.content || []);
        setFolderTotalPages(pageData.totalPages ?? 0);
        setFolderTotalElements(pageData.totalElements ?? 0);
      } catch (e) {
        if (e.name !== "CanceledError" && e.name !== "AbortError") {
          console.error("Failed to fetch folders:", e);
          setFolderError("Failed to load folders");
        }
      } finally {
        setFolderLoading(false);
      }
    };

    fetchFolders();
    return () => controller.abort();
  }, [currentFolderId, folderPage, folderReloadToken]);

  useEffect(() => {
    const controller = new AbortController();

    const fetchPage = async () => {
      setLoading(true);
      setError("");

      const params = { page, size: ARTIFACT_PAGE_SIZE, sortBy, sortDir };

      if (debouncedSearch?.trim()) params.q = debouncedSearch.trim();
      params.tags = selectedFilterTags;

      const fromStr = formatLocalDate(dateFrom);
      const toStr = formatLocalDate(dateTo);

      if (fromStr) params.from = fromStr;
      if (toStr) params.to = toStr;

      params.requireAll = requireAll;
      params.folderId = currentFolderId;

      try {
        const res = await api.get("/api/artifacts", { params, signal: controller.signal });
        setArtifacts(res.data.content ?? []);
        setTotalPages(res.data.totalPages ?? 0);
        setTotalElements(res.data.totalElements ?? 0);
      } catch (e) {
        if (e.name !== "CanceledError" && e.name !== "AbortError") {
          console.error("Failed to fetch paged artifacts:", e);
          setError("Failed to load artifacts");
        }
      } finally {
        setLoading(false);
      }
    };

    fetchPage();
    return () => controller.abort();
  }, [
    page,
    debouncedSearch,
    selectedFilterTags,
    dateFrom,
    dateTo,
    sortBy,
    sortDir,
    requireAll,
    currentFolderId,
    artifactReloadToken,
  ]);

  const changeFolder = (folderId) => {
    setCurrentFolderId(folderId);
    setPage(0);
  };

  // reset page on any filter change
  const onChangeSearch = (e) => { setSearch(e.target.value); setPage(0); };
  const onSelectedFilterTags = (e) => { setSelectedFilterTags(e); setPage(0); };
  const onFromChange = (e) => { setDateFrom(e); setPage(0); };
  const onToChange = (e) => { setDateTo(e); setPage(0); };
  const onSortByChange = (e) => { setSortBy(e.target.value); setPage(0); };
  const onSortDirChange = (e) => { setSortDir(e.target.value); setPage(0); };
  const onTagsModeChange = (all) => { setRequireAll(all); setPage(0); };

  const handleFolderClick = (folder) => {
    setCurrentFolderId(folder.id);
    setCurrentFolderName(folder.name || null);
    setPage(0);
  };

  const handleBackToRoot = () => {
    setCurrentFolderId(null);
    setCurrentFolderName(null);
    setPage(0);
    setFolderPage(0);
  };

  const handleDeleteArtifact = async (artifactId) => {
    const confirmed = window.confirm("Delete this artifact? This cannot be undone.");
    if (!confirmed) return;

    try {
      await api.delete(`/api/artifacts/${artifactId}`);

      setArtifacts((prev) => prev.filter((a) => a.id !== artifactId));
      setTotalElements((prev) => Math.max(0, prev - 1));

      setArtifactReloadToken((t) => t + 1);
    } catch (e) {
      console.error("Failed to delete artifact:", e);
      alert("Failed to delete artifact.");
    }
  };

  const handleDeleteFolder = async (folder) => {
    const confirmed = window.confirm(
      `Delete folder "${folder.name}" and its contents? This cannot be undone.`
    );
    if (!confirmed) return;

    try {
      await api.delete(`/api/artifacts/folders/${folder.id}`);

      setFolders((prev) => prev.filter((f) => f.id !== folder.id));
      setFolderTotalElements((prev) => Math.max(0, prev - 1));

      if (currentFolderId === folder.id) {
        handleBackToRoot();
      }

      setFolderReloadToken((t) => t + 1);
    } catch (e) {
      console.error("Failed to delete folder:", e);
      alert("Failed to delete folder.");
    }
  };

  return (
    <>
      <Navbar />

      <div className="page">
        <header className="page-header">
          <div>
            <h1 className="page-title">Artifacts</h1>
          </div>
        </header>

        <div className="artifacts-layout">
          <ArtifactFilterPanel
            selectedFilterTags={selectedFilterTags}
            onSelectedFilterTags={onSelectedFilterTags}
            dateFrom={dateFrom}
            onFromChange={onFromChange}
            dateTo={dateTo}
            onToChange={onToChange}
            sortBy={sortBy}
            onSortByChange={onSortByChange}
            sortDir={sortDir}
            onSortDirChange={onSortDirChange}
            requireAll={requireAll}
            onTagsModeChange={onTagsModeChange}
          />

          <main className="artifacts-main">
            <div className="artifacts-topbar">
              <input
                type="text"
                placeholder="Search artifacts"
                value={search}
                onChange={onChangeSearch}
                className="input-dark artifacts-search-input"
              />
              <button
                onClick={() => navigate("/artifacts/generate")}
                className="btn btn-ai"
              >
                Generate
              </button>
              <button
                className="btn"
                onClick={() => navigate("/artifacts/upload")}
              >
                Upload
              </button>
            </div>

            <div className="artifacts-breadcrumb">
              {currentFolderId == null ? (
                <span>
                  Viewing <strong>root</strong> artifacts
                </span>
              ) : (
                <>
                  <span>
                    Viewing folder:{" "}
                    <strong>{currentFolderName || "Selected folder"}</strong>
                  </span>
                  <button
                    type="button"
                    onClick={handleBackToRoot}
                    className="btn btn-ghost btn-sm artifacts-back-btn"
                  >
                    Back to root
                  </button>
                </>
              )}
            </div>

            {currentFolderId == null && (
              <FolderPicker
                open={folderPanelOpen}
                onToggle={() => setFolderPanelOpen((o) => !o)}
                folders={folders}
                page={folderPage}
                totalPages={folderTotalPages}
                totalElements={folderTotalElements}
                loading={folderLoading}
                error={folderError}
                onPageChange={setFolderPage}
                onFolderClick={handleFolderClick}
                onDeleteFolder={handleDeleteFolder}
              />
            )}

            <ArtifactList
              artifacts={artifacts}
              page={page}
              totalPages={totalPages}
              totalElements={totalElements}
              pageSize={ARTIFACT_PAGE_SIZE}
              onPageChange={setPage}
              isLoading={loading}
              error={error}
              onDeleteArtifact={handleDeleteArtifact}
            />
          </main>
        </div>
      </div>
    </>
  );
}

/** debounce hook */
function useDebounce(value, delayMs) {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const t = setTimeout(() => setDebounced(value), delayMs);
    return () => clearTimeout(t);
  }, [value, delayMs]);
  return debounced;
}

function formatLocalDate(date) {
  if (!date) return null;
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}
