package com.konsey.artifactservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArtifactServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
