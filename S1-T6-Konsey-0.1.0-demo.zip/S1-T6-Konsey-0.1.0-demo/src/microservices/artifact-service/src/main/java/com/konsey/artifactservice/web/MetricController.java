package com.konsey.artifactservice.web;

import com.konsey.artifactservice.entity.ArtifactMetrics;
import com.konsey.artifactservice.service.MetricService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/artifacts/metrics")
public class MetricController {

    @Autowired
    private MetricService metricService;


    @GetMapping("/{artifactId}")
    public ResponseEntity<ArtifactMetrics> getMetricByArtifactId(@PathVariable UUID artifactId) {
        return metricService.findByArtifactId(artifactId)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
}