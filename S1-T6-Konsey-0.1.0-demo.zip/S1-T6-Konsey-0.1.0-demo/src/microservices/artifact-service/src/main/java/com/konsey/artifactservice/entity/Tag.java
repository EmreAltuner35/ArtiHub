package com.konsey.artifactservice.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.UuidGenerator;

import java.util.UUID;

/**
 * Normalized tag entity shared across artifacts.
 *
 * <p>Stores a unique, lowercase {@code name}. This avoids duplication and enables fast lookup/filtering.</p>
 */
@Entity
@Table(
        name = "tag",
        uniqueConstraints = @UniqueConstraint(name = "uq_tag_name", columnNames = "name"),
        indexes = @Index(name = "idx_tag_name", columnList = "name")
)
@AllArgsConstructor
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@Builder
@Getter
@Setter
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class Tag {

    /** Primary key (UUID). */
    @Id
    @GeneratedValue
    @UuidGenerator
    @EqualsAndHashCode.Include
    @Column(nullable = false, columnDefinition = "uuid")
    private UUID id;

    /** Predefined tag name. */
    @Column(nullable = false)
    private String name;

    @Override
    public String toString() {
        return this.name;
    }
}
