package com.konsey.artifactservice.repository;

import com.konsey.artifactservice.entity.Artifact;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.UUID;

/**
 * Repository for {@link Artifact}.
 *
 * <p>Extends {@link JpaSpecificationExecutor} to support dynamic, composable filters
 * (e.g., owner, time ranges, type, contentType, tags) together with pagination and sorting.</p>
 */
public interface ArtifactRepository extends JpaRepository<Artifact, UUID>, JpaSpecificationExecutor<Artifact> {

    Page<Artifact> findByTitleContainingIgnoreCase(String title, Pageable pageable);
}
