package com.konsey.artifactservice.repository;

import com.konsey.artifactservice.entity.ArtifactMetrics;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;
import java.util.UUID;

public interface ArtifactMetricsRepository
        extends JpaRepository<ArtifactMetrics, UUID> {

    Optional<ArtifactMetrics> findByArtifactId(UUID artifactId);
}

