package com.konsey.artifactservice.web;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.konsey.artifactservice.dto.*;
import com.konsey.artifactservice.service.ArtifactService;
import com.konsey.artifactservice.service.UploadService;
import com.konsey.artifactservice.service.descriptor.ArtifactFileDescriptor;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

/**
 * HTTP API for artifact operations.
 *
 * <p>This controller currently exposes a single endpoint for uploading an artifact as a
 * multipart form. The binary payload is sent as the {@code file} part, and the structured
 * metadata is sent as the {@code meta} part (JSON). The endpoint delegates to
 * {@link UploadService} to enforce policy, stage bytes, upload to object storage, resolve tags,
 * and build the {@link ArtifactDto} response.</p>
 *
 * <p><strong>Multipart contract</strong>:</p>
 * <ul>
 *   <li>{@code file}: the binary content (multipart field name must be exactly {@code "file"})</li>
 *   <li>{@code metaJson}: JSON matching {@link UploadSingleArtifactRequest} (field name must be {@code "meta"})</li>
 * </ul>
 *
 * <p>On success, the endpoint returns {@code 201 Created} with an {@link ArtifactDto} payload.</p>
 */
@RestController
@RequestMapping("/api/artifacts")
public class ArtifactController {

    /** Application service handling the end-to-end upload workflow. */
    @Autowired
    private UploadService uploadService;

    @Autowired
    private ArtifactService artifactService;

    @Autowired
    private ObjectMapper objectMapper;

    @PostMapping("/bulk")
    ArtifactFolderDto uploadBulk(
            @RequestPart("file") MultipartFile file,
            @Valid @RequestPart("meta") String metaJson
    ) throws IOException {
        UploadBulkArtifactRequest meta = objectMapper.readValue(metaJson, UploadBulkArtifactRequest.class);
        return uploadService.handleBulkUpload(file, meta);
    }

    /**
     * Upload a single artifact via multipart/form-data.
     *
     * <p>The request must contain:</p>
     * <ul>
     *   <li>{@code file}: raw bytes of the artifact</li>
     *   <li>{@code meta}: JSON body with owner/type/title/tags/aiGenerated</li>
     * </ul>
     *
     * <p>Validation errors on {@code meta} yield {@code 400 Bad Request} with a ProblemDetail body
     * (see your {@code RestExceptionHandler}). Policy violations (size/extension) also return 400.</p>
     *
     * @param file multipart part containing the binary file to upload
     * @param metaJson multipart part containing JSON metadata; validated with {@link jakarta.validation} annotations
     * @return an {@link ArtifactDto} describing the stored artifact
     * @throws IOException if local staging or stream handling fails
     */
    @Operation(
            summary = "Upload an artifact (multipart)",
            description = """
            Expects multipart/form-data with:
            - file: binary content
            - meta: JSON matching CreateArtifactRequest

            Service validates policy, computes SHA-256, determines Content-Type,
            stores bytes to object storage, resolves tags, and returns an ArtifactDto.
            """,
            responses = {
                    @ApiResponse(responseCode = "201", description = "Artifact created",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = ArtifactDto.class))),
                    @ApiResponse(responseCode = "400", description = "Validation / policy error",
                            content = @Content(mediaType = "application/problem+json")),
                    @ApiResponse(responseCode = "500", description = "Unexpected error",
                            content = @Content(mediaType = "application/problem+json"))
            }
    )
    @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @ResponseStatus(HttpStatus.CREATED)
    ArtifactDto uploadSingle(
            @Parameter(
                    name = "file",
                    description = "Binary file content (multipart field: file)",
                    required = true,
                    content = @Content(
                            mediaType = MediaType.APPLICATION_OCTET_STREAM_VALUE,
                            schema = @Schema(type = "string", format = "binary")
                    )
            )
            @RequestPart("file") MultipartFile file,
            @Parameter(
                    name = "meta",
                    description = "Artifact metadata as JSON (multipart field: meta)",
                    required = true,
                    content = @Content(
                            mediaType = MediaType.APPLICATION_JSON_VALUE,
                            schema = @Schema(implementation = UploadSingleArtifactRequest.class)
                    )
            )
            @Valid @RequestPart("meta") String metaJson) throws IOException {
        UploadSingleArtifactRequest meta = objectMapper.readValue(metaJson, UploadSingleArtifactRequest.class);
        return uploadService.handleSingleUpload(
                file.getInputStream(),
                file.getOriginalFilename(),
                file.getSize(),
                file.getContentType(),
                meta,
                null
        );
    }

    @GetMapping
    PageResponse<ArtifactDto> getArtifacts(
            @RequestParam(required = false) String q,
            @RequestParam(required = false, name = "tags") List<String> tags,
            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to,
            @RequestParam(defaultValue = "createdAt") String sortBy,
            @RequestParam(defaultValue = "desc") String sortDir,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "false") boolean requireAll,
            @RequestParam(defaultValue = "") UUID folderId
    ) {
        return artifactService.getArtifacts(q, tags, from, to, sortBy, sortDir, page, size, requireAll, folderId);
    }

    @GetMapping(path = "/{artifactId}")
    ArtifactDto getArtifact(@PathVariable UUID artifactId) {
        return artifactService.searchArtifactByUUID(artifactId);
    }

    @GetMapping(path = "/{artifactId}/file")
    ResponseEntity<Resource> getArtifactFile(
            @PathVariable UUID artifactId,
            @RequestParam(name = "download", defaultValue = "1") boolean download
    ) {
        ArtifactFileDescriptor descriptor = artifactService.getArtifactFile(artifactId);

        ContentDisposition disposition = ContentDisposition.builder(download ? "attachment" : "inline")
                .name(descriptor.fileName())
                .build();

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.parseMediaType(descriptor.contentType()));
        headers.setContentDisposition(disposition);

        return ResponseEntity.ok().headers(headers).body(descriptor.resource());
    }

    @DeleteMapping(path = "/{artifactId}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    void deleteArtifact(
            @PathVariable UUID artifactId
    ) {
        artifactService.deleteArtifact(artifactId);
    }
}
