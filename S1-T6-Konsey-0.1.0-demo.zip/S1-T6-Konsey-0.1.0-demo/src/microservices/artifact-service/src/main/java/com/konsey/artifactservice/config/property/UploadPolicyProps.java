package com.konsey.artifactservice.config.property;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.Set;

/**
 * Service-level upload policy.
 *
 * <p>Bound from {@code app.upload.*}. Complements servlet multipart limits with
 * business rules (size cap, extension allowlist).</p>
 *
 * <p>Example:</p>
 * <pre>{@code
 * app.upload.maxFileSizeBytes=52428800
 * app.upload.allowExtensions=pdf,png,jpg,jpeg,txt,md,json,xml
 * }</pre>
 *
 * @param maxFileSizeBytes  maximum allowed file size in bytes (service-enforced)
 * @param allowedExtensions   lowercase filename extensions allowed; empty = allow all
 */
@ConfigurationProperties("app.upload")
public record UploadPolicyProps(
        long maxFileSizeBytes,
        Set<String> allowedExtensions
) {}
