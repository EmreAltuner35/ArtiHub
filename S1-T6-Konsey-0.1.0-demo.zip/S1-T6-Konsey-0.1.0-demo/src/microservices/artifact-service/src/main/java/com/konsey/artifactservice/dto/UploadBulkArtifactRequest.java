package com.konsey.artifactservice.dto;

import jakarta.validation.constraints.NotBlank;

public record UploadBulkArtifactRequest(
    @NotBlank String folderPath
) {}
