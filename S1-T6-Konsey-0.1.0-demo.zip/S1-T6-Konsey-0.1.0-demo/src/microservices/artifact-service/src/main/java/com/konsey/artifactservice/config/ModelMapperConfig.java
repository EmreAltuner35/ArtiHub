package com.konsey.artifactservice.config;

import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Application configuration for ModelMapper.
 *
 * <p>Provides a single {@link ModelMapper} instance configured for predictable,
 * refactor-safe DTO–entity mappings (e.g., strict matching, field access, null-skipping).
 * Centralizing this setup ensures consistent mapping behavior across the application
 * and keeps mapping concerns out of business components.</p>
 */
@Configuration
public class ModelMapperConfig {
    public ModelMapperConfig() {
    }

    /**
     * Configure a {@link ModelMapper} for DTO↔entity mapping.
     *
     * @return a {@link ModelMapper} with STRICT matching, field access, and skip-null enabled
     */
    @Bean
    ModelMapper modelMapper() {
        var mapper = new ModelMapper();

        // STRICT: safer mappings; avoids accidental property matches on rename/refactor
        // Field matching + PRIVATE: allows mapping with Lombok-generated accessors or private fields
        // Skip nulls: useful for PATCH-like updates (won't overwrite with null)
        mapper.getConfiguration()
                .setMatchingStrategy(MatchingStrategies.STRICT)
                .setFieldMatchingEnabled(true)
                .setFieldAccessLevel(org.modelmapper.config.Configuration.AccessLevel.PRIVATE)
                .setSkipNullEnabled(true);

        return mapper;
    }
}