package com.konsey.artifactservice.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;
import java.util.Set;
import java.util.UUID;

/**
 * Response DTO for artifact metadata.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ArtifactDto {
    private UUID id;
    private UUID ownerId;
    private String title;
    private String type;
    private String contentType;
    private boolean isAIGenerated;
    private String storageKey;
    private Instant createdAt;
    private String sha256;
    private long sizeBytes;
    private Set<String> tags;
}