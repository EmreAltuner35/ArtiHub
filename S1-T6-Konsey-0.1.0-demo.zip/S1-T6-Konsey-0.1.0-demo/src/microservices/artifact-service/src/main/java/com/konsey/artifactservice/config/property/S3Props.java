package com.konsey.artifactservice.config.property;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Immutable, strongly-typed configuration for the S3-compatible object store (e.g., MinIO).
 *
 * <p>Values are bound from external configuration using the prefix
 * {@code app.storage.s3}. For example, in {@code application.properties}:</p>
 *
 * <pre>{@code
 * app.storage.s3.endpoint=http://localhost:9000
 * app.storage.s3.accessKey=minio
 * app.storage.s3.secretKey=minio12345
 * app.storage.s3.bucket=artifacts
 * app.storage.s3.pathStyleAccess=true
 * app.storage.s3.autoCreateBucket=true
 * }</pre>
 *
 * <p>Typical usage is constructor injection into configuration classes to
 * construct SDK clients and initializers.</p>
 *
 * @param endpoint          base URL of the S3-compatible service
 * @param accessKey         access key for SDK auth
 * @param secretKey         secret key for SDK auth
 * @param bucket            default bucket to store artifact objects
 * @param pathStyleAccess   use path-style URLs; keep {@code true} for localhost/MinIO
 * @param autoCreateBucket  create the bucket at startup when enabled
 */
@ConfigurationProperties(prefix = "app.storage.s3")
public record S3Props(
        String endpoint,
        String accessKey,
        String secretKey,
        String bucket,
        boolean pathStyleAccess,
        boolean autoCreateBucket
) {}
