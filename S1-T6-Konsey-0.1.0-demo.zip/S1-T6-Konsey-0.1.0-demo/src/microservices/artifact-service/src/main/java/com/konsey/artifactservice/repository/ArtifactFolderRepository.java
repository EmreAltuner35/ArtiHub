package com.konsey.artifactservice.repository;

import com.konsey.artifactservice.entity.ArtifactFolder;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.Optional;
import java.util.UUID;

public interface ArtifactFolderRepository extends JpaRepository<ArtifactFolder, UUID>,
        JpaSpecificationExecutor<ArtifactFolder> {
    Page<ArtifactFolder> findAllByOwnerIdAndNameContainingIgnoreCase(UUID userId, String name, Pageable pageable);
    Optional<ArtifactFolder> findByOwnerIdAndName(UUID userId, String name);
}
