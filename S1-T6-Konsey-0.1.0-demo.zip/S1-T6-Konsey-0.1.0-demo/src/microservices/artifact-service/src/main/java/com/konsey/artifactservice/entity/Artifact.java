package com.konsey.artifactservice.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.Instant;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.UUID;

/**
 * Artifact metadata persisted in PostgreSQL.
 *
 * <p>Binary content is stored externally (e.g., MinIO/S3) and referenced via {@link #storageKey}.
 * This entity tracks ownership, classification (type/extension), content identity (sha256),
 * and tag associations. It is NOT a JPA link to a user table; {@link #ownerId} is an
 * application-level reference.</p>
 *
 * <p>Indexes:</p>
 * <ul>
 *   <li>{@code idx_artifact_owner} → queries by owner</li>
 *   <li>{@code idx_ai_generated} → filter by AI-generated flag</li>
 *   <li>{@code idx_type} → filter by artifact type</li>
 * </ul>
 */
@Entity
@Table(
        name = "artifact",
        indexes = {
                @Index(name = "idx_artifact_owner", columnList = "owner_id"),
                @Index(name = "idx_ai_generated", columnList = "is_ai_generated"),
                @Index(name = "idx_type", columnList = "type")
        },
        uniqueConstraints = {
                @UniqueConstraint(
                        name = "uk_artifact_owner_folder_title",
                        columnNames = {"owner_id", "folder_id", "title"}
                )
        }
)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class Artifact {

    /** Primary key (UUID v4), generated in {@link com.konsey.artifactservice.service.UploadService}. */
    @Id
    @EqualsAndHashCode.Include
    @Column(nullable = false, columnDefinition = "uuid")
    private UUID id;

    /**
     * Application-level reference to the owning user (no cross-service FK).
     * Validate existence via the User service at write time.
     */
    @Column(name = "owner_id" ,nullable = false, columnDefinition = "uuid")
    private UUID ownerId;

    /** Human-readable title. */
    @Column(nullable = false)
    private String title;

    /**
     * Logical type/category (e.g., code, test, design, requirement, bug-report).
     * Use controlled values on the client or validate server-side as needed.
     */
    @Column(nullable = false)
    private String type;

    /**
     * File extension (normalized lowercase, no leading dot).
     * Keep short to remain index-friendly.
     */
    @Column(nullable = false)
    private String contentType;

    /** Whether content was produced by an AI system. */
    @Column(name = "is_ai_generated", nullable = false, columnDefinition = "boolean default false")
    private boolean isAIGenerated;

    /**
     * Object storage key (path-like). Combine with the configured bucket to locate bytes in MinIO/S3.
     * Example: raw/2025/10/25/3f3a1a10-9a2a-4c3f-a9a3-6f9f7f4d9e21
     */
    @Column(name = "storage_key", nullable = false)
    private String storageKey;

    /** Creation timestamp (UTC). Set by service at persist time. */
    @Column(name = "created_at", nullable = false, columnDefinition = "timestamptz")
    private Instant createdAt;

    /** Hex-encoded SHA-256 digest (64 chars) of the uploaded bytes. */
    @Column(nullable = false, length = 64)
    private String sha256;

    /** Size of the stored bytes, in bytes. */
    @Column(name = "size_bytes", nullable = false)
    private long sizeBytes;

    /**
     * Normalized tags linked via join table (no REMOVE cascade; tags are shared).
     * Use a Set to avoid duplicate associations.
     */
    @ManyToMany(fetch = FetchType.LAZY, cascade = {CascadeType.PERSIST, CascadeType.MERGE})
    @JoinTable(
            name = "artifact_tags",
            joinColumns = @JoinColumn(name = "artifact_id"),
            inverseJoinColumns = @JoinColumn(name = "tag_id")
    )
    private Set<Tag> tags = new LinkedHashSet<>();

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "folder_id")
    private ArtifactFolder folder;
}
