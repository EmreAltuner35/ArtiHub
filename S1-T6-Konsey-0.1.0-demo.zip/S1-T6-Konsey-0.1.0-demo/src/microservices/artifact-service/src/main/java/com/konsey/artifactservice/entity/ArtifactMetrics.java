package com.konsey.artifactservice.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.UUID;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "artifact_metrics")
public class ArtifactMetrics {

    @Id
    @GeneratedValue
    private UUID id;

    @Column(name = "artifact_id", nullable = false, unique = true)
    private UUID artifactId;

    @Column
    private double averageCyclomaticComplexity;

    @Column
    private double maintainabilityIndex;
}