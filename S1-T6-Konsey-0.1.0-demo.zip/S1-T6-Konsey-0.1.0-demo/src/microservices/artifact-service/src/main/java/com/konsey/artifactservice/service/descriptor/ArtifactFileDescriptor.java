package com.konsey.artifactservice.service.descriptor;

import org.springframework.core.io.Resource;

public record ArtifactFileDescriptor(
        Resource resource,
        String fileName,
        String contentType
) {
}
