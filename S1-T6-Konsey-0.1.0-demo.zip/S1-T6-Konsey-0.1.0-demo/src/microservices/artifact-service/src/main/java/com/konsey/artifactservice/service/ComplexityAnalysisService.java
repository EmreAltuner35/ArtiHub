package com.konsey.artifactservice.service;

import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class ComplexityAnalysisService {

    private static final Pattern SUMMARY_LINE_PATTERN =
            Pattern.compile("^\\s*\\d+\\s+([\\d.]+)\\s+([\\d.]+)\\s+([\\d.]+)");

    public ComplexityResult analyze(Path file) {

        File artifactFile = file.toFile();

        double avgNLOC = 0.0;
        double avgCCN = 0.0;
        double avgToken = 0.0;

        try {

            ProcessBuilder pb = new ProcessBuilder(
                    "lizard",
                    artifactFile.getAbsolutePath()
            );
            pb.redirectErrorStream(true);

            Process process = pb.start();

            boolean finished = process.waitFor(10, TimeUnit.SECONDS);
            if (!finished) {
                process.destroyForcibly();
                throw new RuntimeException("Complexity analysis timed out");
            }

            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8))) {

                String line;
                while ((line = reader.readLine()) != null) {

                    Matcher matcher = SUMMARY_LINE_PATTERN.matcher(line.trim());

                    if (matcher.find()) {
                        avgNLOC = Double.parseDouble(matcher.group(1).trim());
                        avgCCN = Double.parseDouble(matcher.group(2).trim());
                        avgToken = Double.parseDouble(matcher.group(3).trim());
                        break;
                    }
                }
            }

            int maintainabilityIndex = (int) Math.round((avgCCN + avgNLOC) / 2.0);

            return new ComplexityResult(
                    (int) Math.round(avgCCN),
                    maintainabilityIndex
            );

        } catch (Exception e) {
            System.err.println("Complexity Analysis Failed: " + e.getMessage());
            e.printStackTrace();

            return new ComplexityResult(0, 0);
        }
    }

    public record ComplexityResult(int averageCyclomaticComplexity, int maintainabilityIndex) {}
}