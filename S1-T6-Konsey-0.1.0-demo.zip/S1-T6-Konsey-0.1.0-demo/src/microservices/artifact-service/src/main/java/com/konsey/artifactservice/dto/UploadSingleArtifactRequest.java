package com.konsey.artifactservice.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import java.util.List;

/**
 * Request body (JSON part named "meta") for artifact creation.
 */
public record UploadSingleArtifactRequest(
        @NotBlank String title,
        @NotBlank String type,
        @NotNull boolean isAIGenerated,
        @Size(max = 10) List<@Pattern(regexp = "[a-zA-Z._-]+") String> tags
) {}
