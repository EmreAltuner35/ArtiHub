package com.konsey.artifactservice.web;

import com.konsey.artifactservice.dto.PageResponse;
import com.konsey.artifactservice.dto.TagDto;
import com.konsey.artifactservice.service.TagService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/artifacts")
public class TagController {

    @Autowired
    private TagService tagService;

    @GetMapping("/tags")
    public PageResponse<TagDto> getAllTags(
            @RequestParam(required = true) String q,
            @PageableDefault(size = 5) Pageable pageable
    ) {
        return tagService.getTags(q, pageable);
    }
}
