package com.konsey.artifactservice.service;

import com.konsey.artifactservice.config.property.TagProps;
import com.konsey.artifactservice.dto.PageResponse;
import com.konsey.artifactservice.dto.TagDto;
import com.konsey.artifactservice.entity.Tag;
import com.konsey.artifactservice.repository.TagRepository;
import jakarta.annotation.PostConstruct;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Resolves tags by name: reuses existing rows and creates missing ones.
 *
 * <p>Input names are normalized (trim + lowercase), de-duplicated (order preserved),
 * and returned as persistent {@link Tag} entities suitable for attaching to an artifact.</p>
 */
@Service
public class TagService {

    @Autowired
    private TagRepository tagRepository;

    @Autowired
    private TagProps tagProps;

    @Autowired
    private ModelMapper modelMapper;

    @EventListener(ApplicationReadyEvent.class)
    @Transactional
    public void syncPredefinedTagsOnStartup() {
        List<String> predefinedRaw = tagProps.predefined();
        if (predefinedRaw == null || predefinedRaw.isEmpty())
            return;

        Set<String> desiredTags = predefinedRaw.stream()
                .filter(Objects::nonNull)
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .collect(Collectors.toCollection(LinkedHashSet::new));
        if (desiredTags.isEmpty())
            return;

        List<Tag> existingTags = tagRepository.findAll();

        Set<String> existingNames = existingTags.stream()
                .map(Tag::getName)
                .filter(Objects::nonNull)
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .collect(Collectors.toSet());

        Set<String> tagsToInsert = new LinkedHashSet<>(desiredTags);
        tagsToInsert.removeAll(existingNames);

        Set<String> tagsToRemove = new LinkedHashSet<>(existingNames);
        tagsToRemove.removeAll(desiredTags);

        if (!tagsToInsert.isEmpty()) {
            List<Tag> newTags = tagsToInsert.stream()
                    .map(s -> Tag.builder().name(s).build())
                    .toList();
            tagRepository.saveAll(newTags);
        }

        if (!tagsToRemove.isEmpty())
            tagRepository.deleteByNameIn(tagsToRemove);
    }

    /**
     * Normalize, resolve existing tags, create missing ones, and return an insertion-ordered set.
     *
     * @param rawNames raw tag names (may contain nulls/whitespace/mixed case)
     * @return insertion-ordered {@code Set<Tag>} aligned with normalized input order
     */
    public Set<Tag> resolveTags(Collection<String> rawNames) {
        if(rawNames == null || rawNames.isEmpty())
            return Set.of();

        // Normalize: trim + lowercase + remove blanks; keep first-seen order
        Set<String> names = rawNames.stream()
                .filter(Objects::nonNull)
                .filter(s -> !s.isEmpty())
                .collect(Collectors.toCollection(LinkedHashSet::new));
        if(names.isEmpty())
            return Set.of();

        return new HashSet<>(tagRepository.findAllByNameIn(names));
    }

    public PageResponse<TagDto> getTags(String q, Pageable pageable) {
        String term = q == null ? "" : q.trim();

        Page<Tag> page = tagRepository.findByNameContainingIgnoreCase(term, pageable);

        return PageResponse.<TagDto>builder()
                .content(
                        page.getContent().stream()
                                .map(s -> modelMapper.map(s, TagDto.class))
                                .toList()
                )
                .page(page.getNumber())
                .size(page.getSize())
                .totalPages(page.getTotalPages())
                .totalElements(page.getTotalElements())
                .first(page.isFirst())
                .last(page.isLast())
                .build();
    }
}
