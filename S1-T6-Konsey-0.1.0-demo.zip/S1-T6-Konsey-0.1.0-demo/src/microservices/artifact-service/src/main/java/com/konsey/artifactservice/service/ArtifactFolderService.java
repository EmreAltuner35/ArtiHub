package com.konsey.artifactservice.service;

import com.konsey.artifactservice.dto.ArtifactFolderDto;
import com.konsey.artifactservice.dto.PageResponse;
import com.konsey.artifactservice.entity.Artifact;
import com.konsey.artifactservice.entity.ArtifactFolder;
import com.konsey.artifactservice.repository.ArtifactFolderRepository;
import com.konsey.artifactservice.utility.SecurityUtils;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class ArtifactFolderService {

    @Autowired
    private ArtifactFolderRepository artifactFolderRepository;

    @Autowired
    private ArtifactService artifactService;

    @Autowired
    private ModelMapper modelMapper;

    @Transactional
    public ArtifactFolder resolveOrCreateFolder(String folderPath) {
        if(folderPath == null)
            return null;

        String name = folderPath.trim();
        if(name.isBlank())
            return null;

        UUID ownerId = SecurityUtils.userId();
        Optional<ArtifactFolder> folder = artifactFolderRepository.findByOwnerIdAndName(ownerId, name);
        if(folder.isPresent())
            return folder.get();

        ArtifactFolder newFolder = ArtifactFolder.builder()
                .ownerId(ownerId)
                .name(name)
                .build();

        return artifactFolderRepository.save(newFolder);
    }

    @Transactional
    public PageResponse<ArtifactFolderDto> getFolders(String q, Pageable pageable) {
        Page<ArtifactFolder> page = artifactFolderRepository
                .findAllByOwnerIdAndNameContainingIgnoreCase(SecurityUtils.userId(), q, pageable);
        List<ArtifactFolderDto> dtos = page.getContent().stream()
                .map(s -> modelMapper.map(s, ArtifactFolderDto.class))
                .toList();
        return PageResponse.<ArtifactFolderDto>builder()
                .content(dtos)
                .page(page.getNumber())
                .size(page.getSize())
                .totalElements(page.getTotalElements())
                .totalPages(page.getTotalPages())
                .first(page.isFirst())
                .last(page.isLast())
                .build();
    }

    public ArtifactFolderDto getFolder(UUID folderId) {
        return modelMapper.map(artifactFolderRepository.findById(folderId).orElseThrow(), ArtifactFolderDto.class);
    }

    public void deleteFolder(UUID folderId) {
        ArtifactFolder folder = artifactFolderRepository.findById(folderId).orElseThrow();
        for(Artifact artifact : folder.getArtifacts())
            artifactService.deleteArtifact(artifact.getId());
        artifactFolderRepository.delete(folder);
    }
}
