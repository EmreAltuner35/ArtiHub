package com.konsey.artifactservice.config.property;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.List;

@ConfigurationProperties(prefix = "app.tags")
public record TagProps (
        List<String> predefined
) {}
