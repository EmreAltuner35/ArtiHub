package com.konsey.artifactservice.service;

import com.konsey.artifactservice.config.property.S3Props;
import com.konsey.artifactservice.dto.ArtifactDto;
import com.konsey.artifactservice.dto.PageResponse;
import com.konsey.artifactservice.entity.Artifact;
import com.konsey.artifactservice.entity.ArtifactFolder;
import com.konsey.artifactservice.repository.ArtifactRepository;
import com.konsey.artifactservice.repository.spec.ArtifactSpecifications;
import com.konsey.artifactservice.service.descriptor.ArtifactFileDescriptor;
import com.konsey.artifactservice.storage.StorageAdapter;
import com.konsey.artifactservice.utility.SecurityUtils;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

@Service
public class ArtifactService {

    @Autowired
    private ArtifactRepository artifactRepository;

    @Autowired
    private StorageAdapter storageAdapter;

    @Autowired
    private S3Props s3Props;

    @Autowired
    private ArtifactSpecifications specs;

    @Autowired
    private ModelMapper modelMapper;

    public PageResponse<ArtifactDto> getArtifacts(
            String q,
            List<String> tags,
            LocalDate from,
            LocalDate to,
            String sortBy,
            String sortDir,
            int page,
            int size,
            boolean requireAll,
            UUID folderId
    ) {
        String sortField = switch (sortBy){
            case "title", "createdAt" -> sortBy;
            default -> "createdAt";
        };
        Sort.Direction dir = "asc".equalsIgnoreCase(sortDir) ? Sort.Direction.ASC : Sort.Direction.DESC;
        Pageable pageable = PageRequest.of(page, size, Sort.by(dir, sortField));

        Specification<Artifact> specification = Specification.allOf(
                specs.folderWith(folderId),
                specs.titleContains(q),
                specs.createdAtBetween(from, to),
                requireAll ? specs.hasAllTags(tags) : specs.hasAnyTag(tags),
                specs.typeNotEqual("FORUM_ATTACHMENT")
        );

        Page<Artifact> resultPage = artifactRepository.findAll(specification, pageable);

        List<ArtifactDto> dtos = resultPage.getContent()
                .stream().map(s -> modelMapper.map(s, ArtifactDto.class))
                .toList();

        return PageResponse.<ArtifactDto>builder()
                .content(dtos)
                .page(resultPage.getNumber())
                .size(resultPage.getSize())
                .totalElements(resultPage.getTotalElements())
                .totalPages(resultPage.getTotalPages())
                .first(resultPage.isFirst())
                .last(resultPage.isLast())
                .build();
    }

    public ArtifactDto searchArtifactByUUID(UUID artifactId) {
        return modelMapper.map(artifactRepository.findById(artifactId).get(), ArtifactDto.class);
    }

    public ArtifactFileDescriptor getArtifactFile(UUID artifactId) {
        Artifact artifact = artifactRepository.findById(artifactId).orElseThrow();

        Resource resource = storageAdapter.load(s3Props.bucket(), artifact.getStorageKey());

        return new ArtifactFileDescriptor(resource, artifact.getTitle(), artifact.getContentType());
    }

    public void deleteArtifact(UUID artifactId) {
        Artifact artifact = artifactRepository.findById(artifactId).orElseThrow();
        ArtifactFolder folder = artifact.getFolder();

        String key = SecurityUtils.userId() + "/" + (folder == null ? "" : folder.getName() + "/") + artifactId;
        storageAdapter.delete(s3Props.bucket(), key);

        artifactRepository.delete(artifact);
    }
}
