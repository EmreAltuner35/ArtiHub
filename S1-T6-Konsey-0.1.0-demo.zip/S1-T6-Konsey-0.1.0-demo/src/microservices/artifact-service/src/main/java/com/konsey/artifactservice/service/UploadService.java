package com.konsey.artifactservice.service;

import com.konsey.artifactservice.config.property.S3Props;
import com.konsey.artifactservice.config.property.UploadPolicyProps;
import com.konsey.artifactservice.dto.ArtifactDto;
import com.konsey.artifactservice.dto.ArtifactFolderDto;
import com.konsey.artifactservice.dto.UploadBulkArtifactRequest;
import com.konsey.artifactservice.dto.UploadSingleArtifactRequest;
import com.konsey.artifactservice.entity.Artifact;
import com.konsey.artifactservice.entity.ArtifactFolder;
import com.konsey.artifactservice.entity.ArtifactMetrics;
import com.konsey.artifactservice.entity.Tag;
import com.konsey.artifactservice.repository.ArtifactMetricsRepository;
import com.konsey.artifactservice.repository.ArtifactRepository;
import com.konsey.artifactservice.storage.StorageAdapter;
import com.konsey.artifactservice.utility.SecurityUtils;
import org.apache.commons.io.FilenameUtils;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.security.DigestInputStream;
import java.security.MessageDigest;
import java.time.Instant;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

@Service
public class UploadService {

    @Autowired
    private StorageAdapter storageAdapter;

    @Autowired
    private ArtifactRepository artifactRepository;

    @Autowired
    private ArtifactFolderService artifactFolderService;

    @Autowired
    private TagService tagService;

    @Autowired
    private S3Props s3Props;

    @Autowired
    private UploadPolicyProps uploadPolicyProps;

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private ComplexityAnalysisService complexityAnalyzer;

    @Autowired
    private ArtifactMetricsRepository artifactMetricsRepository;

    public ArtifactFolderDto handleBulkUpload(
            MultipartFile file,
            UploadBulkArtifactRequest meta
    ) throws IOException {
        ArtifactFolder folder = artifactFolderService.resolveOrCreateFolder(meta.folderPath());

        if (!folder.getArtifacts().isEmpty())
            throw new IllegalArgumentException("Given folder path is already in use");

        Path tmpArchive = Files.createTempFile("bulk", ".zip");
        try (OutputStream out = Files.newOutputStream(tmpArchive, StandardOpenOption.TRUNCATE_EXISTING)) {
            file.getInputStream().transferTo(out);
        }

        Set<ArtifactDto> createdArtifacts = new HashSet<>();

        try (ZipFile zipFile = new ZipFile(tmpArchive.toFile(), StandardCharsets.UTF_8)) {
            ZipEntry metadataEntry = null;
            Map<String, ZipEntry> filesByBaseName = new HashMap<>();

            Enumeration<? extends ZipEntry> entries = zipFile.entries();
            while (entries.hasMoreElements()) {
                ZipEntry entry = entries.nextElement();
                if (entry.isDirectory()) continue;

                if (entry.getName().toLowerCase(Locale.ROOT).endsWith(".csv")) {
                    if (metadataEntry != null)
                        throw new IllegalArgumentException("Multiple CSV metadata files found");
                    metadataEntry = entry;
                } else {
                    filesByBaseName.put(entry.getName(), entry);
                }
            }

            if (metadataEntry == null)
                throw new IllegalArgumentException("No metadata CSV file found");

            Map<String, UploadSingleArtifactRequest> requestList =
                    parseCSVMeta(zipFile, metadataEntry);

            for (String fileName : requestList.keySet()) {
                ZipEntry fileEntry = filesByBaseName.get(fileName);
                if (fileEntry == null)
                    throw new IllegalArgumentException("Artifact file missing: " + fileName);

                try (InputStream fileIn = zipFile.getInputStream(fileEntry)) {
                    ArtifactDto dto = handleSingleUpload(
                            fileIn,
                            fileName,
                            Math.max(fileEntry.getSize(), 0),
                            null,
                            requestList.get(fileName),
                            folder
                    );
                    createdArtifacts.add(dto);
                }
            }
        } finally {
            Files.deleteIfExists(tmpArchive);
        }

        return ArtifactFolderDto.builder()
                .id(folder.getId())
                .name(folder.getName())
                .ownerId(folder.getOwnerId())
                .artifacts(createdArtifacts)
                .build();
    }

    public ArtifactDto handleSingleUpload(
            InputStream in,
            String fileName,
            long size,
            String clientContentType,
            UploadSingleArtifactRequest meta,
            ArtifactFolder folder
    ) throws IOException {

        ensureWithinLimits(size);

        String extension = FilenameUtils.getExtension(fileName == null ? "" : fileName).toLowerCase();
        ensureAllowedExtension(extension);

        Path tmp = Files.createTempFile("upload", extension.isEmpty() ? "" : "." + extension);
        byte[] sha256;

        try (OutputStream os = Files.newOutputStream(tmp, StandardOpenOption.TRUNCATE_EXISTING);
             DigestInputStream dis = new DigestInputStream(in, MessageDigest.getInstance("SHA-256"))) {
            dis.transferTo(os);
            sha256 = dis.getMessageDigest().digest();
        } catch (Exception e) {
            throw new IOException(e);
        }

        long actualSize = Files.size(tmp);

        String detectedContentType = Files.probeContentType(tmp);
        String contentType = detectedContentType != null
                ? detectedContentType
                : Optional.ofNullable(clientContentType).orElse("text/plain");

        UUID id = UUID.randomUUID();
        String key = SecurityUtils.userId() + "/" +
                (folder == null ? "" : folder.getName() + "/") + id;

        try (InputStream uploadStream = Files.newInputStream(tmp)) {
            storageAdapter.put(s3Props.bucket(), key, uploadStream, actualSize, contentType);
        }

        Set<Tag> tags = tagService.resolveTags(meta.tags());

        Artifact artifact = Artifact.builder()
                .id(id)
                .ownerId(SecurityUtils.userId())
                .title(meta.title())
                .type(meta.type())
                .contentType(contentType)
                .isAIGenerated(meta.isAIGenerated())
                .storageKey(key)
                .createdAt(Instant.now())
                .sha256(HexFormat.of().formatHex(sha256))
                .sizeBytes(actualSize)
                .tags(tags)
                .folder(folder)
                .build();

        artifactRepository.save(artifact);

        // ---------------------------
        // COMPLEXITY ANALYSIS (FIXED)
        // ---------------------------
        MultipartFile analyzedFile = new TempFileMultipartFile(
                "file",
                fileName,
                contentType,
                tmp
        );

        ComplexityAnalysisService.ComplexityResult result =
                complexityAnalyzer.analyze(tmp);

        ArtifactMetrics metrics = ArtifactMetrics.builder()
                .artifactId(artifact.getId())
                .averageCyclomaticComplexity(result.averageCyclomaticComplexity())
                .maintainabilityIndex(result.maintainabilityIndex())
                .build();

        artifactMetricsRepository.save(metrics);

        Files.deleteIfExists(tmp);

        return modelMapper.map(artifact, ArtifactDto.class);
    }

    private void ensureWithinLimits(long size) {
        if (size > uploadPolicyProps.maxFileSizeBytes())
            throw new IllegalArgumentException("File too large");
        if (size <= 0)
            throw new IllegalArgumentException("Invalid file size");
    }

    private void ensureAllowedExtension(String extension) {
        Set<String> allowed = uploadPolicyProps.allowedExtensions();
        if (allowed != null && !allowed.isEmpty() && !allowed.contains(extension))
            throw new IllegalArgumentException("Extension not allowed: " + extension);
    }

    private Map<String, UploadSingleArtifactRequest> parseCSVMeta(
            ZipFile zipFile,
            ZipEntry metaEntry
    ) throws IOException {

        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(zipFile.getInputStream(metaEntry), StandardCharsets.UTF_8))) {

            int artifactCount = Integer.parseInt(reader.readLine());
            Map<String, UploadSingleArtifactRequest> result = new HashMap<>();

            for (int i = 0; i < artifactCount; i++) {
                String[] parts = reader.readLine().split(",", -1);
                int tagCount = Integer.parseInt(parts[3]);

                List<String> tags = new ArrayList<>(tagCount);
                for (int j = 0; j < tagCount; j++) {
                    tags.add(reader.readLine().trim());
                }

                result.put(
                        parts[0].trim(),
                        new UploadSingleArtifactRequest(
                                parts[0].trim(),
                                parts[1].trim(),
                                Boolean.parseBoolean(parts[2].trim()),
                                tags
                        )
                );
            }
            return result;
        }
    }

    /**
     * Minimal production MultipartFile backed by a temp file
     */
    private static class TempFileMultipartFile implements MultipartFile {

        private final String name;
        private final String originalFilename;
        private final String contentType;
        private final Path path;

        TempFileMultipartFile(String name, String originalFilename, String contentType, Path path) {
            this.name = name;
            this.originalFilename = originalFilename;
            this.contentType = contentType;
            this.path = path;
        }

        @Override
        public String getName() {
            return name;
        }

        @Override
        public String getOriginalFilename() {
            return originalFilename;
        }

        @Override
        public String getContentType() {
            return contentType;
        }

        @Override
        public boolean isEmpty() {
            try {
                return Files.size(path) == 0;
            } catch (IOException e) {
                return true;
            }
        }

        @Override
        public long getSize() {
            try {
                return Files.size(path);
            } catch (IOException e) {
                return 0;
            }
        }

        @Override
        public byte[] getBytes() throws IOException {
            return Files.readAllBytes(path);
        }

        @Override
        public InputStream getInputStream() throws IOException {
            return Files.newInputStream(path);
        }

        @Override
        public void transferTo(File dest) throws IOException {
            Files.copy(path, dest.toPath());
        }
    }
}
