package com.konsey.artifactservice.storage;

import org.springframework.core.io.Resource;

import java.io.InputStream;

/**
 * Storage abstraction for artifact bytes.
 */
public interface StorageAdapter {

    /**
     * Upload an object to storage.
     * @param bucket bucket name
     * @param key object key (path-like)
     * @param in input stream positioned at the beginning of the content
     * @param size exact size of the stream in bytes
     * @param contentType media type to store as object metadata, e.g. {@code application/pdf}
     */
    void put(String bucket, String key, InputStream in, long size, String contentType);
    Resource load(String bucket, String key);
    void delete(String bucket, String key);
}
