package com.konsey.artifactservice.config;

import com.konsey.artifactservice.config.property.S3Props;
import io.minio.BucketExistsArgs;
import io.minio.MakeBucketArgs;
import io.minio.MinioClient;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Application configuration for MinIO/S3 integration.
 *
 * <p>Creates and configures the MinIO client from {@link S3Props} and may perform
 * lightweight startup initialization such as bucket existence checks and creation
 * when enabled for local development. Beans defined here are infrastructure-scoped
 * and designed to be application-wide singletons.</p>
 *
 */
@Configuration
@EnableConfigurationProperties(S3Props.class)
public class MinioConfig {

    /**
     * Build a thread-safe {@link MinioClient}.
     *
     * @param s3Props S3/MinIO properties bound from configuration
     * @return configured {@link MinioClient} singleton
     */
    @Bean
    MinioClient minio(S3Props s3Props) {
        return MinioClient.builder()
                .endpoint(s3Props.endpoint())
                .credentials(s3Props.accessKey(), s3Props.secretKey())
                .build();
    }

    /**
     * Create the default bucket if missing.
     * Retries briefly to tolerate container start-up races.
     *
     * @param minioClient MinIO client
     * @param s3Props  S3 properties
     * @return a runner that executes once at startup
     */
    @Bean
    CommandLineRunner ensureBucket(MinioClient minioClient, S3Props s3Props) {
        // Executed once after the Spring context is ready
        return args -> {
            // Allow disabling via config
            if(!s3Props.autoCreateBucket())
                return;

            final int maxAttempts = 20;      // upper bound of retries while MinIO becomes ready
            final long backoffMillis = 1000L; // delay between retries
            int attempt = 0;

            while(true) {
                try {
                    // Check whether the bucket already exists
                    final boolean exists = minioClient.bucketExists(
                            BucketExistsArgs.builder()
                                    .bucket(s3Props.bucket())
                                    .build()
                    );

                    // Create the bucket once if it does not exist
                    if(!exists)
                        minioClient.makeBucket(
                                MakeBucketArgs.builder()
                                        .bucket(s3Props.bucket())
                                        .build()
                        );

                    // Either way bucket is existing so exit loop
                    break;
                } catch (Exception e) {
                    // If MinIO isn't ready yet or transient network error, retry a few times
                    if(++attempt >= maxAttempts)
                        // Surface the error after exhausting retries
                        throw e;

                    try {
                        Thread.sleep(backoffMillis); // simple backoff
                    } catch (InterruptedException ie) {
                        Thread.currentThread().interrupt(); // restore interrupt flag
                        throw ie;                           // and propagate
                    }
                }
            }
        };
    }
}
