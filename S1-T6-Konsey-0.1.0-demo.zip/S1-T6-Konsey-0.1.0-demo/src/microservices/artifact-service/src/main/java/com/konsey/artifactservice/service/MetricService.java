package com.konsey.artifactservice.service;

import com.konsey.artifactservice.entity.ArtifactMetrics;
import com.konsey.artifactservice.repository.ArtifactMetricsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class MetricService {

    @Autowired
    private ArtifactMetricsRepository metricsRepository;

    public Optional<ArtifactMetrics> findById(UUID id) {
        return metricsRepository.findById(id);
    }

    public Optional<ArtifactMetrics> findByArtifactId(UUID artifactId) {

        return metricsRepository.findByArtifactId(artifactId);
    }
}