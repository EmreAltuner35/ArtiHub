package com.konsey.artifactservice.repository.spec;

import com.konsey.artifactservice.entity.Artifact;
import com.konsey.artifactservice.entity.Tag;
import jakarta.persistence.criteria.*;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

@Component
public class ArtifactSpecifications {

    public Specification<Artifact> folderWith(UUID folderId) {
        return (root, query, criteriaBuilder) -> {
            if(folderId == null)
                return criteriaBuilder.isNull(root.get("folder"));
            return criteriaBuilder.equal(root.get("folder").get("id"), folderId);
        };
    }

    public Specification<Artifact> titleContains(String q) {
        if(q == null || q.isBlank())
            return null;

        final String like = "%" + q.toLowerCase() + "%";
        return (root, query, criteriaBuilder) -> criteriaBuilder.like(
                criteriaBuilder.lower(root.get("title")), like
        );
    }

    public Specification<Artifact> createdAtBetween(LocalDate from, LocalDate to) {
        if(from == null && to == null)
            return null;

        return (root, query, criteriaBuilder) -> {
            Path<Instant> createdAt = root.get("createdAt");
            Predicate predicate = criteriaBuilder.conjunction();
            if(from != null) {
                Instant start = from.atStartOfDay(ZoneOffset.UTC).toInstant();
                predicate = criteriaBuilder.and(predicate, criteriaBuilder.greaterThanOrEqualTo(createdAt, start));
            }
            if(to != null) {
                Instant end = to.plusDays(1).atStartOfDay(ZoneOffset.UTC).toInstant();
                predicate = criteriaBuilder.and(predicate, criteriaBuilder.lessThan(createdAt, end));
            }
            return predicate;
        };
    }

    public Specification<Artifact> hasAnyTag(List<String> tags) {
        if(tags == null || tags.isEmpty())
            return null;

        final List<String> lowerCaseTags = tags.stream()
                .filter(s -> s != null && !s.isBlank())
                .map(s -> s.toLowerCase(Locale.ROOT))
                .toList();

        if(lowerCaseTags.isEmpty())
            return null;

        return (root, query, criteriaBuilder) -> {
            query.distinct(true);
            Join<Artifact, Tag> tagJoin = root.join("tags", JoinType.INNER);
            return criteriaBuilder.lower(tagJoin.get("name")).in(lowerCaseTags);
        };
    }

    public Specification<Artifact> hasAllTags(List<String> tags) {
        if(tags == null || tags.isEmpty())
            return null;

        final List<String> lowerCaseTags = tags.stream()
                .filter(s -> s != null && !s.isBlank())
                .map(s -> s.toLowerCase(Locale.ROOT))
                .toList();

        if(lowerCaseTags.isEmpty())
            return null;

        return (root, query, criteriaBuilder) -> {
            Subquery<Long> sq = query.subquery(Long.class);
            Root<Artifact> a2 = sq.from(Artifact.class);
            Join<Artifact, Tag> t2 = a2.join("tags", JoinType.INNER);
            sq.select(criteriaBuilder.countDistinct(criteriaBuilder.lower(t2.get("name"))))
                    .where(
                            criteriaBuilder.equal(a2.get("id"), root.get("id")),
                            criteriaBuilder.lower(t2.get("name")).in(lowerCaseTags)
                    );
            return criteriaBuilder.equal(sq, (long) lowerCaseTags.size());
        };
    }
    public Specification<Artifact> typeNotEqual(String type) {
        if(type == null || type.isBlank()) return null;
        return (root, query, criteriaBuilder) -> criteriaBuilder.notEqual(root.get("type"), type);
    }
}
