package com.konsey.artifactservice.repository;

import com.konsey.artifactservice.entity.Tag;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Repository for {@link Tag}.
 *
 * <p>Supports lookups by normalized name and batched resolution used by the tag upsert flow.</p>
 */
public interface TagRepository extends JpaRepository<Tag, UUID> {

    /**
     * Find a tag by its normalized (lowercase) name.
     * @param name normalized name
     * @return Optional tag
     */
    Optional<Tag> findByName(String name);

    /**
     * Fetch all tags whose names are in the provided collection.
     * @param names normalized names
     * @return list of matching tags
     */
    List<Tag> findAllByNameIn(Collection<String> names);

    Page<Tag> findByNameContainingIgnoreCase(String name, Pageable pageable);

    void deleteByNameIn(Collection<String> names);
}
