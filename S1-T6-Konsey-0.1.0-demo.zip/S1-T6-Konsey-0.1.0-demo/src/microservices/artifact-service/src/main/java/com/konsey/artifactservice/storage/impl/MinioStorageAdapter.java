package com.konsey.artifactservice.storage.impl;

import com.konsey.artifactservice.storage.StorageAdapter;
import io.minio.*;
import lombok.RequiredArgsConstructor;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;

import java.io.InputStream;

/**
 * MinIO-backed {@link StorageAdapter} implementation.
 */
@Component
@RequiredArgsConstructor
public class MinioStorageAdapter implements StorageAdapter {

    private final MinioClient minioClient;

    /**
     * Upload an object to storage.
     *
     * @param bucket      bucket name
     * @param key         object key (path-like)
     * @param in          input stream positioned at the beginning of the content
     * @param size        exact size of the stream in bytes
     * @param contentType media type to store as object metadata, e.g. {@code application/pdf}
     */
    @Override
    public void put(String bucket, String key, InputStream in, long size, String contentType) {
        try {
            // Build the PUT request with explicit content type; S3/MinIO will return this
            // as the HTTP Content-Type when the object is downloaded.
            minioClient.putObject(
                    PutObjectArgs.builder()
                            .bucket(bucket)
                            .object(key)
                            .stream(in, size, -1) // partSize = -1 → let SDK choose defaults for single PUT
                            .contentType(
                                    (contentType == null || contentType.isBlank())
                                    ? "text/plain" : contentType
                            )
                            .build()
            );
        } catch (Exception e) {
            throw new RuntimeException("minio.put failed for key=" + key + " in bucket=" + bucket, e);
        }
    }

    @Override
    public Resource load(String bucket, String key) {
        try {
            InputStream inputStream = minioClient.getObject(
                    GetObjectArgs.builder()
                            .bucket(bucket)
                            .object(key)
                            .build()
            );
            return new InputStreamResource(inputStream);
        } catch (Exception e) {
            throw new RuntimeException("minio.load failed for key=" + key + " in bucket=" + bucket, e);
        }
    }

    @Override
    public void delete(String bucket, String key) {
        try {
            minioClient.removeObject(
                    RemoveObjectArgs.builder()
                            .bucket(bucket)
                            .object(key)
                            .build()
            );
        } catch (Exception e) {
            throw new RuntimeException("minio.delete failed for key=" + key + " in bucket=" + bucket, e);
        }
    }
}
