package com.konsey.artifactservice.web;

import com.konsey.artifactservice.dto.ArtifactFolderDto;
import com.konsey.artifactservice.dto.PageResponse;
import com.konsey.artifactservice.service.ArtifactFolderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/api/artifacts/folders")
public class ArtifactFolderController {

    @Autowired
    private ArtifactFolderService artifactFolderService;

    @GetMapping
    PageResponse<ArtifactFolderDto> getFolders(
            @PageableDefault(sort = "name", direction = Sort.Direction.ASC) Pageable pageable,
            @RequestParam(defaultValue = "") String q
    ) {
        return artifactFolderService.getFolders(q, pageable);
    }

    @GetMapping("/{folderId}")
    ArtifactFolderDto getFolder(@PathVariable UUID folderId) {
        return artifactFolderService.getFolder(folderId);
    }

    @DeleteMapping("/{folderId}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    void deleteFolder(
            @PathVariable UUID folderId
    ) {
        artifactFolderService.deleteFolder(folderId);
    }
}
