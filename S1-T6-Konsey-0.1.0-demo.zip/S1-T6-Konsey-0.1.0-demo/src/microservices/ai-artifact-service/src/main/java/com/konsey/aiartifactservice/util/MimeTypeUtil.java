package com.konsey.aiartifactservice.util;

public class MimeTypeUtil {
    public static String inferType(String mime) {
        if (mime == null)
            return "text";
        String m = mime.toLowerCase();
        if (m.contains("plantuml"))
            return "uml";
        if (m.contains("markdown"))
            return "requirements"; // or report
        if (m.contains("java") || m.contains("python") || m.contains("text/x-"))
            return "code";
        if (m.contains("text/plain"))
            return "txt";
        if (m.contains("application/pdf"))
            return "pdf";
        return "text";
    }
}