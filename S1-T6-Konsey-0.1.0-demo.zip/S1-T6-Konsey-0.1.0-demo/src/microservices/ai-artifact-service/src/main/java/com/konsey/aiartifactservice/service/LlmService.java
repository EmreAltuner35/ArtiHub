package com.konsey.aiartifactservice.service;

import java.util.Map;

public interface LlmService {
    record LlmResult(String text, String mime, Map<String, Object> meta) {}
    LlmResult generate(String type, Map<String, Object> params, Integer seed);
}