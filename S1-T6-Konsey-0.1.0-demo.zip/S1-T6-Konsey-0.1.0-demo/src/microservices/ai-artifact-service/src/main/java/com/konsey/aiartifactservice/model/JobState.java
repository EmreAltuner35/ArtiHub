package com.konsey.aiartifactservice.model;

import com.konsey.aiartifactservice.model.enums.JobStatus;
import org.springframework.data.annotation.Id;
import org.springframework.data.redis.core.RedisHash;
import org.springframework.data.redis.core.index.Indexed;

import java.time.Instant;
import java.util.Map;

@RedisHash("AiGenJob")
public class JobState {

    @Id
    private String id;

    @Indexed
    private JobStatus status;

    private String error;
    private String content; // preview text
    private String format;  // e.g. text/x-java, text/x-plantuml, text/markdown
    private Map<String, Object> meta;

    private Instant createdAt;
    private Instant updatedAt;

    public JobState() {}

    // ---- getters & setters ----
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public JobStatus getStatus() { return status; }
    public void setStatus(JobStatus status) { this.status = status; }

    public String getError() { return error; }
    public void setError(String error) { this.error = error; }

    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }

    public String getFormat() { return format; }
    public void setFormat(String format) { this.format = format; }

    public Map<String, Object> getMeta() { return meta; }
    public void setMeta(Map<String, Object> meta) { this.meta = meta; }

    public Instant getCreatedAt() { return createdAt; }
    public void setCreatedAt(Instant createdAt) { this.createdAt = createdAt; }

    public Instant getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(Instant updatedAt) { this.updatedAt = updatedAt; }
}