package com.konsey.aiartifactservice.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Map;

@Service
public class ArtifactUploader {

    private final WebClient artifactClient;
    private final ObjectMapper objectMapper = new ObjectMapper();

    @Value("${artifact.baseUrl}")
    String baseUrl;

    // Lombok yok, constructor'ı kendimiz yazıyoruz
    public ArtifactUploader(WebClient artifactClient) {
        this.artifactClient = artifactClient;
    }

    public Mono<String> upload(byte[] content,
            String filename,
            String format,
            String title,
            String type,
            List<String> tags,
            String bearerToken) {

        if (tags == null || tags.isEmpty()) {
            tags = List.of("ai");
        }

        Map<String, Object> meta = Map.of(
                "title", title,
                "type", type, // code|uml|requirements|tests|text
                "isAIGenerated", true,
                "tags", tags);

        LinkedMultiValueMap<String, Object> parts = new LinkedMultiValueMap<>();
        parts.add("file", new ByteArrayResource(content) {
            @Override
            public String getFilename() {
                return filename;
            }
        });
        parts.add("meta", new HttpEntity<>(
                metaAsString(meta),
                new HttpHeaders() {
                    {
                        setContentType(MediaType.APPLICATION_JSON);
                    }
                }));

        return artifactClient.post()
                .header("Authorization", "Bearer " + bearerToken)
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .bodyValue(parts)
                .retrieve()
                .bodyToMono(Map.class)
                .onErrorResume(e -> Mono.error(new RuntimeException("artifact-service error", e)))
                .map(response -> {
                    if (response == null || response.get("id") == null) {
                        throw new RuntimeException("artifact-service returned no id");
                    }
                    return String.valueOf(response.get("id"));
                });
    }

    private String metaAsString(Map<String, Object> meta) {
        try {
            return objectMapper.writeValueAsString(meta);
        } catch (Exception e) {
            throw new RuntimeException("meta json error", e);
        }
    }

    public Mono<String> uploadBulk(byte[] zipContent, String folderPath, String bearerToken) {
        Map<String, Object> meta = Map.of(
                "folderPath", folderPath);

        LinkedMultiValueMap<String, Object> parts = new LinkedMultiValueMap<>();
        parts.add("file", new ByteArrayResource(zipContent) {
            @Override
            public String getFilename() {
                return "bulk.zip";
            }
        });
        parts.add("meta", new HttpEntity<>(
                metaAsString(meta),
                new HttpHeaders() {
                    {
                        setContentType(MediaType.APPLICATION_JSON);
                    }
                }));

        return artifactClient.post()
                .uri("/bulk")
                .header("Authorization", "Bearer " + bearerToken)
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .bodyValue(parts)
                .retrieve()
                .bodyToMono(Map.class)
                .onErrorResume(e -> Mono.error(new RuntimeException("artifact-service bulk upload error", e)))
                .map(response -> {
                    if (response == null || response.get("id") == null) {
                        throw new RuntimeException("artifact-service returned no id for bulk upload");
                    }
                    return String.valueOf(response.get("id"));
                });
    }
}