package com.konsey.aiartifactservice.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.util.Map;

public record GenRequest(
        @NotBlank String type,                 // code|tests|uml|requirements
        @NotNull  Map<String, Object> params,  // language, goal, diagram, etc.
        @NotBlank String ownerId,
        String studyId,
        Integer seed
) {}