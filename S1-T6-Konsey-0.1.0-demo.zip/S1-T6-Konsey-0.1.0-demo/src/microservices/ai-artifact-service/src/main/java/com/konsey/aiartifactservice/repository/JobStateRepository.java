package com.konsey.aiartifactservice.repository;

import com.konsey.aiartifactservice.model.JobState;
import org.springframework.data.repository.CrudRepository;

public interface JobStateRepository extends CrudRepository<JobState, String> {}