package com.konsey.aiartifactservice.dto;

import jakarta.validation.constraints.NotBlank;

import java.util.List;

public record SaveRequest(
                @NotBlank String title,
                String studyId,
                String ownerId,
                List<String> tags) {
}