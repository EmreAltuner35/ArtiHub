package com.konsey.aiartifactservice.service;

import com.konsey.aiartifactservice.dto.GenRequest;
import com.konsey.aiartifactservice.model.JobState;
import com.konsey.aiartifactservice.model.enums.JobStatus;
import com.konsey.aiartifactservice.repository.JobStateRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.Map;

@Service
public class GenerationService {

    private static final Logger log = LoggerFactory.getLogger(GenerationService.class);

    private final LlmService llm;
    private final JobStateRepository jobRepo;

    public GenerationService(LlmService llm, JobStateRepository jobRepo) {
        this.llm = llm;
        this.jobRepo = jobRepo;
    }

    public void start(String jobId, GenRequest req) {
        Instant now = Instant.now();
        JobState js = new JobState();
        js.setId(jobId);
        js.setStatus(JobStatus.QUEUED);
        js.setCreatedAt(now);
        js.setUpdatedAt(now);
        jobRepo.save(js);

        // basit async thread; ileride queue ile değiştirebilirsin
        new Thread(() -> run(jobId, req)).start();
    }

    private void run(String jobId, GenRequest req) {
        try {
            update(jobId, JobStatus.RUNNING, null, null, null, null);
            LlmService.LlmResult res = llm.generate(req.type(), req.params(), req.seed());
            update(jobId, JobStatus.SUCCEEDED, null, res.text(), res.mime(), res.meta());
        } catch (Exception e) {
            log.error("Generation failed for {}", jobId, e);
            update(jobId, JobStatus.FAILED, e.getMessage(), null, null, null);
        }
    }

    private void update(String jobId,
                        JobStatus status,
                        String error,
                        String content,
                        String format,
                        Map<String, Object> meta) {
        JobState js = jobRepo.findById(jobId).orElseThrow();
        js.setStatus(status);
        js.setError(error);
        js.setContent(content);
        js.setFormat(format);
        js.setMeta(meta);
        js.setUpdatedAt(Instant.now());
        jobRepo.save(js);
    }
}