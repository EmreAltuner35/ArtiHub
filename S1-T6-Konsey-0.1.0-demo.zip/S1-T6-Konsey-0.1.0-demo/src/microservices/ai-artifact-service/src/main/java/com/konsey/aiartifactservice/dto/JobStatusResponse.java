package com.konsey.aiartifactservice.dto;

import java.util.Map;

public record JobStatusResponse(
        String status,
        String error,
        Preview preview,
        Map<String, Object> meta
) {
    public record Preview(String content, String format) {}
}