package com.konsey.aiartifactservice.service;

import java.util.List;
import java.util.Map;

public class PromptBuilder {

        public record Prompt(List<Map<String, String>> messages, String mime) {
        }

        public static Prompt build(String type, Map<String, Object> p) {
                return switch (type) {
                        case "uml" -> {
                                String diagram = String.valueOf(p.getOrDefault("diagram", "sequence"));
                                String system = "Return valid PlantUML only, no explanations.";
                                String user = """
                                                Diagram: %s
                                                Domain seed: %s
                                                Constraints: %s
                                                Output between @start%s ... @end%s
                                                """.formatted(
                                                diagram,
                                                String.valueOf(p.getOrDefault("domain", "")),
                                                String.valueOf(p.getOrDefault("constraints", "")),
                                                diagram, diagram);
                                yield new Prompt(List.of(
                                                Map.of("role", "system", "content", system),
                                                Map.of("role", "user", "content", user)),
                                                "text/x-plantuml");
                        }

                        case "code" -> {
                                String lang = String.valueOf(p.getOrDefault("language", "Java"));
                                String system = "Return ONLY code. No network calls, no secrets.";
                                String user = """
                                                Language: %s
                                                Goal: %s
                                                IO: %s
                                                Constraints: %s
                                                Style: %s
                                                """.formatted(
                                                lang,
                                                String.valueOf(p.getOrDefault("goal", "")),
                                                String.valueOf(p.getOrDefault("io", "")),
                                                String.valueOf(p.getOrDefault("constraints", "")),
                                                String.valueOf(p.getOrDefault("style", "")));
                                yield new Prompt(List.of(
                                                Map.of("role", "system", "content", system),
                                                Map.of("role", "user", "content", user)),
                                                "text/x-" + lang.toLowerCase());
                        }

                        case "tests" -> {
                                String system = "Return a single unit test file covering edge cases.";
                                String user = """
                                                Framework: %s
                                                Target: %s
                                                Coverage: %s
                                                Count: %s
                                                """.formatted(
                                                String.valueOf(p.getOrDefault("framework", "JUnit5")),
                                                String.valueOf(p.getOrDefault("target", "")),
                                                String.valueOf(p.getOrDefault("coverage", "")),
                                                String.valueOf(p.getOrDefault("count", "5")));
                                yield new Prompt(List.of(
                                                Map.of("role", "system", "content", system),
                                                Map.of("role", "user", "content", user)),
                                                "text/x-java");
                        }

                        case "requirements" -> {
                                String system = "Write INVEST-compliant user stories with Given/When/Then acceptance criteria. No commentary.";
                                String user = """
                                                Feature: %s
                                                Scope: %s
                                                Constraints/Non-goals: %s
                                                """.formatted(
                                                String.valueOf(p.getOrDefault("feature", "")),
                                                String.valueOf(p.getOrDefault("scope", "story")),
                                                String.valueOf(p.getOrDefault("nonGoals", "")));
                                yield new Prompt(List.of(
                                                Map.of("role", "system", "content", system),
                                                Map.of("role", "user", "content", user)),
                                                "text/markdown");
                        }

                        case "txt" -> {
                                String system = "Return plain text content. No markdown formatting unless requested.";
                                String user = """
                                                Topic: %s
                                                Detail Level: %s
                                                Tone: %s
                                                """.formatted(
                                                String.valueOf(p.getOrDefault("topic", "")),
                                                String.valueOf(p.getOrDefault("detailLevel", "medium")),
                                                String.valueOf(p.getOrDefault("tone", "neutral")));
                                yield new Prompt(List.of(
                                                Map.of("role", "system", "content", system),
                                                Map.of("role", "user", "content", user)),
                                                "text/plain");
                        }

                        case "report" -> {
                                String system = "Write a comprehensive report in Markdown format. Use headers, lists, and clear structure.";
                                String user = """
                                                Subject: %s
                                                Audience: %s
                                                Key Points: %s
                                                """.formatted(
                                                String.valueOf(p.getOrDefault("subject", "")),
                                                String.valueOf(p.getOrDefault("audience", "general")),
                                                String.valueOf(p.getOrDefault("keyPoints", "")));
                                yield new Prompt(List.of(
                                                Map.of("role", "system", "content", system),
                                                Map.of("role", "user", "content", user)),
                                                "text/markdown");
                        }

                        case "pdf" -> {
                                // PDF generation starts with text/markdown content, then converted to PDF in
                                // controller
                                String system = "Write detailed content suitable for a PDF document. Use clear sections.";
                                String user = """
                                                Title: %s
                                                Content Requirements: %s
                                                """.formatted(
                                                String.valueOf(p.getOrDefault("title", "Document")),
                                                String.valueOf(p.getOrDefault("requirements", "")));
                                yield new Prompt(List.of(
                                                Map.of("role", "system", "content", system),
                                                Map.of("role", "user", "content", user)),
                                                "application/pdf");
                        }

                        case "project" -> {
                                String system = "Return a JSON object where keys are filenames (with extension) and values are the text content of the files. Do not include any other text, markdown formatting, or explanations. Just raw JSON. If you return code directly, the system will fail.";
                                String user = """
                                                Project Type: %s
                                                Description: %s
                                                Tech Stack: %s
                                                """.formatted(
                                                String.valueOf(p.getOrDefault("type", "generic")),
                                                String.valueOf(p.getOrDefault("description", "")),
                                                String.valueOf(p.getOrDefault("stack", "")));
                                yield new Prompt(List.of(
                                                Map.of("role", "system", "content", system),
                                                Map.of("role", "user", "content", user)),
                                                "application/json");
                        }

                        default -> throw new IllegalArgumentException("Unsupported type: " + type);
                };
        }
}