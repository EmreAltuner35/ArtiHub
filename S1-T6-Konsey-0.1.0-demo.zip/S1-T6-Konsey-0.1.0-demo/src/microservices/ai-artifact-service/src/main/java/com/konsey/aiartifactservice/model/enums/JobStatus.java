package com.konsey.aiartifactservice.model.enums;

public enum JobStatus {
    QUEUED, RUNNING, SUCCEEDED, FAILED
}