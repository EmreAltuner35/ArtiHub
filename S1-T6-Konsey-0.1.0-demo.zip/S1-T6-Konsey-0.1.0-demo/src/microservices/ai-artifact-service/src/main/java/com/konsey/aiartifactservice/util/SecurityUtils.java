package com.konsey.aiartifactservice.util;

import org.springframework.security.core.context.ReactiveSecurityContextHolder;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.oauth2.jwt.Jwt;
import reactor.core.publisher.Mono;

public class SecurityUtils {

    private SecurityUtils() {
    }

    public static Mono<String> userId() {
        return ReactiveSecurityContextHolder.getContext()
                .map(SecurityContext::getAuthentication)
                .flatMap(auth -> {
                    if (auth.getPrincipal() instanceof Jwt jwt) {
                        return Mono.justOrEmpty(jwt.getSubject());
                    }
                    return Mono.justOrEmpty(auth.getName());
                });
    }

    public static Mono<String> jwtToken() {
        return ReactiveSecurityContextHolder.getContext()
                .map(SecurityContext::getAuthentication)
                .flatMap(auth -> {
                    if (auth.getPrincipal() instanceof Jwt jwt) {
                        return Mono.justOrEmpty(jwt.getTokenValue());
                    }
                    return Mono.empty();
                });
    }
}
