package com.konsey.aiartifactservice.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class RedisConfig {
    // Spring Boot auto-configures LettuceConnectionFactory and RedisTemplate
    // from spring.data.redis.* in application.yml. Keep this class for clarity/overrides if needed.
}