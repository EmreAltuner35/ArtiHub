package com.konsey.aiartifactservice.controller;

import com.konsey.aiartifactservice.dto.GenRequest;
import com.konsey.aiartifactservice.dto.JobStatusResponse;
import com.konsey.aiartifactservice.dto.SaveRequest;
import com.konsey.aiartifactservice.model.JobState;
import com.konsey.aiartifactservice.model.enums.JobStatus;
import com.konsey.aiartifactservice.repository.JobStateRepository;
import com.konsey.aiartifactservice.service.ArtifactUploader;
import com.konsey.aiartifactservice.service.GenerationService;
import com.konsey.aiartifactservice.util.MimeTypeUtil;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/ai-artifacts")
public class AiArtifactController {

    private final GenerationService generationService;
    private final JobStateRepository jobRepo;
    private final ArtifactUploader uploader;

    // Lombok yok, constructor'ı kendimiz yazıyoruz
    public AiArtifactController(GenerationService generationService,
            JobStateRepository jobRepo,
            ArtifactUploader uploader) {
        this.generationService = generationService;
        this.jobRepo = jobRepo;
        this.uploader = uploader;
    }

    @PostMapping
    public Map<String, String> create(@Valid @RequestBody GenRequest req) {
        String jobId = "gen_" + UUID.randomUUID().toString().replace("-", "").substring(0, 12);
        generationService.start(jobId, req);
        return Map.of("jobId", jobId, "status", "queued");
    }

    @GetMapping("/jobs/{jobId}")
    public ResponseEntity<JobStatusResponse> status(@PathVariable String jobId) {
        JobState js = jobRepo.findById(jobId).orElse(null);
        if (js == null) {
            return ResponseEntity.notFound().build();
        }

        JobStatusResponse.Preview preview = (js.getContent() == null)
                ? null
                : new JobStatusResponse.Preview(js.getContent(), js.getFormat());

        return ResponseEntity.ok(
                new JobStatusResponse(
                        js.getStatus().name().toLowerCase(),
                        js.getError(),
                        preview,
                        js.getMeta()));
    }

    @PostMapping("/jobs/{jobId}/save")
    public Mono<Map<String, String>> save(@PathVariable String jobId, @Valid @RequestBody SaveRequest body) {
        return Mono.justOrEmpty(jobRepo.findById(jobId))
                .switchIfEmpty(Mono.error(new IllegalArgumentException("job not found")))
                .flatMap(js -> {
                    if (js.getStatus() != JobStatus.SUCCEEDED) {
                        return Mono.error(new IllegalStateException("job not ready"));
                    }

                    String type = MimeTypeUtil.inferType(js.getFormat()); // code|uml|requirements|text|pdf|txt

                    // Use token from security context
                    return com.konsey.aiartifactservice.util.SecurityUtils.jwtToken()
                            .switchIfEmpty(Mono.error(new IllegalStateException("User not authenticated")))
                            .flatMap(token -> {

                                byte[] contentBytes = js.getContent().getBytes(StandardCharsets.UTF_8);
                                String finalTitle = body.title();

                                // Handle PDF conversion
                                if ("application/pdf".equals(js.getFormat())) {
                                    try (org.apache.pdfbox.pdmodel.PDDocument doc = new org.apache.pdfbox.pdmodel.PDDocument()) {
                                        org.apache.pdfbox.pdmodel.PDPage page = new org.apache.pdfbox.pdmodel.PDPage();
                                        doc.addPage(page);
                                        try (org.apache.pdfbox.pdmodel.PDPageContentStream contentStream = new org.apache.pdfbox.pdmodel.PDPageContentStream(
                                                doc, page)) {
                                            contentStream.beginText();
                                            contentStream.setFont(new org.apache.pdfbox.pdmodel.font.PDType1Font(
                                                    org.apache.pdfbox.pdmodel.font.Standard14Fonts.FontName.HELVETICA),
                                                    12);
                                            contentStream.newLineAtOffset(25, 700);

                                            // Simple text wrapping for PDF
                                            String[] lines = js.getContent().split("\n");
                                            for (String line : lines) {
                                                // Basic sanitization to avoid PDFBox errors with unsupported chars
                                                // Replace tabs with 4 spaces, and replace other non-printable chars
                                                String safeLine = line.replace("\t", "    ").replaceAll(
                                                        "[^\\x20-\\x7E]",
                                                        "?");
                                                contentStream.showText(safeLine);
                                                contentStream.newLineAtOffset(0, -15);
                                            }
                                            contentStream.endText();
                                        }
                                        java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
                                        doc.save(baos);
                                        contentBytes = baos.toByteArray();
                                        if (!finalTitle.toLowerCase().endsWith(".pdf")) {
                                            finalTitle += ".pdf";
                                        }
                                    } catch (java.io.IOException e) {
                                        return Mono.error(new RuntimeException("Failed to generate PDF", e));
                                    }
                                } else if ("text/plain".equals(js.getFormat())) {
                                    if (!finalTitle.toLowerCase().endsWith(".txt")) {
                                        finalTitle += ".txt";
                                    }
                                } else if ("text/markdown".equals(js.getFormat())) {
                                    if (!finalTitle.toLowerCase().endsWith(".md")) {
                                        finalTitle += ".md";
                                    }
                                } else if ("application/json".equals(js.getFormat())) {
                                    // Bulk upload flow
                                    try {
                                        // Strip markdown code blocks if present
                                        String jsonContent = js.getContent().trim();
                                        if (jsonContent.startsWith("```json")) {
                                            jsonContent = jsonContent.substring(jsonContent.indexOf('\n') + 1);
                                        } else if (jsonContent.startsWith("```")) {
                                            jsonContent = jsonContent.substring(jsonContent.indexOf('\n') + 1);
                                        }
                                        if (jsonContent.endsWith("```")) {
                                            jsonContent = jsonContent.substring(0, jsonContent.lastIndexOf("```"))
                                                    .trim();
                                        }

                                        Map<String, String> files;
                                        try {
                                            com.fasterxml.jackson.databind.ObjectMapper mapper = new com.fasterxml.jackson.databind.ObjectMapper();
                                            files = mapper.readValue(jsonContent,
                                                    new com.fasterxml.jackson.core.type.TypeReference<Map<String, String>>() {
                                                    });
                                        } catch (com.fasterxml.jackson.core.JsonProcessingException e) {
                                            System.out.println(
                                                    "WARN: JSON parsing failed, attempting fallback to single-file project.");
                                            String content = js.getContent();
                                            String filename = "ProjectSource.txt";
                                            if (content.contains("public class ") || content.contains("import java"))
                                                filename = "Main.java";
                                            else if (content.contains("def ") || content.contains("import "))
                                                filename = "script.py";
                                            else if (content.contains("function ") || content.contains("const "))
                                                filename = "index.js";
                                            else if (content.contains("<!DOCTYPE html>") || content.contains("<html>"))
                                                filename = "index.html";

                                            files = new java.util.HashMap<>();
                                            files.put(filename, content);
                                        }

                                        java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
                                        try (java.util.zip.ZipOutputStream zos = new java.util.zip.ZipOutputStream(
                                                baos)) {

                                            // Create metadata.csv
                                            StringBuilder csv = new StringBuilder();
                                            csv.append(files.size()).append("\n"); // Count

                                            for (Map.Entry<String, String> entry : files.entrySet()) {
                                                String filename = entry.getKey();
                                                String fileContent = entry.getValue();
                                                String fileType = MimeTypeUtil.inferType(
                                                        com.konsey.aiartifactservice.util.MimeTypeUtil
                                                                .inferType(filename)); // Simple
                                                                                       // inference

                                                // Add file to ZIP
                                                java.util.zip.ZipEntry zipEntry = new java.util.zip.ZipEntry(filename);
                                                zos.putNextEntry(zipEntry);
                                                zos.write(fileContent.getBytes(StandardCharsets.UTF_8));
                                                zos.closeEntry();

                                                // Add to CSV: filename,type,isAI,tagCount
                                                csv.append(filename).append(",").append(fileType).append(",true,1\n");
                                                csv.append("ai-generated\n"); // Tag
                                            }

                                            // Add metadata.csv to ZIP
                                            java.util.zip.ZipEntry metaEntry = new java.util.zip.ZipEntry(
                                                    "metadata.csv");
                                            zos.putNextEntry(metaEntry);
                                            zos.write(csv.toString().getBytes(StandardCharsets.UTF_8));
                                            zos.closeEntry();
                                        }

                                        String folderPath = body.title();
                                        return uploader.uploadBulk(baos.toByteArray(), folderPath, token)
                                                .map(folderId -> Map.of("folderId", folderId, "status", "saved"));

                                    } catch (Exception e) {
                                        return Mono.error(new RuntimeException("Failed to process bulk artifact", e));
                                    }
                                }

                                String finalTitleForLambda = finalTitle;
                                return uploader.upload(
                                        contentBytes,
                                        finalTitleForLambda,
                                        js.getFormat(),
                                        body.title(),
                                        type,
                                        body.tags(),
                                        token)
                                        .map(artifactId -> Map.of("artifactId", artifactId, "status", "saved"));
                            });
                });
    }
}