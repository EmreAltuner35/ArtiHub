package com.konsey.quizservice.entity;

/**
 * Enum representing the status of a quiz.
 */
public enum QuizStatus {
    DRAFT,      // Quiz is being created/edited
    PUBLISHED,  // Quiz is available for participants
    ARCHIVED    // Quiz is no longer active
}

