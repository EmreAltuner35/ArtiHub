package com.konsey.quizservice.entity;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Represents a competency quiz created by a Researcher.
 * Each quiz contains multiple questions and can be associated with a study.
 */
@Entity
@Table(name = "quizzes")
public class Quiz {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "quiz_id", updatable = false, nullable = false)
    private UUID quizId;

    /**
     * The foreign key (FK) relationship to the User (Researcher).
     * This field represents the User entity that created this quiz.
     */
    @Column(name = "researcher_id", nullable = false)
    private UUID researcherId;

    /**
     * Optional foreign key to associate the quiz with a study.
     */
    @Column(name = "study_id")
    private UUID studyId;

    /**
     * The title of the quiz.
     */
    @Column(name = "title", nullable = false, length = 255)
    private String title;

    /**
     * The description of the quiz.
     */
    @Column(name = "description", columnDefinition = "TEXT")
    private String description;

    /**
     * The time limit for the quiz in seconds.
     * Null means no time limit.
     */
    @Column(name = "time_limit")
    private Integer timeLimit;

    /**
     * The status of the quiz (e.g., DRAFT, PUBLISHED, ARCHIVED).
     */
    @Enumerated(EnumType.STRING)
    @Column(name = "status", length = 50)
    private QuizStatus status = QuizStatus.DRAFT;

    /**
     * One-to-many relationship with Question entities.
     * Cascade operations allow operations on Quiz to affect Questions.
     * Orphan removal ensures Questions are deleted when removed from Quiz.
     */
    @OneToMany(mappedBy = "quiz", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    @OrderBy("questionOrder ASC")
    private List<Question> questions = new ArrayList<>();

    /**
     * Timestamp when the quiz was created.
     */
    @Column(name = "created_at", nullable = false, updatable = false)
    private java.time.LocalDateTime createdAt;

    /**
     * Timestamp when the quiz was last updated.
     */
    @Column(name = "updated_at")
    private java.time.LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        createdAt = java.time.LocalDateTime.now();
        updatedAt = java.time.LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = java.time.LocalDateTime.now();
    }

    // Constructors
    public Quiz() {}

    public Quiz(UUID researcherId, String title, String description) {
        this.researcherId = researcherId;
        this.title = title;
        this.description = description;
        this.status = QuizStatus.DRAFT;
    }

    public Quiz(UUID researcherId, String title, String description, Integer timeLimit) {
        this(researcherId, title, description);
        this.timeLimit = timeLimit;
    }

    // Getters and Setters
    public UUID getQuizId() {
        return quizId;
    }

    public void setQuizId(UUID quizId) {
        this.quizId = quizId;
    }

    public UUID getResearcherId() {
        return researcherId;
    }

    public void setResearcherId(UUID researcherId) {
        this.researcherId = researcherId;
    }

    public UUID getStudyId() {
        return studyId;
    }

    public void setStudyId(UUID studyId) {
        this.studyId = studyId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getTimeLimit() {
        return timeLimit;
    }

    public void setTimeLimit(Integer timeLimit) {
        this.timeLimit = timeLimit;
    }

    public QuizStatus getStatus() {
        return status;
    }

    public void setStatus(QuizStatus status) {
        this.status = status;
    }

    public List<Question> getQuestions() {
        return questions;
    }

    public void setQuestions(List<Question> questions) {
        this.questions = questions;
    }

    public java.time.LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(java.time.LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public java.time.LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(java.time.LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    // Helper methods
    public void addQuestion(Question question) {
        questions.add(question);
        question.setQuiz(this);
    }

    public void removeQuestion(Question question) {
        questions.remove(question);
        question.setQuiz(null);
    }
}

