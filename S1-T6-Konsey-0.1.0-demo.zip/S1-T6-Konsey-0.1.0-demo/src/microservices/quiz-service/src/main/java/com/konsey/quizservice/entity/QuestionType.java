package com.konsey.quizservice.entity;

/**
 * Enum representing the type of a question.
 */
public enum QuestionType {
    SINGLE_CHOICE,    // Only one answer can be selected
    MULTIPLE_CHOICE,  // Multiple answers can be selected
    TEXT              // Free text answer
}

