package com.konsey.quizservice.entity;

import jakarta.persistence.*;
import java.util.UUID;

/**
 * Represents an answer option for a question.
 */
@Entity
@Table(name = "answers")
public class Answer {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "answer_id", updatable = false, nullable = false)
    private UUID answerId;

    /**
     * The foreign key (FK) relationship to the Question.
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "question_id", nullable = false)
    private Question question;

    /**
     * The text of the answer option.
     */
    @Column(name = "answer_text", nullable = false, columnDefinition = "TEXT")
    private String answerText;

    /**
     * Whether this answer is correct.
     */
    @Column(name = "is_correct", nullable = false)
    private Boolean isCorrect = false;

    /**
     * The order of this answer within the question.
     */
    @Column(name = "answer_order", nullable = false)
    private Integer answerOrder;

    // Constructors
    public Answer() {}

    public Answer(Question question, String answerText, Boolean isCorrect, Integer answerOrder) {
        this.question = question;
        this.answerText = answerText;
        this.isCorrect = isCorrect;
        this.answerOrder = answerOrder;
    }

    // Getters and Setters
    public UUID getAnswerId() {
        return answerId;
    }

    public void setAnswerId(UUID answerId) {
        this.answerId = answerId;
    }

    public Question getQuestion() {
        return question;
    }

    public void setQuestion(Question question) {
        this.question = question;
    }

    public String getAnswerText() {
        return answerText;
    }

    public void setAnswerText(String answerText) {
        this.answerText = answerText;
    }

    public Boolean getIsCorrect() {
        return isCorrect;
    }

    public void setIsCorrect(Boolean isCorrect) {
        this.isCorrect = isCorrect;
    }

    public Integer getAnswerOrder() {
        return answerOrder;
    }

    public void setAnswerOrder(Integer answerOrder) {
        this.answerOrder = answerOrder;
    }
}

