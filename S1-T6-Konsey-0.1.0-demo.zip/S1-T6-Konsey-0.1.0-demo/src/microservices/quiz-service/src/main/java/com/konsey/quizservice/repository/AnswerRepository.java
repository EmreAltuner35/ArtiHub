package com.konsey.quizservice.repository;

import com.konsey.quizservice.entity.Answer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

/**
 * Repository interface for Answer entity.
 */
@Repository
public interface AnswerRepository extends JpaRepository<Answer, UUID> {

    /**
     * Find all answers for a specific question, ordered by answer order.
     */
    List<Answer> findByQuestion_QuestionIdOrderByAnswerOrderAsc(UUID questionId);

    /**
     * Delete all answers for a specific question.
     */
    void deleteByQuestion_QuestionId(UUID questionId);
}

