package com.konsey.quizservice.repository;

import com.konsey.quizservice.entity.Question;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

/**
 * Repository interface for Question entity.
 */
@Repository
public interface QuestionRepository extends JpaRepository<Question, UUID> {

    /**
     * Find all questions for a specific quiz, ordered by question order.
     */
    List<Question> findByQuiz_QuizIdOrderByQuestionOrderAsc(UUID quizId);

    /**
     * Delete all questions for a specific quiz.
     */
    void deleteByQuiz_QuizId(UUID quizId);
}

