package com.konsey.quizservice.dto;

import com.konsey.quizservice.entity.QuizStatus;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * DTO for creating a new quiz.
 */
public class QuizCreationRequest {

    @NotBlank(message = "Quiz title cannot be blank")
    @Size(min = 3, max = 255, message = "Quiz title must be between 3 and 255 characters")
    private String title;

    @Size(max = 2000, message = "Description must not exceed 2000 characters")
    private String description;

    private Integer timeLimit;

    private UUID studyId;

    private QuizStatus status = QuizStatus.DRAFT;

    @Valid
    @Size(min = 1, message = "At least one question is required")
    private List<QuestionDto> questions = new ArrayList<>();

    // Constructors
    public QuizCreationRequest() {}

    public QuizCreationRequest(String title, String description, UUID studyId, List<QuestionDto> questions) {
        this.title = title;
        this.description = description;
        this.studyId = studyId;
        this.questions = questions;
    }

    public QuizCreationRequest(String title, String description, Integer timeLimit, UUID studyId, List<QuestionDto> questions) {
        this.title = title;
        this.description = description;
        this.timeLimit = timeLimit;
        this.studyId = studyId;
        this.questions = questions;
    }

    // Getters and Setters
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getTimeLimit() {
        return timeLimit;
    }

    public void setTimeLimit(Integer timeLimit) {
        this.timeLimit = timeLimit;
    }

    public UUID getStudyId() {
        return studyId;
    }

    /**
     * Setter that accepts Object (String or UUID) and converts appropriately.
     * This allows Jackson to deserialize from JSON string values.
     * Empty strings or invalid UUIDs are treated as null (optional field).
     */
    @com.fasterxml.jackson.annotation.JsonSetter("studyId")
    public void setStudyId(Object studyIdObj) {
        if (studyIdObj == null) {
            this.studyId = null;
        } else if (studyIdObj instanceof UUID) {
            this.studyId = (UUID) studyIdObj;
        } else if (studyIdObj instanceof String) {
            String studyIdStr = ((String) studyIdObj).trim();
            if (studyIdStr.isEmpty() || studyIdStr.equals("null")) {
                this.studyId = null;
            } else {
                try {
                    this.studyId = UUID.fromString(studyIdStr);
                } catch (IllegalArgumentException e) {
                    // If it's not a valid UUID, set to null (optional field)
                    // This allows the request to proceed even with invalid UUID
                    // The frontend validation should prevent this, but this provides a fallback
                    this.studyId = null;
                }
            }
        } else {
            // For any other type, set to null
            this.studyId = null;
        }
    }

    public QuizStatus getStatus() {
        return status;
    }

    public void setStatus(QuizStatus status) {
        this.status = status;
    }

    public List<QuestionDto> getQuestions() {
        return questions;
    }

    public void setQuestions(List<QuestionDto> questions) {
        this.questions = questions;
    }
}

