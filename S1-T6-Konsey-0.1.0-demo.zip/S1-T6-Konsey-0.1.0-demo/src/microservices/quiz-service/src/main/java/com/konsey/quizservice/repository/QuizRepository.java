package com.konsey.quizservice.repository;

import com.konsey.quizservice.entity.Quiz;
import com.konsey.quizservice.entity.QuizStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

/**
 * Repository interface for Quiz entity.
 */
@Repository
public interface QuizRepository extends JpaRepository<Quiz, UUID> {

    /**
     * Find all quizzes created by a specific researcher.
     */
    Page<Quiz> findByResearcherId(UUID researcherId, Pageable pageable);

    /**
     * Find all quizzes associated with a specific study.
     */
    Page<Quiz> findByStudyId(UUID studyId, Pageable pageable);

    /**
     * Find all quizzes by researcher and status.
     */
    Page<Quiz> findByResearcherIdAndStatus(UUID researcherId, QuizStatus status, Pageable pageable);

    /**
     * Find all quizzes by status.
     */
    Page<Quiz> findByStatus(QuizStatus status, Pageable pageable);

    /**
     * Check if a quiz exists and belongs to a researcher.
     */
    boolean existsByQuizIdAndResearcherId(UUID quizId, UUID researcherId);
}

