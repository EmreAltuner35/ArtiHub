package com.konsey.quizservice.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

/**
 * DTO for Answer entity.
 */
public class AnswerDto {

    private String answerId;

    @NotBlank(message = "Answer text cannot be blank")
    private String answerText;

    @NotNull(message = "isCorrect must be specified")
    private Boolean isCorrect;

    @NotNull(message = "Answer order must be specified")
    private Integer answerOrder;

    // Constructors
    public AnswerDto() {}

    public AnswerDto(String answerText, Boolean isCorrect, Integer answerOrder) {
        this.answerText = answerText;
        this.isCorrect = isCorrect;
        this.answerOrder = answerOrder;
    }

    // Getters and Setters
    public String getAnswerId() {
        return answerId;
    }

    public void setAnswerId(String answerId) {
        this.answerId = answerId;
    }

    public String getAnswerText() {
        return answerText;
    }

    public void setAnswerText(String answerText) {
        this.answerText = answerText;
    }

    public Boolean getIsCorrect() {
        return isCorrect;
    }

    public void setIsCorrect(Boolean isCorrect) {
        this.isCorrect = isCorrect;
    }

    public Integer getAnswerOrder() {
        return answerOrder;
    }

    public void setAnswerOrder(Integer answerOrder) {
        this.answerOrder = answerOrder;
    }
}

