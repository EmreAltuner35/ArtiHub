package com.konsey.quizservice.service;

import com.konsey.quizservice.dto.*;
import com.konsey.quizservice.entity.*;
import com.konsey.quizservice.repository.QuizRepository;
import com.konsey.quizservice.utility.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Service class for managing quizzes.
 */
@Service
public class QuizService {

    @Autowired
    private QuizRepository quizRepository;

    private static final ObjectMapper objectMapper = new ObjectMapper();

    /**
     * Create a new quiz.
     */
    @Transactional
    public QuizDto createQuiz(QuizCreationRequest request) {
        UUID researcherId = SecurityUtils.userId();
        if (researcherId == null) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "User not authenticated");
        }
        
        // Only researchers can create quizzes
        String role = SecurityUtils.userRole();
        System.err.println("QuizService.createQuiz(): Extracted role: '" + role + "'");
        
        if (role == null) {
            System.err.println("QuizService.createQuiz(): Role is null - user might not have role claim in JWT");
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Only researchers can create quizzes. Role not found in token.");
        }
        
        // Normalize role: trim whitespace and convert to uppercase for comparison
        String normalizedRole = role.trim().toUpperCase();
        System.err.println("QuizService.createQuiz(): Normalized role: '" + normalizedRole + "'");
        
        if (!normalizedRole.equals("RESEARCHER")) {
            System.err.println("QuizService.createQuiz(): User role '" + normalizedRole + "' is not RESEARCHER");
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Only researchers can create quizzes. Current role: " + role);
        }

        // Create quiz entity
        Quiz quiz = new Quiz(researcherId, request.getTitle(), request.getDescription());
        if (request.getStudyId() != null) {
            quiz.setStudyId(request.getStudyId());
        }
        if (request.getStatus() != null) {
            quiz.setStatus(request.getStatus());
        }
        if (request.getTimeLimit() != null) {
            quiz.setTimeLimit(request.getTimeLimit());
        }

        // Add questions
        if (request.getQuestions() != null && !request.getQuestions().isEmpty()) {
            for (QuestionDto questionDto : request.getQuestions()) {
                // Validate question based on type
                validateQuestion(questionDto);
                
                Question question = new Question(quiz, questionDto.getQuestionText(), 
                    questionDto.getQuestionType(), questionDto.getQuestionOrder());

                // Set images (serialize list to JSON)
                if (questionDto.getImages() != null && !questionDto.getImages().isEmpty()) {
                    try {
                        question.setImages(objectMapper.writeValueAsString(questionDto.getImages()));
                    } catch (JsonProcessingException e) {
                        throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid images data");
                    }
                }

                // Add answers (TEXT questions have no answers)
                if (questionDto.getAnswers() != null && !questionDto.getAnswers().isEmpty()) {
                    for (AnswerDto answerDto : questionDto.getAnswers()) {
                        Answer answer = new Answer(question, answerDto.getAnswerText(), 
                            answerDto.getIsCorrect(), answerDto.getAnswerOrder());
                        question.addAnswer(answer);
                    }
                }
                quiz.addQuestion(question);
            }
        }

        Quiz savedQuiz = quizRepository.save(quiz);
        return convertToDto(savedQuiz);
    }

    /**
     * Get a quiz by ID.
     */
    public QuizDto getQuiz(UUID quizId) {
        Quiz quiz = findQuiz(quizId);
        return convertToDto(quiz);
    }

    /**
     * Update an existing quiz.
     */
    @Transactional
    public QuizDto updateQuiz(UUID quizId, QuizUpdateRequest request) {
        Quiz quiz = findQuiz(quizId);
        UUID researcherId = SecurityUtils.userId();
        
        // Check if user is the owner
        if (!quiz.getResearcherId().equals(researcherId)) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "You don't have permission to update this quiz");
        }

        // Update basic fields
        if (request.getTitle() != null && !request.getTitle().isBlank()) {
            quiz.setTitle(request.getTitle());
        }
        if (request.getDescription() != null) {
            quiz.setDescription(request.getDescription());
        }
        if (request.getTimeLimit() != null) {
             quiz.setTimeLimit(request.getTimeLimit());
        }
        if (request.getStudyId() != null) {
            quiz.setStudyId(request.getStudyId());
        }
        if (request.getStatus() != null) {
            quiz.setStatus(request.getStatus());
        }

        // Update questions if provided
        if (request.getQuestions() != null) {
            // Remove existing questions (cascade will remove answers)
            quiz.getQuestions().clear();
            
            // Add new questions
            for (QuestionDto questionDto : request.getQuestions()) {
                // Validate question based on type
                validateQuestion(questionDto);
                
                Question question = new Question(quiz, questionDto.getQuestionText(), 
                    questionDto.getQuestionType(), questionDto.getQuestionOrder());

                // Set images (serialize list to JSON)
                if (questionDto.getImages() != null && !questionDto.getImages().isEmpty()) {
                    try {
                        question.setImages(objectMapper.writeValueAsString(questionDto.getImages()));
                    } catch (JsonProcessingException e) {
                        throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid images data");
                    }
                }

                // Add answers (TEXT questions have no answers)
                if (questionDto.getAnswers() != null && !questionDto.getAnswers().isEmpty()) {
                    for (AnswerDto answerDto : questionDto.getAnswers()) {
                        Answer answer = new Answer(question, answerDto.getAnswerText(), 
                            answerDto.getIsCorrect(), answerDto.getAnswerOrder());
                        question.addAnswer(answer);
                    }
                }
                quiz.addQuestion(question);
            }
        }

        Quiz updatedQuiz = quizRepository.save(quiz);
        return convertToDto(updatedQuiz);
    }

    /**
     * Delete a quiz.
     */
    @Transactional
    public void deleteQuiz(UUID quizId) {
        Quiz quiz = findQuiz(quizId);
        UUID researcherId = SecurityUtils.userId();
        
        // Check if user is the owner
        if (!quiz.getResearcherId().equals(researcherId)) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "You don't have permission to delete this quiz");
        }

        quizRepository.delete(quiz);
    }

    /**
     * Get all quizzes created by the current user.
     */
    public PagedResponse<QuizDto> getMyQuizzes(int page, int size) {
        UUID researcherId = SecurityUtils.userId();
        if (researcherId == null) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "User not authenticated");
        }

        Pageable pageable = PageRequest.of(page, size);
        Page<Quiz> quizPage = quizRepository.findByResearcherId(researcherId, pageable);

        List<QuizDto> quizDtos = quizPage.getContent().stream()
            .map(this::convertToDto)
            .collect(Collectors.toList());

        return new PagedResponse<>(
            quizDtos,
            quizPage.getNumber(),
            quizPage.getSize(),
            quizPage.getTotalElements(),
            quizPage.getTotalPages(),
            quizPage.isLast()
        );
    }

    /**
     * Get all quizzes by study ID.
     */
    public PagedResponse<QuizDto> getQuizzesByStudy(UUID studyId, int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        Page<Quiz> quizPage = quizRepository.findByStudyId(studyId, pageable);

        List<QuizDto> quizDtos = quizPage.getContent().stream()
            .map(this::convertToDto)
            .collect(Collectors.toList());

        return new PagedResponse<>(
            quizDtos,
            quizPage.getNumber(),
            quizPage.getSize(),
            quizPage.getTotalElements(),
            quizPage.getTotalPages(),
            quizPage.isLast()
        );
    }

    /**
     * Find a quiz by ID or throw exception.
     */
    private Quiz findQuiz(UUID quizId) {
        return quizRepository.findById(quizId)
            .orElseThrow(() -> new ResponseStatusException(
                HttpStatus.NOT_FOUND, "Quiz not found with id: " + quizId));
    }

    /**
     * Convert Quiz entity to QuizDto.
     */
    private QuizDto convertToDto(Quiz quiz) {
        QuizDto dto = new QuizDto();
        dto.setQuizId(quiz.getQuizId());
        dto.setResearcherId(quiz.getResearcherId());
        dto.setStudyId(quiz.getStudyId());
        dto.setTitle(quiz.getTitle());
        dto.setDescription(quiz.getDescription());
        dto.setTimeLimit(quiz.getTimeLimit());
        dto.setStatus(quiz.getStatus());
        dto.setCreatedAt(quiz.getCreatedAt());
        dto.setUpdatedAt(quiz.getUpdatedAt());

        // Convert questions
        List<QuestionDto> questionDtos = quiz.getQuestions().stream()
            .map(this::convertToDto)
            .collect(Collectors.toList());
        dto.setQuestions(questionDtos);

        return dto;
    }

    /**
     * Convert Question entity to QuestionDto.
     */
    private QuestionDto convertToDto(Question question) {
        QuestionDto dto = new QuestionDto();
        dto.setQuestionId(question.getQuestionId().toString());
        dto.setQuestionText(question.getQuestionText());
        dto.setQuestionType(question.getQuestionType());
        dto.setQuestionOrder(question.getQuestionOrder());

        // Convert images JSON to list
        if (question.getImages() != null && !question.getImages().isEmpty()) {
            try {
                List<String> imagesList = objectMapper.readValue(question.getImages(), new TypeReference<List<String>>() {});
                dto.setImages(imagesList);
            } catch (JsonProcessingException e) {
                dto.setImages(new ArrayList<>());
            }
        }

        // Convert answers
        List<AnswerDto> answerDtos = question.getAnswers().stream()
            .map(this::convertToDto)
            .collect(Collectors.toList());
        dto.setAnswers(answerDtos);

        return dto;
    }

    /**
     * Convert Answer entity to AnswerDto.
     */
    private AnswerDto convertToDto(Answer answer) {
        AnswerDto dto = new AnswerDto();
        dto.setAnswerId(answer.getAnswerId().toString());
        dto.setAnswerText(answer.getAnswerText());
        dto.setIsCorrect(answer.getIsCorrect());
        dto.setAnswerOrder(answer.getAnswerOrder());
        return dto;
    }

    /**
     * Validate question based on its type.
     * TEXT questions should have no answers.
     * SINGLE_CHOICE and MULTIPLE_CHOICE questions should have at least 2 answers with at least one correct.
     */
    private void validateQuestion(QuestionDto questionDto) {
        if (questionDto.getQuestionType() == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Question type must be specified");
        }

        if (questionDto.getQuestionText() == null || questionDto.getQuestionText().trim().isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Question text cannot be blank");
        }

        // TEXT questions should have no answers
        if (questionDto.getQuestionType() == QuestionType.TEXT) {
            if (questionDto.getAnswers() != null && !questionDto.getAnswers().isEmpty()) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "TEXT questions should not have answers");
            }
            return; // TEXT questions are valid if they have no answers
        }

        // SINGLE_CHOICE and MULTIPLE_CHOICE questions must have at least 2 answers
        if (questionDto.getAnswers() == null || questionDto.getAnswers().isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "SINGLE_CHOICE and MULTIPLE_CHOICE questions must have at least 2 answers");
        }

        if (questionDto.getAnswers().size() < 2) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "SINGLE_CHOICE and MULTIPLE_CHOICE questions must have at least 2 answers");
        }

        // Validate each answer
        for (AnswerDto answerDto : questionDto.getAnswers()) {
            if (answerDto.getAnswerText() == null || answerDto.getAnswerText().trim().isEmpty()) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Answer text cannot be blank");
            }
            if (answerDto.getIsCorrect() == null) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Answer isCorrect must be specified");
            }
        }

        // At least one answer must be correct
        boolean hasCorrectAnswer = questionDto.getAnswers().stream()
            .anyMatch(AnswerDto::getIsCorrect);
        if (!hasCorrectAnswer) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "At least one answer must be marked as correct");
        }
    }
}

