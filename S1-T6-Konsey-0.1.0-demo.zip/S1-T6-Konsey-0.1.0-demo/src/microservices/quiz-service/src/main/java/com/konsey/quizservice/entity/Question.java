package com.konsey.quizservice.entity;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Represents a question within a quiz.
 * Each question has multiple answer options.
 */
@Entity
@Table(name = "questions")
public class Question {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "question_id", updatable = false, nullable = false)
    private UUID questionId;

    /**
     * The foreign key (FK) relationship to the Quiz.
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "quiz_id", nullable = false)
    private Quiz quiz;

    /**
     * The text of the question.
     */
    @Column(name = "question_text", nullable = false, columnDefinition = "TEXT")
    private String questionText;

    /**
     * The type of question (e.g., SINGLE_CHOICE, MULTIPLE_CHOICE, TEXT).
     */
    @Enumerated(EnumType.STRING)
    @Column(name = "question_type", length = 50, nullable = false)
    private QuestionType questionType = QuestionType.SINGLE_CHOICE;

    /**
     * The order of this question within the quiz.
     */
    @Column(name = "question_order", nullable = false)
    private Integer questionOrder;

    /**
     * One-to-many relationship with Answer entities.
     * Cascade operations allow operations on Question to affect Answers.
     * Orphan removal ensures Answers are deleted when removed from Question.
     */
    @OneToMany(mappedBy = "question", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    @OrderBy("answerOrder ASC")
    private List<Answer> answers = new ArrayList<>();

    /**
     * JSON array of Base64-encoded images for this question.
     */
    @Column(name = "images", columnDefinition = "TEXT")
    private String images;

    // Constructors
    public Question() {}

    public Question(Quiz quiz, String questionText, QuestionType questionType, Integer questionOrder) {
        this.quiz = quiz;
        this.questionText = questionText;
        this.questionType = questionType;
        this.questionOrder = questionOrder;
    }

    // Getters and Setters
    public UUID getQuestionId() {
        return questionId;
    }

    public void setQuestionId(UUID questionId) {
        this.questionId = questionId;
    }

    public Quiz getQuiz() {
        return quiz;
    }

    public void setQuiz(Quiz quiz) {
        this.quiz = quiz;
    }

    public String getQuestionText() {
        return questionText;
    }

    public void setQuestionText(String questionText) {
        this.questionText = questionText;
    }

    public QuestionType getQuestionType() {
        return questionType;
    }

    public void setQuestionType(QuestionType questionType) {
        this.questionType = questionType;
    }

    public Integer getQuestionOrder() {
        return questionOrder;
    }

    public void setQuestionOrder(Integer questionOrder) {
        this.questionOrder = questionOrder;
    }

    public List<Answer> getAnswers() {
        return answers;
    }

    public void setAnswers(List<Answer> answers) {
        this.answers = answers;
    }

    public String getImages() {
        return images;
    }

    public void setImages(String images) {
        this.images = images;
    }

    // Helper methods
    public void addAnswer(Answer answer) {
        answers.add(answer);
        answer.setQuestion(this);
    }

    public void removeAnswer(Answer answer) {
        answers.remove(answer);
        answer.setQuestion(null);
    }
}

