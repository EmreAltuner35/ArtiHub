package com.konsey.quizservice.utility;

import lombok.experimental.UtilityClass;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;

import java.util.Map;
import java.util.UUID;

@UtilityClass
public class SecurityUtils {
    public UUID userId() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null) {
            System.err.println("SecurityUtils.userId(): Authentication is null");
            return null;
        }
        if(!(auth instanceof JwtAuthenticationToken token)) {
            System.err.println("SecurityUtils.userId(): Authentication is not JwtAuthenticationToken, type: " + auth.getClass().getName());
            return null;
        }
        Jwt jwt = token.getToken();
        String id = jwt.getSubject();
        if (id == null) {
            System.err.println("SecurityUtils.userId(): JWT subject is null");
            return null;
        }
        try {
            return UUID.fromString(id);
        } catch (IllegalArgumentException e) {
            System.err.println("SecurityUtils.userId(): Failed to parse UUID: " + id);
            return null;
        }
    }

    public String userRole() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null) {
            System.err.println("SecurityUtils.userRole(): Authentication is null");
            return null;
        }
        if(!(auth instanceof JwtAuthenticationToken token)) {
            System.err.println("SecurityUtils.userRole(): Authentication is not JwtAuthenticationToken, type: " + auth.getClass().getName());
            return null;
        }
        Jwt jwt = token.getToken();
        
        // Debug: Print all claims to see what's in the JWT
        System.err.println("SecurityUtils.userRole(): All JWT claims: " + jwt.getClaims());
        
        // Try to get role as string first
        String role = null;
        try {
            role = jwt.getClaimAsString("role");
        } catch (Exception e) {
            System.err.println("SecurityUtils.userRole(): Failed to get role as string: " + e.getMessage());
        }
        
        if (role == null || role.trim().isEmpty()) {
            // Try to get as object and convert
            Object roleObj = jwt.getClaim("role");
            if (roleObj != null) {
                // Handle different object types
                if (roleObj instanceof String) {
                    role = (String) roleObj;
                } else if (roleObj instanceof Map) {
                    // If it's a map (JSON object), try to get a "name" or "value" field
                    Map<?, ?> roleMap = (Map<?, ?>) roleObj;
                    Object nameObj = roleMap.get("name");
                    if (nameObj != null) {
                        role = nameObj.toString();
                    } else {
                        role = roleObj.toString();
                    }
                } else {
                    // For any other type, convert to string
                    role = roleObj.toString();
                }
                System.err.println("SecurityUtils.userRole(): Role claim is not a string, converted from: " + roleObj.getClass().getName() + " to: '" + role + "'");
            } else {
                System.err.println("SecurityUtils.userRole(): Role claim is null. Available claims: " + jwt.getClaims().keySet());
                return null;
            }
        }
        
        // Normalize the role: trim whitespace and handle case
        if (role != null) {
            role = role.trim();
        }
        
        System.err.println("SecurityUtils.userRole(): Extracted role: '" + role + "'");
        return role;
    }
}

