package com.konsey.quizservice.controller;

import com.konsey.quizservice.dto.*;
import com.konsey.quizservice.service.QuizService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

/**
 * REST controller for quiz management.
 */
@RestController
@RequestMapping("/api/quizzes")
public class QuizController {

    @Autowired
    private QuizService quizService;

    /**
     * Create a new quiz.
     */
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<QuizDto> createQuiz(@Valid @RequestBody QuizCreationRequest request) {
        QuizDto quiz = quizService.createQuiz(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(quiz);
    }

    /**
     * Get a quiz by ID.
     */
    @GetMapping("/{quizId}")
    public ResponseEntity<QuizDto> getQuiz(@PathVariable UUID quizId) {
        QuizDto quiz = quizService.getQuiz(quizId);
        return ResponseEntity.ok(quiz);
    }

    /**
     * Update an existing quiz.
     */
    @PutMapping("/{quizId}")
    public ResponseEntity<QuizDto> updateQuiz(
            @PathVariable UUID quizId,
            @Valid @RequestBody QuizUpdateRequest request) {
        QuizDto quiz = quizService.updateQuiz(quizId, request);
        return ResponseEntity.ok(quiz);
    }

    /**
     * Delete a quiz.
     */
    @DeleteMapping("/{quizId}")
    public ResponseEntity<?> deleteQuiz(@PathVariable UUID quizId) {
        try {
            quizService.deleteQuiz(quizId);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Get all quizzes created by the current user.
     */
    @GetMapping("/my-quizzes")
    public ResponseEntity<PagedResponse<QuizDto>> getMyQuizzes(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        PagedResponse<QuizDto> response = quizService.getMyQuizzes(page, size);
        return ResponseEntity.ok(response);
    }

    /**
     * Get all quizzes for a specific study.
     */
    @GetMapping("/study/{studyId}")
    public ResponseEntity<PagedResponse<QuizDto>> getQuizzesByStudy(
            @PathVariable UUID studyId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        PagedResponse<QuizDto> response = quizService.getQuizzesByStudy(studyId, page, size);
        return ResponseEntity.ok(response);
    }
}

