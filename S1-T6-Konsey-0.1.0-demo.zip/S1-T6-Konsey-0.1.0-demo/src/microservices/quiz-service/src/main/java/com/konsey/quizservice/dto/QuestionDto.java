package com.konsey.quizservice.dto;

import com.konsey.quizservice.entity.QuestionType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.util.ArrayList;
import java.util.List;

/**
 * DTO for Question entity.
 */
public class QuestionDto {

    private String questionId;

    @NotBlank(message = "Question text cannot be blank")
    @Size(max = 2000, message = "Question text must not exceed 2000 characters")
    private String questionText;

    @NotNull(message = "Question type must be specified")
    private QuestionType questionType;

    @NotNull(message = "Question order must be specified")
    private Integer questionOrder;

    // Note: TEXT questions have empty answers, so we validate in service layer based on question type
    // Validation is done in QuizService.validateQuestion() method
    private List<AnswerDto> answers = new ArrayList<>();

    // Base64 encoded images for this question
    private List<String> images = new ArrayList<>();

    // Constructors
    public QuestionDto() {}

    public QuestionDto(String questionText, QuestionType questionType, Integer questionOrder, List<AnswerDto> answers) {
        this.questionText = questionText;
        this.questionType = questionType;
        this.questionOrder = questionOrder;
        this.answers = answers;
    }

    // Getters and Setters
    public String getQuestionId() {
        return questionId;
    }

    public void setQuestionId(String questionId) {
        this.questionId = questionId;
    }

    public String getQuestionText() {
        return questionText;
    }

    public void setQuestionText(String questionText) {
        this.questionText = questionText;
    }

    public QuestionType getQuestionType() {
        return questionType;
    }

    public void setQuestionType(QuestionType questionType) {
        this.questionType = questionType;
    }

    public Integer getQuestionOrder() {
        return questionOrder;
    }

    public void setQuestionOrder(Integer questionOrder) {
        this.questionOrder = questionOrder;
    }

    public List<AnswerDto> getAnswers() {
        return answers;
    }

    public void setAnswers(List<AnswerDto> answers) {
        this.answers = answers;
    }

    public List<String> getImages() {
        return images;
    }

    public void setImages(List<String> images) {
        this.images = images;
    }
}

