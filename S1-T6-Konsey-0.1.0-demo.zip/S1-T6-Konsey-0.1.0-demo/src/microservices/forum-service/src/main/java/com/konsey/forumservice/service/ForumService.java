package com.konsey.forumservice.service;

import com.konsey.forumservice.dto.ForumCreationRequest;
import com.konsey.forumservice.dto.ForumResponse;
import com.konsey.forumservice.dto.ForumUpdateRequest;
import com.konsey.forumservice.entity.Forum;
import com.konsey.forumservice.entity.ForumStatus;
import com.konsey.forumservice.exception.AccessDeniedException;
import com.konsey.forumservice.exception.ResourceNotFoundException;
import com.konsey.forumservice.repository.ForumRepository;
import com.konsey.forumservice.repository.ThreadRepository;
import com.konsey.forumservice.utility.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@Transactional
public class ForumService {

    @Autowired
    private ForumRepository forumRepository;

    @Autowired
    private ThreadRepository threadRepository;

    /**
     * Get all forums accessible to the current user.
     * Admins and Researchers can see all forums.
     * Other users can see public forums (no studyId) and forums linked to their studies.
     */
    public List<ForumResponse> getAccessibleForums() {
        List<Forum> forums;
        
        if (SecurityUtils.isAdmin() || SecurityUtils.isResearcher()) {
            forums = forumRepository.findAll();
        } else {
            // For now, return all public forums (studyId is null)
            // In a full implementation, we'd check which studies the user has access to
            forums = forumRepository.findByStudyIdIsNull();
        }
        
        return forums.stream()
                .map(forum -> {
                    long threadCount = threadRepository.countByForumId(forum.getForumId());
                    return ForumResponse.fromEntity(forum, threadCount);
                })
                .collect(Collectors.toList());
    }

    /**
     * Get a forum by ID.
     */
    public ForumResponse getForumById(UUID forumId) {
        Forum forum = findForumOrThrow(forumId);
        long threadCount = threadRepository.countByForumId(forumId);
        return ForumResponse.fromEntity(forum, threadCount);
    }

    /**
     * Get the raw Forum entity by ID.
     */
    public Forum findForumOrThrow(UUID forumId) {
        return forumRepository.findById(forumId)
                .orElseThrow(() -> new ResourceNotFoundException("Forum not found: " + forumId));
    }

    /**
     * Create a new forum. Only Admins and Researchers can create forums.
     */
    public ForumResponse createForum(ForumCreationRequest request) {
        if (!SecurityUtils.isAdmin() && !SecurityUtils.isResearcher()) {
            throw new AccessDeniedException("Only Admins and Researchers can create forums");
        }

        UUID userId = SecurityUtils.userId();
        Forum forum = new Forum(request.getTitle(), request.getDescription(), userId);
        forum.setStudyId(request.getStudyId());

        Forum saved = forumRepository.save(forum);
        return ForumResponse.fromEntity(saved);
    }

    /**
     * Update a forum. Only the manager, creator, or admin can update.
     */
    public ForumResponse updateForum(UUID forumId, ForumUpdateRequest request) {
        Forum forum = findForumOrThrow(forumId);
        checkModeratorAccess(forum);

        if (request.getTitle() != null) {
            forum.setTitle(request.getTitle());
        }
        if (request.getDescription() != null) {
            forum.setDescription(request.getDescription());
        }
        if (request.getManagerId() != null) {
            forum.setManagerId(request.getManagerId());
        }
        if (request.getStatus() != null) {
            forum.setStatus(request.getStatus());
        }

        Forum saved = forumRepository.save(forum);
        return ForumResponse.fromEntity(saved);
    }

    /**
     * Archive a forum (read-only, no new content).
     */
    public ForumResponse archiveForum(UUID forumId) {
        Forum forum = findForumOrThrow(forumId);
        checkModeratorAccess(forum);
        
        forum.setStatus(ForumStatus.ARCHIVED);
        Forum saved = forumRepository.save(forum);
        return ForumResponse.fromEntity(saved);
    }

    /**
     * Close a forum (read-only, no new content).
     */
    public ForumResponse closeForum(UUID forumId) {
        Forum forum = findForumOrThrow(forumId);
        checkModeratorAccess(forum);
        
        forum.setStatus(ForumStatus.CLOSED);
        Forum saved = forumRepository.save(forum);
        return ForumResponse.fromEntity(saved);
    }

    /**
     * Reopen an archived/closed forum.
     */
    public ForumResponse reopenForum(UUID forumId) {
        Forum forum = findForumOrThrow(forumId);
        checkModeratorAccess(forum);
        
        forum.setStatus(ForumStatus.ACTIVE);
        Forum saved = forumRepository.save(forum);
        return ForumResponse.fromEntity(saved);
    }

    /**
     * Delete a forum. Only admins can delete.
     */
    public void deleteForum(UUID forumId) {
        if (!SecurityUtils.isAdmin()) {
            throw new AccessDeniedException("Only Admins can delete forums");
        }
        
        Forum forum = findForumOrThrow(forumId);
        forumRepository.delete(forum);
    }

    /**
     * Check if the current user has moderator access to the forum.
     */
    private void checkModeratorAccess(Forum forum) {
        UUID userId = SecurityUtils.userId();
        boolean isCreator = userId.equals(forum.getCreatedBy());
        boolean isManager = userId.equals(forum.getManagerId());
        
        if (!SecurityUtils.isAdmin() && !isCreator && !isManager) {
            throw new AccessDeniedException("You don't have permission to modify this forum");
        }
    }

    /**
     * Check if the current user can post in the forum.
     */
    public boolean canUserPost(Forum forum) {
        if (forum.isReadOnly()) {
            return false;
        }
        // All authenticated users can post in active forums
        return true;
    }
}
