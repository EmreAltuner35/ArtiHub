package com.konsey.forumservice.controller;

import com.konsey.forumservice.dto.ForumCreationRequest;
import com.konsey.forumservice.dto.ForumResponse;
import com.konsey.forumservice.dto.ForumUpdateRequest;
import com.konsey.forumservice.service.ForumService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/forums")
public class ForumController {

    @Autowired
    private ForumService forumService;

    /**
     * Get all accessible forums.
     */
    @GetMapping
    public ResponseEntity<List<ForumResponse>> getForums() {
        List<ForumResponse> forums = forumService.getAccessibleForums();
        return ResponseEntity.ok(forums);
    }

    /**
     * Get a specific forum by ID.
     */
    @GetMapping("/{forumId}")
    public ResponseEntity<ForumResponse> getForumById(@PathVariable UUID forumId) {
        ForumResponse forum = forumService.getForumById(forumId);
        return ResponseEntity.ok(forum);
    }

    /**
     * Create a new forum.
     */
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<ForumResponse> createForum(@Valid @RequestBody ForumCreationRequest request) {
        ForumResponse forum = forumService.createForum(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(forum);
    }

    /**
     * Update a forum.
     */
    @PutMapping("/{forumId}")
    public ResponseEntity<ForumResponse> updateForum(
            @PathVariable UUID forumId,
            @RequestBody ForumUpdateRequest request) {
        ForumResponse forum = forumService.updateForum(forumId, request);
        return ResponseEntity.ok(forum);
    }

    /**
     * Archive a forum (read-only).
     */
    @PutMapping("/{forumId}/archive")
    public ResponseEntity<ForumResponse> archiveForum(@PathVariable UUID forumId) {
        ForumResponse forum = forumService.archiveForum(forumId);
        return ResponseEntity.ok(forum);
    }

    /**
     * Close a forum (read-only).
     */
    @PutMapping("/{forumId}/close")
    public ResponseEntity<ForumResponse> closeForum(@PathVariable UUID forumId) {
        ForumResponse forum = forumService.closeForum(forumId);
        return ResponseEntity.ok(forum);
    }

    /**
     * Reopen an archived/closed forum.
     */
    @PutMapping("/{forumId}/reopen")
    public ResponseEntity<ForumResponse> reopenForum(@PathVariable UUID forumId) {
        ForumResponse forum = forumService.reopenForum(forumId);
        return ResponseEntity.ok(forum);
    }

    /**
     * Delete a forum.
     */
    @DeleteMapping("/{forumId}")
    public ResponseEntity<Void> deleteForum(@PathVariable UUID forumId) {
        forumService.deleteForum(forumId);
        return ResponseEntity.noContent().build();
    }
}
