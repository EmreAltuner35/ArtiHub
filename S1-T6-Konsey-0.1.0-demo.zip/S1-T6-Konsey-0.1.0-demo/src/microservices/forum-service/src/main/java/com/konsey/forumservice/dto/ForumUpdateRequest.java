package com.konsey.forumservice.dto;

import com.konsey.forumservice.entity.ForumStatus;

import java.util.UUID;

public class ForumUpdateRequest {

    private String title;
    private String description;
    private UUID managerId;
    private ForumStatus status;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public UUID getManagerId() {
        return managerId;
    }

    public void setManagerId(UUID managerId) {
        this.managerId = managerId;
    }

    public ForumStatus getStatus() {
        return status;
    }

    public void setStatus(ForumStatus status) {
        this.status = status;
    }
}
