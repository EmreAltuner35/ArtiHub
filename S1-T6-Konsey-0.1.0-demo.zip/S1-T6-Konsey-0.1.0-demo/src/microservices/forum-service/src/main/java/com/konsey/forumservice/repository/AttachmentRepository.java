package com.konsey.forumservice.repository;

import com.konsey.forumservice.entity.PostAttachment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface AttachmentRepository extends JpaRepository<PostAttachment, UUID> {

    @Query("SELECT a FROM PostAttachment a WHERE a.post.postId = :postId")
    List<PostAttachment> findByPostId(@Param("postId") UUID postId);

    @Query("SELECT a FROM PostAttachment a WHERE a.thread.threadId = :threadId")
    List<PostAttachment> findByThreadId(@Param("threadId") UUID threadId);

    void deleteByPostPostId(UUID postId);

    void deleteByThreadThreadId(UUID threadId);
}
