package com.konsey.forumservice.entity;

import jakarta.persistence.*;

import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Represents an attachment on a post or thread.
 * Can be a direct file upload or a link to an artifact.
 */
@Entity
@Table(name = "POST_ATTACHMENT")
public class PostAttachment {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "attachment_id", updatable = false, nullable = false)
    private UUID attachmentId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "post_id")
    private Post post;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "thread_id")
    private ForumThread thread;

    @Enumerated(EnumType.STRING)
    @Column(name = "type", length = 20)
    private AttachmentType type;

    /**
     * If type is ARTIFACT_LINK, this is the artifact ID from artifact-service.
     */
    @Column(name = "artifact_id")
    private UUID artifactId;

    @Column(name = "file_name")
    private String fileName;

    /**
     * If type is FILE, this is the URL or storage path of the file.
     */
    @Column(name = "file_url")
    private String fileUrl;

    @Column(name = "content_type")
    private String contentType;

    @Column(name = "file_size")
    private Long fileSize;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    public PostAttachment() {
    }

    public PostAttachment(Post post, AttachmentType type, String fileName, String fileUrl) {
        this.post = post;
        this.type = type;
        this.fileName = fileName;
        this.fileUrl = fileUrl;
        this.createdAt = LocalDateTime.now();
    }

    public PostAttachment(ForumThread thread, AttachmentType type, String fileName, String fileUrl) {
        this.thread = thread;
        this.type = type;
        this.fileName = fileName;
        this.fileUrl = fileUrl;
        this.createdAt = LocalDateTime.now();
    }

    public static PostAttachment createArtifactLink(Post post, UUID artifactId, String fileName) {
        PostAttachment attachment = new PostAttachment();
        attachment.setPost(post);
        attachment.setType(AttachmentType.ARTIFACT_LINK);
        attachment.setArtifactId(artifactId);
        attachment.setFileName(fileName);
        attachment.setCreatedAt(LocalDateTime.now());
        return attachment;
    }

    public static PostAttachment createArtifactLink(ForumThread thread, UUID artifactId, String fileName) {
        PostAttachment attachment = new PostAttachment();
        attachment.setThread(thread);
        attachment.setType(AttachmentType.ARTIFACT_LINK);
        attachment.setArtifactId(artifactId);
        attachment.setFileName(fileName);
        attachment.setCreatedAt(LocalDateTime.now());
        return attachment;
    }

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
    }

    // Getters and Setters
    public UUID getAttachmentId() {
        return attachmentId;
    }

    public Post getPost() {
        return post;
    }

    public void setPost(Post post) {
        this.post = post;
    }

    public ForumThread getThread() {
        return thread;
    }

    public void setThread(ForumThread thread) {
        this.thread = thread;
    }

    public AttachmentType getType() {
        return type;
    }

    public void setType(AttachmentType type) {
        this.type = type;
    }

    public UUID getArtifactId() {
        return artifactId;
    }

    public void setArtifactId(UUID artifactId) {
        this.artifactId = artifactId;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFileUrl() {
        return fileUrl;
    }

    public void setFileUrl(String fileUrl) {
        this.fileUrl = fileUrl;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public Long getFileSize() {
        return fileSize;
    }

    public void setFileSize(Long fileSize) {
        this.fileSize = fileSize;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
}
