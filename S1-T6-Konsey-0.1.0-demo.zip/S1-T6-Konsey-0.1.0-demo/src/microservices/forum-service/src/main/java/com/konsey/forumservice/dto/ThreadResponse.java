package com.konsey.forumservice.dto;

import com.konsey.forumservice.entity.ForumThread;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

public class ThreadResponse {

    private UUID threadId;
    private UUID forumId;
    private String forumTitle;
    private String title;
    private String body;
    private UUID authorId;
    private String authorName;
    private boolean isLocked;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private long replyCount;
    private List<AttachmentResponse> attachments;

    public ThreadResponse() {
    }

    public static ThreadResponse fromEntity(ForumThread thread) {
        ThreadResponse response = new ThreadResponse();
        response.setThreadId(thread.getThreadId());
        response.setForumId(thread.getForumId());
        if (thread.getForum() != null) {
            response.setForumTitle(thread.getForum().getTitle());
        }
        response.setTitle(thread.getTitle());
        response.setBody(thread.getBody());
        response.setAuthorId(thread.getAuthorId());
        response.setAuthorName(thread.getAuthorName());
        response.setLocked(thread.isLocked());
        response.setCreatedAt(thread.getCreatedAt());
        response.setUpdatedAt(thread.getUpdatedAt());
        response.setReplyCount(thread.getPosts() != null ? thread.getPosts().size() : 0);
        if (thread.getAttachments() != null) {
            response.setAttachments(thread.getAttachments().stream()
                    .map(AttachmentResponse::fromEntity)
                    .collect(Collectors.toList()));
        }
        return response;
    }

    public static ThreadResponse fromEntity(ForumThread thread, long replyCount) {
        ThreadResponse response = fromEntity(thread);
        response.setReplyCount(replyCount);
        return response;
    }

    // Getters and Setters
    public UUID getThreadId() {
        return threadId;
    }

    public void setThreadId(UUID threadId) {
        this.threadId = threadId;
    }

    public UUID getForumId() {
        return forumId;
    }

    public void setForumId(UUID forumId) {
        this.forumId = forumId;
    }

    public String getForumTitle() {
        return forumTitle;
    }

    public void setForumTitle(String forumTitle) {
        this.forumTitle = forumTitle;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public UUID getAuthorId() {
        return authorId;
    }

    public void setAuthorId(UUID authorId) {
        this.authorId = authorId;
    }

    public String getAuthorName() {
        return authorName;
    }

    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }

    public boolean isLocked() {
        return isLocked;
    }

    public void setLocked(boolean locked) {
        isLocked = locked;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public long getReplyCount() {
        return replyCount;
    }

    public void setReplyCount(long replyCount) {
        this.replyCount = replyCount;
    }

    public List<AttachmentResponse> getAttachments() {
        return attachments;
    }

    public void setAttachments(List<AttachmentResponse> attachments) {
        this.attachments = attachments;
    }
}
