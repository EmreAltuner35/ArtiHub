package com.konsey.forumservice.service;

import com.konsey.forumservice.dto.ThreadCreationRequest;
import com.konsey.forumservice.dto.ThreadResponse;
import com.konsey.forumservice.entity.*;
import com.konsey.forumservice.exception.AccessDeniedException;
import com.konsey.forumservice.exception.ForumClosedException;
import com.konsey.forumservice.exception.ResourceNotFoundException;
import com.konsey.forumservice.repository.AttachmentRepository;
import com.konsey.forumservice.repository.PostRepository;
import com.konsey.forumservice.repository.ThreadRepository;
import com.konsey.forumservice.utility.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@Transactional
public class ThreadService {

    @Autowired
    private ThreadRepository threadRepository;

    @Autowired
    private PostRepository postRepository;

    @Autowired
    private AttachmentRepository attachmentRepository;

    @Autowired
    private ForumService forumService;

    /**
     * Get all threads in a forum.
     */
    public List<ThreadResponse> getThreadsByForum(UUID forumId) {
        // Verify forum exists
        forumService.findForumOrThrow(forumId);
        
        List<ForumThread> threads = threadRepository.findByForumId(forumId);
        return threads.stream()
                .map(thread -> {
                    long replyCount = postRepository.countByThreadId(thread.getThreadId());
                    return ThreadResponse.fromEntity(thread, replyCount);
                })
                .collect(Collectors.toList());
    }

    /**
     * Get a thread by ID with attachments eagerly loaded.
     */
    public ThreadResponse getThreadById(UUID threadId) {
        ForumThread thread = threadRepository.findByIdWithAttachments(threadId)
                .orElseThrow(() -> new ResourceNotFoundException("Thread not found: " + threadId));
        long replyCount = postRepository.countByThreadId(threadId);
        return ThreadResponse.fromEntity(thread, replyCount);
    }

    /**
     * Get the raw ForumThread entity by ID.
     */
    public ForumThread findThreadOrThrow(UUID threadId) {
        return threadRepository.findById(threadId)
                .orElseThrow(() -> new ResourceNotFoundException("Thread not found: " + threadId));
    }

    /**
     * Create a new thread in a forum.
     */
    @Autowired
    private ArtifactUploadService artifactUploadService;

    /**
     * Create a new thread in a forum.
     */
    public ThreadResponse createThread(UUID forumId, ThreadCreationRequest request, List<org.springframework.web.multipart.MultipartFile> files) {
        Forum forum = forumService.findForumOrThrow(forumId);
        
        if (forum.isReadOnly()) {
            throw new ForumClosedException("Cannot create threads in archived/closed forums");
        }

        // Check if user can create threads (Researcher or Admin for study-linked forums)
        if (!canUserCreateThread(forum)) {
            throw new AccessDeniedException("You don't have permission to create threads in this forum");
        }

        UUID userId = SecurityUtils.userId();
        String displayName = SecurityUtils.displayName();
        
        ForumThread thread = new ForumThread(forum, request.getTitle(), request.getBody(), userId, displayName);
        
        // Add artifact attachments if provided (linked existing artifacts)
        if (request.getArtifactIds() != null && !request.getArtifactIds().isEmpty()) {
            for (UUID artifactId : request.getArtifactIds()) {
                PostAttachment attachment = PostAttachment.createArtifactLink(thread, artifactId, "artifact:" + artifactId);
                thread.getAttachments().add(attachment);
            }
        }

        // Upload and add new files
        if (files != null && !files.isEmpty()) {
            for (org.springframework.web.multipart.MultipartFile file : files) {
                try {
                    // Upload to artifact-service
                    UUID artifactId = artifactUploadService.uploadFile(file, "FORUM_ATTACHMENT");
                    
                    // Create attachment link
                    PostAttachment attachment = PostAttachment.createArtifactLink(
                        thread, 
                        artifactId, 
                        file.getOriginalFilename()
                    );
                    thread.getAttachments().add(attachment);
                } catch (Exception e) {
                    // Log error but continue with other files if one fails? 
                    // Or abort? For now, we'll log and throw to ensure user knows it failed.
                    throw new RuntimeException("Failed to upload file: " + file.getOriginalFilename(), e);
                }
            }
        }

        ForumThread saved = threadRepository.save(thread);
        return ThreadResponse.fromEntity(saved);
    }

    /**
     * Update a thread's title or body.
     */
    public ThreadResponse updateThread(UUID threadId, String title, String body) {
        ForumThread thread = findThreadOrThrow(threadId);
        
        if (thread.getForum().isReadOnly()) {
            throw new ForumClosedException("Cannot update threads in archived/closed forums");
        }
        
        checkAuthorOrModerator(thread);
        
        if (title != null) {
            thread.setTitle(title);
        }
        if (body != null) {
            thread.setBody(body);
        }

        ForumThread saved = threadRepository.save(thread);
        return ThreadResponse.fromEntity(saved);
    }

    /**
     * Lock a thread (prevents new replies).
     */
    public ThreadResponse lockThread(UUID threadId) {
        ForumThread thread = findThreadOrThrow(threadId);
        checkModeratorAccess(thread);
        
        thread.setLocked(true);
        ForumThread saved = threadRepository.save(thread);
        return ThreadResponse.fromEntity(saved);
    }

    /**
     * Unlock a thread (allows new replies).
     */
    public ThreadResponse unlockThread(UUID threadId) {
        ForumThread thread = findThreadOrThrow(threadId);
        checkModeratorAccess(thread);
        
        thread.setLocked(false);
        ForumThread saved = threadRepository.save(thread);
        return ThreadResponse.fromEntity(saved);
    }

    /**
     * Delete a thread (soft delete).
     */
    public void deleteThread(UUID threadId) {
        ForumThread thread = findThreadOrThrow(threadId);
        checkAuthorOrModerator(thread);
        
        thread.setDeleted(true);
        threadRepository.save(thread);
    }

    /**
     * Hard delete a thread. Only admins can do this.
     */
    public void hardDeleteThread(UUID threadId) {
        if (!SecurityUtils.isAdmin()) {
            throw new AccessDeniedException("Only Admins can permanently delete threads");
        }
        
        ForumThread thread = findThreadOrThrow(threadId);
        threadRepository.delete(thread);
    }

    /**
     * Check if user can create threads in the forum.
     */
    private boolean canUserCreateThread(Forum forum) {
        // Admins and Researchers can always create threads
        if (SecurityUtils.isAdmin() || SecurityUtils.isResearcher()) {
            return true;
        }
        
        // For public forums (no studyId), all authenticated users can create threads
        if (forum.getStudyId() == null) {
            return true;
        }
        
        // For study-linked forums, check would require study-service integration
        // For now, allow all users
        return true;
    }

    /**
     * Check if current user is the thread author or a moderator.
     */
    private void checkAuthorOrModerator(ForumThread thread) {
        UUID userId = SecurityUtils.userId();
        boolean isAuthor = userId.equals(thread.getAuthorId());
        
        if (!SecurityUtils.isModerator() && !isAuthor) {
            throw new AccessDeniedException("You don't have permission to modify this thread");
        }
    }

    /**
     * Check if current user has moderator access to the thread.
     */
    private void checkModeratorAccess(ForumThread thread) {
        if (!SecurityUtils.isModerator()) {
            throw new AccessDeniedException("Only moderators can perform this action");
        }
    }
}
