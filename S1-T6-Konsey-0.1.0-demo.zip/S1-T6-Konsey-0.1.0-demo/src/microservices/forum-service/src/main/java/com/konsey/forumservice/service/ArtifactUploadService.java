package com.konsey.forumservice.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.MediaType;
import org.springframework.http.client.MultipartBodyBuilder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;

import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Service
public class ArtifactUploadService {

    private final WebClient webClient;
    private final ObjectMapper objectMapper;

    @Autowired
    public ArtifactUploadService(WebClient.Builder webClientBuilder, 
                                 ObjectMapper objectMapper,
                                 @Value("${artifact.service.url:http://artifact-service:8080}") String artifactServiceUrl) {
        this.webClient = webClientBuilder.baseUrl(artifactServiceUrl).build();
        this.objectMapper = objectMapper;
    }

    /**
     * Upload a file to the artifact-service and return the created artifact ID.
     */
    public UUID uploadFile(MultipartFile file, String type) {
        try {
            MultipartBodyBuilder builder = new MultipartBodyBuilder();
            
            // Add file part
            builder.part("file", new ByteArrayResource(file.getBytes()) {
                @Override
                public String getFilename() {
                    return file.getOriginalFilename();
                }
            });

            // Add meta part
            Map<String, Object> meta = Map.of(
                "title", file.getOriginalFilename(),
                "type", type != null ? type : "FILE", // Default type
                "isAIGenerated", false,
                "tags", java.util.Collections.singletonList("forum-attachment")
            );
            String metaJson = objectMapper.writeValueAsString(meta);
            builder.part("meta", metaJson, MediaType.APPLICATION_JSON);


            String token = com.konsey.forumservice.utility.SecurityUtils.getToken();
            
            // Execute request
            Map response = webClient.post()
                    .uri("/api/artifacts")
                    .contentType(MediaType.MULTIPART_FORM_DATA)
                    .header("Authorization", token != null ? "Bearer " + token : null)
                    .body(BodyInserters.fromMultipartData(builder.build()))
                    .retrieve()
                    .bodyToMono(Map.class)
                    .block();

            if (response != null && response.get("id") != null) {
                return UUID.fromString((String) response.get("id"));
            } else {
                throw new RuntimeException("Failed to upload artifact: No ID returned");
            }
        } catch (IOException e) {
            throw new RuntimeException("Failed to read file bytes", e);
        } catch (Exception e) {
            throw new RuntimeException("Failed to upload artifact to service", e);
        }
    }
}
