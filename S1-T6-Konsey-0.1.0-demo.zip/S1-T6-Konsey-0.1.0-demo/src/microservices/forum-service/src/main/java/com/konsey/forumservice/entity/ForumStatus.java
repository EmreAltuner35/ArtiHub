package com.konsey.forumservice.entity;

/**
 * Represents the status of a forum.
 */
public enum ForumStatus {
    ACTIVE,     // Forum is open for new threads and posts
    ARCHIVED,   // Forum is read-only, no new content allowed
    CLOSED      // Forum is closed, no new content allowed
}
