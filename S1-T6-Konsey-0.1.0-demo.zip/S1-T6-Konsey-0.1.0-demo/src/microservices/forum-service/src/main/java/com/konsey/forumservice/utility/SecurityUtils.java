package com.konsey.forumservice.utility;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;

import java.util.UUID;

/**
 * Utility class for extracting security information from the current context.
 */
public class SecurityUtils {

    private SecurityUtils() {
        // Utility class - no instantiation
    }

    /**
     * Get the current authenticated user's ID from JWT claims.
     */
    public static UUID userId() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !(authentication.getPrincipal() instanceof Jwt)) {
            throw new RuntimeException("No authenticated user found");
        }
        Jwt jwt = (Jwt) authentication.getPrincipal();
        String sub = jwt.getClaimAsString("sub");
        return UUID.fromString(sub);
    }

    /**
     * Get the current authenticated user's display name from JWT claims.
     */
    public static String displayName() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !(authentication.getPrincipal() instanceof Jwt)) {
            return "Unknown";
        }
        Jwt jwt = (Jwt) authentication.getPrincipal();
        String displayName = jwt.getClaimAsString("displayName");
        return displayName != null ? displayName : "Unknown";
    }

    /**
     * Get the current authenticated user's role from JWT claims.
     */
    public static String role() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !(authentication.getPrincipal() instanceof Jwt)) {
            return null;
        }
        Jwt jwt = (Jwt) authentication.getPrincipal();
        return jwt.getClaimAsString("role");
    }

    /**
     * Check if the current user is an admin.
     */
    public static boolean isAdmin() {
        String role = role();
        return "ADMIN".equalsIgnoreCase(role);
    }

    /**
     * Check if the current user is a researcher.
     */
    public static boolean isResearcher() {
        String role = role();
        return "RESEARCHER".equalsIgnoreCase(role);
    }

    /**
     * Check if the current user has moderator permissions (Admin or Researcher).
     */
    public static boolean isModerator() {
        return isAdmin() || isResearcher();
    }

    /**
     * Get the current JWT token value.
     */
    public static String getToken() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !(authentication.getPrincipal() instanceof Jwt)) {
            return null;
        }
        Jwt jwt = (Jwt) authentication.getPrincipal();
        return jwt.getTokenValue();
    }
}
