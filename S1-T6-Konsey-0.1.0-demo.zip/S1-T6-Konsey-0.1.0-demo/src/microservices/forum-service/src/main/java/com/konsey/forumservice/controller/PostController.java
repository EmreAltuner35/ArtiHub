package com.konsey.forumservice.controller;

import com.konsey.forumservice.dto.PostCreationRequest;
import com.konsey.forumservice.dto.PostResponse;
import com.konsey.forumservice.dto.PostUpdateRequest;
import com.konsey.forumservice.service.PostService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/forums")
public class PostController {

    @Autowired
    private PostService postService;

    /**
     * Create a new post/reply in a thread with optional file uploads.
     */
    @PostMapping(value = "/threads/{threadId}/posts", consumes = {org.springframework.http.MediaType.MULTIPART_FORM_DATA_VALUE})
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<PostResponse> createPost(
            @PathVariable UUID threadId,
            @RequestPart("data") @Valid PostCreationRequest request,
            @RequestPart(value = "files", required = false) java.util.List<org.springframework.web.multipart.MultipartFile> files) {
        PostResponse post = postService.createPost(threadId, request, files);
        return ResponseEntity.status(HttpStatus.CREATED).body(post);
    }

    /**
     * Get a specific post by ID.
     */
    @GetMapping("/posts/{postId}")
    public ResponseEntity<PostResponse> getPostById(@PathVariable UUID postId) {
        PostResponse post = postService.getPostById(postId);
        return ResponseEntity.ok(post);
    }

    /**
     * Update a post.
     */
    @PutMapping("/posts/{postId}")
    public ResponseEntity<PostResponse> updatePost(
            @PathVariable UUID postId,
            @RequestBody PostUpdateRequest request) {
        PostResponse post = postService.updatePost(postId, request);
        return ResponseEntity.ok(post);
    }

    /**
     * Delete a post (soft delete).
     */
    @DeleteMapping("/posts/{postId}")
    public ResponseEntity<Void> deletePost(@PathVariable UUID postId) {
        postService.deletePost(postId);
        return ResponseEntity.noContent().build();
    }

    /**
     * Add an artifact attachment to a post.
     */
    @PostMapping("/posts/{postId}/attachments")
    public ResponseEntity<PostResponse> addAttachment(
            @PathVariable UUID postId,
            @RequestBody Map<String, String> body) {
        UUID artifactId = UUID.fromString(body.get("artifactId"));
        String fileName = body.getOrDefault("fileName", "attachment");
        PostResponse post = postService.addArtifactAttachment(postId, artifactId, fileName);
        return ResponseEntity.ok(post);
    }

    /**
     * Remove an attachment.
     */
    @DeleteMapping("/attachments/{attachmentId}")
    public ResponseEntity<Void> removeAttachment(@PathVariable UUID attachmentId) {
        postService.removeAttachment(attachmentId);
        return ResponseEntity.noContent().build();
    }
}
