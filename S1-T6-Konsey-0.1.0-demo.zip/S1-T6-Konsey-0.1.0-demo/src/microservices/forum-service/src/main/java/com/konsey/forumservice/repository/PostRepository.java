package com.konsey.forumservice.repository;

import com.konsey.forumservice.entity.Post;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface PostRepository extends JpaRepository<Post, UUID> {

    @Query("SELECT DISTINCT p FROM Post p LEFT JOIN FETCH p.attachments WHERE p.thread.threadId = :threadId ORDER BY p.createdAt ASC")
    List<Post> findByThreadId(@Param("threadId") UUID threadId);

    @Query("SELECT p FROM Post p WHERE p.authorId = :authorId AND p.isDeleted = false ORDER BY p.createdAt DESC")
    List<Post> findByAuthorId(@Param("authorId") UUID authorId);

    @Query("SELECT COUNT(p) FROM Post p WHERE p.thread.threadId = :threadId AND p.isDeleted = false")
    long countByThreadId(@Param("threadId") UUID threadId);
}
