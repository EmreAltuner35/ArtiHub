package com.konsey.forumservice.controller;

import com.konsey.forumservice.dto.PostResponse;
import com.konsey.forumservice.dto.ThreadCreationRequest;
import com.konsey.forumservice.dto.ThreadResponse;
import com.konsey.forumservice.service.PostService;
import com.konsey.forumservice.service.ThreadService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/forums")
public class ThreadController {

    @Autowired
    private ThreadService threadService;

    @Autowired
    private PostService postService;

    /**
     * Get all threads in a forum.
     */
    @GetMapping("/{forumId}/threads")
    public ResponseEntity<List<ThreadResponse>> getThreadsByForum(@PathVariable UUID forumId) {
        List<ThreadResponse> threads = threadService.getThreadsByForum(forumId);
        return ResponseEntity.ok(threads);
    }

    /**
     * Create a new thread in a forum with optional file uploads.
     */
    @PostMapping(value = "/{forumId}/threads", consumes = {org.springframework.http.MediaType.MULTIPART_FORM_DATA_VALUE})
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<ThreadResponse> createThread(
            @PathVariable UUID forumId,
            @RequestPart("data") @Valid ThreadCreationRequest request,
            @RequestPart(value = "files", required = false) List<org.springframework.web.multipart.MultipartFile> files) {
        ThreadResponse thread = threadService.createThread(forumId, request, files);
        return ResponseEntity.status(HttpStatus.CREATED).body(thread);
    }

    /**
     * Get a specific thread by ID.
     */
    @GetMapping("/threads/{threadId}")
    public ResponseEntity<ThreadResponse> getThreadById(@PathVariable UUID threadId) {
        ThreadResponse thread = threadService.getThreadById(threadId);
        return ResponseEntity.ok(thread);
    }

    /**
     * Get all posts in a thread.
     */
    @GetMapping("/threads/{threadId}/posts")
    public ResponseEntity<List<PostResponse>> getPostsByThread(@PathVariable UUID threadId) {
        List<PostResponse> posts = postService.getPostsByThread(threadId);
        return ResponseEntity.ok(posts);
    }

    /**
     * Update a thread.
     */
    @PutMapping("/threads/{threadId}")
    public ResponseEntity<ThreadResponse> updateThread(
            @PathVariable UUID threadId,
            @RequestBody Map<String, String> body) {
        String title = body.get("title");
        String bodyContent = body.get("body");
        ThreadResponse thread = threadService.updateThread(threadId, title, bodyContent);
        return ResponseEntity.ok(thread);
    }

    /**
     * Lock a thread.
     */
    @PutMapping("/threads/{threadId}/lock")
    public ResponseEntity<ThreadResponse> lockThread(@PathVariable UUID threadId) {
        ThreadResponse thread = threadService.lockThread(threadId);
        return ResponseEntity.ok(thread);
    }

    /**
     * Unlock a thread.
     */
    @PutMapping("/threads/{threadId}/unlock")
    public ResponseEntity<ThreadResponse> unlockThread(@PathVariable UUID threadId) {
        ThreadResponse thread = threadService.unlockThread(threadId);
        return ResponseEntity.ok(thread);
    }

    /**
     * Delete a thread (soft delete).
     */
    @DeleteMapping("/threads/{threadId}")
    public ResponseEntity<Void> deleteThread(@PathVariable UUID threadId) {
        threadService.deleteThread(threadId);
        return ResponseEntity.noContent().build();
    }
}
