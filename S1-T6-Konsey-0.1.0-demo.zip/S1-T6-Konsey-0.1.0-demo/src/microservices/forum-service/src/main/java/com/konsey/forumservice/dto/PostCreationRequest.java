package com.konsey.forumservice.dto;

import jakarta.validation.constraints.NotBlank;

import java.util.List;
import java.util.UUID;

public class PostCreationRequest {

    @NotBlank(message = "Content is required")
    private String content;

    private List<UUID> artifactIds;

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public List<UUID> getArtifactIds() {
        return artifactIds;
    }

    public void setArtifactIds(List<UUID> artifactIds) {
        this.artifactIds = artifactIds;
    }
}
