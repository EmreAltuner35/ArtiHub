package com.konsey.forumservice.repository;

import com.konsey.forumservice.entity.ForumThread;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface ThreadRepository extends JpaRepository<ForumThread, UUID> {

    @Query("SELECT t FROM ForumThread t WHERE t.forum.forumId = :forumId AND t.isDeleted = false ORDER BY t.createdAt DESC")
    List<ForumThread> findByForumId(@Param("forumId") UUID forumId);

    @Query("SELECT t FROM ForumThread t WHERE t.authorId = :authorId AND t.isDeleted = false ORDER BY t.createdAt DESC")
    List<ForumThread> findByAuthorId(@Param("authorId") UUID authorId);

    @Query("SELECT t FROM ForumThread t WHERE t.forum.forumId = :forumId AND t.isLocked = :isLocked AND t.isDeleted = false")
    List<ForumThread> findByForumIdAndIsLocked(@Param("forumId") UUID forumId, @Param("isLocked") boolean isLocked);

    @Query("SELECT COUNT(t) FROM ForumThread t WHERE t.forum.forumId = :forumId AND t.isDeleted = false")
    long countByForumId(@Param("forumId") UUID forumId);

    @Query("SELECT DISTINCT t FROM ForumThread t LEFT JOIN FETCH t.attachments WHERE t.threadId = :threadId")
    java.util.Optional<ForumThread> findByIdWithAttachments(@Param("threadId") UUID threadId);
}
