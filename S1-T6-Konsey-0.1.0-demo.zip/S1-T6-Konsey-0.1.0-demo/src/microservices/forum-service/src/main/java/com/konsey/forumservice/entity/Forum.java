package com.konsey.forumservice.entity;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Represents a forum in the system.
 * Forums can be linked to studies for permission management.
 */
@Entity
@Table(name = "FORUM")
public class Forum {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "forum_id", updatable = false, nullable = false)
    private UUID forumId;

    /**
     * Optional link to a study. If set, users with access to the study
     * have access to this forum.
     */
    @Column(name = "study_id")
    private UUID studyId;

    @Column(name = "title", nullable = false, length = 255)
    private String title;

    @Column(name = "description", columnDefinition = "TEXT")
    private String description;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", length = 20)
    private ForumStatus status = ForumStatus.ACTIVE;

    @Column(name = "created_by", nullable = false)
    private UUID createdBy;

    @Column(name = "manager_id")
    private UUID managerId;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @OneToMany(mappedBy = "forum", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference
    private List<ForumThread> threads = new ArrayList<>();

    public Forum() {
    }

    public Forum(String title, String description, UUID createdBy) {
        this.title = title;
        this.description = description;
        this.createdBy = createdBy;
        this.managerId = createdBy;
        this.status = ForumStatus.ACTIVE;
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

    // Getters and Setters
    public UUID getForumId() {
        return forumId;
    }

    public UUID getStudyId() {
        return studyId;
    }

    public void setStudyId(UUID studyId) {
        this.studyId = studyId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public ForumStatus getStatus() {
        return status;
    }

    public void setStatus(ForumStatus status) {
        this.status = status;
    }

    public UUID getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(UUID createdBy) {
        this.createdBy = createdBy;
    }

    public UUID getManagerId() {
        return managerId;
    }

    public void setManagerId(UUID managerId) {
        this.managerId = managerId;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public List<ForumThread> getThreads() {
        return threads;
    }

    public void setThreads(List<ForumThread> threads) {
        this.threads = threads;
    }

    public void addThread(ForumThread thread) {
        threads.add(thread);
        thread.setForum(this);
    }

    public void removeThread(ForumThread thread) {
        threads.remove(thread);
        thread.setForum(null);
    }

    public boolean isReadOnly() {
        return status == ForumStatus.ARCHIVED || status == ForumStatus.CLOSED;
    }
}
