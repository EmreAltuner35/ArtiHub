package com.konsey.forumservice.service;

import com.konsey.forumservice.dto.PostCreationRequest;
import com.konsey.forumservice.dto.PostResponse;
import com.konsey.forumservice.dto.PostUpdateRequest;
import com.konsey.forumservice.entity.*;
import com.konsey.forumservice.exception.AccessDeniedException;
import com.konsey.forumservice.exception.ForumClosedException;
import com.konsey.forumservice.exception.ResourceNotFoundException;
import com.konsey.forumservice.exception.ThreadLockedException;
import com.konsey.forumservice.repository.AttachmentRepository;
import com.konsey.forumservice.repository.PostRepository;
import com.konsey.forumservice.utility.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@Transactional
public class PostService {

    @Autowired
    private PostRepository postRepository;

    @Autowired
    private AttachmentRepository attachmentRepository;

    @Autowired
    private ThreadService threadService;

    /**
     * Get all posts in a thread (chronologically ordered).
     */
    public List<PostResponse> getPostsByThread(UUID threadId) {
        // Verify thread exists
        threadService.findThreadOrThrow(threadId);
        
        List<Post> posts = postRepository.findByThreadId(threadId);
        return posts.stream()
                .map(PostResponse::fromEntity)
                .collect(Collectors.toList());
    }

    /**
     * Get a post by ID.
     */
    public PostResponse getPostById(UUID postId) {
        Post post = findPostOrThrow(postId);
        return PostResponse.fromEntity(post);
    }

    /**
     * Get the raw Post entity by ID.
     */
    public Post findPostOrThrow(UUID postId) {
        return postRepository.findById(postId)
                .orElseThrow(() -> new ResourceNotFoundException("Post not found: " + postId));
    }

    /**
     * Create a new post (reply) in a thread.
     */
    @Autowired
    private ArtifactUploadService artifactUploadService;

    /**
     * Create a new post (reply) in a thread.
     */
    public PostResponse createPost(UUID threadId, PostCreationRequest request, List<org.springframework.web.multipart.MultipartFile> files) {
        ForumThread thread = threadService.findThreadOrThrow(threadId);
        
        // Check if forum is read-only
        if (thread.getForum().isReadOnly()) {
            throw new ForumClosedException("Cannot post in archived/closed forums");
        }
        
        // Check if thread is locked
        if (thread.isLocked()) {
            throw new ThreadLockedException("Cannot reply to a locked thread");
        }

        UUID userId = SecurityUtils.userId();
        String displayName = SecurityUtils.displayName();
        
        Post post = new Post(thread, userId, displayName, request.getContent());
        
        // Add artifact attachments if provided (linked existing artifacts)
        if (request.getArtifactIds() != null && !request.getArtifactIds().isEmpty()) {
            for (UUID artifactId : request.getArtifactIds()) {
                PostAttachment attachment = PostAttachment.createArtifactLink(post, artifactId, "artifact:" + artifactId);
                post.getAttachments().add(attachment);
            }
        }

        // Upload and add new files
        if (files != null && !files.isEmpty()) {
            for (org.springframework.web.multipart.MultipartFile file : files) {
                try {
                    // Upload to artifact-service
                    UUID artifactId = artifactUploadService.uploadFile(file, "FORUM_ATTACHMENT");
                    
                    // Create attachment link
                    PostAttachment attachment = PostAttachment.createArtifactLink(
                        post, 
                        artifactId, 
                        file.getOriginalFilename()
                    );
                    post.getAttachments().add(attachment);
                } catch (Exception e) {
                    throw new RuntimeException("Failed to upload file: " + file.getOriginalFilename(), e);
                }
            }
        }

        Post saved = postRepository.save(post);
        return PostResponse.fromEntity(saved);
    }

    /**
     * Update a post's content. Only the author can update.
     */
    public PostResponse updatePost(UUID postId, PostUpdateRequest request) {
        Post post = findPostOrThrow(postId);
        
        // Check if forum is read-only
        if (post.getThread().getForum().isReadOnly()) {
            throw new ForumClosedException("Cannot update posts in archived/closed forums");
        }
        
        // Check if thread is locked
        if (post.getThread().isLocked()) {
            throw new ThreadLockedException("Cannot edit posts in a locked thread");
        }
        
        // Only author can edit their own post
        checkAuthorOnly(post);
        
        if (request.getContent() != null) {
            post.setContent(request.getContent());
        }

        Post saved = postRepository.save(post);
        return PostResponse.fromEntity(saved);
    }

    /**
     * Delete a post (soft delete). Author or moderator can delete.
     */
    public void deletePost(UUID postId) {
        Post post = findPostOrThrow(postId);
        
        // Check if thread is locked (moderators can still delete)
        if (post.getThread().isLocked() && !SecurityUtils.isModerator()) {
            throw new ThreadLockedException("Cannot delete posts in a locked thread");
        }
        
        checkAuthorOrModerator(post);
        
        post.setDeleted(true);
        postRepository.save(post);
    }

    /**
     * Hard delete a post. Only admins can do this.
     */
    public void hardDeletePost(UUID postId) {
        if (!SecurityUtils.isAdmin()) {
            throw new AccessDeniedException("Only Admins can permanently delete posts");
        }
        
        Post post = findPostOrThrow(postId);
        postRepository.delete(post);
    }

    /**
     * Add an artifact attachment to a post.
     */
    public PostResponse addArtifactAttachment(UUID postId, UUID artifactId, String fileName) {
        Post post = findPostOrThrow(postId);
        checkAuthorOnly(post);
        
        PostAttachment attachment = PostAttachment.createArtifactLink(post, artifactId, fileName);
        attachmentRepository.save(attachment);
        
        return PostResponse.fromEntity(post);
    }

    /**
     * Remove an attachment from a post.
     */
    public void removeAttachment(UUID attachmentId) {
        PostAttachment attachment = attachmentRepository.findById(attachmentId)
                .orElseThrow(() -> new ResourceNotFoundException("Attachment not found: " + attachmentId));
        
        // Check if user owns the post
        if (attachment.getPost() != null) {
            checkAuthorOrModerator(attachment.getPost());
        } else if (attachment.getThread() != null) {
            UUID userId = SecurityUtils.userId();
            if (!userId.equals(attachment.getThread().getAuthorId()) && !SecurityUtils.isModerator()) {
                throw new AccessDeniedException("You don't have permission to remove this attachment");
            }
        }
        
        attachmentRepository.delete(attachment);
    }

    /**
     * Check if current user is the post author only.
     */
    private void checkAuthorOnly(Post post) {
        UUID userId = SecurityUtils.userId();
        if (!userId.equals(post.getAuthorId())) {
            throw new AccessDeniedException("Only the author can modify this post");
        }
    }

    /**
     * Check if current user is the post author or a moderator.
     */
    private void checkAuthorOrModerator(Post post) {
        UUID userId = SecurityUtils.userId();
        boolean isAuthor = userId.equals(post.getAuthorId());
        
        if (!SecurityUtils.isModerator() && !isAuthor) {
            throw new AccessDeniedException("You don't have permission to modify this post");
        }
    }
}
