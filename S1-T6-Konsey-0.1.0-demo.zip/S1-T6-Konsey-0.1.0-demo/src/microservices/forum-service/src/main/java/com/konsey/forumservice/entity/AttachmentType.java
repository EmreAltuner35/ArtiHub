package com.konsey.forumservice.entity;

/**
 * Represents the type of attachment.
 */
public enum AttachmentType {
    FILE,           // Direct file upload
    ARTIFACT_LINK   // Link to artifact in artifact-service
}
