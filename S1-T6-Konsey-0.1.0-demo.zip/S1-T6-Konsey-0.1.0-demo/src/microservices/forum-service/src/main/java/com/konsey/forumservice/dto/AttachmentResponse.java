package com.konsey.forumservice.dto;

import com.konsey.forumservice.entity.AttachmentType;
import com.konsey.forumservice.entity.PostAttachment;

import java.time.LocalDateTime;
import java.util.UUID;

public class AttachmentResponse {

    private UUID attachmentId;
    private AttachmentType type;
    private UUID artifactId;
    private String fileName;
    private String fileUrl;
    private String contentType;
    private Long fileSize;
    private LocalDateTime createdAt;

    public AttachmentResponse() {
    }

    public static AttachmentResponse fromEntity(PostAttachment attachment) {
        AttachmentResponse response = new AttachmentResponse();
        response.setAttachmentId(attachment.getAttachmentId());
        response.setType(attachment.getType());
        response.setArtifactId(attachment.getArtifactId());
        response.setFileName(attachment.getFileName());
        response.setFileUrl(attachment.getFileUrl());
        response.setContentType(attachment.getContentType());
        response.setFileSize(attachment.getFileSize());
        response.setCreatedAt(attachment.getCreatedAt());
        return response;
    }

    // Getters and Setters
    public UUID getAttachmentId() {
        return attachmentId;
    }

    public void setAttachmentId(UUID attachmentId) {
        this.attachmentId = attachmentId;
    }

    public AttachmentType getType() {
        return type;
    }

    public void setType(AttachmentType type) {
        this.type = type;
    }

    public UUID getArtifactId() {
        return artifactId;
    }

    public void setArtifactId(UUID artifactId) {
        this.artifactId = artifactId;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFileUrl() {
        return fileUrl;
    }

    public void setFileUrl(String fileUrl) {
        this.fileUrl = fileUrl;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public Long getFileSize() {
        return fileSize;
    }

    public void setFileSize(Long fileSize) {
        this.fileSize = fileSize;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
}
