package com.konsey.forumservice.dto;

import com.konsey.forumservice.entity.Forum;
import com.konsey.forumservice.entity.ForumStatus;

import java.time.LocalDateTime;
import java.util.UUID;

public class ForumResponse {

    private UUID forumId;
    private String title;
    private String description;
    private ForumStatus status;
    private UUID studyId;
    private UUID createdBy;
    private UUID managerId;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private long threadCount;

    public ForumResponse() {
    }

    public static ForumResponse fromEntity(Forum forum) {
        ForumResponse response = new ForumResponse();
        response.setForumId(forum.getForumId());
        response.setTitle(forum.getTitle());
        response.setDescription(forum.getDescription());
        response.setStatus(forum.getStatus());
        response.setStudyId(forum.getStudyId());
        response.setCreatedBy(forum.getCreatedBy());
        response.setManagerId(forum.getManagerId());
        response.setCreatedAt(forum.getCreatedAt());
        response.setUpdatedAt(forum.getUpdatedAt());
        response.setThreadCount(forum.getThreads() != null ? forum.getThreads().size() : 0);
        return response;
    }

    public static ForumResponse fromEntity(Forum forum, long threadCount) {
        ForumResponse response = fromEntity(forum);
        response.setThreadCount(threadCount);
        return response;
    }

    // Getters and Setters
    public UUID getForumId() {
        return forumId;
    }

    public void setForumId(UUID forumId) {
        this.forumId = forumId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public ForumStatus getStatus() {
        return status;
    }

    public void setStatus(ForumStatus status) {
        this.status = status;
    }

    public UUID getStudyId() {
        return studyId;
    }

    public void setStudyId(UUID studyId) {
        this.studyId = studyId;
    }

    public UUID getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(UUID createdBy) {
        this.createdBy = createdBy;
    }

    public UUID getManagerId() {
        return managerId;
    }

    public void setManagerId(UUID managerId) {
        this.managerId = managerId;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public long getThreadCount() {
        return threadCount;
    }

    public void setThreadCount(long threadCount) {
        this.threadCount = threadCount;
    }
}
