package com.konsey.forumservice.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.jose.jws.MacAlgorithm;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

/**
 * Spring Security configuration for the forum service.
 */
@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Value("${jwt.secret}")
    private String secret;

    @Bean
    SecurityFilterChain filterChain(HttpSecurity httpSecurity,
                                    JwtAuthenticationConverter jwtAuthenticationConverter) throws Exception {
        httpSecurity.csrf(AbstractHttpConfigurer::disable)
                .cors(cors -> {});

        httpSecurity.authorizeHttpRequests(auth -> auth
                .requestMatchers(org.springframework.http.HttpMethod.GET, "/api/forums/**").authenticated()
                .requestMatchers(org.springframework.http.HttpMethod.GET, "/api/threads/**").authenticated()
                .requestMatchers(org.springframework.http.HttpMethod.GET, "/api/posts/**").authenticated()
                .requestMatchers(org.springframework.http.HttpMethod.POST, "/api/forums/**", "/api/threads/**", "/api/posts/**").hasAnyRole("PARTICIPANT", "RESEARCHER", "REVIEWER", "ADMIN")
                .requestMatchers(org.springframework.http.HttpMethod.PUT, "/api/forums/**", "/api/threads/**", "/api/posts/**").hasAnyRole("PARTICIPANT", "RESEARCHER", "REVIEWER", "ADMIN")
                .requestMatchers(org.springframework.http.HttpMethod.DELETE, "/api/forums/**", "/api/threads/**", "/api/posts/**").hasAnyRole("PARTICIPANT", "RESEARCHER", "REVIEWER", "ADMIN")
                .anyRequest().authenticated());

        httpSecurity.oauth2ResourceServer(oauth -> oauth
                .jwt(jwt -> jwt
                        .jwtAuthenticationConverter(jwtAuthenticationConverter)));

        return httpSecurity.build();
    }

    @Bean
    public CorsFilter corsFilter() {
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        CorsConfiguration config = new CorsConfiguration();
        config.setAllowCredentials(true);
        config.setAllowedOrigins(Arrays.asList(
                "http://localhost:80",
                "http://127.0.0.1:80",
                "http://localhost:3000",
                "http://127.0.0.1:3000"
        ));
        config.addAllowedHeader("*");
        config.addAllowedMethod("*");
        source.registerCorsConfiguration("/**", config);
        return new CorsFilter(source);
    }

    @Bean
    JwtDecoder jwtDecoder() {
        byte[] keyBytes = secret.getBytes(StandardCharsets.UTF_8);
        return NimbusJwtDecoder
                .withSecretKey(new SecretKeySpec(keyBytes, "HmacSHA256"))
                .macAlgorithm(MacAlgorithm.HS256)
                .build();
    }

    @Bean
    JwtAuthenticationConverter jwtAuthenticationConverter() {
        JwtAuthenticationConverter converter = new JwtAuthenticationConverter();
        converter.setPrincipalClaimName("sub");
        converter.setJwtGrantedAuthoritiesConverter(SecurityConverters::authoritiesFromSingleRoleClaim);
        return converter;
    }

    static final class SecurityConverters {
        static Collection<GrantedAuthority> authoritiesFromSingleRoleClaim(Jwt jwt) {
            String role = jwt.getClaimAsString("role");
            if (role == null || role.isBlank())
                return List.of();
            return List.of(new SimpleGrantedAuthority("ROLE_" + role));
        }
    }
}
