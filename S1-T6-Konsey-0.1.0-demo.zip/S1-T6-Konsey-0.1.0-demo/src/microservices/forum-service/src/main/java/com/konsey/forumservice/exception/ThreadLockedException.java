package com.konsey.forumservice.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.BAD_REQUEST)
public class ThreadLockedException extends RuntimeException {
    public ThreadLockedException(String message) {
        super(message);
    }
}
