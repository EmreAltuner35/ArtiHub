package com.konsey.forumservice.dto;

public class PostUpdateRequest {

    private String content;

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
