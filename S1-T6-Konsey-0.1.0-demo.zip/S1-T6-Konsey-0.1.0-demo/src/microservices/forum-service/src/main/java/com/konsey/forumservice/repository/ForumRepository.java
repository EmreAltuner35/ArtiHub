package com.konsey.forumservice.repository;

import com.konsey.forumservice.entity.Forum;
import com.konsey.forumservice.entity.ForumStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface ForumRepository extends JpaRepository<Forum, UUID> {

    List<Forum> findByStudyId(UUID studyId);

    List<Forum> findByStatus(ForumStatus status);

    List<Forum> findByCreatedBy(UUID userId);

    List<Forum> findByManagerId(UUID managerId);

    @Query("SELECT f FROM Forum f WHERE f.studyId IN :studyIds")
    List<Forum> findByStudyIdIn(@Param("studyIds") List<UUID> studyIds);

    @Query("SELECT f FROM Forum f WHERE f.studyId IS NULL OR f.studyId IN :studyIds")
    List<Forum> findAccessibleForums(@Param("studyIds") List<UUID> studyIds);

    List<Forum> findByStudyIdIsNull();
}
