package com.konsey.userservice.entity.enums;

public enum Role {
    PARTICIPANT,
    RESEARCHER,
    REVIEWER,
    ADMIN,
    GUEST
}
