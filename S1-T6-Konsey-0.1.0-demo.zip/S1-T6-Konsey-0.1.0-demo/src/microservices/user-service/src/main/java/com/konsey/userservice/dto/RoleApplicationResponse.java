package com.konsey.userservice.dto;

import com.konsey.userservice.entity.enums.ApplicationStatus;
import com.konsey.userservice.entity.enums.Role;
import lombok.*;

import java.time.Instant;
import java.util.UUID;

@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RoleApplicationResponse {
    private UUID id;
    private UserResponse applicant;
    private UserResponse reviewer;
    private Role requestedRole;
    private ApplicationStatus status;
    private String motivation;
    private String reviewerComment;
    private Instant createdAt;
    private Instant updatedAt;
}
