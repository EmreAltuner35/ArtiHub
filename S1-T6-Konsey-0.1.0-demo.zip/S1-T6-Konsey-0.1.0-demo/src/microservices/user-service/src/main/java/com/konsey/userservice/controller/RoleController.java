package com.konsey.userservice.controller;

import com.konsey.userservice.dto.PagedResponse;
import com.konsey.userservice.dto.RoleApplicationRequest;
import com.konsey.userservice.dto.RoleApplicationResponse;
import com.konsey.userservice.dto.RoleApplicationUpdateRequest;
import com.konsey.userservice.entity.RoleApplication;
import com.konsey.userservice.entity.User;
import com.konsey.userservice.service.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/api/users/role")
public class RoleController {
    @Autowired
    RoleService roleService;

    @GetMapping
    public PagedResponse<RoleApplicationResponse> allApplications(
            @PageableDefault Pageable pageable
    ) {
        return roleService.getAllRoleConversionRequests(pageable);
    }

    @PutMapping("/{applicationId}")
    public void makeDecisionForApplication(
            @PathVariable UUID applicationId,
            @RequestBody RoleApplicationUpdateRequest request
    ) {
        roleService.updateRoleConversionRequest(request, applicationId);
    }

    @PostMapping("/apply")
    public ResponseEntity<RoleApplicationResponse> roleApplication(@RequestBody RoleApplicationRequest request) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if(auth == null || !(auth.getPrincipal() instanceof User currentUser))
            return ResponseEntity.badRequest().build();

        RoleApplicationResponse application = roleService.createRoleConversionRequest(currentUser, request);
        return new ResponseEntity<>(application, HttpStatus.CREATED);
    }

    @GetMapping("/mine")
    public ResponseEntity<RoleApplicationResponse> myApplication() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if(auth == null || !(auth.getPrincipal() instanceof User currentUser))
            return ResponseEntity.badRequest().build();

        RoleApplicationResponse application = roleService.getRoleConversationRequest(currentUser);
        return new ResponseEntity<>(application, HttpStatus.OK);
    }
}
