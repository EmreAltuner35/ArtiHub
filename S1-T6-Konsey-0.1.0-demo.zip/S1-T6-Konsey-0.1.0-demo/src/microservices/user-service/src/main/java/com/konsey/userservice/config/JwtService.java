package com.konsey.userservice.config;


import com.konsey.userservice.entity.enums.Role;
import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import org.springframework.stereotype.Service;
import java.util.*;
import java.security.Key;

@Service
public class JwtService {

    private final String SECRET_KEY = "supersecretkey1234567890supersecretkey123";
    private final long EXPIRATION_TIME = 1000 * 60 * 30; // 30 minutes

    private Key getSignKey() {
        return Keys.hmacShaKeyFor(SECRET_KEY.getBytes());
    }

    public String generateToken(UUID id, Role role, String displayName) {
        return Jwts.builder()
                .setSubject(id.toString())
                .claim("role", role != null ? role.name() : null) // Store enum as string name
                .claim("displayName", displayName)
                .setIssuedAt(new Date(System.currentTimeMillis()))
                .setExpiration(new Date(System.currentTimeMillis() + EXPIRATION_TIME))
                .signWith(getSignKey(), SignatureAlgorithm.HS256)
                .compact();
    }

    public boolean isGuestToken(String token) {
        Claims claims = extractAllClaims(token);
        return claims.get("guest", Boolean.class) != null && claims.get("guest", Boolean.class);
    }

    public String extractId(String token) {
        return extractAllClaims(token).getSubject();
    }

    public String extractRole(String token) {
        return extractAllClaims(token).get("role", String.class);
    }

    public boolean isTokenValid(String token, String id) {
        return extractId(token).equals(id) && !isTokenExpired(token);
    }

    private boolean isTokenExpired(String token) {
        return extractAllClaims(token).getExpiration().before(new Date());
    }

    private Claims extractAllClaims(String token) {
        return Jwts.parserBuilder()
                .setSigningKey(getSignKey())
                .build()
                .parseClaimsJws(token)
                .getBody();
    }

    public long getExpirationMillis() {
        return EXPIRATION_TIME;
    }
}
