package com.konsey.userservice.controller;

import com.konsey.userservice.entity.enums.Role;
import jakarta.validation.Valid;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.konsey.userservice.dto.*;
import com.konsey.userservice.service.AuthService;

@RestController
@RequestMapping("/api/users")
public class AuthController {

    @Autowired
    private AuthService authService;

    @PostMapping("/register")
    public ResponseEntity<AuthResponse> register(@Valid @RequestBody RegisterRequest request) {
        return ResponseEntity.ok(authService.register(request));
    }

    @PostMapping("/login")
    public ResponseEntity<AuthResponse> login(@RequestBody LoginRequest request) {
        return ResponseEntity.ok(authService.login(request));
    }

    @PostMapping("/guest")
    public ResponseEntity<AuthResponse> guestLogin() {


        UUID guestId = UUID.randomUUID();

        AuthResponse token = authService.generateTokenForGuest(guestId, Role.GUEST);
        return ResponseEntity.ok(token);
    }

}

