package com.konsey.userservice.dto;

import jakarta.validation.constraints.Email;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UpdateUserRequest {

    @Email
    private String email;
    private String newPassword;
    private String currentPassword;
    private String displayName;
}
