package com.konsey.userservice.entity.enums;

public enum ApplicationStatus {
    PENDING,
    APPROVED,
    REJECTED
}
