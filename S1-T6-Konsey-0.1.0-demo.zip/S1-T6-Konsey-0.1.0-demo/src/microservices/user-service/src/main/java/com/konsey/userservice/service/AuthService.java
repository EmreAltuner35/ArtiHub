package com.konsey.userservice.service;


import java.util.UUID;

import com.konsey.userservice.entity.enums.Role;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.konsey.userservice.config.JwtService;
import com.konsey.userservice.dto.*;
import com.konsey.userservice.entity.User;
import com.konsey.userservice.repository.UserRepository;

@Service
public class AuthService {

    @Autowired
    private UserRepository userRepository;
    @Autowired
    private PasswordEncoder passwordEncoder;
    @Autowired
    private JwtService jwtService;

    public AuthResponse register(RegisterRequest request) {
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new RuntimeException("Email already exists");
        }

        User user = new User(
                request.getEmail(),
                passwordEncoder.encode(request.getPassword()),
                request.getDisplayName(),
                Role.PARTICIPANT // Default
        );

        userRepository.save(user);
        String token = jwtService.generateToken(user.getId(), user.getRole(), user.getDisplayName());
        return new AuthResponse(token, user.getRole(), jwtService.getExpirationMillis());
    }

    public AuthResponse login(LoginRequest request) {
        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new RuntimeException("Invalid email"));

        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            throw new RuntimeException("Invalid credentials");
        }

        String token = jwtService.generateToken(user.getId(), user.getRole(), user.getDisplayName());
        return new AuthResponse(token, user.getRole(), jwtService.getExpirationMillis());
    }

    public AuthResponse generateTokenForGuest(UUID guestId, Role role) {
        String token = jwtService.generateToken(guestId, role, "Guest User");
        long expiresIn = jwtService.getExpirationMillis();
        return new AuthResponse(token, Role.GUEST, expiresIn);
    }


}

