package com.konsey.userservice.controller;

import com.konsey.userservice.entity.enums.Role;
import com.konsey.userservice.dto.EditUserRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.*;

import com.konsey.userservice.dto.PagedResponse;
import com.konsey.userservice.dto.UpdateUserRequest;
import com.konsey.userservice.dto.UserResponse;
import com.konsey.userservice.entity.User;
import com.konsey.userservice.service.UserService;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/users")
@CrossOrigin
public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping("")
    public ResponseEntity<List<User>> getAllUsers() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        User user = (User) auth.getPrincipal();
        if (auth == null || !(auth.getPrincipal() instanceof User || !user.getRole().equals("ADMIN"))) {
            return ResponseEntity.status(401).build();
        }

        return ResponseEntity.ok(userService.getAllUsers());
    }


    @GetMapping("/me")
    public ResponseEntity<UserResponse> getCurrentUser() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || !(auth.getPrincipal() instanceof User)) {
            UserResponse response = new UserResponse();
            response.setRole(Role.GUEST);
            response.setDisplayName("guest");
            return ResponseEntity.ok(response);
        }

        User user = (User) auth.getPrincipal();
        return ResponseEntity.ok(new UserResponse(user));
    }

    @PutMapping("/me")
    public ResponseEntity<UserResponse> updateUser(@RequestBody UpdateUserRequest request) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || !(auth.getPrincipal() instanceof User)) {
            return ResponseEntity.status(401).build();
        }

        User user = (User) auth.getPrincipal();
        User updated = userService.updateUser(user, request);
        return ResponseEntity.ok(new UserResponse(updated));
    }

    @DeleteMapping("/me")
    public ResponseEntity<?> deleteUser() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || !(auth.getPrincipal() instanceof User)) {
            return ResponseEntity.status(401).build();
        }

        User user = (User) auth.getPrincipal();
        userService.deleteUser(user);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/search")
    public PagedResponse<UserResponse> searchUsers(
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) String role,
            @PageableDefault(sort = "displayName", direction = Sort.Direction.ASC) Pageable pageable
    ) {
        Page<User> page = userService.searchUsers(keyword, role, pageable);
        return new PagedResponse<>(
                page.getContent().stream().map(UserResponse::fromEntity).collect(Collectors.toList()),
                page.getNumber(),
                page.getSize(),
                page.getTotalElements(),
                page.getTotalPages()
        );
    }

    @PutMapping("/{id}")
    public ResponseEntity<UserResponse> updateUserById(
            @PathVariable String id,
            @RequestBody EditUserRequest request
    ) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || !(auth.getPrincipal() instanceof User)) {
            return ResponseEntity.status(401).build();
        }


        User updated = userService.updateUserById(UUID.fromString(id), request);
        return ResponseEntity.ok(new UserResponse(updated));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteUserById(@PathVariable String id) {

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || !(auth.getPrincipal() instanceof User)) {
            return ResponseEntity.status(401).build();
        }

        UUID userId;
        try {
            userId = UUID.fromString(id);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body("Invalid UUID format");
        }

        User user = userService.getUser(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        userService.deleteUser(user);

        return ResponseEntity.noContent().build();
    }



    @GetMapping("/{id}")
    public ResponseEntity<?> getUserById(@PathVariable String id) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || !(auth.getPrincipal() instanceof User)) {
            return ResponseEntity.status(401).build();
        }
        return ResponseEntity.ok(userService.getUser(UUID.fromString(id)));
    }

    @PostMapping("/batch")
    public ResponseEntity<List<UserResponse>> getUsersByIds(@RequestBody List<UUID> ids) {
        List<User> users = userService.getUsersByIds(ids);
        List<UserResponse> responses = users.stream()
                .map(UserResponse::new)
                .collect(Collectors.toList());
        return ResponseEntity.ok(responses);
    }

}
