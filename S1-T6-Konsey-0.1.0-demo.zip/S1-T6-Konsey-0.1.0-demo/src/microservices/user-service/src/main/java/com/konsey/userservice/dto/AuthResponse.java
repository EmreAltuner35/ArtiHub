package com.konsey.userservice.dto;


import com.konsey.userservice.entity.enums.Role;

public class AuthResponse {
    private String accessToken;
    private Role role;
    private long expiresIn;

    public AuthResponse(String accessToken, Role role, long expiresIn) {
        this.accessToken = accessToken;
        this.role = role;
        this.expiresIn = expiresIn;
    }

    public String getAccessToken() { return accessToken; }
    public Role getRole() { return role; }
    public long getExpiresIn() { return expiresIn; }
}

