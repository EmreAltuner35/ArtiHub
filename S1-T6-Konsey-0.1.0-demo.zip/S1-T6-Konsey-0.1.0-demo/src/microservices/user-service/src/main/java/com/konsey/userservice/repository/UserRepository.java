package com.konsey.userservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;
import java.util.UUID;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.konsey.userservice.entity.User;

public interface UserRepository extends JpaRepository<User, UUID> {
    Optional<User> findByEmail(String email);
    boolean existsByEmail(String email);
    Page<User> findByDisplayNameContainingIgnoreCase(String displayName, Pageable pageable);


    @org.springframework.data.jpa.repository.Query("SELECT u FROM User u WHERE u.role = :role AND (LOWER(u.displayName) LIKE LOWER(CONCAT('%', :keyword, '%')))")
    Page<User> findByRoleAndKeyword(@org.springframework.data.repository.query.Param("role") com.konsey.userservice.entity.enums.Role role, @org.springframework.data.repository.query.Param("keyword") String keyword, Pageable pageable);
}

