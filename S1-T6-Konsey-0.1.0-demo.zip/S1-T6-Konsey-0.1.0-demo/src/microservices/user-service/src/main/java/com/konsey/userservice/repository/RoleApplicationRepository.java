package com.konsey.userservice.repository;

import com.konsey.userservice.entity.RoleApplication;
import com.konsey.userservice.entity.User;
import com.konsey.userservice.entity.enums.ApplicationStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;
import java.util.UUID;

public interface RoleApplicationRepository extends JpaRepository<RoleApplication, UUID> {
    Optional<RoleApplication> findByApplicant(User applicant);
    Page<RoleApplication> findAllByStatus(ApplicationStatus status, Pageable pageable);
}
