package com.konsey.userservice.service;

import com.konsey.userservice.dto.EditUserRequest;
import com.konsey.userservice.entity.enums.Role;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.konsey.userservice.config.JwtService;
import com.konsey.userservice.dto.UpdateUserRequest;
import com.konsey.userservice.entity.User;
import com.konsey.userservice.repository.UserRepository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public UserService() {}

    public User updateUser(User user, UpdateUserRequest request) {
        if (request.getDisplayName() != null && !request.getDisplayName().isBlank()) {
            user.setDisplayName(request.getDisplayName());
        }
        if (request.getNewPassword() != null && !request.getNewPassword().isBlank()) {
            if(passwordEncoder.matches(request.getCurrentPassword(), user.getPassword()))
                user.setPassword(passwordEncoder.encode(request.getNewPassword()));
            else
                throw new IllegalArgumentException("Password is wrong!");
        }
        if (request.getEmail() != null && !request.getEmail().isBlank()) {
            user.setEmail(request.getEmail());
        }
        return userRepository.save(user);
    }

    public Page<User> searchUsers(String keyword, String role, Pageable pageable) {
        if (role != null && !role.isBlank()) {
            try {
                Role roleEnum = Role.valueOf(role.toUpperCase());
                if (keyword == null || keyword.isBlank()) {
                    // If no keyword but role is present, find all by role (need to add this method or just use the query with empty string?)
                    // The query uses LIKE %keyword%, so empty string matches all.
                    return userRepository.findByRoleAndKeyword(roleEnum, "", pageable);
                }
                return userRepository.findByRoleAndKeyword(roleEnum, keyword, pageable);
            } catch (IllegalArgumentException e) {
                // Invalid role, ignore or return empty? Let's ignore role filter if invalid or return empty.
                // Returning empty is safer.
                return Page.empty(pageable);
            }
        }

        if (keyword == null || keyword.isBlank()) {
            return userRepository.findAll(pageable);
        }
        return userRepository.findByDisplayNameContainingIgnoreCase(keyword, pageable);
    }

    public User updateUserById(UUID id, EditUserRequest request) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found"));


        if (request.getDisplayName() != null) {
            user.setDisplayName(request.getDisplayName());
        }
        if (request.getRole() != null) {
            user.setRole(Role.valueOf(request.getRole()));
        }
        if (request.getEmail() != null) {
            user.setEmail(request.getEmail());
        }
        if (request.getPassword() != null) {
            user.setPassword(passwordEncoder.encode(request.getPassword()));
        }

        return userRepository.save(user);
    }

    public Optional<User> getUser(UUID id) {return userRepository.findById(id);}

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    public void deleteUser(User user) {
        userRepository.delete(user);
    }

    public List<User> getUsersByIds(List<UUID> ids) {
        return userRepository.findAllById(ids);
    }
}

