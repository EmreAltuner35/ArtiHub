package com.konsey.userservice.dto;

import com.konsey.userservice.entity.enums.Role;
import jakarta.validation.constraints.NotBlank;


public record RoleApplicationRequest (
    @NotBlank Role requestedRole,
    String motivation
) {}
