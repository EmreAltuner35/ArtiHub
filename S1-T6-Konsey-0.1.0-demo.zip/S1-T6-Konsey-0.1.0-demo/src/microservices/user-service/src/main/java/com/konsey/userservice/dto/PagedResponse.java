package com.konsey.userservice.dto;

import lombok.*;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PagedResponse<T> {
    private List<T> results;
    private int page;
    private int size;
    private long totalElements;
    private int totalPages;
}
