package com.konsey.userservice.service;

import com.konsey.userservice.dto.PagedResponse;
import com.konsey.userservice.dto.RoleApplicationRequest;
import com.konsey.userservice.dto.RoleApplicationResponse;
import com.konsey.userservice.dto.RoleApplicationUpdateRequest;
import com.konsey.userservice.entity.RoleApplication;
import com.konsey.userservice.entity.User;
import com.konsey.userservice.entity.enums.ApplicationStatus;
import com.konsey.userservice.entity.enums.Role;
import com.konsey.userservice.repository.RoleApplicationRepository;
import com.konsey.userservice.repository.UserRepository;
import jakarta.transaction.Transactional;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class RoleService {

    @Autowired
    RoleApplicationRepository roleApplicationRepository;

    @Autowired
    UserRepository userRepository;

    @Autowired
    ModelMapper modelMapper;

    public PagedResponse<RoleApplicationResponse> getAllRoleConversionRequests(Pageable pageable) {
        Page<RoleApplication> page = roleApplicationRepository.findAllByStatus(ApplicationStatus.PENDING, pageable);

        List<RoleApplicationResponse> dtos = page.getContent().stream()
                .map(s -> modelMapper.map(s, RoleApplicationResponse.class))
                .toList();

        return PagedResponse.<RoleApplicationResponse>builder()
                .results(dtos)
                .page(page.getNumber())
                .size(page.getSize())
                .totalElements(page.getTotalElements())
                .totalPages(page.getTotalPages())
                .build();
    }

    @Transactional
    public void updateRoleConversionRequest(RoleApplicationUpdateRequest request, UUID applicationId) {
        RoleApplication application = roleApplicationRepository.findById(applicationId).orElseThrow();
        application.setReviewer(((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal()));
        application.setReviewerComment(request.comment());
        application.setStatus(request.status());
        roleApplicationRepository.save(application);

        if(request.status() == ApplicationStatus.APPROVED) {
            User applicant = application.getApplicant();
            applicant.setRole(application.getRequestedRole());
            userRepository.save(applicant);
        }
    }

    @Transactional
    public RoleApplicationResponse createRoleConversionRequest(User user, RoleApplicationRequest request) {
        String motivation = request.motivation() == null || request.motivation().isBlank() ? "" : request.motivation();
        RoleApplication application = RoleApplication.builder()
                .applicant(user)
                .requestedRole(request.requestedRole())
                .motivation(motivation)
                .build();

        return modelMapper.map(roleApplicationRepository.save(application), RoleApplicationResponse.class);
    }

    public RoleApplicationResponse getRoleConversationRequest(User user) {
        return modelMapper.map(
                roleApplicationRepository.findByApplicant(user).orElseThrow(),
                RoleApplicationResponse.class
        );
    }
}
