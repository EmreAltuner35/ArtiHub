package com.konsey.userservice.dto;

import com.konsey.userservice.entity.enums.ApplicationStatus;

public record RoleApplicationUpdateRequest(
        ApplicationStatus status,
        String comment
) {
}
