package com.konsey.studyservice.entity;

import java.util.List;

public class FiveStarRatingDistribution {
    private List<String> options;
    private double[] averages;
    private int[] counts;
    private Criterion criterion;
    public FiveStarRatingDistribution(Criterion criterion){
        this.criterion = criterion;
        this.options = criterion.getOptions();
        averages = new double[options.size()];
        counts = new int[options.size()];
        for(int i = 0;i<options.size();i++){
            averages[i] = 0.0;
            counts[i] = 0;
        }
    }
    public void update(int score,String option){
        int index = 0;
        for(int i = 0;i<options.size();i++){
            if(options.get(i).equals(option)){
                index = i;
                i = options.size();
            }
        }
        averages[index] += (score - averages[index])/(counts[index]+1);
        counts[index]++;
    }

    public Criterion getCriterion() {
        return criterion;
    }

    public double[] getAverages() {
        return averages;
    }

    public List<String> getOptions() {
        return options;
    }

    public int[] getCounts() {
        return counts;
    }
}
