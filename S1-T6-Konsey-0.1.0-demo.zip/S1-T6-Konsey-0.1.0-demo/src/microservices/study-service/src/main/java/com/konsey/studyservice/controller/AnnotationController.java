package com.konsey.studyservice.controller;

import com.konsey.studyservice.dto.AnnotationDto;
import com.konsey.studyservice.entity.Annotation;
import com.konsey.studyservice.service.AnnotationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.ZonedDateTime;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/studies/annotations")
public class AnnotationController {

    private final AnnotationService annotationService;

    @Autowired
    public AnnotationController(AnnotationService annotationService) {
        this.annotationService = annotationService;
    }

    @PostMapping
    public ResponseEntity<Annotation> createAnnotation(@RequestBody AnnotationDto dto) {

        if (dto.getArtifactId() == null || dto.getParticipantId() == null || dto.getTaskId() == null) {
            return ResponseEntity.badRequest().build();
        }

        boolean isText = dto.getStartIndex() != null && dto.getEndIndex() != null;
        boolean isImage = dto.getX() != null && dto.getY() != null;

        if (!isText && !isImage) {
            return ResponseEntity.badRequest().body(null);
        }

        return new ResponseEntity<>(annotationService.saveAnnotation(dto), HttpStatus.CREATED);
    }


    @GetMapping("/{taskId}/{artifactId}/{participantId}")
    public ResponseEntity<List<Annotation>> getAnnotationsByArtifact(
            @PathVariable String taskId,
            @PathVariable String artifactId,
            @PathVariable String participantId) {

        List<Annotation> annotations =
                annotationService.findByTaskIdAndArtifactIdAndParticipantId(
                        UUID.fromString(taskId),
                        UUID.fromString(artifactId),
                        UUID.fromString(participantId)
                );

        return ResponseEntity.ok(annotations);
    }

    @DeleteMapping("/{annotationId}")
    public ResponseEntity<Void> deleteAnnotation(@PathVariable UUID annotationId) {
        boolean deleted = annotationService.deleteAnnotation(annotationId);

        if (deleted) {
            return ResponseEntity.noContent().build(); // 204
        } else {
            return ResponseEntity.notFound().build(); // 404
        }
    }

}
