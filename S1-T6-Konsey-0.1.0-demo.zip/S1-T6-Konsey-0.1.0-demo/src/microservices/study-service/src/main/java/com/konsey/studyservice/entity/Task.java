package com.konsey.studyservice.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.*;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "Evaluation_Task")
public class Task {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO) // Lets JPA handle ID generation
    @Column(name = "task_id", updatable = false, nullable = false)
    private UUID taskId;



    @Column
    private boolean isBlinded;

    @Column
    private String instructions;
    @Column
    private String name;
    @Column(updatable = false)
    private ViewType viewType;

    /**
     * This is the "One" side of the relationship.
     * A single Task can have a list of many Criterion objects.
     *
     * - mappedBy = "task": Tells JPA to look at the 'task' field in the
     * Criterion class to find the foreign key. This Task is NOT the owner.
     *
     * - cascade = CascadeType.ALL: Convenience. If you save or update a Task,
     * it will also save/update its criteria. If you delete a Task,
     * its criteria will be deleted too.
     *
     * - orphanRemoval = true: If you remove a criterion from this list
     * (but don't delete the task), the "orphaned" criterion will be
     * deleted from the database.
     *
     * - @JsonManagedReference: Prevents infinite loops when serializing to JSON
     * for your API.
     */
    @OneToMany(
            mappedBy = "task",
            cascade = CascadeType.ALL,
            orphanRemoval = true
    )
    @JsonManagedReference
    @Builder.Default
    private List<Criterion> criteria = new ArrayList<Criterion>();

    @ElementCollection(fetch = FetchType.LAZY) // LAZY is default, but good to be explicit
    @CollectionTable(
            name = "task_artifacts", // Name of the new table
            joinColumns = @JoinColumn(name = "task_id") // Foreign key column in the new table
    )
    @Column(name = "artifact_id") // Name of the column that will store the UUID
    @Builder.Default
    private List<UUID> artifacts = new ArrayList<UUID>();


    @ManyToOne(fetch = FetchType.LAZY) // LAZY is more efficient
    @JoinColumn(name = "study") // This is the actual DB column name
    @JsonBackReference // Prevents JSON infinite loops
    private Study study;

    public void addCriterion(Criterion criterion){this.criteria.add(criterion);}
}
