package com.konsey.studyservice.client.impl;

import com.konsey.studyservice.client.ArtifactClient;
import com.konsey.studyservice.client.impl.dto.ArtifactFolderDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Component
public class HttpArtifactClient implements ArtifactClient {

    @Autowired
    private RestTemplate restTemplate;

    @Value("${app.artifact.base-url}")
    private String artifactServiceBaseUrl;

    @Override
    public Map<String, UUID> findArtifactIdsByTitleInFolder(UUID folderId) {
        String url = artifactServiceBaseUrl + "/folders/" + folderId;

        ArtifactFolderDto folder = restTemplate.getForObject(url, ArtifactFolderDto.class);

        if(folder == null || folder.artifacts() == null)
            return Map.of();

        Map<String, UUID> titleToId = new HashMap<>();
        folder.artifacts().forEach(artifact -> {
            if(artifact.title() == null || artifact.id() == null)
                return;
            titleToId.put(artifact.title().trim(), artifact.id());
        });

        return titleToId;
    }
}
