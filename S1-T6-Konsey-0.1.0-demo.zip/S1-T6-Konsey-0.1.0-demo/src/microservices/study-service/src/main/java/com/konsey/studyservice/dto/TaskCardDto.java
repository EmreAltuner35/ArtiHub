package com.konsey.studyservice.dto;

public class TaskCardDto {
    private int submissionCount;
    private int total;
    private double completion_rate;
    private double avg_time;
    public TaskCardDto(int submissionCount,int total){
        this.submissionCount = submissionCount;
        this.total = total;
        completion_rate = ((double)submissionCount/total);
    }

    public double getCompletion_rate() {
        return completion_rate;
    }

    public int getTotal() {
        return total;
    }

    public int getSubmissionCount() {
        return submissionCount;
    }
}
