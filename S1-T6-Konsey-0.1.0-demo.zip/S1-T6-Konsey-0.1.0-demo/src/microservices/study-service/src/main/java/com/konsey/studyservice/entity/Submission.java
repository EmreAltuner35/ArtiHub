package com.konsey.studyservice.entity;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;

import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import com.konsey.studyservice.entity.CriteriaResponse;
@Entity
@Table(name = "submissions")
public class Submission {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    @Column(name = "study_id", nullable = false)
    private UUID studyId;

    @Column(name = "task_id", nullable = false)
    private UUID taskId;

    @Column(name = "participant_id", nullable = false)
    private UUID participantId;

    @Column(name = "timestamp", nullable = false)
    private ZonedDateTime timestamp;

    @ElementCollection(fetch = FetchType.LAZY)
    @CollectionTable(
            name = "submission_annotations", // New table to hold submission ID and annotation ID
            joinColumns = @JoinColumn(name = "submission_id")
    )
    @Column(name = "annotation_id", nullable = false)
    private List<UUID> linkedAnnotationIds = new ArrayList<>();

    @OneToMany(
            mappedBy = "submission",
            cascade = CascadeType.ALL,
            orphanRemoval = true
    )
    @JsonManagedReference(value = "submission-response")
    private List<CriteriaResponse> criteriaResponses = new ArrayList<CriteriaResponse>();

    @Column(name = "submission_time")
    private Integer submissionTime;

    @Column
    private UUID assignedReviewerId;

    @Column
    private LocalDateTime assignedAt;

    @Column
    private boolean reviewCompleted;

    public Submission() {
        this.timestamp = ZonedDateTime.now();
    }

    // --- Getters and Setters for core fields ---

    public UUID getId() { return id; }
    public void setId(UUID id) { this.id = id; }

    public UUID getStudyId() { return studyId; }
    public void setStudyId(UUID studyId) { this.studyId = studyId; }

    public UUID getTaskId() { return taskId; }
    public void setTaskId(UUID taskId) { this.taskId = taskId; }

    public UUID getParticipantId() { return participantId; }
    public void setParticipantId(UUID participantId) { this.participantId = participantId; }

    public ZonedDateTime getTimestamp() { return timestamp; }
    public void setTimestamp(ZonedDateTime timestamp) { this.timestamp = timestamp; }

    // --- Getters and Setters for criteriaResponses ---

    public List<CriteriaResponse> getCriteriaResponses() {
        return criteriaResponses;
    }

    public void setCriteriaResponses(List<CriteriaResponse> criteriaResponses) {
        this.criteriaResponses = criteriaResponses;
    }

    public void addCriteriaResponse(CriteriaResponse response) {
        this.criteriaResponses.add(response);
        response.setSubmission(this);
    }

    public Integer getSubmissionTime() {
        return submissionTime;
    }

    public void setSubmissionTime(Integer submissionTime) {
        this.submissionTime = submissionTime;
    }

    public List<UUID> getLinkedAnnotationIds() {
        return linkedAnnotationIds;
    }

    public void setLinkedAnnotationIds(List<UUID> linkedAnnotationIds) {
        this.linkedAnnotationIds = linkedAnnotationIds;
    }

    public UUID getAssignedReviewerId() { return assignedReviewerId; }
    public void setAssignedReviewerId(UUID assignedReviewerId) { this.assignedReviewerId = assignedReviewerId; }

    public LocalDateTime getAssignedAt() { return assignedAt; }
    public void setAssignedAt(LocalDateTime assignedAt) { this.assignedAt = assignedAt; }

    public boolean isReviewCompleted() { return reviewCompleted; }
    public void setReviewCompleted(boolean reviewCompleted) { this.reviewCompleted = reviewCompleted; }

}