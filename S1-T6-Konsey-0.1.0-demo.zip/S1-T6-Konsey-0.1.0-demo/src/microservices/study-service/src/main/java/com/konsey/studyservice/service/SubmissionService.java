package com.konsey.studyservice.service;

import com.konsey.studyservice.dto.SubmissionRequest;
import com.konsey.studyservice.entity.Annotation;
import com.konsey.studyservice.entity.Submission;
import com.konsey.studyservice.repository.AnnotationRepository;
import com.konsey.studyservice.repository.SubmissionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.ZonedDateTime;
import java.util.List;
import java.util.UUID;

@Service
public class SubmissionService {

    private final SubmissionRepository submissionRepository;
    private final AnnotationRepository annotationRepository; // Assuming you have this repository

    @Autowired
    public SubmissionService(SubmissionRepository submissionRepository, AnnotationRepository annotationRepository) {
        this.submissionRepository = submissionRepository;
        this.annotationRepository = annotationRepository;
    }

    @Transactional
    public Submission processSubmission(SubmissionRequest request) {
        // 1. Create and populate the new Submission entity
        if(hasSubmitted(request.getParticipantId(), request.getTaskId())) {
            return null;
        }

        Submission submission = new Submission();
        submission.setStudyId(request.getStudyId());
        submission.setTaskId(request.getTaskId());
        submission.setParticipantId(request.getParticipantId());
        submission.setTimestamp(ZonedDateTime.now());
        submission.setSubmissionTime(request.getSubmissionTime());
        submission.setLinkedAnnotationIds(request.getLinkedAnnotationIds());

        if (request.getCriteriaResponses() != null) {
            request.getCriteriaResponses().forEach(response -> {
                submission.addCriteriaResponse(response);
            });
        }

        Submission savedSubmission = submissionRepository.save(submission);

        if (request.getLinkedAnnotationIds() != null && !request.getLinkedAnnotationIds().isEmpty()) {
            List<Annotation> annotationsToLink = annotationRepository.findAllById(request.getLinkedAnnotationIds());

            annotationsToLink.forEach(annotation -> {
                // Manually update the foreign key (submission_id) on the existing Annotation entity
                annotation.setSubmission(savedSubmission);
                // The annotation repository must save this update
                annotationRepository.save(annotation);
            });
        }

        // Return the final Submission object
        return savedSubmission;
    }

    public boolean hasSubmitted(UUID participantId, UUID taskId) {
        return submissionRepository.existsByParticipantIdAndTaskId(participantId, taskId);
    }
    public List<Submission> getSubmissionsByTaskId(UUID taskId){
        return submissionRepository.findByTaskId(taskId);
    }
    public int getSubmissionCountByStudyAndParticipantId(UUID participantId,UUID studyId){
        return submissionRepository.countByParticipantIdAndStudyId(participantId,studyId);
    }
    public int getSubmissionCountByTaskId(UUID taskId){
        return submissionRepository.countByTaskId(taskId);
    }
}