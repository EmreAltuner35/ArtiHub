package com.konsey.studyservice.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "STUDY_CRITERION")
public class Criterion {
    @Column(name = "criterion_id", updatable = false, nullable = false)
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID criterionID;
    @ManyToOne(fetch = FetchType.LAZY) // LAZY is more efficient
    @JoinColumn(name = "task") // This is the actual DB column name
    @JsonBackReference // Prevents JSON infinite loops
    private Task task;
    @Column
    private String name;

    @Column
    private String description;

    @Column
    @Enumerated(EnumType.STRING)
    private ScaleType scaleType;

    @ElementCollection
    @CollectionTable(
            name = "criterion_options",
            joinColumns = @JoinColumn(name = "criterion_id")
    )
    @Column(name = "option_value")
    @Builder.Default
    private List<String> options = new ArrayList<>();
}


