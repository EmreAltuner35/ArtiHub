package com.konsey.studyservice.entity;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Represents the STUDY table in the database.
 */// Adds getters, setters, toString(), equals(), and hashCode()
@Entity // Declares this class as a JPA entity
@Table(name = "STUDY") // Maps this class to the "STUDY" table
public class Study {

    /**
     * The primary key (PK) for the study.
     * Mapped to the 'study_id' column.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO) // Lets JPA handle ID generation
    @Column(name = "study_id", updatable = false, nullable = false)
    private UUID studyId;

    /**
     * The foreign key (FK) relationship to the User (Researcher).
     * This field represents the User entity that this study belongs to.
     * We use FetchType.LAZY for better performance.
     */
    @Column(name = "researcher_id",nullable = false)  // Maps the FK column
    private UUID researcherId;

    /**
     * The title of the study.
     * Mapped to the 'title' column, which cannot be null.
     */
    @Column(name = "title", nullable = false, length = 255)
    private String title;

    /**
     * The description of the study.
     * Mapped to the 'description' column (TEXT type).
     */
    @Column(name = "description", columnDefinition = "TEXT")
    private String description;

    @OneToMany(
            mappedBy = "study",
            cascade = CascadeType.ALL,
            orphanRemoval = true
    )
    @JsonManagedReference
    private List<Task> tasks = new ArrayList<Task>();
    /**
     * The date and time when the study begins.
     */
    @Column
    private LocalDate startDate;


    @Column
    private LocalDate endDate;

    /**
     * The current status of the study (e.g., Draft, Active, Completed).
     * Mapped to the 'status' column as a String-based Enum.
     */
    @Enumerated(EnumType.STRING) // Stores the enum name ("DRAFT", "ACTIVE") in the DB
    @Column(name = "status", length = 50)
    private StudyStatus status;

    @ElementCollection(fetch = FetchType.LAZY) // LAZY is default, but good to be explicit
    @CollectionTable(
            name = "study_participants", // Name of the new table
            joinColumns = @JoinColumn(name = "study_id") // Foreign key column in the new table
    )
    @Column(name = "participant_id")
    private List<UUID> participants = new ArrayList<UUID>();

    @ElementCollection(fetch = FetchType.LAZY)
    @CollectionTable(
            name = "study_reviewers",
            joinColumns = @JoinColumn(name = "study_id")
    )
    @Column(name = "reviewer_id")
    private List<UUID> reviewers = new ArrayList<UUID>();

    public String getTitle(){return title;}
    public void setTitle(String title){this.title = title;}

    public String getDescription(){return description;}
    public void setDescription(String description){this.description = description;}

    public StudyStatus getStatus(){return status;}
    public void setStatus(StudyStatus status){this.status = status;}

    public UUID getResearcherId() {return researcherId;}
    public UUID getStudyId() {return studyId;}

    public LocalDate getStartDate() {return startDate;}
    public void setStartDate(LocalDate startDate) {this.startDate = startDate;}

    public LocalDate getEndDate() {return endDate;}
    public void setEndDate(LocalDate endDate) {this.endDate = endDate;}

    public void addTask(Task task){this.tasks.add(task);}
    public Study(){}

    public Study(UUID researcherId, String title, String description,LocalDate startDate,LocalDate endDate){
        this.researcherId = researcherId;
        this.description = description;
        this.title = title;
        this.status = StudyStatus.DRAFT;//when the study is first initialized, its status will be draft
        this.startDate = startDate;
        this.endDate = endDate;
    }
    public void updateStatusIfExpired() {
        if (this.endDate != null && LocalDate.now().isAfter(this.endDate)) {
            this.status = StudyStatus.COMPLETED;
        }
    }

    public List<UUID> getParticipants() {
        return participants;
    }

    public void setParticipants(List<UUID> participants) {
        this.participants = participants;
    }

    public List<Task> getTasks() {
        return tasks;
    }

    public void setTasks(List<Task> tasks) {
        this.tasks = tasks;
    }

    public List<UUID> getReviewers() {
        return reviewers;
    }

    public void setReviewers(List<UUID> reviewers) {
        this.reviewers = reviewers;
    }
}