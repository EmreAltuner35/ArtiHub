package com.konsey.studyservice.controller;

import com.konsey.studyservice.dto.QuizSubmissionRequest;
import com.konsey.studyservice.entity.Invitation;
import com.konsey.studyservice.entity.InvitationStatus;
import com.konsey.studyservice.service.InvitationService;
import com.konsey.studyservice.utility.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/studies/participant/invitations")
@CrossOrigin
public class ParticipantController {

    @Autowired
    private InvitationService invitationService;

    @GetMapping
    public ResponseEntity<List<Invitation>> getMyInvitations() {
        UUID userId = SecurityUtils.userId();
        List<Invitation> invitations = invitationService.getInvitationsForUser(userId);
        return ResponseEntity.ok(invitations);
    }

    @PutMapping("/{invitationId}/status")
    public ResponseEntity<Invitation> updateInvitationStatus(
            @PathVariable UUID invitationId,
            @RequestParam InvitationStatus status) {
        return ResponseEntity.ok(invitationService.updateInvitationStatus(invitationId, status));
    }

    @PostMapping("/{invitationId}/quiz")
    public ResponseEntity<Invitation> submitQuiz(
            @PathVariable UUID invitationId,
            @RequestBody QuizSubmissionRequest request) {
        return ResponseEntity.ok(invitationService.submitQuiz(invitationId, request));
    }
}
