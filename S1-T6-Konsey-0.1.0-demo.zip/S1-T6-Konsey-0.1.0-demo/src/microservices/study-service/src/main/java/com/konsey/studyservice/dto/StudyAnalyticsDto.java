package com.konsey.studyservice.dto;
import com.konsey.studyservice.entity.ParticipantStatus;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class StudyAnalyticsDto {
     private Map<UUID, ParticipantStatus> participantStatusMap;
     private int totalParticipants;
        public StudyAnalyticsDto(Map<UUID, ParticipantStatus> participantStatusMap,int totalParticipants){
            this.participantStatusMap = participantStatusMap;
            this.totalParticipants = totalParticipants;
        }
    public StudyAnalyticsDto(){}
    public int getTotalParticipants() {
        return totalParticipants;
    }
    public Map<UUID, ParticipantStatus> getParticipantStatusMap() {
        return participantStatusMap;
    }
}
