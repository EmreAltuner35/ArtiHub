package com.konsey.studyservice.dto;

import java.util.UUID;

public class FinalizeReviewDto {

    private String comment;
    private UUID studyId;
    private UUID participantId;


    public FinalizeReviewDto() {
    }

    public FinalizeReviewDto(String comment, UUID studyId, UUID participantId) {
        this.comment = comment;
        this.studyId = studyId;
        this.participantId = participantId;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public UUID getStudyId() {
        return studyId;
    }

    public void setStudyId(UUID studyId) {
        this.studyId = studyId;
    }

    public UUID getParticipantId() {
        return participantId;
    }

    public void setParticipantId(UUID participantId) {
        this.participantId = participantId;
    }
}
