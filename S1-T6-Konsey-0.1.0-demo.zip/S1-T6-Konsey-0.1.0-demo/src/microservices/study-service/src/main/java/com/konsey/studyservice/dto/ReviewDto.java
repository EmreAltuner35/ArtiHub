package com.konsey.studyservice.dto;

import com.konsey.studyservice.entity.Annotation;
import com.konsey.studyservice.entity.CriteriaResponse;
import com.konsey.studyservice.entity.Task;

import java.util.List;
import java.util.UUID;

public class ReviewDto {

    private UUID participantId;

    // List of Artifact IDs for the frontend to fetch content
    private List<UUID> artifactIds;

    // List of full Annotation entities linked to the submission
    private List<Annotation> annotations;

    // List of CriteriaResponse entities (the participant's final answers)
    private List<CriteriaResponse> answers;

    private UUID taskId;

    private String existingReviewStatus;

    // Getters and Setters

    public UUID getParticipantId() { return participantId; }
    public void setParticipantId(UUID participantId) { this.participantId = participantId; }

    public List<UUID> getArtifactIds() { return artifactIds; }
    public void setArtifactIds(List<UUID> artifactIds) { this.artifactIds = artifactIds; }

    public List<Annotation> getAnnotations() { return annotations; }
    public void setAnnotations(List<Annotation> annotations) { this.annotations = annotations; }

    public List<CriteriaResponse> getAnswers() { return answers; }
    public void setAnswers(List<CriteriaResponse> answers) { this.answers = answers; }

    public UUID getTaskId() {
        return taskId;
    }

    public void setTaskId(UUID taskId) {
        this.taskId = taskId;
    }

    public String getExistingReviewStatus() {
        return existingReviewStatus;
    }

    public void setExistingReviewStatus(String existingReviewStatus) {
        this.existingReviewStatus = existingReviewStatus;
    }
}