package com.konsey.studyservice.service;

import com.konsey.studyservice.dto.NextReviewResponse;
import com.konsey.studyservice.dto.ReviewDecisionDto;
import com.konsey.studyservice.dto.ReviewDto;
import com.konsey.studyservice.entity.*;
import com.konsey.studyservice.repository.AnnotationRepository;
import com.konsey.studyservice.repository.ReviewDecisionRepository;
import com.konsey.studyservice.repository.SubmissionRepository;
import com.konsey.studyservice.repository.TaskRepository;
import com.konsey.studyservice.utility.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class ReviewService {

    @Autowired
    private SubmissionRepository submissionRepository;

    @Autowired
    private AnnotationRepository annotationRepository;

    @Autowired
    private TaskService taskService;

    @Autowired
    private ReviewDecisionRepository reviewDecisionRepository;

    @Autowired
    private TaskRepository taskRepository;


    @Transactional(readOnly = true)
    public List<ReviewDto> getParticipantReviewDetails(UUID studyId, UUID participantId) {

        List<Submission> submissions =
                submissionRepository.findByParticipantIdAndStudyIdOrderByTimestampAsc(participantId, studyId);

        return submissions.stream()
                .map(submission -> {
                    UUID taskId = submission.getTaskId();
                    Task task = taskService.findTask(taskId);

                    List<UUID> artifactIds = task.getArtifacts();

                    List<Annotation> annotations =
                            annotationRepository.findAllById(
                                    submission.getLinkedAnnotationIds()
                            );

                    List<CriteriaResponse> answers =
                            submission.getCriteriaResponses();

                    ReviewDto dto = new ReviewDto();
                    dto.setParticipantId(participantId);
                    dto.setArtifactIds(artifactIds);
                    dto.setAnnotations(annotations);
                    dto.setAnswers(answers);
                    dto.setTaskId(taskId);
                    Optional<ReviewDecision> decision =
                            reviewDecisionRepository
                                    .findByStudyIdAndTaskIdAndParticipantId(
                                            studyId,
                                            task.getTaskId(),
                                            participantId
                                    );

                    decision.ifPresent(d -> {
                        dto.setExistingReviewStatus(d.getReviewStatus());
                    });

                    return dto;
                })
                .toList();
    }



    @Transactional
    public void submitReviewDecision(
            UUID studyId,
            UUID taskId,
            UUID participantId,
            String status,
            String comment
    ) {
        UUID reviewerId = SecurityUtils.userId();

        Submission submission = submissionRepository
                .findByParticipantIdAndTaskId(participantId, taskId)
                .orElseThrow(() -> new RuntimeException("Submission not found"));

        submission.setReviewCompleted(true);
        submissionRepository.save(submission);

        ReviewDecision decision = reviewDecisionRepository
                .findByStudyIdAndTaskIdAndParticipantId(studyId, taskId, participantId)
                .orElseGet(ReviewDecision::new);

        decision.setStudyId(studyId);
        decision.setTaskId(taskId);
        decision.setParticipantId(participantId);
        decision.setReviewerId(reviewerId);
        decision.setReviewStatus(status);
        decision.setReviewComment(comment);
        decision.setReviewDate(LocalDateTime.now());

        reviewDecisionRepository.save(decision);
    }

    @Transactional
    public void submitFinalComment(String comment, UUID studyId, UUID participantId) {
        List<ReviewDecision> reviews =
                reviewDecisionRepository.findByParticipantIdAndStudyId(participantId, studyId);

        if (reviews.isEmpty()) {
            throw new IllegalStateException(
                    "No review decisions found to finalize"
            );
        }

        for (ReviewDecision review : reviews) {
            review.setReviewComment(comment);
            review.setReviewOver(true);
        }

        reviewDecisionRepository.saveAll(reviews);
    }

    @Transactional(readOnly = true)
    public List<ReviewDecisionDto> getParticipantReviewDecisions(
            UUID studyId,
            UUID participantId
    ) {
        List<ReviewDecision> decisions =
                reviewDecisionRepository
                        .findByParticipantIdAndStudyId(participantId, studyId);

        return decisions.stream()
                .map(d -> {
                    String taskTitle = taskRepository
                            .findById(d.getTaskId())
                            .map(Task::getName)
                            .orElse("Unknown Task");
                    ReviewDecisionDto dto = new ReviewDecisionDto();
                    dto.setTaskTitle(taskTitle);
                    dto.setReviewStatus(d.getReviewStatus());
                    dto.setReviewComment(d.getReviewComment());
                    dto.setReviewDate(d.getReviewDate());
                    return dto;
                })
                .toList();
    }

}
