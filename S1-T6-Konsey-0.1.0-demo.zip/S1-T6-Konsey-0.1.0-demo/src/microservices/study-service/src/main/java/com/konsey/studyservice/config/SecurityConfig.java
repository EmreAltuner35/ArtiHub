package com.konsey.studyservice.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.jose.jws.MacAlgorithm;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter;
import org.springframework.security.web.SecurityFilterChain;

import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import org.springframework.web.filter.CorsFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

/**
 * Spring Security configuration for the artifact service.
 * <p>
 * Responsibilities:
 * <ul>
 *     <li>Define which endpoints are protected and which are public.</li>
 *     <li>Configure the app as an OAuth2 resource server that validates JWTs.</li>
 *     <li>Define how to decode HMAC-signed JWTs using a shared secret.</li>
 * </ul>
 */
@Configuration
@EnableWebSecurity
public class SecurityConfig {
    /**
     * Shared secret used to verify HMAC-signed JWTs.
     * Loaded from application properties: {@code jwt.secret}.
     */
    @Value("${jwt.secret}")
    private String secret;

    /**
     * Defines the main security filter chain.
     *
     * @param httpSecurity the HTTP security builder
     * @return the built {@link SecurityFilterChain}
     * @throws Exception if configuration fails
     */
    @Bean
    SecurityFilterChain filterChain(HttpSecurity httpSecurity,
                                    JwtAuthenticationConverter jwtAuthenticationConverter) throws Exception {
        // disable CSRF for simplicity
        httpSecurity.csrf(AbstractHttpConfigurer::disable)
                .cors(cors -> {});

        // define authorization rules
        httpSecurity.authorizeHttpRequests(auth -> auth
                .requestMatchers("/api/studies/**").permitAll()
                .anyRequest().authenticated());
        // configure the app as a JWT resource server
        httpSecurity.oauth2ResourceServer(oauth -> oauth
                .jwt(jwt -> jwt
                        .jwtAuthenticationConverter(jwtAuthenticationConverter)));
        return httpSecurity.build();
    }

    @Bean
    public CorsFilter corsFilter() {
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        CorsConfiguration config = new CorsConfiguration();
        config.setAllowCredentials(true);
        config.setAllowedOrigins(Arrays.asList(
                "http://localhost:80",
                "http://127.0.0.1:80"
        ));
        config.addAllowedHeader("*");
        config.addAllowedMethod("*"); // GET, POST, PUT, DELETE, OPTIONS
        source.registerCorsConfiguration("/**", config);
        return new CorsFilter(source);
    }

    /**
     * Creates a {@link JwtDecoder} that verifies tokens signed with HS256 using
     * the shared secret from configuration.
     *
     * @return configured {@link JwtDecoder}
     */
    @Bean
    JwtDecoder jwtDecoder() {
        // turn the secret into bytes
        byte[] keyBytes = secret.getBytes(StandardCharsets.UTF_8);

        // build a Nimbus decoder for HMAC-SHA256
        return NimbusJwtDecoder
                .withSecretKey(new SecretKeySpec(keyBytes, "HmacSHA256"))
                .macAlgorithm(MacAlgorithm.HS256)
                .build();
    }

    @Bean
    JwtAuthenticationConverter jwtAuthenticationConverter() {
        JwtAuthenticationConverter converter = new JwtAuthenticationConverter();
        converter.setPrincipalClaimName("sub");
        converter.setJwtGrantedAuthoritiesConverter(SecurityConverters::authoritiesFromSingleRoleClaim);
        return converter;
    }

    static final class SecurityConverters {
        static Collection<GrantedAuthority> authoritiesFromSingleRoleClaim(Jwt jwt) {
            String role = jwt.getClaimAsString("role");
            if(role == null || role.isBlank())
                return List.of();
            return List.of(new SimpleGrantedAuthority("ROLE_" + role));
        }
    }
}
