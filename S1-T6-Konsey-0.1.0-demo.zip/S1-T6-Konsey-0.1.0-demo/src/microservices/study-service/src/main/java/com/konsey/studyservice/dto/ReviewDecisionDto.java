package com.konsey.studyservice.dto;

import java.time.LocalDateTime;
import java.util.UUID;

public class ReviewDecisionDto {

    private UUID studyId;
    private String taskTitle;
    private UUID participantId;

    private String reviewStatus;   // APPROVED / DENIED
    private String reviewComment;

    private UUID reviewerId;
    private LocalDateTime reviewDate;

    // -------------------- Constructors --------------------

    public ReviewDecisionDto() {
    }

    // -------------------- Getters & Setters --------------------

    public UUID getStudyId() {
        return studyId;
    }

    public void setStudyId(UUID studyId) {
        this.studyId = studyId;
    }

    public String getTaskTitle() {
        return taskTitle;
    }

    public void setTaskTitle(String taskTitle) {
        this.taskTitle = taskTitle;
    }

    public UUID getParticipantId() {
        return participantId;
    }

    public void setParticipantId(UUID participantId) {
        this.participantId = participantId;
    }

    public String getReviewStatus() {
        return reviewStatus;
    }

    public void setReviewStatus(String reviewStatus) {
        this.reviewStatus = reviewStatus;
    }

    public String getReviewComment() {
        return reviewComment;
    }

    public void setReviewComment(String reviewComment) {
        this.reviewComment = reviewComment;
    }

    public UUID getReviewerId() {
        return reviewerId;
    }

    public void setReviewerId(UUID reviewerId) {
        this.reviewerId = reviewerId;
    }

    public LocalDateTime getReviewDate() {
        return reviewDate;
    }

    public void setReviewDate(LocalDateTime reviewDate) {
        this.reviewDate = reviewDate;
    }
}

