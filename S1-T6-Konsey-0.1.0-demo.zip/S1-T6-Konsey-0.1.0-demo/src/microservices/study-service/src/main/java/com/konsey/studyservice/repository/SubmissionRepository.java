package com.konsey.studyservice.repository;

import com.konsey.studyservice.entity.Submission;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface SubmissionRepository extends JpaRepository<Submission, UUID> {

    boolean existsByParticipantIdAndTaskId(UUID participantId, UUID taskId);

    Optional<Submission> findByParticipantIdAndTaskId(UUID participantId, UUID taskId);
    List<Submission> findByParticipantIdAndStudyId(UUID participantId, UUID studyId);
    int countByParticipantIdAndStudyId(UUID participantId, UUID studyId);
    List<Submission> findByTaskId(UUID taskId);
    int countByTaskId(UUID taskId);
    List<Submission> findByParticipantIdAndStudyIdOrderByTimestampAsc(
            UUID participantId,
            UUID studyId
    );
}
