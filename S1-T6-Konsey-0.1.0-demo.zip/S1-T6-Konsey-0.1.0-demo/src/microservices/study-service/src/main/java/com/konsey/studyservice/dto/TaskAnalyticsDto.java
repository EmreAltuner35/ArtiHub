package com.konsey.studyservice.dto;

import com.konsey.studyservice.entity.FiveStarRatingDistribution;
import com.konsey.studyservice.entity.MultChoiceRatingDistribution;

import java.util.List;

public class TaskAnalyticsDto {
    private double completionRate;
    private double avgCompletionTime;
    private List<MultChoiceRatingDistribution> multChoiceRatingDistributionList;
    private List<FiveStarRatingDistribution> fiveStarRatingDistributionList;
    public TaskAnalyticsDto(double completionRate,
                            double avgCompletionRate,
                            List<MultChoiceRatingDistribution> multChoiceRatingDistributionList,
                            List<FiveStarRatingDistribution> fiveStarRatingDistributionList){
        this.completionRate = completionRate;
        this.multChoiceRatingDistributionList = multChoiceRatingDistributionList;
        this.fiveStarRatingDistributionList = fiveStarRatingDistributionList;
        this.avgCompletionTime = avgCompletionRate;
    }
    public TaskAnalyticsDto(){}
    public double getCompletionRate() {
        return completionRate;
    }
    public double getAvgCompletionTime(){return  this.avgCompletionTime;}
    public List<MultChoiceRatingDistribution> getRatingDistributionList() {
        return multChoiceRatingDistributionList;
    }

    public List<FiveStarRatingDistribution> getFiveStarRatingDistributionList() {
        return fiveStarRatingDistributionList;
    }
}
