package com.konsey.studyservice.repository;

import com.konsey.studyservice.entity.Invitation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface InvitationRepository extends JpaRepository<Invitation, UUID> {
    List<Invitation> findByStudy_StudyId(UUID studyId);
    List<Invitation> findByUserId(UUID userId);
}
