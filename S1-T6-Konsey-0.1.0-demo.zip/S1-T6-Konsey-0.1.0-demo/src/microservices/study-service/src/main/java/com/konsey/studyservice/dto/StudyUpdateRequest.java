package com.konsey.studyservice.dto;

import com.konsey.studyservice.entity.StudyStatus;

import java.time.LocalDate;


public class StudyUpdateRequest {
    private String title;
    private String description;
    private StudyStatus status;
    private LocalDate startDate;
    private LocalDate endDate;
    public String getTitle(){return title;}
    public void setTitle(String title) {this.title = title;}

    public String getDescription() {return description;}
    public void setDescription(String description){this.description = description;}

    public StudyStatus getStatus(){return status;}
    public void setStatus(StudyStatus status){this.status = status;}

    public LocalDate getStartDate() {return startDate;}
    public LocalDate getEndDate() {return endDate;}
}
