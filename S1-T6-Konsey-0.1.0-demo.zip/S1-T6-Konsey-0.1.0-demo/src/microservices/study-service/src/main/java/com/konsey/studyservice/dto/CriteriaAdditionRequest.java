package com.konsey.studyservice.dto;

import com.konsey.studyservice.entity.Criterion;

import java.util.List;
import java.util.UUID;

public class CriteriaAdditionRequest {
    public CriteriaAdditionRequest(){}
    private List<Criterion> criteria;
}
