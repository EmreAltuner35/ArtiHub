package com.konsey.studyservice.repository;

import com.konsey.studyservice.entity.Criterion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.UUID;

public interface CriterionRepository extends JpaRepository<Criterion, UUID> {
    @Query("SELECT c FROM Criterion c WHERE c.task.study.studyId = :studyId")
    List<Criterion> findByStudyId(@Param("studyId") UUID studyId);
    Criterion findByName(String name);
}
