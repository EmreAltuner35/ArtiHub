package com.konsey.studyservice.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

public class StudyCreationRequest {

    @NotBlank(message = "Study name cannot be empty")
    @Size(min = 3, max = 255)
    private String title;


    @Size(max = 500)
    @NotBlank(message = "Study name cannot be empty")
    private String description;


    private LocalDate startDate;
    private LocalDate endDate;

    public StudyCreationRequest(String title, String description, LocalDate startDate,LocalDate endDate){
        this.title = title;
        this.description = description;
        this.endDate = endDate;
        this.startDate = startDate;
    }


    // --- Getters and Setters ---
    public String getTitle() {
        return title;
    }

    public void setTitle(String study_name) {
        this.title = study_name;}

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public LocalDate getStartDate() {
        return startDate;
    }
}