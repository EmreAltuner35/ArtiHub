package com.konsey.studyservice.repository;

import com.konsey.studyservice.entity.ReviewDecision;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface ReviewDecisionRepository extends JpaRepository<ReviewDecision, UUID> {

    List<ReviewDecision> findByParticipantIdAndStudyId(UUID participantId, UUID studyId);
    Optional<ReviewDecision> findByStudyIdAndTaskIdAndParticipantId(
            UUID studyId,
            UUID taskId,
            UUID participantId
    );
    boolean existsByParticipantIdAndStudyId(UUID participantId, UUID studyId);
}