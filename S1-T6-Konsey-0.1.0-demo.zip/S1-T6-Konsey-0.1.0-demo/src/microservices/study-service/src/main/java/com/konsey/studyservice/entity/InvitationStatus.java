package com.konsey.studyservice.entity;

public enum InvitationStatus {
    PENDING,
    ACCEPTED,
    REJECTED,
    QUIZ_COMPLETED
}
