package com.konsey.studyservice.service;

import com.konsey.studyservice.dto.ArtifactAdditionRequest;
import com.konsey.studyservice.dto.TaskAnalyticsDto;
import com.konsey.studyservice.dto.TaskCardDto;
import com.konsey.studyservice.dto.TaskCreationRequest;
import com.konsey.studyservice.entity.*;
import com.konsey.studyservice.dto.CriterionUpdateRequest;
import com.konsey.studyservice.dto.TaskUpdateRequest;
import com.konsey.studyservice.repository.TaskRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class TaskService {
    @Autowired
    private TaskRepository taskRepository;
    @Autowired
    private CriterionService criterionService;
    @Autowired
    private SubmissionService submissionService;

    public Task createTask(TaskCreationRequest request, Study study){
        Task task = Task.builder()
                .name(request.getName())
                .instructions(request.getInstructions())
                .isBlinded(request.isBlinded())
                .viewType(request.getViewType())
                .artifacts(request.getArtifacts())
                .study(study)
                .build();

        taskRepository.save(task);

        if (request.getCriteria() != null) {
            request.getCriteria().forEach(criterionRequest ->
                    criterionService.createCriterion(criterionRequest, task)
            );
        }
        study.addTask(task);
        taskRepository.save(task);
        return task;
    }

    @Transactional
    public Task updateTask(TaskUpdateRequest request, UUID taskId) {
        Task task = taskRepository.findById(taskId).orElseThrow();

        task.setName(request.name().trim());
        task.setInstructions(request.instructions() == null ? null : request.instructions().trim());
        task.setBlinded(request.isBlinded());
        task.setViewType(request.viewType());

        task.setArtifacts(new ArrayList<>(request.artifacts()));

        task.getCriteria().clear();
        for(CriterionUpdateRequest cr : request.criteria()) {
            Criterion criterion = Criterion.builder()
                    .task(task)
                    .name(cr.name().trim())
                    .description(cr.description() == null ? null : cr.description().trim())
                    .scaleType(cr.scaleType())
                    .options(
                            cr.options().stream()
                                    .map(String::trim)
                                    .filter(s -> !s.isEmpty())
                                    .toList()
                    )
                    .build();
            task.addCriterion(criterion);
        }

        taskRepository.save(task);
        return task;
    }

    public Task findTask(UUID taskId){
        Optional<Task> optionalTask;

        // 1. Find the task by its ID from the repository
        optionalTask = taskRepository.findById(taskId);

        // 2. Check if the task was found
        if (optionalTask.isEmpty()) {
            // 3. Throw a 404 Not Found exception if it wasn't
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Task not found with id: " + taskId);
        }
        // 4. Return the found task
        return optionalTask.get();
    }

    public List<Task> getUnfinishedTasksByStudyAndParticipant(Study study, UUID participantId) {

        List<Task> allTasksInStudy = getTasksByStudy(study);

        return allTasksInStudy.stream()
                .filter(task -> !submissionService.hasSubmitted(participantId, task.getTaskId()))
                .collect(Collectors.toList());
    }

    public Task addArtifacts(Task task, ArtifactAdditionRequest request){
         task.setArtifacts(request.getArtifacts());
         taskRepository.save(task);
         return task;
    }
    public void deleteTask(Task task){
        taskRepository.delete(task);}

    public List<Task> getTasksByStudy(Study study) {
        return taskRepository.findByStudy(study);
    }

    public TaskAnalyticsDto getTaskAnalytics(Task task){
        double avgCompletionTime = 0.0;
        int total = task.getStudy().getParticipants().size();
        List<Submission> submissions = submissionService.getSubmissionsByTaskId(task.getTaskId());
        int submissionCount = submissions.size();
        double completionRate = (double) submissionCount / total;
        List<Criterion> criteria = task.getCriteria();
        Map<UUID, MultChoiceRatingDistribution> multChoiceRatingDistributionMap = new HashMap<>();
        Map<UUID, FiveStarRatingDistribution> fiveStarRatingDistributionMap = new HashMap<>();
        for(Criterion c:criteria){
                if(c.getScaleType() == ScaleType.FIVESTAR){
                    fiveStarRatingDistributionMap.put(c.getCriterionID(),new FiveStarRatingDistribution(c));
                }
                else if(c.getScaleType() == ScaleType.MULTIPLE_CHOICE){
                    multChoiceRatingDistributionMap.put(c.getCriterionID(),new MultChoiceRatingDistribution(c));
                }
        }
        int count = 0;
        for(Submission s:submissions){
            avgCompletionTime += (s.getSubmissionTime()-avgCompletionTime)/(count+1);
            count++;
            List<CriteriaResponse> responses = s.getCriteriaResponses();
            for(CriteriaResponse response: responses){
                String criterionName = response.getGroupName();
                Criterion c = criterionService.findCriterionByName(criterionName);
                if(c.getScaleType() == ScaleType.FIVESTAR){
                    fiveStarRatingDistributionMap.get(c.getCriterionID()).update(response.getScore(),response.getItemName());
                }
                else if(c.getScaleType() == ScaleType.MULTIPLE_CHOICE){
                    multChoiceRatingDistributionMap.get(c.getCriterionID()).update(response.getItemName());
                }
            }
        }
        List<FiveStarRatingDistribution> valuesList1 = new ArrayList<FiveStarRatingDistribution>(fiveStarRatingDistributionMap.values());
        List<MultChoiceRatingDistribution> valuesList2 = new ArrayList<MultChoiceRatingDistribution>(multChoiceRatingDistributionMap.values());
        return new TaskAnalyticsDto(completionRate,avgCompletionTime,valuesList2,valuesList1);
    }


}
