package com.konsey.studyservice.entity;

public enum ViewType {
    SINGLE,
    SIDE_BY_SIDE,
    THREE_WAY,
}
