package com.konsey.studyservice.dto;

import java.util.UUID;

public class NextReviewResponse {

    private UUID participantId;
    private boolean found;

    public NextReviewResponse(UUID participantId, boolean found) {
        this.participantId = participantId;
        this.found = found;
    }

    public UUID getParticipantId() { return participantId; }
    public boolean isFound() { return found; }
}
