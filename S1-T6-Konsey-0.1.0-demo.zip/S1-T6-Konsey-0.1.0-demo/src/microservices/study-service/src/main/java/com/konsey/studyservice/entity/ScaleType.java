package com.konsey.studyservice.entity;

public enum ScaleType {
    FIVESTAR,
    MULTIPLE_CHOICE,
    YESNO,
    ARTIFACT_EDIT
}
