package com.konsey.studyservice.controller;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.konsey.studyservice.dto.*;
import com.konsey.studyservice.entity.Study;
import com.konsey.studyservice.entity.StudyStatus;
import com.konsey.studyservice.service.AnalyticsService;
import com.konsey.studyservice.service.UserServiceClient;
import com.konsey.studyservice.utility.SecurityUtils;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import  com.konsey.studyservice.service.StudyService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;
import java.util.UUID;
@RestController
@RequestMapping("/api/studies")
class StudyController {
    @Autowired
    private StudyService studyService;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private AnalyticsService analyticsService;

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<Study> createStudy(@Valid @RequestBody StudyCreationRequest request){
        return ResponseEntity.ok(studyService.createStudy(request));
    }

    @PostMapping("/bulk")
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<Study> createStudyBulk(
            @RequestPart("file") MultipartFile file,
            @RequestPart("meta") String meta
    ) throws Exception {
        BulkStudyCreationRequest request = objectMapper.readValue(meta, BulkStudyCreationRequest.class);
        return ResponseEntity.ok(studyService.createBulkStudy(request, file));
    }

    @GetMapping("/{studyId}")
    public ResponseEntity<Study> getStudy(@PathVariable UUID studyId){
        Study study = studyService.findStudy(studyId);
        return ResponseEntity.ok(study);
    }
    //This method is behaving as GET.However since the method above uses the same, POST is used there
    @GetMapping("/mine")
    public ResponseEntity<List<Study>> displayStudies(){
        return ResponseEntity.ok(studyService.displayStudies());
    }

    @PutMapping("/{studyId}")//study wont be updated if the status is not valid
    public ResponseEntity<Study> updateStudy(@PathVariable UUID studyId,@Valid @RequestBody StudyUpdateRequest request){
        Study study = studyService.findStudy(studyId);
        if(study.getStatus() != StudyStatus.DRAFT){
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }
        else{
            return ResponseEntity.ok(studyService.updateStudy(study,request));
        }
    }

    @DeleteMapping("/{studyId}")
    public ResponseEntity<?> deleteStudy(@PathVariable UUID studyId){
        Study study = studyService.findStudy(studyId);
        if(study.getStatus() == StudyStatus.ACTIVE) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }
        try {
            studyService.deleteStudy(study);
            return ResponseEntity.noContent().build();
        }
        catch (Exception e){
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/enrolled")
    public ResponseEntity<List<Study>> getEnrolledStudies() {
        UUID participantId = SecurityUtils.userId();
        List<Study> enrolledStudies = studyService.getEnrolledStudies(participantId);
        return ResponseEntity.ok(enrolledStudies);
    }

    @PostMapping("/{studyId}/participants/{participantId}")
    public ResponseEntity<?> addParticipant(
            @PathVariable UUID studyId,
            @PathVariable UUID participantId) {

        studyService.addParticipant(studyId, participantId);
        return ResponseEntity.ok().build();
    }
    @GetMapping("/{studyId}/analytics")
    public ResponseEntity<StudyAnalyticsDto> getStudyAnalytics(@PathVariable UUID studyId){
        return ResponseEntity.ok(analyticsService.getStudyAnalytics(studyId));
    }

    @GetMapping
    public ResponseEntity<List<Study>> getAllStudies() {
        List<Study> studies = studyService.getAllStudies();
        return ResponseEntity.ok(studies);
    }
    @GetMapping("/{studyId}/tasks/analytics")
    public ResponseEntity<Map<UUID, TaskCardDto>> getTaskCardAnalytics(@PathVariable UUID studyId){
        return ResponseEntity.ok(studyService.getTaskCardAnalytics(studyId));
    }

    // Reviewer management endpoints
    @PostMapping("/{studyId}/reviewers")
    public ResponseEntity<?> addReviewer(
            @PathVariable UUID studyId,
            @RequestBody Map<String, String> body) {
        UUID reviewerId = UUID.fromString(body.get("reviewerId"));
        studyService.addReviewer(studyId, reviewerId);
        return ResponseEntity.ok().build();
    }

    @DeleteMapping("/{studyId}/reviewers/{reviewerId}")
    public ResponseEntity<?> removeReviewer(
            @PathVariable UUID studyId,
            @PathVariable UUID reviewerId) {
        studyService.removeReviewer(studyId, reviewerId);
        return ResponseEntity.ok().build();
    }

    @GetMapping("/{studyId}/reviewers")
    public ResponseEntity<List<UUID>> getReviewers(@PathVariable UUID studyId) {
        return ResponseEntity.ok(studyService.getReviewers(studyId));
    }

    @GetMapping("/my-reviewer-studies")
    public ResponseEntity<List<Study>> getMyReviewerStudies() {
        UUID reviewerId = SecurityUtils.userId();
        return ResponseEntity.ok(studyService.getStudiesForReviewer(reviewerId));
    }

    @GetMapping("/{studyId}/participants")
    public ResponseEntity<List<UserResponseWithReview>> getStudyParticipants(
            @PathVariable UUID studyId
    ) {
        List<UserResponseWithReview> participants = studyService.getStudyParticipantsWithReviewStatus(studyId);
        return ResponseEntity.ok(participants);
    }

}