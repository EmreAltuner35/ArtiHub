package com.konsey.studyservice.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import java.util.UUID;

@Entity
@Table(name = "criteria_responses")
public class CriteriaResponse {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    // The name of the criterion group (e.g., "Bug Category", "Metrics")
    @Column(name = "group_name", nullable = false)
    private String groupName;

    // The specific metric or option name (e.g., "Readability", "Functional Issue")
    @Column(name = "item_name", nullable = false)
    private String itemName;

    // Stores the numerical score (for FiveStar: 1-5). Use Integer to allow null.
    @Column(name = "score")
    private Integer score;

    @Column(name = "response_text", columnDefinition = "TEXT")
    private String responseText;

    // Link back to the Submission entity
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "submission_id", nullable = false)
    @JsonBackReference(value = "submission-response")
    private Submission submission;

    public CriteriaResponse() {}

    public CriteriaResponse(String groupName, String itemName, Integer score) { //

        this.groupName = groupName;
        this.itemName = itemName;
        this.score = score;

    }

    public CriteriaResponse(String groupName, String itemName) {
        this.groupName = groupName;
        this.itemName = itemName;
        this.score = null; // score is nullable
    }

    public CriteriaResponse(String groupName, String itemName, String responseText) {
        this.groupName = groupName;
        this.itemName = itemName; // Will be "ARTIFACT_EDIT_SUBMISSION" based on frontend
        this.score = null;
        this.responseText = responseText;
    }

    // Getters and Setters
    public UUID getId() { return id; }
    public String getGroupName() { return groupName; }
    public void setGroupName(String groupName) { this.groupName = groupName; }
    public String getItemName() { return itemName; }
    public void setItemName(String itemName) { this.itemName = itemName; }
    public Integer getScore() { return score; }
    public void setScore(Integer score) { this.score = score; }
    public Submission getSubmission() { return submission; }
    public void setSubmission(Submission submission) { this.submission = submission; }
    public String getResponseText() { return responseText; }
    public void setResponseText(String responseText) { this.responseText = responseText; }
}