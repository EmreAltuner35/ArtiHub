package com.konsey.studyservice.entity;

import java.util.ArrayList;
import java.util.List;

public class MultChoiceRatingDistribution {
    private int[] optionCounts;
    private Criterion criterion;
    private List<String> options;
    public MultChoiceRatingDistribution(Criterion criterion){
        this.criterion = criterion;
        options = criterion.getOptions();
        optionCounts = new int[options.size()];
            for (int i = 0; i < options.size(); i++) {
                optionCounts[i] = 0;
            }

    }
    public MultChoiceRatingDistribution(){};
    public Criterion getCriterion() {
        return criterion;
    }
    public int[] getOptionCounts() {
        return optionCounts;
    }
    public List<String> getOptions() {
        return options;
    }

    public void update(String option){
        int index = 0;
        for(int i = 0;i<options.size();i++){
            if(options.get(i).equals(option)){
                index = i;
                i = options.size();
            }
        }
        optionCounts[index]++;
    }
}
