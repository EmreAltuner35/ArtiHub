package com.konsey.studyservice.service;

import com.konsey.studyservice.dto.CriterionCreationRequest;
import com.konsey.studyservice.entity.Criterion;
import com.konsey.studyservice.entity.ScaleType;
import com.konsey.studyservice.entity.Task;
import com.konsey.studyservice.repository.CriterionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
@Service
public class CriterionService {
    @Autowired
    private CriterionRepository repo;

    public List<Criterion> getCriteriaByStudyId(UUID studyId) {
        return repo.findByStudyId(studyId);
    }

    public Criterion createCriterion(CriterionCreationRequest request, Task task){
        Criterion criterion = Criterion.builder()
                .task(task)
                .name(request.getName().trim())
                .description(request.getDescription().trim())
                .scaleType(request.getScaleType())
                .options(
                        request.getOptions().stream()
                                .map(String::trim)
                                .filter(s -> !s.isEmpty())
                                .toList()
                )
                .build();
        repo.save(criterion);
        return criterion;
    }
    public Criterion findCriterion(UUID criterionId) {
        Optional<Criterion> optionalCriterion;
        optionalCriterion = repo.findById(criterionId);

        if (optionalCriterion.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Criterion not found with id: " + criterionId);
        }
        return optionalCriterion.get();
    }
    public Criterion findCriterionByName(String name){
        return repo.findByName(name);
    }
    public Criterion updateCriterion(Criterion criterion,CriterionCreationRequest request){
        String newName = request.getName();
        if (newName != null && !newName.isBlank() && !newName.equals(criterion.getName())) {
            criterion.setName(newName);
        }

        String newDescription = request.getDescription();
        if (newDescription != null && !newDescription.equals(criterion.getDescription())) {
            criterion.setDescription(newDescription);
        }

        ScaleType newScaleType = request.getScaleType();
        if (newScaleType != null && !newScaleType.equals(criterion.getScaleType())) {
            criterion.setScaleType(newScaleType);
        }
        repo.save(criterion);
        return criterion;
    }

    public void deleteCriterion(Criterion criterion){
        repo.delete(criterion);
    }
}
