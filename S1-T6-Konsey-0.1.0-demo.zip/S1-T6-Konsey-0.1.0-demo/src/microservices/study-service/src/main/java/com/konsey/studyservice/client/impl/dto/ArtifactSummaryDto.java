package com.konsey.studyservice.client.impl.dto;

import java.util.UUID;

public record ArtifactSummaryDto(
        UUID id,
        String title
) {}
