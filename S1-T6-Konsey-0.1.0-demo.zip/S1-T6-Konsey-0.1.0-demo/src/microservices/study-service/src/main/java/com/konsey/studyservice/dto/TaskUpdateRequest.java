package com.konsey.studyservice.dto;

import com.konsey.studyservice.entity.ViewType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

import java.util.List;
import java.util.UUID;

public record TaskUpdateRequest(
        @NotBlank String name,
        String instructions,
        @NotNull ViewType viewType,
        @NotNull boolean isBlinded,
        @NotEmpty List<UUID> artifacts,
        @NotEmpty List<CriterionUpdateRequest> criteria
) {}
