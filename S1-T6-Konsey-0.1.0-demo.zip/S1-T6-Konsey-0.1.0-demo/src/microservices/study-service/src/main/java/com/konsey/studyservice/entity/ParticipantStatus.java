package com.konsey.studyservice.entity;


public enum ParticipantStatus {
    PENDING,
    IN_PROGRESS,
    COMPLETED;
}
