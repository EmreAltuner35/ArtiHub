package com.konsey.studyservice.service;

import com.konsey.studyservice.dto.AnnotationDto;
import com.konsey.studyservice.entity.Annotation;
import com.konsey.studyservice.repository.AnnotationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.ZonedDateTime;
import java.util.List;
import java.util.UUID;


@Service
public class AnnotationService {


    private final AnnotationRepository annotationRepository;

    @Autowired
    public AnnotationService(AnnotationRepository annotationRepository) {
        this.annotationRepository = annotationRepository;
    }


    public Annotation saveAnnotation(AnnotationDto dto) {

        Annotation annotation = new Annotation();
        annotation.setTaskId(dto.getTaskId());
        annotation.setArtifactId(dto.getArtifactId());
        annotation.setParticipantId(dto.getParticipantId());
        annotation.setHighlighted(dto.isHighlighted());
        annotation.setAnnotationText(dto.getAnnotationText());
        annotation.setTimestamp(ZonedDateTime.now());

        boolean isText = dto.getStartIndex() != null && dto.getEndIndex() != null;
        boolean isImage = dto.getX() != null && dto.getY() != null;

        if (isText) {
            annotation.setStartIndex(dto.getStartIndex());
            annotation.setEndIndex(dto.getEndIndex());
        }

        if (isImage) {
            annotation.setX(dto.getX());
            annotation.setY(dto.getY());
            annotation.setWidth(dto.getWidth());
            annotation.setHeight(dto.getHeight());
        }

        return annotationRepository.save(annotation);
    }

    public boolean deleteAnnotation(UUID annotationId) {

        if (!annotationRepository.existsById(annotationId)) {
            return false;
        }

        annotationRepository.deleteById(annotationId);
        return true;
    }


    public List<Annotation> findByTaskIdAndArtifactIdAndParticipantId(UUID taskId, UUID artifactId, UUID participantId) {

        return annotationRepository.findByTaskIdAndArtifactIdAndParticipantId(taskId, artifactId, participantId);
    }
}

