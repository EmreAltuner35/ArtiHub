package com.konsey.studyservice.dto;

import com.konsey.studyservice.entity.ScaleType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

import java.util.List;

public record CriterionUpdateRequest(
        @NotBlank String name,
        String description,
        @NotNull ScaleType scaleType,
        @NotEmpty List<String> options
) {}
