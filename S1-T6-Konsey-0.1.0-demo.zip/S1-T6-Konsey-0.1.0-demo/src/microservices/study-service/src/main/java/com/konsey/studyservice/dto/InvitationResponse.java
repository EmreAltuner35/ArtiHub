package com.konsey.studyservice.dto;

import com.konsey.studyservice.entity.Invitation;
import com.konsey.studyservice.entity.InvitationStatus;
import java.time.LocalDateTime;
import java.util.UUID;

public class InvitationResponse {
    private UUID invitationId;
    private UUID studyId;
    private UUID userId;
    private String userDisplayName;
    private UUID quizId;
    private InvitationStatus status;
    private Integer quizScore;
    private Integer quizMaxScore;
    private String quizAnswers;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    public InvitationResponse(Invitation invitation, String userDisplayName) {
        this.invitationId = invitation.getInvitationId();
        this.studyId = invitation.getStudy().getStudyId();
        this.userId = invitation.getUserId();
        this.userDisplayName = userDisplayName;
        this.quizId = invitation.getQuizId();
        this.status = invitation.getStatus();
        this.quizScore = invitation.getQuizScore();
        this.quizMaxScore = invitation.getQuizMaxScore();
        this.quizAnswers = invitation.getQuizAnswers();
        this.createdAt = invitation.getCreatedAt();
        this.updatedAt = invitation.getUpdatedAt();
    }

    public UUID getInvitationId() { return invitationId; }
    public UUID getStudyId() { return studyId; }
    public UUID getUserId() { return userId; }
    public String getUserDisplayName() { return userDisplayName; }
    public UUID getQuizId() { return quizId; }
    public InvitationStatus getStatus() { return status; }
    public Integer getQuizScore() { return quizScore; }
    public Integer getQuizMaxScore() { return quizMaxScore; }
    public String getQuizAnswers() { return quizAnswers; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public LocalDateTime getUpdatedAt() { return updatedAt; }
}
