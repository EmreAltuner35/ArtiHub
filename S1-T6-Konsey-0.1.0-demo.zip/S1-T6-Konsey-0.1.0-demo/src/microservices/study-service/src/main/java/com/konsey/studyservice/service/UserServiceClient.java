package com.konsey.studyservice.service;

import com.konsey.studyservice.dto.UserResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class UserServiceClient {

    @Autowired
    private RestTemplate restTemplate;

    private static final String USER_SERVICE_URL =
            "http://user-service:8080/api/users/batch";

    public List<UserResponse> getUsersByIds(List<UUID> ids) {
        HttpEntity<List<UUID>> request = new HttpEntity<>(ids);

        ResponseEntity<List<UserResponse>> response =
                restTemplate.exchange(
                        USER_SERVICE_URL,
                        HttpMethod.POST,
                        request,
                        new ParameterizedTypeReference<>() {}
                );

        return response.getBody();
    }
}


