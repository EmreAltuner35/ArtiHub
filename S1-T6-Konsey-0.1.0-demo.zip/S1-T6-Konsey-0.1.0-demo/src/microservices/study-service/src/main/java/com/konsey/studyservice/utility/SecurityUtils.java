package com.konsey.studyservice.utility;

import lombok.experimental.UtilityClass;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;

import java.util.UUID;

@UtilityClass
public class SecurityUtils {
    public UUID userId() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if(!(auth instanceof JwtAuthenticationToken token))
            return null;
        Jwt jwt = token.getToken();
        String id = jwt.getSubject();
        return id == null ? null : UUID.fromString(id);
    }

    public String userRole() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if(!(auth instanceof JwtAuthenticationToken token))
            return null;
        return token.getToken().getClaimAsString("role");
    }
}
