package com.konsey.studyservice.dto;

import java.util.List;
import java.util.UUID;

public class ArtifactAdditionRequest {
    private List<UUID> artifacts;
    public ArtifactAdditionRequest(List<UUID> artifacts){this.artifacts = artifacts;}

    public List<UUID> getArtifacts() {
        return this.artifacts;
    }
    public  ArtifactAdditionRequest(){}
}
