package com.konsey.studyservice.repository;
import com.konsey.studyservice.entity.Study;
import com.konsey.studyservice.entity.StudyStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;


import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

public interface StudyRepository extends JpaRepository<Study, UUID> {
    List<Study> findByResearcherId(UUID researcherId);
    List<Study> findByStatusAndEndDateBefore(StudyStatus status, LocalDate currentTime);
    @Query("SELECT s FROM Study s JOIN s.participants p WHERE p = :participantId")
    List<Study> findByParticipantIdEnrolled(@Param("participantId") UUID participantId);

    List<Study> findAll();

}