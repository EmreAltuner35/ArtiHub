package com.konsey.studyservice.dto;

import com.konsey.studyservice.entity.ScaleType;
import jakarta.validation.constraints.*;

import java.util.List;


public class CriterionCreationRequest {


    @NotBlank(message = "Criterion name cannot be empty")
    private String name;

    private String description;

    private ScaleType scaleType;

    private List<String> options;


    public CriterionCreationRequest() {
    }
    public CriterionCreationRequest(String name, String description, ScaleType scaleType, List<String> options) {
        this.name = name;
        this.description = description;
        this.scaleType = scaleType;
        this.options = options;
    }


    // --- Getters and Setters for other fields ---

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    public String getDescription() {return description;}

    /**
     * Sets the description for the criterion.
     * @param description The description.
     */
    public void setDescription(String description) {
        this.description = description;
    }

    public ScaleType getScaleType() {
        return scaleType;
    }

    public void setScaleType(ScaleType scaleType) {
        this.scaleType = scaleType;
    }

    public List<String> getOptions() {
        return options;
    }

    public void setOptions(List<String> options) {
        this.options = options;
    }
}
