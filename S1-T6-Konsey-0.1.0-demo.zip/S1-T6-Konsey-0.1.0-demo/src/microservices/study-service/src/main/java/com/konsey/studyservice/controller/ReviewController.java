package com.konsey.studyservice.controller;

import com.konsey.studyservice.dto.*;
import com.konsey.studyservice.entity.Submission;
import com.konsey.studyservice.service.ReviewService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/studies/review")
public class ReviewController {

    private final ReviewService reviewService;

    @Autowired
    public ReviewController(ReviewService reviewService) {
        this.reviewService = reviewService;
    }


    @GetMapping("/{studyId}/details/{participantId}")
    public ResponseEntity<List<ReviewDto>> getParticipantReviewDetails(
            @PathVariable UUID studyId,
            @PathVariable UUID participantId) {

        List<ReviewDto> details = reviewService.getParticipantReviewDetails(studyId, participantId);
        return ResponseEntity.ok(details);
    }

    @PostMapping("/submit")
    public ResponseEntity<Void> submitReviewDecision(@RequestBody ReviewDecisionRequest request) {

        if (request.getStudyId() == null ||
                request.getTaskId() == null ||
                request.getParticipantId() == null ||
                request.getReviewStatus() == null) {
            return ResponseEntity.badRequest().build();
        }

        reviewService.submitReviewDecision(
                request.getStudyId(),
                request.getTaskId(),
                request.getParticipantId(),
                request.getReviewStatus(),
                request.getReviewComment()
        );

        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @PostMapping("/submit-final")
    public ResponseEntity<Void> submitFinalComment(@RequestBody FinalizeReviewDto request) {
        reviewService.submitFinalComment(request.getComment(), request.getStudyId(), request.getParticipantId());

        return ResponseEntity.status(HttpStatus.OK).build();
    }

    @GetMapping("/{studyId}/participant/{participantId}/decisions")
    public ResponseEntity<List<ReviewDecisionDto>> getParticipantReviewDecisions(
            @PathVariable UUID studyId,
            @PathVariable UUID participantId
    ) {
        return ResponseEntity.ok(
                reviewService.getParticipantReviewDecisions(studyId, participantId)
        );
    }

}
