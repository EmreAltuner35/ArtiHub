package com.konsey.studyservice.service;

import com.konsey.studyservice.dto.InvitationCreationRequest;
import com.konsey.studyservice.entity.Invitation;
import com.konsey.studyservice.entity.InvitationStatus;
import com.konsey.studyservice.entity.Study;
import com.konsey.studyservice.repository.InvitationRepository;
import com.konsey.studyservice.repository.StudyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.server.Session;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Properties;
import java.util.UUID;
import jakarta.mail.*;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;

@Service
@org.springframework.transaction.annotation.Transactional
public class InvitationService {

    @Autowired
    private InvitationRepository invitationRepository;

    @Autowired
    private StudyService studyService;

    @Autowired
    private StudyRepository studyRepository;

    @Autowired
    private EmailService emailService;

    public Invitation createInvitation(UUID studyId, InvitationCreationRequest request) {
        Study study = studyRepository.findById(studyId)
                .orElseThrow(() -> new RuntimeException("Study not found"));

        Invitation invitation = new Invitation(
                study,
                request.getUserId(),
                request.getQuizId()
        );
        String subject = "Study Invitation";
        String body = "You were invited to the study named " + study.getTitle() + ".";
        emailService.sendInvitation(request.getEmail(),body,subject);
        return invitationRepository.save(invitation);
    }

    public List<com.konsey.studyservice.dto.InvitationResponse> getInvitationsByStudy(UUID studyId) {
        List<Invitation> invitations = invitationRepository.findByStudy_StudyId(studyId);
        if (invitations.isEmpty()) {
            return List.of();
        }

        List<UUID> userIds = invitations.stream()
                .map(Invitation::getUserId)
                .distinct()
                .toList();

        org.springframework.web.client.RestTemplate restTemplate = new org.springframework.web.client.RestTemplate();
        // Use service name if in docker, or localhost if local.
        // A robust way is to use an environment variable or property.
        // For now, I'll try the service name 'user-service' which works in docker-compose.
        // If it fails locally, the user might need to adjust.
        String userServiceUrl = "http://user-service:8080/api/users/batch";
        
        // Check if running locally (hacky check, but useful if user is running locally)
        // Actually, let's just use the service name. If it fails, we can fallback or user can configure.
        // Better: try/catch the call.
        
        java.util.Map<UUID, com.konsey.studyservice.dto.UserResponse> userMap = new java.util.HashMap<>();
        try {
            com.konsey.studyservice.dto.UserResponse[] userArray = restTemplate.postForObject(userServiceUrl, userIds, com.konsey.studyservice.dto.UserResponse[].class);
            if (userArray != null) {
                for (com.konsey.studyservice.dto.UserResponse u : userArray) {
                    userMap.put(u.getId(), u);
                }
            }
        } catch (Exception e) {
            System.err.println("Failed to fetch users from user-service: " + e.getMessage());
            // Fallback: try localhost if user-service failed (maybe running locally)
             try {
                userServiceUrl = "http://localhost:8080/api/users/batch";
                com.konsey.studyservice.dto.UserResponse[] userArray = restTemplate.postForObject(userServiceUrl, userIds, com.konsey.studyservice.dto.UserResponse[].class);
                if (userArray != null) {
                    for (com.konsey.studyservice.dto.UserResponse u : userArray) {
                        userMap.put(u.getId(), u);
                    }
                }
            } catch (Exception ex) {
                 System.err.println("Failed to fetch users from localhost fallback: " + ex.getMessage());
            }
        }

        return invitations.stream()
                .map(inv -> {
                    com.konsey.studyservice.dto.UserResponse user = userMap.get(inv.getUserId());
                    String displayName = user != null ? user.getDisplayName() : "Unknown User";
                    return new com.konsey.studyservice.dto.InvitationResponse(inv, displayName);
                })
                .toList();
    }

    public List<Invitation> getInvitationsForUser(UUID userId) {
        return invitationRepository.findByUserId(userId);
    }

    public Invitation submitQuiz(UUID invitationId, com.konsey.studyservice.dto.QuizSubmissionRequest request) {
        Invitation invitation = invitationRepository.findById(invitationId)
                .orElseThrow(() -> new RuntimeException("Invitation not found"));
        
        invitation.setQuizScore(request.getAutoScore());
        invitation.setQuizMaxScore(request.getMaxScore());
        invitation.setQuizAnswers(request.getAnswers());
        invitation.setStatus(InvitationStatus.QUIZ_COMPLETED);
        
        return invitationRepository.save(invitation);
    }

    public Invitation updateQuizScore(UUID invitationId, int score) {
        Invitation invitation = invitationRepository.findById(invitationId)
                .orElseThrow(() -> new RuntimeException("Invitation not found"));
        invitation.setQuizScore(score);
        return invitationRepository.save(invitation);
    }

    public Invitation updateInvitationStatus(UUID invitationId, InvitationStatus status) {
        Invitation invitation = invitationRepository.findById(invitationId)
                .orElseThrow(() -> new RuntimeException("Invitation not found"));
        invitation.setStatus(status);

        if (status == InvitationStatus.ACCEPTED) {
            studyService.addParticipant(invitation.getStudy().getStudyId(), invitation.getUserId());
        }

        return invitationRepository.save(invitation);
    }
}
