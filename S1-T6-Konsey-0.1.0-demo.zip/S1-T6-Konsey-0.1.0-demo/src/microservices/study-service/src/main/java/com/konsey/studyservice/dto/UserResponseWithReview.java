package com.konsey.studyservice.dto;

import java.util.UUID;

public class UserResponseWithReview {
    private UUID id;
    private String displayName;
    private String email;
    private boolean reviewOver;

    public UserResponseWithReview(UserResponse user, boolean reviewOver) {
        this.id = user.getId();
        this.displayName = user.getDisplayName();
        this.email = user.getEmail();
        this.reviewOver = reviewOver;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getEmail() {
        return email;
    }

    public UUID getId() {
        return id;
    }

    public boolean isReviewOver() {
        return reviewOver;
    }

    public void setReviewOver(boolean reviewOver) {
        this.reviewOver = reviewOver;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }
}

