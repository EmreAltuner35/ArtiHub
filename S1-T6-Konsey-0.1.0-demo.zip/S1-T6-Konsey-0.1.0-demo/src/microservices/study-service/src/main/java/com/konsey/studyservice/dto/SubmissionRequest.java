package com.konsey.studyservice.dto;

import com.konsey.studyservice.entity.CriteriaResponse;
import java.util.List;
import java.util.UUID;

public class SubmissionRequest {

    private UUID studyId;
    private UUID taskId;
    private UUID participantId;

    // List of CriteriaResponse objects (full details are sent)
    private List<CriteriaResponse> criteriaResponses;

    private List<UUID> linkedAnnotationIds;
    private Integer submissionTime;

    public SubmissionRequest() {}

    // Getters and Setters
    public UUID getStudyId() { return studyId; }
    public void setStudyId(UUID studyId) { this.studyId = studyId; }
    public UUID getTaskId() { return taskId; }
    public void setTaskId(UUID taskId) { this.taskId = taskId; }
    public UUID getParticipantId() { return participantId; }
    public void setParticipantId(UUID participantId) { this.participantId = participantId; }
    public List<CriteriaResponse> getCriteriaResponses() { return criteriaResponses; }
    public void setCriteriaResponses(List<CriteriaResponse> criteriaResponses) { this.criteriaResponses = criteriaResponses; }
    public List<UUID> getLinkedAnnotationIds() { return linkedAnnotationIds; }
    public void setLinkedAnnotationIds(List<UUID> linkedAnnotationIds) { this.linkedAnnotationIds = linkedAnnotationIds; }

    public void setSubmissionTime(Integer submissionTime) {
        this.submissionTime = submissionTime;
    }

    public Integer getSubmissionTime() {
        return submissionTime;
    }
}