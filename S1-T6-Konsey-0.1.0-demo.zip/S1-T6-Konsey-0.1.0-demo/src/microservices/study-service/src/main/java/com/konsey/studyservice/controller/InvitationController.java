package com.konsey.studyservice.controller;

import com.konsey.studyservice.dto.InvitationCreationRequest;
import com.konsey.studyservice.entity.Invitation;
import com.konsey.studyservice.entity.InvitationStatus;
import com.konsey.studyservice.service.InvitationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/studies/{studyId}/invitations")
@CrossOrigin
public class InvitationController {

    @Autowired
    private InvitationService invitationService;

    @PostMapping
    public ResponseEntity<Invitation> createInvitation(
            @PathVariable UUID studyId,
            @RequestBody InvitationCreationRequest request) {
        return ResponseEntity.ok(invitationService.createInvitation(studyId, request));
    }

    @GetMapping
    public ResponseEntity<List<com.konsey.studyservice.dto.InvitationResponse>> getInvitations(@PathVariable UUID studyId) {
        return ResponseEntity.ok(invitationService.getInvitationsByStudy(studyId));
    }

    @PutMapping("/{invitationId}")
    public ResponseEntity<Invitation> updateInvitationStatus(
            @PathVariable UUID studyId,
            @PathVariable UUID invitationId,
            @RequestParam InvitationStatus status) {
        return ResponseEntity.ok(invitationService.updateInvitationStatus(invitationId, status));
    }

    @PutMapping("/{invitationId}/score")
    public ResponseEntity<Invitation> updateQuizScore(
            @PathVariable UUID studyId,
            @PathVariable UUID invitationId,
            @RequestParam int score) {
        return ResponseEntity.ok(invitationService.updateQuizScore(invitationId, score));
    }
}
