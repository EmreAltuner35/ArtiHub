package com.konsey.studyservice.repository;

import com.konsey.studyservice.entity.Annotation;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface AnnotationRepository extends JpaRepository<Annotation, UUID> {

    List<Annotation> findByTaskIdAndArtifactIdAndParticipantId(UUID studyId, UUID artifactId, UUID participantId);
}
