package com.konsey.studyservice.controller;
import com.konsey.studyservice.dto.CriterionCreationRequest;
import com.konsey.studyservice.entity.Criterion;
import com.konsey.studyservice.entity.Study;
import com.konsey.studyservice.entity.Task;
import com.konsey.studyservice.service.CriterionService;
import com.konsey.studyservice.service.TaskService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("api/studies")
public class CriterionController {
    @Autowired
    private CriterionService criterionService;
    @Autowired
    private TaskService taskService;
    @GetMapping("/{studyId}/criteria")
    public ResponseEntity<List<Criterion>> getStudyCriteria(@PathVariable UUID studyId) {
        return ResponseEntity.ok(criterionService.getCriteriaByStudyId(studyId));
    }

    @PostMapping("/{studyId}/tasks/{taskId}/criteria")
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<Criterion> createCriterion(@PathVariable UUID studyId, @PathVariable UUID taskId,@Valid @RequestBody CriterionCreationRequest request){

        Task task = taskService.findTask(taskId);
        return ResponseEntity.ok(criterionService.createCriterion(request,task));
    }



    @PutMapping("/{studyId}/tasks/{taskId}/criteria/{criterionId}")
    public ResponseEntity<Criterion> updateCriterion(@PathVariable UUID studyId,
                                                     @PathVariable UUID taskId,
                                                     @PathVariable UUID criterionId,
                                                     @Valid @RequestBody CriterionCreationRequest request){
        Criterion criterion = criterionService.findCriterion(criterionId);
        return ResponseEntity.ok(criterionService.updateCriterion(criterion,request));
    }

    @DeleteMapping("/{studyId}/tasks/{taskId}/criteria/{criterionId}")
    public ResponseEntity<?> deleteCriterion(@PathVariable UUID studyId,
                                             @PathVariable UUID taskId,
                                             @PathVariable UUID criterionId){
        Criterion criterion = criterionService.findCriterion(criterionId);
        try {
            criterionService.deleteCriterion(criterion);
            return ResponseEntity.noContent().build();
        }catch (Exception e){
            return ResponseEntity.notFound().build();
        }
    }
}
