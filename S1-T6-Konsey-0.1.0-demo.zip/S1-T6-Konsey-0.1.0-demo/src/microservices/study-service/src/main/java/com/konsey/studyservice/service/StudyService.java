package com.konsey.studyservice.service;
import com.konsey.studyservice.client.ArtifactClient;
import com.konsey.studyservice.dto.*;
import com.konsey.studyservice.entity.*;

import com.konsey.studyservice.repository.ReviewDecisionRepository;
import com.konsey.studyservice.repository.TaskRepository;
import com.konsey.studyservice.utility.SecurityUtils;
import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.*;

import com.konsey.studyservice.repository.StudyRepository;

@Service
@EnableScheduling
public class StudyService {
    @Autowired
    private StudyRepository repo;
    @Autowired
    private TaskRepository taskRepo;
    @Autowired
    private TaskService taskService;

    @Autowired
    private ArtifactClient artifactClient;

    @Autowired
    private SubmissionService submissionService;

    @Autowired
    private UserServiceClient userServiceClient;

    @Autowired
    private ReviewDecisionRepository reviewDecisionRepository;

    @Transactional
    public Study createBulkStudy(
            BulkStudyCreationRequest request,
            MultipartFile metaFile
    ) throws IOException {
        Study study = createStudy(new StudyCreationRequest(
                request.title(),
                request.description(),
                request.startDate(),
                request.endDate()
        ));

        Map<String, UUID> artifactMap = artifactClient.findArtifactIdsByTitleInFolder(request.artifactFolder());

        readBulkStudyCreationCSVFile(metaFile, study, artifactMap);

        return study;
    }

    public Study createStudy(StudyCreationRequest request){
        if (request.getStartDate() != null && request.getEndDate() != null) {

            // Check if End Date is before Start Date
            if (request.getEndDate().isBefore(request.getStartDate())) {
                throw new IllegalArgumentException("Select logical dates: End date cannot be before start date.");
            }

            // Optional: Check if Start Date is in the past
            if (request.getStartDate().isBefore(LocalDate.now())) {
                throw new IllegalArgumentException("Select logical dates: Start date cannot be in the past.");
            }
        }
            Study study = new Study(SecurityUtils.userId(), request.getTitle(), request.getDescription(), request.getStartDate(), request.getEndDate());
            repo.save(study);
            return study;
    }

    public Study findStudy(UUID studyId){
        Optional<Study> optionalStudy;
        optionalStudy = repo.findById(studyId);
        if(optionalStudy.isEmpty()){
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Study not found with id: " + studyId);
        }
        return optionalStudy.get();
    }

    public List<Study> displayStudies(){
        List<Study> result;
        result = repo.findByResearcherId(SecurityUtils.userId());
        return result;
    }

    public Study updateStudy(Study study, StudyUpdateRequest request){
        if(request.getTitle() != null && !request.getTitle().isBlank()){
            study.setTitle(request.getTitle());
        }
        if(request.getDescription() != null && !request.getDescription().isBlank()){
            study.setDescription(request.getDescription());
        }
        if(request.getStatus() != null){
            study.setStatus(request.getStatus());
        }
        if(request.getEndDate() != null && request.getEndDate() != study.getEndDate()) {
            study.setEndDate(request.getEndDate());
        }
        if(request.getStartDate() != null && request.getStartDate() != study.getStartDate()){
            study.setStartDate(request.getStartDate());
        }
        return repo.save(study);
    }

    public void deleteStudy(Study study){
        repo.delete(study);
    }

    @EventListener(ApplicationReadyEvent.class)
    @Transactional
    public void markExpiredStudies() {
        // 1. Find all active studies where endDate is in the past
        List<Study> expiredStudies = repo.findByStatusAndEndDateBefore(StudyStatus.ACTIVE, LocalDate.now());

        // 2. Update them
        for (Study study : expiredStudies) {
            study.updateStatusIfExpired(); // Calls the method inside your Entity
        }

        // 3. Save changes (JPA does this automatically in a Transactional method)
        repo.saveAll(expiredStudies);
    }
    public List<Study> getEnrolledStudies(UUID participantId) {
        return repo.findByParticipantIdEnrolled(participantId);
    }

    public void addParticipant(UUID studyId, UUID participantId) {
        Study study = findStudy(studyId);

        if (study.getParticipants().contains(participantId)) {
            return;
        }

        study.getParticipants().add(participantId);
        repo.save(study);
    }
    public Map<UUID, TaskCardDto> getTaskCardAnalytics(UUID studyId){
         Map<UUID, TaskCardDto> result = new HashMap<>();
         Study study = findStudy(studyId);
         List<Task> tasks = study.getTasks();
         for(Task task:tasks){
             int submissionCount = submissionService.getSubmissionCountByTaskId(task.getTaskId());
             int total = study.getParticipants().size();
             UUID taskId = task.getTaskId();
             result.put(taskId,new TaskCardDto(submissionCount,total));
         }
         return result;
    }


    private void readBulkStudyCreationCSVFile(
            MultipartFile metaFile,
            Study study,
            Map<String, UUID> artifactMap
    ) throws IOException {

        try(
                BufferedReader reader = new BufferedReader(new InputStreamReader(
                        metaFile.getInputStream(),
                        StandardCharsets.UTF_8)
                )
        ) {
            String taskCountStr = reader.readLine();
            if(taskCountStr == null || taskCountStr.isBlank())
                throw new IllegalArgumentException("CSV is empty");

            int taskCount;
            try {
                taskCount = Integer.parseInt(taskCountStr);
            } catch (NumberFormatException ex) {
                throw new IllegalArgumentException("First line does not represent task count");
            }

            for(int i = 0; i < taskCount; i++) {
                String headerLine = reader.readLine();
                if(headerLine == null || headerLine.isBlank())
                    throw new IllegalArgumentException("Unexpected end of metadata CSV at task: " + (i + 1));

                String[] headerParts = headerLine.split(",", -1);
                if(headerParts.length < 5)
                    throw new IllegalArgumentException("Invalid meta line (expected 5 columns): " + headerLine);

                String taskName = headerParts[0].trim();
                String taskInstructions = headerParts[1].trim();
                boolean isTaskBlinded = Boolean.parseBoolean(headerParts[2]);
                ViewType taskViewType = ViewType.valueOf(headerParts[3].trim());
                String criteriaCountStr = headerParts[4].trim();

                if(taskName.isEmpty())
                    throw new IllegalArgumentException("Task name cannot be empty");

                int criteriaCount;
                try {
                    criteriaCount = Integer.parseInt(criteriaCountStr);
                } catch (NumberFormatException ex) {
                    throw new IllegalArgumentException("Invalid criteria count for task " + taskName, ex);
                }

                int artifactCount = taskViewType.ordinal() + 1;

                List<UUID> artifactIds = new ArrayList<>(artifactCount);
                for(int j = 0; j < artifactCount; j++) {
                    String artifactName = reader.readLine().trim();
                    if(artifactName.isEmpty())
                        throw new IllegalArgumentException(
                                "Unexpected end of metadata CSV at task " + (i + 1) + " artifact " + (j + 1)
                        );

                    UUID artifactId = artifactMap.get(artifactName);
                    if(artifactId == null)
                        throw new IllegalArgumentException(
                                "Wrong artifact name \"" + artifactName + "\" on task " + taskName
                        );

                    artifactIds.add(artifactId);
                }

                List<CriterionCreationRequest> criterionRequests = new ArrayList<>(criteriaCount);
                for(int j = 0; j < criteriaCount; j++) {
                    String criterionLine = reader.readLine();
                    if(criterionLine == null || criterionLine.isBlank())
                        throw new IllegalArgumentException(
                                "Unexpected end of metadata CSV at task " + (i + 1) + " artifact " + (j + 1)
                        );

                    String[] criterionParts = criterionLine.split(",");

                    String criterionName = criterionParts[0].trim();
                    String criterionDescription = criterionParts[1].trim();
                    ScaleType criterionScaleType = ScaleType.valueOf(criterionParts[2].trim());
                    String optionCountStr = criterionParts[3].trim();

                    int optionCount;
                    try {
                        optionCount = Integer.parseInt(optionCountStr);
                    } catch (NumberFormatException ex) {
                        throw new IllegalArgumentException(
                                "Invalid option count for task " + (i + 1) + " criterion " + (j + 1)
                        );
                    }

                    List<String> optionList = new ArrayList<>(optionCount);
                    for(int k = 0; k < optionCount; k++) {
                        String option = reader.readLine().trim();
                        if(option.isEmpty())
                            throw new IllegalArgumentException(
                                    "Empty option name in task " + (i + 1) + " criterion " + (j + 1) +
                                            " option " + (k + 1)
                            );
                        optionList.add(option);
                    }

                    criterionRequests.add(new CriterionCreationRequest(
                            criterionName,
                            criterionDescription,
                            criterionScaleType,
                            optionList
                    ));
                }

                taskService.createTask(
                        TaskCreationRequest.builder()
                                .name(taskName)
                                .instructions(taskInstructions)
                                .isBlinded(isTaskBlinded)
                                .viewType(taskViewType)
                                .artifacts(artifactIds)
                                .criteria(criterionRequests)
                                .build(),
                        study
                );
            }
        }
    }
    public List<Study> getAllStudies() {
        return repo.findAll();
    }

    // Reviewer management methods
    public void addReviewer(UUID studyId, UUID reviewerId) {
        Study study = findStudy(studyId);
        if (study.getReviewers().contains(reviewerId)) {
            return;
        }
        study.getReviewers().add(reviewerId);
        repo.save(study);
    }

    public void removeReviewer(UUID studyId, UUID reviewerId) {
        Study study = findStudy(studyId);
        study.getReviewers().remove(reviewerId);
        repo.save(study);
    }

    public List<UUID> getReviewers(UUID studyId) {
        Study study = findStudy(studyId);
        return study.getReviewers();
    }

    public List<Study> getStudiesForReviewer(UUID reviewerId) {
        return repo.findAll().stream()
                .filter(study -> study.getReviewers().contains(reviewerId))
                .toList();
    }

    public Study getStudyById(UUID studyId) {
        return repo.findById(studyId)
                .orElseThrow(() -> new EntityNotFoundException("Study not found"));
    }

    public List<UserResponseWithReview> getStudyParticipantsWithReviewStatus(UUID studyId) {
        Study study = repo.findById(studyId)
                .orElseThrow(() -> new RuntimeException("Study not found: " + studyId));

        List<UUID> participantIds = study.getParticipants();
        if (participantIds == null || participantIds.isEmpty()) {
            return List.of();
        }

        // Fetch user details
        List<UserResponse> users = userServiceClient.getUsersByIds(participantIds);

        // Map to response with reviewOver
        return users.stream()
                .map(user -> {
                    List<ReviewDecision> decisions =
                            reviewDecisionRepository.findByParticipantIdAndStudyId(user.getId(), studyId);

                    boolean reviewOver = !decisions.isEmpty() && Boolean.TRUE.equals(decisions.get(0).isReviewOver());

                    return new UserResponseWithReview(user, reviewOver);
                })
                .toList();

    }
}
