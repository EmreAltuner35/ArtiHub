package com.konsey.studyservice.dto;

public class QuizSubmissionRequest {
    private Integer autoScore;
    private Integer maxScore;
    private String answers; // JSON string

    public QuizSubmissionRequest() {}

    public QuizSubmissionRequest(Integer autoScore, Integer maxScore, String answers) {
        this.autoScore = autoScore;
        this.maxScore = maxScore;
        this.answers = answers;
    }

    public Integer getAutoScore() {
        return autoScore;
    }

    public void setAutoScore(Integer autoScore) {
        this.autoScore = autoScore;
    }

    public Integer getMaxScore() {
        return maxScore;
    }

    public void setMaxScore(Integer maxScore) {
        this.maxScore = maxScore;
    }

    public String getAnswers() {
        return answers;
    }

    public void setAnswers(String answers) {
        this.answers = answers;
    }
}
