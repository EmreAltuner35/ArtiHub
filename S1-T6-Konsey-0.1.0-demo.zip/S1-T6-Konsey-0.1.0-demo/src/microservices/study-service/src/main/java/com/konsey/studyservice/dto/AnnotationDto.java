package com.konsey.studyservice.dto;

import java.time.ZonedDateTime;
import java.util.UUID;

public class AnnotationDto {

    private UUID taskId;
    private UUID artifactId;
    private UUID participantId;

    private boolean isHighlighted;

    // text-based
    private Integer startIndex;
    private Integer endIndex;

    // image-based
    private Integer x;
    private Integer y;
    private Integer width;
    private Integer height;

    private String annotationText;

    // Getters and Setters


    public UUID getTaskId() {
        return taskId;
    }

    public void setTaskId(UUID taskId) {
        this.taskId = taskId;
    }

    public UUID getArtifactId() {
        return artifactId;
    }

    public void setArtifactId(UUID artifactId) {
        this.artifactId = artifactId;
    }

    public UUID getParticipantId() {
        return participantId;
    }

    public void setParticipantId(UUID participantId) {
        this.participantId = participantId;
    }

    public boolean isHighlighted() {
        return isHighlighted;
    }

    public void setHighlighted(boolean highlighted) {
        isHighlighted = highlighted;
    }

    public Integer getStartIndex() {
        return startIndex;
    }

    public void setStartIndex(Integer startIndex) {
        this.startIndex = startIndex;
    }

    public Integer getEndIndex() {
        return endIndex;
    }

    public void setEndIndex(Integer endIndex) {
        this.endIndex = endIndex;
    }

    public String getAnnotationText() {
        return annotationText;
    }

    public void setAnnotationText(String annotationText) {
        this.annotationText = annotationText;
    }

    public Integer getX() {
        return x;
    }

    public Integer getY() {
        return y;
    }
    public Integer getHeight() {
        return height;
    }

    public Integer getWidth() {
        return width;
    }

    public void setX(Integer x) {
        this.x = x;
    }

    public void setY(Integer y) {
        this.y = y;
    }

    public void setHeight(Integer height) {
        this.height = height;
    }

    public void setWidth(Integer width) {
        this.width = width;
    }
}
