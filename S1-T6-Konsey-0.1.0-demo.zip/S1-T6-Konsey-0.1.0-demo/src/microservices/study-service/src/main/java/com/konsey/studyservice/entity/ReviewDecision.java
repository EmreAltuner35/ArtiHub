package com.konsey.studyservice.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "review_decisions")
public class ReviewDecision {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    @Column(name = "study_id", nullable = false)
    private UUID studyId;

    @Column(name = "task_id", nullable = false)
    private UUID taskId;

    @Column(name = "participant_id", nullable = false)
    private UUID participantId;

    // e.g., "APPROVED", "DENIED"
    @Column(name = "review_status", nullable = false)
    private String reviewStatus;

    // The comment/description entered by the reviewer
    @Column(name = "review_comment", columnDefinition = "TEXT", nullable = true)
    private String reviewComment;

    @Column(name = "review_date", nullable = false)
    private LocalDateTime reviewDate;

    @Column(name = "reviewer_id")
    private UUID reviewerId;

    @Column(name = "review_over", nullable = true)
    private Boolean reviewOver;

    public ReviewDecision() {
        this.reviewDate = LocalDateTime.now();
    }

    // Getters and Setters

    public UUID getId() { return id; }
    public void setId(UUID id) { this.id = id; }

    public UUID getStudyId() { return studyId; }
    public void setStudyId(UUID studyId) { this.studyId = studyId; }

    public UUID getTaskId() { return taskId; }
    public void setTaskId(UUID taskId) { this.taskId = taskId; }

    public UUID getParticipantId() { return participantId; }
    public void setParticipantId(UUID participantId) { this.participantId = participantId; }

    public String getReviewStatus() { return reviewStatus; }
    public void setReviewStatus(String reviewStatus) { this.reviewStatus = reviewStatus; }

    public String getReviewComment() { return reviewComment; }
    public void setReviewComment(String reviewComment) { this.reviewComment = reviewComment; }

    public LocalDateTime getReviewDate() { return reviewDate; }
    public void setReviewDate(LocalDateTime reviewDate) { this.reviewDate = reviewDate; }

    public UUID getReviewerId() {
        return reviewerId;
    }

    public void setReviewerId(UUID reviewerId) {
        this.reviewerId = reviewerId;
    }

    public void setReviewOver(Boolean reviewOver) {
        this.reviewOver = reviewOver;
    }

    public Boolean isReviewOver() {
        return reviewOver;
    }
}