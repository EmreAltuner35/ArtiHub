package com.konsey.studyservice.controller;

import com.konsey.studyservice.dto.ArtifactAdditionRequest;
import com.konsey.studyservice.dto.TaskAnalyticsDto;
import com.konsey.studyservice.dto.TaskCardDto;
import com.konsey.studyservice.dto.TaskCreationRequest;
import com.konsey.studyservice.dto.TaskUpdateRequest;
import com.konsey.studyservice.entity.Study;
import com.konsey.studyservice.entity.StudyStatus;
import com.konsey.studyservice.entity.Task;
import com.konsey.studyservice.service.StudyService;
import com.konsey.studyservice.service.TaskService;
import com.konsey.studyservice.service.SubmissionService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("api/studies")
public class TaskController {
    @Autowired
    private TaskService taskService;
    @Autowired
    private StudyService studyService;
    @Autowired
    private SubmissionService submissionService;

    @PostMapping("/{studyId}/tasks")
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<Task> createTask(@PathVariable UUID studyId,@Valid @RequestBody TaskCreationRequest request){
        Study study = studyService.findStudy(studyId);
        if(study.getStatus() != StudyStatus.DRAFT){
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }
        return ResponseEntity.ok(taskService.createTask(request,study));
    }

    @PutMapping("/{studyId}/tasks/{taskId}")
    public ResponseEntity<Task> updateTask(
            @PathVariable UUID studyId,
            @PathVariable UUID taskId,
            @RequestBody TaskUpdateRequest request
    ) {
        return ResponseEntity.ok(taskService.updateTask(request,taskId));
    }

    @DeleteMapping("/{studyId}/tasks/{taskId}")
    public ResponseEntity<?> deleteTask(@PathVariable UUID studyId, @PathVariable UUID taskId) {
        Task task = taskService.findTask(taskId);
        if(task.getStudy().getStatus() != StudyStatus.DRAFT){
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }
        try {
            taskService.deleteTask(task);
            return ResponseEntity.noContent().build();
        }
        catch (Exception e){
            return ResponseEntity.notFound().build();
        }
    }
    @PutMapping("/{studyId}/tasks/{taskId}/artifact-add")
    public Task addArtifact(@PathVariable UUID taskId,@RequestBody ArtifactAdditionRequest request){
        Task task = taskService.findTask(taskId);
        if(task.getStudy().getStatus() != StudyStatus.DRAFT){
            return task;
        }
            return taskService.addArtifacts(task,request);
    }

    @GetMapping("/{studyId}/tasks/analytics/{taskId}")
    public ResponseEntity<TaskAnalyticsDto> getTaskAnalytics(@PathVariable UUID taskId){
        Task task = taskService.findTask(taskId);
        return ResponseEntity.ok(taskService.getTaskAnalytics(task));
    }
    @GetMapping("/{studyId}/tasks")
    public ResponseEntity<List<Task>> getTasks(@PathVariable UUID studyId) {
        Study study = studyService.findStudy(studyId);
        return ResponseEntity.ok(taskService.getTasksByStudy(study));
    }

    @GetMapping("/{studyId}/tasks/{taskId}")
    public ResponseEntity<Task> getTask(@PathVariable UUID studyId, @PathVariable UUID taskId) {
        return ResponseEntity.ok(taskService.findTask(taskId));
    }


    @GetMapping("/{studyId}/tasks/unfinished/{participantId}")
    public ResponseEntity<List<Task>> getUnfinishedTasks(
            @PathVariable UUID studyId,
            @PathVariable UUID participantId)
    {
        Study study = studyService.findStudy(studyId);

        List<Task> unfinishedTasks = taskService.getUnfinishedTasksByStudyAndParticipant(study, participantId);

        return ResponseEntity.ok(unfinishedTasks);
    }

}
