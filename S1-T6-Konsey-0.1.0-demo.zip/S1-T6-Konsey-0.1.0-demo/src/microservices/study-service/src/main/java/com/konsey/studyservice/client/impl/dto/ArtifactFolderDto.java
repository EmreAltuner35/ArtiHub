package com.konsey.studyservice.client.impl.dto;

import java.util.List;
import java.util.UUID;

public record ArtifactFolderDto(
        UUID id,
        String name,
        List<ArtifactSummaryDto> artifacts
) {}