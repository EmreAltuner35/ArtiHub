package com.konsey.studyservice.service;
import lombok.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

    private final JavaMailSender mailSender;

    public EmailService(JavaMailSender mailSender) {
        this.mailSender = mailSender;
    }

    public void sendInvitation(String recipientEmail, String body,String subject) {
        SimpleMailMessage message = new SimpleMailMessage();
        // The sender address is set automatically by Spring from spring.mail.username
        message.setTo(recipientEmail);
        message.setSubject(subject);
        message.setText(body);
        mailSender.send(message);
    }
}
