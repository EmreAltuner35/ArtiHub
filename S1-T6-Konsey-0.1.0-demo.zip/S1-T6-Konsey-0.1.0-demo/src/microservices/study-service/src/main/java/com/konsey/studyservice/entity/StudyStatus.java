package com.konsey.studyservice.entity;

public enum StudyStatus {
    DRAFT,
    ACTIVE,
    COMPLETED
}
