package com.konsey.studyservice.controller;

import com.konsey.studyservice.dto.SubmissionRequest;
import com.konsey.studyservice.entity.Submission;
import com.konsey.studyservice.service.SubmissionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/studies/submissions")
public class SubmissionController {

    private final SubmissionService submissionService;

    @Autowired
    public SubmissionController(SubmissionService submissionService) {
        this.submissionService = submissionService;
    }

    @PostMapping
    public ResponseEntity<Submission> createSubmission(@RequestBody SubmissionRequest request) {
        if (request.getTaskId() == null || request.getParticipantId() == null) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }

        try {
            Submission newSubmission = submissionService.processSubmission(request);
            if(newSubmission == null) {
                return new ResponseEntity<>(HttpStatus.CONFLICT);
            }
            return new ResponseEntity<>(newSubmission, HttpStatus.CREATED);
        } catch (Exception e) {
            System.err.println("Error processing submission: " + e.getMessage());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}