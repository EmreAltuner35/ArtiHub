package com.konsey.studyservice.service;

import com.konsey.studyservice.dto.InvitationResponse;
import com.konsey.studyservice.dto.StudyAnalyticsDto;
import com.konsey.studyservice.entity.InvitationStatus;
import com.konsey.studyservice.entity.ParticipantStatus;
import com.konsey.studyservice.entity.Study;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
@Service
public class AnalyticsService {
    @Autowired
    private InvitationService invitationService;
    @Autowired
    private StudyService studyService;
    @Autowired
    private SubmissionService submissionService;
    public StudyAnalyticsDto getStudyAnalytics(UUID studyId){
        Study study = studyService.findStudy(studyId);
        List<InvitationResponse> invitations = invitationService.getInvitationsByStudy(studyId);
        Map<UUID, ParticipantStatus> participantStatusMap = new HashMap<>();
        for(InvitationResponse invitationResponse:invitations){
            UUID participantId = invitationResponse.getUserId();
            if(invitationResponse.getStatus() == InvitationStatus.PENDING || invitationResponse.getStatus() == InvitationStatus.QUIZ_COMPLETED){
                participantStatusMap.put(participantId,ParticipantStatus.PENDING);
            }
            else if(invitationResponse.getStatus() == InvitationStatus.ACCEPTED){
                int taskCount = study.getTasks().size();
                int submissionCount = submissionService.getSubmissionCountByStudyAndParticipantId(participantId,studyId);
                ParticipantStatus status;
                if(submissionCount == taskCount){
                    status = ParticipantStatus.COMPLETED;
                }
                else {
                    status = ParticipantStatus.IN_PROGRESS;
                }
                participantStatusMap.put(participantId,status);
            }
        }
        return new StudyAnalyticsDto(participantStatusMap,participantStatusMap.size());
    }
}
