package com.konsey.studyservice.dto;

import com.konsey.studyservice.entity.ViewType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Getter
@Setter
@Builder
public class TaskCreationRequest {

    private boolean isBlinded;

    private ViewType viewType;

    @Size(max = 400)
    private String instructions;

    @NotBlank
    private String name;

    @Builder.Default
    private List<UUID> artifacts = new ArrayList<>();

    @Builder.Default
    private List<CriterionCreationRequest> criteria = new ArrayList<CriterionCreationRequest>();
}
