package com.konsey.studyservice.client;

import java.util.Map;
import java.util.UUID;

public interface ArtifactClient {
    Map<String, UUID> findArtifactIdsByTitleInFolder(UUID folderId);
}
