package com.konsey.aiquizservice.controller;

import com.konsey.aiquizservice.dto.JobStatusResponse;
import com.konsey.aiquizservice.dto.QuizGenRequest;
import com.konsey.aiquizservice.model.JobState;
import com.konsey.aiquizservice.model.enums.JobStatus;
import com.konsey.aiquizservice.service.GenerationService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/ai-quizzes")
public class AiQuizController {

    private final GenerationService generationService;

    // ---- MANUAL CONSTRUCTOR (Lombok yok) ----
    public AiQuizController(GenerationService generationService) {
        this.generationService = generationService;
    }

    @PostMapping
    public ResponseEntity<?> generate(@Valid @RequestBody QuizGenRequest req) {
        String jobId = generationService.enqueue(req);
        return ResponseEntity.accepted().body(
                java.util.Map.of(
                        "status", "queued",
                        "jobId", jobId
                )
        );
    }

    @GetMapping("/jobs/{jobId}")
    public ResponseEntity<JobStatusResponse> getJob(@PathVariable String jobId) {
        JobState js = generationService.getJob(jobId);

        JobStatusResponse.Preview preview = null;
        if (js.getContent() != null && js.getFormat() != null) {
            preview = new JobStatusResponse.Preview(js.getContent(), js.getFormat());
        }

        JobStatusResponse dto = new JobStatusResponse(
                js.getStatus(),
                js.getError(),
                preview,
                js.getMeta()
        );

        return new ResponseEntity<>(dto, HttpStatus.OK);
    }
}