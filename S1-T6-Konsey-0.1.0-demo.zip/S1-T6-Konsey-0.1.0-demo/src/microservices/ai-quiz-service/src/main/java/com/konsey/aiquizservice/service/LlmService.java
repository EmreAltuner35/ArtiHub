package com.konsey.aiquizservice.service;

import java.util.Map;

public interface LlmService {

    // Tek LlmResult tanımımız bu olsun
    record LlmResult(
            String content,
            String mime,
            Map<String, Object> meta
    ) {}

    LlmResult generate(String type, Map<String, Object> params, Integer seed);
}