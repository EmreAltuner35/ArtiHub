package com.konsey.aiquizservice.service;

import com.konsey.aiquizservice.dto.QuizGenRequest;
import com.konsey.aiquizservice.model.JobState;
import com.konsey.aiquizservice.model.enums.JobStatus;
import com.konsey.aiquizservice.repository.JobStateRepository;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Service
public class GenerationService {

    private final LlmService llmService;
    private final JobStateRepository jobStateRepository;

    // 🔥 MANUEL CONSTRUCTOR — sorun burada çözülüyor
    public GenerationService(LlmService llmService, JobStateRepository jobStateRepository) {
        this.llmService = llmService;
        this.jobStateRepository = jobStateRepository;
    }

    public String enqueue(QuizGenRequest req) {
        String jobId = "quiz_" + UUID.randomUUID()
                .toString()
                .replace("-", "")
                .substring(0, 12);

        JobState js = new JobState();
        js.setId(jobId);
        js.setStatus(JobStatus.QUEUED);
        js.setError(null);
        js.setContent(null);
        js.setFormat(null);
        js.setMeta(null);

        jobStateRepository.save(js);

        new Thread(() -> run(js, req)).start();

        return jobId;
    }

    private void run(JobState js, QuizGenRequest req) {
        try {
            Map<String, Object> params = new HashMap<>();
            params.put("topic", req.topic());
            params.put("difficulty", req.difficulty());
            params.put("questionCount", req.questionCount());
            if (req.language() != null && !req.language().isBlank()) {
                params.put("language", req.language());
            }

            LlmService.LlmResult result =
                    llmService.generate("quiz", params, req.seed());

            js.setStatus(JobStatus.SUCCEEDED);
            js.setContent(result.content());
            js.setFormat(result.mime());

            Map<String, Object> meta = new HashMap<>();
            meta.put("topic", req.topic());
            meta.put("difficulty", req.difficulty());
            meta.put("questionCount", req.questionCount());

            if (req.language() != null && !req.language().isBlank()) {
                meta.put("language", req.language());
            }

            if (result.meta() != null) {
                meta.putAll(result.meta());
            }

            js.setMeta(meta);

        } catch (Exception e) {
            js.setStatus(JobStatus.FAILED);
            js.setError(e.getMessage());
        }

        jobStateRepository.save(js);
    }

    public JobState getJob(String jobId) {
        return jobStateRepository.findById(jobId)
                .orElseThrow(() -> new IllegalArgumentException("Job not found: " + jobId));
    }
}