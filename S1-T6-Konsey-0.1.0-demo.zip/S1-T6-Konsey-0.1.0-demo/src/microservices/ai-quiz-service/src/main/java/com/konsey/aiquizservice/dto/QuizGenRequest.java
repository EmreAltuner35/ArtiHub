package com.konsey.aiquizservice.dto;

import com.fasterxml.jackson.annotation.JsonAlias;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record QuizGenRequest(
        @NotBlank String topic,

        // "easy" | "medium" | "hard" vs.
        @NotBlank String difficulty,

        // Hem "questionCount" hem "numQuestions" ismini destekle
        @NotNull
        @Min(1) @Max(50)
        @JsonAlias({"numQuestions", "questionCount"})
        Integer questionCount,

        // language opsiyonel olsun, null gelirse PromptBuilder zaten "en" default kullanıyor
        String language,

        @NotBlank String ownerId,
        String studyId,
        Integer seed
) {}