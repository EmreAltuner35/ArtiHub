package com.konsey.aiquizservice.service;

import com.konsey.aiquizservice.service.LlmService.LlmResult;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class OpenAiService implements LlmService {

    private final WebClient llmClient;

    @Value("${ai.provider.model}")
    private String model;

    @Value("${ai.provider.maxTokens:4096}")
    private Integer maxTokens;

    @Value("${ai.provider.temperature:0.2}")
    private Double temperature;

    // 🔥 Elle yazılmış constructor — Lombok yok
    public OpenAiService(WebClient llmClient) {
        this.llmClient = llmClient;
    }

    @Override
    public LlmResult generate(String type, Map<String, Object> params, Integer seed) {

        var prompt = PromptBuilder.build(type, params);

        Map<String, Object> body = new HashMap<>();
        body.put("model", model);
        body.put("messages", prompt.messages());
        body.put("max_tokens", maxTokens);
        body.put("temperature", temperature);
        if (seed != null) {
            body.put("seed", seed);
        }

        try {
            Map<String, Object> resp = llmClient.post()
                    .uri("/v1/chat/completions")
                    .bodyValue(body)
                    .retrieve()
                    .onStatus(HttpStatusCode::isError, r -> r.bodyToMono(String.class)
                            .map(b -> new RuntimeException(
                                    "LLM error " + r.statusCode() + ": " + b)))
                    .bodyToMono(Map.class)
                    .block();

            @SuppressWarnings("unchecked")
            List<Map<String, Object>> choices = (List<Map<String, Object>>) resp.get("choices");
            @SuppressWarnings("unchecked")
            Map<String, Object> message = (Map<String, Object>) choices.get(0).get("message");
            String text = String.valueOf(message.get("content"));

            Map<String, Object> meta = Map.of(
                    "provider", "huggingface-router",
                    "model", model);

            return new LlmResult(text, prompt.mime(), meta);

        } catch (WebClientResponseException e) {
            System.err.println("LLM HTTP error: " + e.getStatusCode() + " " + e.getResponseBodyAsString());
            throw e;
        }
    }
}