package com.konsey.aiquizservice.model.enums;

public enum JobStatus {
    QUEUED,
    RUNNING,
    SUCCEEDED,
    FAILED
}