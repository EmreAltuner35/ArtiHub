package com.konsey.aiquizservice.repository;

import com.konsey.aiquizservice.model.JobState;
import org.springframework.data.repository.CrudRepository;

public interface JobStateRepository extends CrudRepository<JobState, String> {
}