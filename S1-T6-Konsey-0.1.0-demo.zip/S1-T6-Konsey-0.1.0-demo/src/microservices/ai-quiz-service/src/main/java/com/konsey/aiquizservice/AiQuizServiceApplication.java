package com.konsey.aiquizservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AiQuizServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(AiQuizServiceApplication.class, args);
    }
}