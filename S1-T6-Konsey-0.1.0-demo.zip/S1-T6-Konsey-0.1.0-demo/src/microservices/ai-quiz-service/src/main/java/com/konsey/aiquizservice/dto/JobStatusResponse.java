package com.konsey.aiquizservice.dto;

import com.konsey.aiquizservice.model.enums.JobStatus;

import java.util.Map;

public record JobStatusResponse(
        JobStatus status,
        String error,
        Preview preview,
        Map<String, Object> meta
) {
    public record Preview(
            String content,
            String format
    ) {}
}