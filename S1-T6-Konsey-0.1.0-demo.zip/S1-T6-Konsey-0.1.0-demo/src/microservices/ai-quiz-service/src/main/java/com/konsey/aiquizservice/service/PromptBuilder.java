package com.konsey.aiquizservice.service;

import java.util.List;
import java.util.Map;

public class PromptBuilder {

  public record PromptPayload(List<Map<String, Object>> messages, String mime) {
  }

  public static PromptPayload build(String type, Map<String, Object> params) {
    if (!"quiz".equalsIgnoreCase(type)) {
      throw new IllegalArgumentException("Unsupported type: " + type);
    }

    String topic = String.valueOf(params.getOrDefault("topic", "software engineering"));
    String difficulty = String.valueOf(params.getOrDefault("difficulty", "medium"));
    Integer questionCount = (Integer) params.getOrDefault("questionCount", 5);
    String language = String.valueOf(params.getOrDefault("language", "en"));
    String studyId = params.get("studyId") != null ? String.valueOf(params.get("studyId")) : null;

    String systemContent = """
        You are an assistant that generates JSON for quizzes.
        Output MUST be valid JSON ONLY, no markdown, no explanations.
        The JSON schema is:

        {
          "title": string,
          "description": string,
          "studyId": string or null,
          "status": "DRAFT",
          "questions": [
            {
              "questionText": string,
              "questionOrder": integer (1-based),
              "answers": [
                {
                  "answerText": string,
                  "isCorrect": boolean,
                  "answerOrder": integer (1-based)
                },
                ...
              ]
            },
            ...
          ]
        }

        Rules:
        - All text (title, description, questionText, answerText) must be in LANGUAGE.
        - Exactly N questions.
        - Each question must have 4 answer options.
        - Exactly ONE answer per question must have "isCorrect": true, the others false.
        - Use consecutive order values starting from 1 for questions and answers.
        """.replace("LANGUAGE", language);

    String userContent = String.format("""
        Create a quiz in JSON format.
        Topic: %s
        Difficulty: %s
        Number of questions (N): %d
        studyId: %s

        Remember:
        - Respond ONLY with the JSON object.
        - Do not include any backticks or markdown.
        """,
        topic,
        difficulty,
        questionCount,
        studyId == null ? "null" : ("\"" + studyId + "\""));

    Map<String, Object> systemMsg = Map.of(
        "role", "system",
        "content", systemContent);

    Map<String, Object> userMsg = Map.of(
        "role", "user",
        "content", userContent);

    return new PromptPayload(
        List.of(systemMsg, userMsg),
        "application/json");
  }
}