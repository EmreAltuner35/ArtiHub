package com.konsey.aiquizservice.config;

import com.konsey.aiquizservice.model.JobState;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;
import org.springframework.data.redis.core.RedisKeyValueAdapter;
import org.springframework.data.redis.core.RedisKeyValueTemplate;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.mapping.RedisMappingContext;
import org.springframework.data.redis.repository.configuration.EnableRedisRepositories;
import org.springframework.data.redis.serializer.GenericJackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;

@Configuration
@EnableRedisRepositories(basePackages = "com.konsey.aiquizservice.repository")
public class RedisConfig {

    // Host ve port'u direkt env'den oku: REDIS_HOST, REDIS_PORT
    @Bean
    public RedisConnectionFactory redisConnectionFactory(
            @Value("${REDIS_HOST:redis}") String host,
            @Value("${REDIS_PORT:6379}") int port
    ) {
        return new LettuceConnectionFactory(host, port);
    }

    @Bean
    public RedisTemplate<String, JobState> redisTemplate(RedisConnectionFactory connectionFactory) {
        RedisTemplate<String, JobState> template = new RedisTemplate<>();

        template.setConnectionFactory(connectionFactory);

        template.setKeySerializer(new StringRedisSerializer());
        template.setHashKeySerializer(new StringRedisSerializer());

        template.setValueSerializer(new GenericJackson2JsonRedisSerializer());
        template.setHashValueSerializer(new GenericJackson2JsonRedisSerializer());

        template.afterPropertiesSet();
        return template;
    }

    @Bean
    public RedisKeyValueTemplate redisKeyValueTemplate(RedisTemplate<String, JobState> redisTemplate) {
        RedisKeyValueAdapter adapter = new RedisKeyValueAdapter(redisTemplate);
        RedisMappingContext mappingContext = new RedisMappingContext();
        return new RedisKeyValueTemplate(adapter, mappingContext);
    }
}