# Naming Conventions

## 1. Services (folders, docker, compose)
- Use kebab-case.
- Suffix with `-service` for microservices.
- Examples:
  - `user-service`
  - `artifact-service`

## 2. Java packages
- No dashes.
- All lowercase.
- Prefer `com.konsey.<domain>[.<layer>]`.
- Examples:
  - `com.konsey.userservice`
  - `com.konsey.artifactservice.controller`

## 3. API routes
- Base path should match the service domain.
- Examples:
  - `user-service` → `/api/users/...`
  - `artifact-service` → `/api/artifacts/...`

## 4. Repo hygiene
- Do not commit IDE-specific folders.
- Add to `.gitignore`:
  - `.idea/`
  - `.vscode/`
- If accidentally committed:
  ```bash
  git rm -r --cached .idea .vscode
  git commit -m "Remove IDE folders from repo"

## 5. Branches
- Use kebab-case.
- Prefix with `branch-type` + `/`
- Examples:
  - `feature/artifact-upload`
  - `fix/service-naming-and-cleanup`
