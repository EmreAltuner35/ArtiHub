---
name: User Story template
about: Creating a user story.
title: ''
labels: ''
assignees: ''

---

## *Acceptance Criteria*

- [ ] Acceptance 1
- [ ] Acceptance 2

## *Development Tasks*

- [ ] Development 1
- [ ] Development 2
